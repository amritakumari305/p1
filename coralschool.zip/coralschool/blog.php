<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <!-- <div class="default_tabs">
                            <nav>
                                <div class="nav nav-tabs tab_default  justify-content-center">
                                    <a class="nav-item nav-link active" href="about_us.html">About</a>
                                    <a class="nav-item nav-link" href="our_blog.html">Blog</a>
                                    <a class="nav-item nav-link" href="career.html">Careers</a>
                                    <a class="nav-item nav-link" href="press.html">Press</a>
                                </div>
                            </nav>
                        </div> -->
                        <div class="title129">
                            <h2>Blog</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="blog-gambo" style="background: url(images/course-shape.png)100% center / cover no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt text-center">
                            <div class="main-title-left">
                                <span>From the News</span>
                                <h2>Latest Blog </h2>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="blog-item">
                            <a href="blog_single.php" class="blog-img">
                                <img src="images/blog/blog1.jpg" alt="">
                                
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">09 March, 2021</div>
                                
                            </div>
                            <div class="blog-detail">
                                <h4>Shutdown of schools extended to Aug 31</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. </p>
                                <a href="blog_single.php">Read More <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                        
                        
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="blog-item">
                            <a href="blog_single.php" class="blog-img">
                                <img src="images/blog/blog1.jpg" alt="">
                                
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">09 March, 2021</div>
                                
                            </div>
                            <div class="blog-detail">
                                <h4>Shutdown of schools extended to Aug 31</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. </p>
                                <a href="blog_single.php">Read More <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                        
                        
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="blog-item">
                            <a href="blog_single.php" class="blog-img">
                                <img src="images/blog/blog1.jpg" alt="">
                               
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">09 March, 2021</div>
                                
                            </div>
                            <div class="blog-detail">
                                <h4>Shutdown of schools extended to Aug 31</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. </p>
                                <a href="blog_single.php">Read More <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>

</div>        


<?php 
include("footer.php");
?>