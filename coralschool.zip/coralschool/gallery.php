<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="title129">
                            <h2>Gallery</h2>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    

    <div class="section147 pt-5" style="background: url(images/course-shape.png)100% center / cover no-repeat;">
            <div class="container">
                <div class="row image-container">
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="tile" style="background-image: url('images/bg1.jpg');">
                                <div class="image-title"><h1>Image Title</h1>
                                Content text goes here. Placeholder.
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="tile" style="background-image: url('images/bg1.jpg');">
                                <div class="image-title"><h1>Image Title</h1>
                                Content text goes here. Placeholder.
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="tile" style="background-image: url('images/bg1.jpg');">
                                <div class="image-title"><h1>Image Title</h1>
                                Content text goes here. Placeholder.
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="tile" style="background-image: url('images/bg1.jpg');">
                                <div class="image-title"><h1>Image Title</h1>
                                Content text goes here. Placeholder.
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="tile" style="background-image: url('images/bg1.jpg');">
                                <div class="image-title"><h1>Image Title</h1>
                                Content text goes here. Placeholder.
                                </div>
                            </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="tile" style="background-image: url('images/bg1.jpg');">
                                <div class="image-title"><h1>Image Title</h1>
                                Content text goes here. Placeholder.
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
</div>        

<?php 
include("footer.php");
?>