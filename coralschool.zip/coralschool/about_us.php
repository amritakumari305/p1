<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                       
                        <div class="title129">
                            <h2>About Us</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section147 py-5" >
            <div class="container" >
                <div class="row" >
                    <div class="col-md-6 col-sm-6 col-12">
                        <div class="img-part js-tilt" style="will-change: transform; transform: perspective(300px) rotateX(0deg) rotateY(0deg);">
                            <img src="images/about/about1.png" alt="images" style="max-width: 100%;height: auto;">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-12">
                        <div class="contents pl-5">
                            <div class="sub-title mb-20"> About Us</div>
                            <h2 class="sl-title mb-40 md-mb-20">We are leading discovery and innovation since 1905</h2>
                            <p class="desc mb-50">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem sum dolor sit amet.
                            </p>
                            <p class="desc mb-50">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem sum dolor sit amet.
                            </p>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4 col-sm-6 col-12">
                        <div class="why-us" >
                            <span class="section-subtitle-txt">01</span>
                            <h2 class="section-title-txt">Why Choose us</h2>
                            <p class="section-subtitle-txts">Lorem ipsum gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit sollicitudirem quibibendum auci</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-12">
                        <div class="why-us" >
                            <span class="section-subtitle-txt">02</span>
                            <h2 class="section-title-txt">Our Mission</h2>
                            <p class="section-subtitle-txts">Lorem ipsum gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit sollicitudirem quibibendum auci</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 col-12">
                        <div class="why-us" >
                            <span class="section-subtitle-txt">03</span>
                            <h2 class="section-title-txt">Our Vision</h2>
                            <p class="section-subtitle-txts">Lorem ipsum gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit sollicitudirem quibibendum auci</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="about-steps-group white-bg pb-5">
            <div class="container">
                <div class="row elementor-row">
                    <div class="col-lg-3  col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #F14D5D;">400+</span></h4>
                            <p>Courses & videos</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #EE8C1C;">400+</span></h4>
                            <p>Expert teachers</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #55BC7E;">400+</span></h4>
                            <p>Total students</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #0056D2;">400+</span></h4>
                            <p>Batches Passout</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section147 py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-6 col-12">
                        <div class="text-center">
                            <img src="images/mahatma_gandhi_PNG23.png" alt="images">
                           
                        </div>
                        <div class="title-cher-person text-center pt-5">
                        <h3>Title Here</h3>
                            <p style="color:#F2184F">Post Title Here</p>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-6 col-12">
                        <div class="contents pl-5">
                            
                            <h2 class="sl-title mb-40 md-mb-20">We are leading discovery and innovation since 1905</h2>
                            <p class="desc mb-50">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem sum dolor sit amet.
                            </p>
                            <p class="desc mb-50">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem sum dolor sit amet.
                            </p>
                            
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
</div>        


<?php 
include("footer.php");
?>