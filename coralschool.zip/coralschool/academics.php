<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="title129">
                            <h2>Academics</h2>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <div class="section147 py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-12">
                        <div class="img-infra">
                            <img src="images/Lab1.jpg" alt="images" style="width: 100%;height: auto;">
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-12">
                        <div class="why-us">
                           
                            <h2 class="section-title-txt">ACADEMIC PROGRAMMES</h2>
                            <div id="yellowpatch" class="font_resize"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem sum dolor sit amet.</div>
                        </div>
                    </div>
                    
                </div>
                <div class="row pt-5">
                    <div class="col-md-4">
                       
                        <a href="gallery.php">
                            <div class="academic-chart-section4">
                                <h3>Kindergarten Programme</h3>
                                <!-- <p>Integrated Curriculum</p> -->
                                <p class="ital">LKG &amp; UKG</p>
                            </div>
                        </a>  
                       
                    </div>
                    <div class="col-md-4">
                       
                        <a href="gallery.php">
                            <div class="academic-chart-section4">
                                <h3>Primary School Programme</h3>
                                <!-- <p>Integrated Curriculum</p> -->
                                <p class="ital">Classes I to IV</p>
                            </div>
                        </a>  
                       
                    </div>
                    <div class="col-md-4">
                       
                        <a href="gallery.php">
                            <div class="academic-chart-section4">
                                <h3>Middle School Programme</h3>
                                <!-- <p>Integrated Curriculum</p> -->
                                <p class="ital">Classes V to VII</p>
                            </div>
                        </a>  
                       
                    </div>
                    <div class="col-md-6">
                       
                        <a href="gallery.php">
                            <div class="academic-chart-section4">
                                <h3>High School Programme</h3>
                                <!-- <p>Integrated Curriculum</p> -->
                                <p class="ital">IX &amp; X</p>
                            </div>
                        </a>  
                       
                    </div>
                    <div class="col-md-6">
                       
                        <a href="gallery.php">
                            <div class="academic-chart-section4">
                                <h3>Senior School Programme</h3>
                                <!-- <p>Integrated Curriculum</p> -->
                                <p class="ital">XI &amp; XII</p>
                            </div>
                        </a>  
                       
                    </div>
                    
                </div>


               
            </div>
    </div>

       
</div>        


<?php 
include("footer.php");
?>