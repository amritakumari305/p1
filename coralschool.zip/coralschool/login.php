<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="title129">
                            <!-- <h2>Login </h2> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sign-inup">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="sign-form">
                        <div class="sign-inner">
                           
                            <div class="form-dt">
                                <div class="form-inpts checout-address-step">
                                    <form method="POST" action="">
                                        <div class="form-title">
                                            <h6>Login Here</h6>
                                        </div>
                                        
                                        <div class="form-group pos_rel">
                                            <input id="email_id" name="email_id" type="text" placeholder="Email Address" class="form-control lgn_input" required="">
                                            
                                        </div>
                                        
                                       
                                        <div class="form-group pos_rel">
                                            <input id="password" name="password" type="password" placeholder="New Password" class="form-control lgn_input" required="">
                                           
                                        </div>
                                        <center><button class="login-btn hover-btn" type="submit" name="submit" value="Submit">Register Now</button></center>
                                    </form>
                                </div>
                                <div class="signup-link">
                                    <p>I don't have an account? - <a href="login.php">Register Now</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
</div>   

</div>        


<?php 
include("footer.php");
?>