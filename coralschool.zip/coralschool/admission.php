<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="title129">
                            <h2>Admission</h2>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    

    <div class="all-product-grid">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="default-title mt-4">
                            <h1 class="bluebigtitle" style="text-align: center; font-weight: bold;">Admissions for academic year 2021-22</h1>
                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="panel-group accordion pt-1" id="accordion0">
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingOne">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseOne" href="#" aria-expanded="false" aria-controls="collapseOne">
                                        Instructions for filling in online 'Application for Admission' form
                                    </a>
                                    </div>
                                </div>
                                <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion0" style="">
                                    <div class="panel-body">
                                        <h3>Please read the instructions carefully before completing the online 'Application for Admission' form..</h3>
                                        <ul class="disclist">

                                            <li>Please complete the online 'Application for Admission' form using the registered Login ID.</li>
                                            <li>If the application has to be made for more than one child, please complete the online 'Application for Admission' form using the same Login ID.</li>
                                            <li>While the 'Application for Admission' form can be completed using a mobile phone, it is advisable to use a desktop computer or laptop.</li>
                                            <li>Please complete the online 'Application for Admission' form using the latest versions of Google Chrome, Mozilla Firefox, or Internet Explorer (IE10 or above).</li>
                                            <li>In Class VIII, each applicant can apply ONLY for one stream, that is, either ICSE or IGCSE. Please note that no change of stream will be permitted after submission of the online 'Application for Admission' form.</li>

					
						                </ul>
                                        <table cellpadding="0" cellspacing="0" width="100%" style="vertical-align: top;" class="adm-info">
						<tbody><tr class="">
							<td width="22%"><strong>User Registration </strong> </td>
							<td width="78%">
								<p class="admtxt"><strong>Your 'Email ID' is your 'Login ID'</strong></p>
								
								<p class="admtxt">All communications from the School concerning admissions will be sent ONLY to the registered '<strong>Mobile Number</strong>' (mobile number issued in India) and '<strong>Email ID</strong>' used at the time of submission of the online 'Application for Admission' form.  </p>
								
								<p class="admtxt">All emails from the School will be sent from  <a href="mailto:onlineadmissions@coral.edu.in" target="_blank">onlineadmissions@coral.edu.in</a> or <a href="mailto:admissions@coral.edu.in" target="_blank">admissions@coral.edu.in</a></p>
                              
								<p class="admtxt">All text messages/SMS from the School will be sent from <strong>'CORAL'.</strong> </p>

								<p class="admtxt">If you do not find the emails from coral in your inbox, please check your junk/spam e-mail folder. If the emails from coral appear in the junk/spam folder, select the email and click 'Not Junk/Spam', which will allow future emails to reach directly to your inbox.</p>
							</td>
						</tr>

						<tr class="">
							<td><strong>Eligibility</strong></td>
							<td><p class="admtxt">Before completing the online 'Application for Admission' form, make sure that you have checked the eligibility criteria for the class to which admission is sought and that the child meets the eligibility criteria. </p></td>
						</tr>

						<tr class="">
							<td><strong>Name of the Student</strong></td>
							<td>
								<p class="admtxt">Ensure that the student's name entered on the online 'Application for Admission' form matches the name mentioned in his/her birth certificate. If the student does not have a 'Middle Name’, the field may be left blank.</p>
							</td>
						</tr>

						<tr class="">
							<td> <strong>Photograph</strong></td>
							<td>
								<p class="admtxt">	
								The photograph of the student should be a recent colour passport photograph (Size: 5.5 cm x 4.5 cm) on white, red, or blue background. </p>
								<p class="admtxt">
								The photograph should capture the full face, front view with eyes open. The head should be in the centre of the frame.</p>
								
								<p class="admtxt">The file size should not exceed 5 MB. Only PNG, JPG, or JPEG format files can be uploaded.</p>
							</td>
						</tr>

						<tr class="">
							<td> <strong>Documents to be uploaded  </strong></td>
							<td>
								<table>
									<tbody><tr>
										<td width="15%"><strong>LKG</strong></td>
										<td>
											<p class="admtxt">a.	Self-attested copy of the child's birth certificate.</p>

											<p class="admtxt">b.	Self-attested copy of school reports, if available.</p>


										</td>
									</tr>

									<tr>
										<td><strong>Class VIII</strong></td>
										<td>
											<p class="admtxt">a.	Self-attested copy of the child's birth certificate.<br>

                                                b.	Self-attested copies of school reports of the last three years and the current year (2020-21).<br>

                                                c.	Personal Statement in a maximum of 500 words (to be written by the student and uploaded)<br>

                                                <em>"Write briefly your areas of interests and achievements, and state how studying at coral would help you achieve your goals and aspirations."</em><br>

                                                d.	Self-attested documents of academic, co-curricular, and sports achievements, if any, may be uploaded on the ‘Additional Information’ page under the relevant section.</p>


										</td>
									</tr>

									<tr>
										<td><strong>IBDP Class XI</strong></td>
										<td>
											<p class="admtxt">a.	Self-attested copy of the child's birth certificate.<br>

                                                        b.	Self-attested copies of school reports of the last three years and the current year (2020-21).<br>

                                                        c.	Personal Statement in a maximum of  500 words (to be written by the student and uploaded)<br>

                                                        <em>"Provide an overview of your interests in academics and co-curricular activities as well as your achievements, and state how studying at coral would help you achieve your goals and aspirations while contributing to school life and the broader community"</em><br>

                                                        d.	Self-attested copy of certificate/report card/document evidencing successful completion of Class X. <br>

                                                        e.	Self-attested documents of academic, co-curricular, and sports achievements, if any, may be uploaded on the ‘Additional Information’ page under the relevant section.</p>


										</td>
									</tr>
								</tbody></table>
							</td>
						</tr>

						<tr class="">
							<td><strong>File Size of Documents  </strong></td>
							<td>
								<p class="admtxt">Make sure that the size of each file to be uploaded does not exceed 5 MB. Documents should be uploaded ONLY in PDF, JPG, or JPEG formats. Every page of the document must be self-attested by any one parent or guardian. In the 'Additional Information' page of the 'Application for Admission' form, with respect to Class VIII and IBDP (Class XI), DOC files can be uploaded.</p>
							</td>
						</tr>

						<tr class="">
							<td><strong>Registration Charges</strong></td>
								<td><p class="admtxt">A non-refundable ‘Registration Charge’ of ₹5000 is payable online for the submission of the 'Application for Admission' form. Additionally, convenience charges will be charged by the Payment Gateway as applicable for the selected mode of payment. If any error/time-out occurs while making the online payment of ‘Registration Charge’, parents/guardian should immediately inform the coral Admissions Office, so that further guidance can be provided.</p></td>
						</tr>

						<tr class="">
							<td><strong>Parents'/Guardian's Declaration </strong></td>
							<td><p class="admtxt">Before the submission of the 'Application for Admission' form, make sure you have read and understood the Parents'/Guardian's 'Declaration' and 'Accept' the same.</p></td>
						</tr>

						<tr class="">
							<td> <strong>Parents'/Guardian's Signature </strong></td>
							<td>
								 <p class="admtxt">At the time of online submission of the 'Application for Admission' form, ticking the checkbox in the Parents'/Guardian’s Declaration section will be sufficient. Parents/Guardian are not required to e-sign the 'Application for Admission' form. Signatures of Parents/Guardian will be taken at a later stage.</p>
							</td>
						</tr>

						<tr class="">
							<td> <strong>Printing the 'Application for Admission' Form </strong></td>
							<td>
								<p class="admtxt">•	Select ‘Printing Options’ in the ‘Print’ dialogue window<br>

                                            •	Set Layout to 'Portrait'<br>

                                            •	Set Paper Size to 'A4<br>

                                            •	Set Margins to 'None'<br>

                                            •	Click 'Print' to / save / print the ‘Application for Admission’ form<br></p>


							</td>
						</tr>




					  </tbody></table>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingTwo">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseTwo" href="#" aria-expanded="false" aria-controls="collapseTwo">
                                        Admissions Information - Admissions to LKG, Class VIII and Class XI
                                                </a>
                                    </div>
                                </div>
                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordion0">
                                    <div class="panel-body">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam semper faucibus erat a efficitur. Praesent vulputate mauris eget augue semper, at eleifend enim aliquam. Vivamus suscipit lacinia neque eget suscipit.
                                            Morbi vitae nisl ac justo placerat vulputate ac quis lectus. Vestibulum pellentesque, orci eu ultrices molestie, nisi libero hendrerit eros, vel interdum augue tortor vel urna. Nullam enim dolor, pulvinar in
                                            metus vitae, tincidunt dignissim neque. Pellentesque tempor nulla eu neque hendrerit fringilla. Suspendisse ultricies venenatis maximus. Suspendisse erat elit, ultricies eu porta nec, luctus sit amet dui. Fusce
                                            feugiat odio semper, hendrerit lectus vitae, convallis nisl. Ut a justo diam. Donec vitae leo lorem. Cras pharetra libero ut urna condimentum, non imperdiet leo posuere.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingThree">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseThree" href="#" aria-expanded="false" aria-controls="collapseThree">
                                        Eligibility Criteria for LKG, Class VIII  Class XI
                                                </a>
                                    </div>
                                </div>
                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordion0">
                                    <div class="panel-body">
                                    <table class="adm-info" cellpadding="0" cellspacing="0" width="100%">
                               	<tbody>
									<tr>
										<td width="30%"><strong>LKG</strong></td>
										<td>A child born between October 1, 2016 and December 31, 2017 (both days inclusive).
                              			</td>
									</tr>
                              		<tr>
										<td><strong>Class VIII (ICSE / IGCSE)</strong></td>
										<td> The student must have successfully completed Class VII and should have been promoted to Class VIII from a recognized school, before joining Coral  School.
										</td>
									</tr>

                              		<tr>
										<td><strong>Class XI (IB Diploma Programme)</strong></td>
										<td>The student must have successfully completed the Class X from a recognized secondary education board before joining Coral  School.</td>
									</tr>

                              </tbody>
                               </table>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>   
        <div class="container pt-5">
            <div class="row">
                <div class="col-md-12">
                     <a href="login.php" target="_blank"><img src="images/schoolform.png" width="100%"></a>
                </div>
            </div>
        </div>
</div>        


<?php 
include("footer.php");
?>