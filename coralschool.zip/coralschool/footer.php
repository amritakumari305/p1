
    <footer class="footer">
        
        <div class="footer-second-row">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="second-row-item">
                            <h4>Latest News</h4>
                            <ul>
                                <li>
                                    <a href="#" >We are at Independent Schools Show</a>
                                    <p class="post-date"><i class="uil uil-calendar-alt"></i> March 10, 2021</p>
                                </li>
                                <li>
                                    <a href="#" >We are at Independent Schools Show</a>
                                    <p class="post-date"><i class="uil uil-calendar-alt"></i> March 10, 2021</p>
                                </li>
                                <li>
                                    <a href="#" >We are at Independent Schools Show</a>
                                    <p class="post-date"><i class="uil uil-calendar-alt"></i> March 10, 2021</p>
                                </li>
                                <li>
                                    <a href="#" >We are at Independent Schools Show</a>
                                    <p class="post-date"><i class="uil uil-calendar-alt"></i> March 10, 2021</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-6">
                        <div class="second-row-item">
                            <h4>Useful Links</h4>
                            <ul>
                                <li><a href="about_us.php">About US</a></li>
                                <li><a href="contact_us.php">Contact Us</a></li>
                                <li><a href="blog.php">Blog</a></li>
                               
                                <li><a href="academics.php">Academics</a></li>
                                <li><a href="campus.php">Campus</a></li>
                                <li><a href="teachers.php">Teachers</a></li>
                                <li><a href="features.php">Features</a></li>
                                <li><a href="gallery.php">Gallery</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-6">
                        <div class="second-row-item">
                            <h4>Branches</h4>
                            <ul>
                                <li><a href="#">Jaipur</a></li>
                                <li><a href="#">New Delhi</a></li>
                                <li><a href="#">Bangaluru</a></li>
                                <li><a href="#">Mumbai</a></li>
                                <li><a href="#">Hyderabad</a></li>
                                <li><a href="#">Kolkata</a></li>
                                <li><a href="#">Ludhiana</a></li>
                                <li><a href="#">Chandigrah</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="second-row-item-app">
                            <a href="#"><img src="images/LOGOS.png" alt=""></a>
                        </div>
                        
                        <div class="second-row-item-payment">
                            <h4>School Address :</h4>
                            <div class="newsletter-input pb-3">
                            <i class="uil uil-location-point"></i> <a href="#" class="text-white">28A, Jaipur, Rajasthan, India 302019</a>
                            </div>
                            <div class="newsletter-input pb-3"><i class="uil uil-dialpad-alt"></i> <a href="#" class="text-white">+91-9521132592</a></div>
                            <div class="newsletter-input pb-3"><i class="uil uil-envelope-alt"></i> <a href="#" class="text-white">coralitsolutions2018@gmail.com</a></div>
                        </div>
                        <div class="second-row-item-payments">
                           
                            <div class="footer-payments">
                                <ul id="paypal-gateway" class="financial-institutes">
                                    <li class="financial-institutes__logo">
                                        <img alt="Visa" title="Visa" src="images/socialicon/facebook.png">
                                    </li>
                                    <li class="financial-institutes__logo">
                                        <img alt="Visa" title="Visa" src="images/socialicon/instagram.png">
                                    </li>
                                    <li class="financial-institutes__logo">
                                        <img alt="MasterCard" title="MasterCard" src="images/socialicon/linkedin.png">
                                    </li>
                                    <li class="financial-institutes__logo">
                                        <img alt="American Express" title="American Express" src="images/socialicon/youtube.png">
                                    </li>
                                    <li class="financial-institutes__logo">
                                        <img alt="Discover" title="Discover" src="images/socialicon/twitter.png">
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-last-row" >
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        
                        <div class="copyright-text">
                            <a href="https://coralitsolution.com/">&copy; 2021 <b>Coral School</b> . All rights reserved | Designed & Developed By : <img src="images/coral-logo.png" alt="" width="120"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


   
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/OwlCarousel/owl.carousel.js"></script>
    <script src="vendor/semantic/semantic.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/custom.js"></script>
    <script src="js/offset_overlay.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.3.5/jquery.fancybox.min.js"></script>
</body>

</html>