<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="title129">
                            <h2>Campus</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section147 py-5">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-12">
                        <div class="img-infra">
                            <img src="images/schoolinfra.jpg" alt="images" style="max-width: 100%;height: auto;">
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-12">
                        <div class="why-us">
                           
                            <h2 class="section-title-txt">Campus</h2>
                            <div id="yellowpatch" class="font_resize"> Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem sum dolor sit amet.</div>
                        </div>
                    </div>
                    
                </div>
                <div class="row pt-5">
                    <div class="col-md-6">
                        <div id="commoncontentleftwrap" class="font_resize">
                            <p style="color: #202c45;font-size:16px"><strong>Infrastructure and Facilities</strong></p><br>
                            <ul class="mainbullet2">
                                <li>Unique open school design</li>
                                <li>Well-equipped, IT-enabled classrooms with multimedia projectors </li>
                                <li>State-of-the-art Computer, Physics, Chemistry, Biology and Mathematics laboratories</li>
                                <li>Multipurpose Auditorium </li>
                                <li>A modern Centre for Performing Arts</li>
                                <li>Special Activity rooms for Art, Music (Western &amp; Indian), Dance, Drama and Yoga </li>
                                <li>Purpose-built play areas for pre-primary and primary</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div id="commoncontentleftwrap" class="font_resize">
                           
                            <ul class="mainbullet2">
                                <li>Unique open school design</li>
                                <li>Well-equipped, IT-enabled classrooms with multimedia projectors </li>
                                <li>State-of-the-art Computer, Physics, Chemistry, Biology and Mathematics laboratories</li>
                                <li>Multipurpose Auditorium </li>
                                <li>A modern Centre for Performing Arts</li>
                                <li>Special Activity rooms for Art, Music (Western &amp; Indian), Dance, Drama and Yoga </li>
                                <li>Purpose-built play areas for pre-primary and primary</li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="row pt-4">
                    <div class="col-md-4">
                        <div class="mb-3">
                           <img src="images/schoolinfra.jpg" alt="images" width="100%">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                           <img src="images/schoolinfra.jpg" alt="images" width="100%">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                           <img src="images/schoolinfra.jpg" alt="images" width="100%">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                           <img src="images/schoolinfra.jpg" alt="images" width="100%">
                        </div>
                    </div>

                </div>
            </div>
        </div>

       
</div>        


<?php 
include("footer.php");
?>