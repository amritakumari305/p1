<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <!-- <div class="default_tabs">
                            <nav>
                                <div class="nav nav-tabs tab_default  justify-content-center">
                                    <a class="nav-item nav-link active" href="about_us.html">About</a>
                                    <a class="nav-item nav-link" href="our_blog.html">Blog</a>
                                    <a class="nav-item nav-link" href="career.html">Careers</a>
                                    <a class="nav-item nav-link" href="press.html">Press</a>
                                </div>
                            </nav>
                        </div> -->
                        <div class="title129">
                            <h2>Blog Single</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="blog-gambo" style="background: url(images/course-shape.png)100% center / cover no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-7">
                        <div class="blog-item">
                            <a href="blog_single.php" class="blog-img">
                                <img src="images/blog/blog1.jpg" alt="">
                                
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">09 March, 2021</div>
                                
                            </div>
                            <div class="blog-detail">
                                <h4>Shutdown of schools extended to Aug 31</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate.</p>
                               
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-5">
                        <div class="pdpt-bg-left mt-0">
                            <div class="blog-search-widget">
                                <div class="form-group blog-from mb-0">
                                    <input name="search" type="text" placeholder="Search here..." class="form-control input-md">
                                    <button type="submit" class="blog-search-btn">
                                        <i class="uil uil-search"></i>
                                        </button>
                                </div>
                            </div>
                        </div>
                        <div class="pdpt-bg-left mt-30">
                            <div class="pdpt-title">
                                <h4>Categories</h4>
                            </div>
                            <ul class="top-posts pl-2 pr-2">
                                <li>
                                    <div class="blog-top-item">
                                        <a href="#" class="post-cate-link mb-0">School & Life Style</a>
                                        <span class="cate-count">1</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="#" class="post-cate-link mb-0">Sports</a>
                                        <span class="cate-count">1</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="#" class="post-cate-link mb-0">Uncategories</a>
                                        <span class="cate-count">2</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="pdpt-bg-left">
                            <div class="pdpt-title">
                                <h4>Recent Posts</h4>
                            </div>
                            <ul class="top-posts">
                                <li class="media-list">
                                    <div class="blog-top-item media">
                                        <div class="media-left">
                                            <img class="ft-plus-square icon-bg-circle bg-cyan mr-0" src="images/blog/blog1.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <a href="blog_detail_view.html" class="top-post-link">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a>
                                            <span class="blog-time">8 May, 2020</span>
                                        </div>
                                    </div>
                                </li>
                                <li class="media-list">
                                    <div class="blog-top-item media">
                                        <div class="media-left">
                                            <img class="ft-plus-square icon-bg-circle bg-cyan mr-0" src="images/blog/blog1.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <a href="blog_detail_view.html" class="top-post-link">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a>
                                            <span class="blog-time">7 May, 2020</span>
                                        </div>
                                    </div>
                                </li>
                                <li class="media-list">
                                    <div class="blog-top-item media">
                                        <div class="media-left">
                                            <img class="ft-plus-square icon-bg-circle bg-cyan mr-0" src="images/blog/blog1.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <a href="blog_detail_view.html" class="top-post-link">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a>
                                            <span class="blog-time">6 May, 2020</span>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="pdpt-bg-left mb-30">
                            <div class="pdpt-title">
                                <h4>Tags</h4>
                            </div>
                            <div class="cntct-social">
                                <div class="team-social tagcloud">
                                    <a href="#" class="tag-cloud-link tag-link-position-1 hover-btn">School</a>
                                    <a href="#" class="tag-cloud-link tag-link-position-1 hover-btn">Science</a>
                                    <a href="#" class="tag-cloud-link tag-link-position-1 hover-btn">History</a>
                                    <a href="#" class="tag-cloud-link tag-link-position-1 hover-btn">Education</a>
                                    <a href="#" class="tag-cloud-link tag-link-position-1 hover-btn">Sports</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>        


<?php 
include("footer.php");
?>