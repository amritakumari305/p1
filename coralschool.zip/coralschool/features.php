<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        
                        <div class="title129">
                            <h2>Gallery</h2>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    

    <div class="section145" style="background-color: #ffffff !important;">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-6 col-md-6">
                        <div class="best-offer-item active">
                            <h3 class="elementskit-section-subtitle ">Find your Pathway</h3>
                            <h2 class="offer-counter-text ">
                                Our School Best  <span><span> Services</span></span>
                            </h2>
                            <div class="heading__description">
                                <p>Get new experience your<br>subject at Courselog as you learn.</p>
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon  ">
                                        <img src="images/avatar/online-class.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Online Classes </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon  ">
                                        <img src="images/avatar/presentation.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Indoor Classes </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon  ">
                                        <img src="images/avatar/library.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Amazing Library </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon  ">
                                        <img src="images/avatar/instructor.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Best Teachers </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon  ">
                                        <img src="images/avatar/sports.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Sports </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                   
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
</div>        

<?php 
include("footer.php");
?>