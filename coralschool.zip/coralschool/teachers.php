<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
    <div class="default-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <!-- <div class="default_tabs">
                            <nav>
                                <div class="nav nav-tabs tab_default  justify-content-center">
                                    <a class="nav-item nav-link active" href="about_us.html">About</a>
                                    <a class="nav-item nav-link" href="our_blog.html">Blog</a>
                                    <a class="nav-item nav-link" href="career.html">Careers</a>
                                    <a class="nav-item nav-link" href="press.html">Press</a>
                                </div>
                            </nav>
                        </div> -->
                        <div class="title129">
                            <h2>Teachers</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       

        <div class="life-gambo mb-4">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-12">
                        
                        <div class="dd-content">
                            <div class="row">
                                <div class="col-lg-4 item mb-4">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team1.png" alt="">
                                        </div>
                                        <h4>Joginder Singh</h4>
                                        <span>CEO & Co-Founder</span>
                                        
                                    </div>
                                </div>
                                <div class="col-lg-4 item mb-4">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team2.png" alt="">
                                        </div>
                                        <h4>John Doe</h4>
                                        <span>CTO & Senior Developer</span>
                                       
                                    </div>
                                </div>
                                <div class="col-lg-4 item mb-4">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team1.png" alt="">
                                        </div>
                                        <h4>Jassica William</h4>
                                        <span>HR Manager</span>
                                        
                                    </div>
                                </div>
                                <div class="col-lg-4 item mb-4">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team2.png" alt="">
                                        </div>
                                        <h4>Zoena Singh</h4>
                                        <span>Senior Sales Manager</span>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

</div>        


<?php 
include("footer.php");
?>