

<div class="wrapper">
   
    <div id="demo" class="carousel slide" data-ride="carousel">
    <!-- <ul class="carousel-indicators">
        <li data-target="#demo" data-slide-to="0" class="active"></li>
        <li data-target="#demo" data-slide-to="1"></li>
        <li data-target="#demo" data-slide-to="2"></li>
    </ul> -->
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="images/banners/bg2.jpg" alt="Feed Your Knowledge " width="100%">
            <div class="carousel-caption">
                <h3><span>Feed Your Knowledge</span></h3>
                <p><span>World’s Best School</span></p>
                <p><b>We provides always our best services for our clients and always</b></p>
                <button class="next-btn16 hover-btn mt-3 " type="submit" >Submit Request</button>
            </div>   
        </div>
        <div class="carousel-item">
            <img src="images/banners/bg3.jpg" alt="Chicago" width="100%">
            <div class="carousel-caption">
                <h3><span>Feed Your Knowledge</span></h3>
                <p><span>World’s Best School</span></p>
                <p><b>We provides always our best services for our clients and always</b></p>
                <button class="next-btn16 hover-btn mt-3 " type="submit" >Submit Request</button>
            </div>    
        </div>
        <!-- <div class="carousel-item">
            <img src="images/banners/bg4.jpg" alt="New York" width="100%">
            <div class="carousel-caption">
                <h3><span>Feed Your Knowledge</span></h3>
                <p><span>World’s Best School</span></p>
                <p><b>We provides always our best services for our clients and always</b></p>
                <button class="next-btn16 hover-btn mt-3 " type="submit" >Submit Request</button>
            </div>  
        </div> -->
    </div>
        <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
        </a>
    </div>

    <div id="rs-features" class="rs-features style2">
        <div class="container">
            <div class="row">
                        <div class="col-lg-3 col-md-6  col-sm-6 col-6 ">
                            <div class="rs-iconbox-area mb-3">
                                <div class="icon-area">
                                   <img src="images/avatar/1.png" alt="">
                                </div>
                                <div class="text-area">
                                   <h3 class="icon-title">Academics</h3>
                                </div>
                            </div>
                        </div>  
                        <div class="col-lg-3 col-md-6 col-sm-6 col-6 ">
                            <div class="rs-iconbox-area mb-3">
                                <div class="icon-area">
                                   <img src="images/avatar/2.png" alt="">
                                </div>
                                <div class="text-area">
                                   <h3 class="icon-title">Notice</h3>
                                </div>
                            </div>
                        </div>  
                        <div class="col-lg-3 col-md-6 col-sm-6 col-6 ">
                            <div class="rs-iconbox-area mb-3">
                                <div class="icon-area">
                                   <img src="images/avatar/3.png" alt="">
                                </div>
                                <div class="text-area">
                                   <h3 class="icon-title">Gallery</h3>
                                </div>
                            </div>
                        </div>  
                        <div class="col-lg-3 col-md-6 col-sm-6 col-6">
                            <div class="rs-iconbox-area mb-3">
                                <div class="icon-area">
                                   <img src="images/avatar/4.png" alt="">
                                </div>
                                <div class="text-area">
                                   <h3 class="icon-title">Teachers </h3>
                                </div>
                            </div>
                        </div> 
            </div>
        </div>
    </div>


    <div class="section147 py-5" >
        <div class="container" >
            <div class="row" >
                <div class="col-md-6 col-sm-12 col-12">
                    <div class="img-part js-tilt" style="will-change: transform; transform: perspective(300px) rotateX(0deg) rotateY(0deg);">
                        <img src="images/about/about1.png" alt="images" style="max-width: 100%;height: auto;">
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-12">
                    <div class="contents pl-5">
                        <div class="sub-title mb-20"> About Us</div>
                        <h2 class="sl-title mb-40 md-mb-20">We are leading discovery and innovation since 1905</h2>
                        <p class="desc mb-50">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem ipsum dolor sit amet, consectetur adipisicing elit, eius to mod tempor incidi dunt ut labore et dolore magna aliqua. Ut enims ad minim veniam.Lorem sum dolor sit amet.
                        </p>
                        <a class="next-btn16  mt-3" href="about_us.php">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="section145" style="background-color: #ffffff !important;">
            <div class="container">
                <div class="row">
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="best-offer-item active">
                            <h3 class="elementskit-section-subtitle ">Find your Pathway</h3>
                            <h2 class="offer-counter-text ">
                                Our School Best  <span><span> Services</span></span>
                            </h2>
                            <div class="heading__description">
                                <p>Get new experience your<br>subject at Courselog as you learn.</p>
                            </div>
                            <button class="next-btn16 hover-btn mt-3 " type="submit">See More</button>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon">
                                        <img src="images/avatar/online-class.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Online Classes </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    <div class="box-footer disable_hover_button">
                                        <div class="btn-wraper">
                                            <a href="features.php" target="_self" rel="" class="elementskit-btn">View Details<i class="fas fa-arrow-right"></i></i></a>
                                       </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon">
                                        <img src="images/avatar/presentation.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Indoor Classes </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    <div class="box-footer disable_hover_button">
                                        <div class="btn-wraper">
                                            <a href="features.php" target="_self" rel="" class="elementskit-btn">View Details<i class="fas fa-arrow-right"></i></i></a>
                                       </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon">
                                        <img src="images/avatar/library.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Amazing Library </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    <div class="box-footer disable_hover_button">
                                        <div class="btn-wraper">
                                            <a href="features.php" target="_self" rel="" class="elementskit-btn">View Details<i class="fas fa-arrow-right"></i></i></a>
                                       </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon">
                                        <img src="images/avatar/instructor.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Best Teachers </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    <div class="box-footer disable_hover_button">
                                        <div class="btn-wraper">
                                            <a href="features.php" target="_self" rel="" class="elementskit-btn">View Details<i class="fas fa-arrow-right"></i></i></a>
                                       </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="best-offer-item actives">
                            <div class="elementskit-box-header">
                                    <div class="elementskit-info-box-icon">
                                        <img src="images/avatar/sports.png" alt="">
                                    </div>
                            </div>
                            <div class="box-body">
                                <h3 class="elementskit-info-box-title">Sports </h3>
                                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla</p>
                                    <div class="box-footer disable_hover_button">
                                        <div class="btn-wraper">
                                            <a href="features.php" target="_self" rel="" class="elementskit-btn">View Details<i class="fas fa-arrow-right"></i></i></a>
                                       </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
        <div class="about-steps-group white-bg">
            <div class="container">
                <div class="row elementor-row">
                    <div class="col-lg-3  col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #F14D5D;">400+</span></h4>
                            <p>Courses & videos</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #EE8C1C;">400+</span></h4>
                            <p>Expert teachers</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #55BC7E;">400+</span></h4>
                            <p>Total students</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                        <div class="about-step">
                            
                            <h4><span style="color: #0056D2;">400+</span></h4>
                            <p>Batches Passout</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="section145">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt text-center">
                            <div class="main-title-left">
                                <span>For You</span>
                                <h2>Our Gallery</h2>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="owl-carousel featured-slider owl-theme">
                            <div class="item">
                                <div class="product-item">
                                    <a href="gallery.php" class="product-img">
                                        <img src="images/gallery/1.jpg" alt="">
                                        
                                    </a>
                                    
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="gallery.php" class="product-img">
                                        <img src="images/gallery/4.jpg" alt="">
                                        
                                    </a>
                                   
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="gallery.php" class="product-img">
                                        <img src="images/gallery/3.jpg" alt="">
                                        
                                    </a>
                                   
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="gallery.php" class="product-img">
                                        <img src="images/gallery/4.jpg" alt="">
                                        
                                    </a>
                                   
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="gallery.php" class="product-img">
                                        <img src="images/gallery/4.jpg" alt="">
                                        
                                    </a>
                                   
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="gallery.php" class="product-img">
                                     <img src="images/gallery/3.jpg" alt="">
                                        
                                    </a>
                                    
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="gallery.php" class="product-img">
                                        <img src="images/gallery/4.jpg" alt="">
                                        
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section145">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <img src="images/admisionbg.png" alt="" width="100%">        
                    </div>
                    
                </div>
            </div>
        </div>

        <div class="section1451">
            <div class="container">
                <div class="row">

                    <div class="col-lg-4 col-md-12">
                    <div class="admission inquiry-form"> 
                            <div class="contact-form">
                                    <h2 style="color: #202C45;border-bottom:1px solid #F2184F;padding:10px 0">Enquiry Form</h2>
                                    <form>
                                        <div class="form-group mt-1">
                                            <label class="control-label">Full Name*</label>
                                            <div class="ui search focus">
                                                <div class="ui left icon input swdh11 swdh19">
                                                    <input class="prompt srch_explore" type="text" name="sendername" id="sendername" required="" placeholder="Your Full">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group mt-1">
                                            <label class="control-label">Email Address*</label>
                                            <div class="ui search focus">
                                                <div class="ui left icon input swdh11 swdh19">
                                                    <input class="prompt srch_explore" type="email" name="emailaddress" id="emailaddress" required="" placeholder="Your Email Address">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group mt-1">
                                            <label class="control-label">Class</label>
                                            <div class="ui search focus">
                                                <div class="ui left icon input swdh11 swdh19">
                                                    <input class="prompt srch_explore" type="text" name="sendersubject" id="sendersubject" required="" placeholder="Subject">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group mt-1">
                                            <div class="field">
                                                <label class="control-label">Message*</label>
                                                <textarea rows="2" class="form-control" id="sendermessage" name="sendermessage" required="" placeholder="Write Message"></textarea>
                                            </div>
                                        </div>
                                        <button class="next-btn16 hover-btn mt-3" type="submit" >Submit Request</button>
                                    </form>
                            </div>
                    </div>    
                    </div>
                    <div class="col-lg-8 col-md-12 schh-adm">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="addmission-class">
                                    <div class="admision-kg-img">
                                        <img src="images/pre-primary-kgp-homepage.jpg" alt="" width="100%">
                                    </div>
                                    <div class="admision-kg-title">
                                    <h3>PRE PRIMARY</h3>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="addmission-class">
                                    <div class="admision-kg-img">
                                        <img src="images/pre-primary-kgp-homepage.jpg" alt="" width="100%">
                                    </div>
                                    <div class="admision-kg-title">
                                    <h3>PRIMARY CLASS (I TO V)</h3>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="addmission-class">
                                    <div class="admision-kg-img">
                                        <img src="images/pre-primary-kgp-homepage.jpg" alt="" width="100%">
                                    </div>
                                    <div class="admision-kg-title">
                                    <h3>MIDDLE CLASS (VI TO VIII)</h3>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="addmission-class">
                                    <div class="admision-kg-img">
                                        <img src="images/pre-primary-kgp-homepage.jpg" alt="" width="100%">
                                    </div>
                                    <div class="admision-kg-title">
                                        <h3>SENIOR CLASS (IX TO XII)</h3>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="life-gambo" style="background: url(images/testimonial_bg.png)100% center / cover no-repeat;padding:60px">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt text-center">
                            <div class="main-title-left">
                                <span>Client Say</span>
                                <h2>Testimonials</h2>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-md-12">
                        
                        <div class="dd-content">
                            <div class="owl-carousel testimonial-slider owl-theme">
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                            <div class="team-avatar">
                                                <img src="images/avatar/imgicon.png" alt="">
                                            </div>
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                             <div class="team-avatar">
                                                <img src="images/avatar/imgicon.png" alt="">
                                            </div>
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                            <div class="team-avatar">
                                                <img src="images/avatar/imgicon.png" alt="">
                                            </div>
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                            <div class="team-avatar">
                                                <img src="images/avatar/imgicon.png" alt="">
                                            </div>
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="life-gambo mb-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt text-center">
                            <div class="main-title-left">
                                <span>Teachers</span>
                                <h2>Meet our Teachers </h2>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-12">
                        
                        <div class="dd-content">
                            <div class="owl-carousel team-slider owl-theme">
                                <div class="item">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team1.png" alt="">
                                        </div>
                                        <h4>Joginder Singh</h4>
                                        <span>CEO & Co-Founder</span>
                                        
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team2.png" alt="">
                                        </div>
                                        <h4>John Doe</h4>
                                        <span>CTO & Senior Developer</span>
                                       
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team1.png" alt="">
                                        </div>
                                        <h4>Jassica William</h4>
                                        <span>HR Manager</span>
                                        
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="team-item">
                                        <div class="team-img">
                                            <img src="images/team/team2.png" alt="">
                                        </div>
                                        <h4>Zoena Singh</h4>
                                        <span>Senior Sales Manager</span>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <section class="divider parallaxs layer-overlay overlay-theme-colored-9" data-bg-img="images/bg1.jpg" data-parallax-ratio="0.7" style="background-image: url(&quot;images/bg1.jpg&quot;); background-position: 50% 737px;">
      <div class="container py-5"> 
        <!-- Section Content -->
        <div class="section-content">
          <div class="row">
            <div class="col-md-12 text-center pt-5 pb-4" >
              <h3 class="text-white mt-0 mb-4">Watch Our Latest Campus Tour video</h3>
              <a href="https://www.youtube.com/watch?v=duXiopBZ8k0" data-lightbox-gallery="youtube-video"><i class="fa fa-play-circle text-theme-color-2 font-72"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
        <div class="blog-gambo" style="background: url(images/course-shape.png)100% center / cover no-repeat;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt text-center">
                            <div class="main-title-left">
                                <span>From the News</span>
                                <h2>Latest Blog </h2>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="blog-item">
                            <a href="blog.php" class="blog-img">
                                <img src="images/blog/blog1.jpg" alt="">
                                
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">09 March, 2021</div>
                                
                            </div>
                            <div class="blog-detail">
                                <h4>Shutdown of schools extended to Aug 31</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. </p>
                                <a href="blog.php">Read More <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                        
                        
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="blog-item">
                            <a href="blog.php" class="blog-img">
                                <img src="images/blog/blog1.jpg" alt="">
                                
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">09 March, 2021</div>
                                
                            </div>
                            <div class="blog-detail">
                                <h4>Shutdown of schools extended to Aug 31</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. </p>
                                <a href="blog.php">Read More <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                        
                        
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="blog-item">
                            <a href="blog.php" class="blog-img">
                                <img src="images/blog/blog1.jpg" alt="">
                               
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">09 March, 2021</div>
                                
                            </div>
                            <div class="blog-detail">
                                <h4>Shutdown of schools extended to Aug 31</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. </p>
                                <a href="blog.php">Read More <i class="fas fa-arrow-right"></i></a>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>

       

        <section class="section148" style="background: url(images/welcome-back-school-background_3589-817.jpg)100% center / cover no-repeat;padding-bottom:50px">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt text-center">
                            <div class="main-title-left">
                                <span>Events</span>
                                <h2>Student Desk </h2>
                            </div>
                            
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 col-12 mb-3">
                        <div class="card">
                            
                            <img class="card-img-bottom" src="images/bg1.jpg" alt="Card image" style="width:100%;height:250px">
                            <div class="card-body">
                                <a href="gallery.php"><h4 class="card-title">Our Awards</h4></a>
                                <p class="card-text">Lorem ipsum gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. </p>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 col-12 mb-3">
                        <div class="card">
                            
                            
                            <div class="card-body">
                                <h4 class="card-title">Fall Admission 2021 Going on</h4>
                                <p class="card-text py-3">Lorem ipsum gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. </p>
                                <h4 class="card-title">Help Line </h4>
                                <h5>+010 4561 32145</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 col-sm-12 col-12 mb-3">
                        <div class="card">
                            
                            <img class="card-img-bottom" src="images/bg1.jpg" alt="Card image" style="width:100%;height:250px">
                            <div class="card-body">
                                <a href="academics.php"><h4 class="card-title">Our Academics</h4></a>
                                <p class="card-text">Lorem ipsum gravida nibh vel velit auctor aliquetn sollicitudirem quibibendum auci elit cons equat ipsutis sem nibh id elit. </p>
                                
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </section>

        

        

</div> 
<div class="section145">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="thim-newlleter-homepage">
                            <p class="description">Subscribe now and receive weekly newsletter with educational materials, new courses, interesting posts, popular books and much more!</p> 
                       
                        <form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-3101 mc4wp-form-basic" method="post" data-id="3101" data-name="Default sign-up form">
                            <div class="mc4wp-form-fields">
                                <input type="email" id="mc4wp_email" name="EMAIL" placeholder="Your email here" required="">
                                <input type="submit" value="Subscribe">
                            </div>
                            <label style="display: none !important;">Leave this field empty if you're human: 
                                <input type="text" name="honeypot" value="" tabindex="-1" autocomplete="off"></label>
                                <input type="hidden" name="timestamp" value="1615350441">
                                <input type="hidden" name="form_id" value="3101">
                                <input type="hidden" name="form_element_id" value="-form-1">
                                <div class="mc4wp-response">

                                </div>
                            </form>
                        </div>
  
                    </div>
                    
                </div>
            </div>
        </div>