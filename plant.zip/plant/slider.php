<?php include('common/config.php');?>
  <!--Main Slider-->
  <section class="rev_slider_wrapper">
            <div id="slider2" class="rev_slider" data-version="5.0">
                <ul>
                    <?php
                        $result1 = mysqli_query($conn,"SELECT * FROM slider");
                        while($rows = mysqli_fetch_array($result1)) {
                        
                    ?>
                    <!-- SLIDE 1 -->
                    <li data-index="rs-1" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/main-slider/bk7.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500"
                        data-fsslotamount="7" data-saveperformance="off" data-title="Make an Impact">
                        <!-- MAIN IMAGE -->
                        <img src="admin/<?php echo $rows["sld_img"]; ?>" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        <!-- LAYERS -->

                        <!-- LAYER NR. 1 -->
                        <div class="tp-caption tp-resizeme bigtitle text-white rs-parallaxlevel-0" id="slide-1-layer-2" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['280','260','230','180']" data-fontsize="['59','46','40','36']"
                            data-lineheight="['70','60','50','45']" data-fontweight="['600','600','700','700']" data-width="['700','650','600','420']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                            data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on"><?php echo $rows["sld_title"]; ?>
                        </div>
                        <!-- LAYER NR. 2 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-1-layer-3" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['450','390','350','290']" data-fontsize="['18','18','16','13']"
                            data-lineheight="['30','30','28','25']" data-fontweight="['400','400','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-100px;opacity:0;s:1000;e:Power3.easeOut;"
                            data-transform_out="x:-100px;opacity:0;s:700;e:Power2.easeInOut" data-start="1800" data-splitin="none" data-splitout="none" data-responsive_offset="on"><?php echo $rows["sld_subtitle"]; ?>
                        </div>
                        <!-- LAYER NR. 3 -->
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-1-layer-4" data-x="['left','left','left','left']" data-hoffset="['53','53','53','30']" data-y="['top','top','top','top']" data-voffset="['550','470','440','370']" data-fontsize="['18','18','16','16']"
                            data-lineheight="['30','30','30','30']" data-fontweight="['400','400','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power3.easeInOut;"
                            data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on"><a href="<?php echo $rows["sld_link"]; ?>" class="slider-link-style1">MORE ABOUT OUR COMPANY </a>
                        </div>
                    </li>

                    <!-- SLIDE 2 -->
                    <!-- <li data-index="rs-2" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/main-slider/bk2.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500"
                        data-fsslotamount="7" data-saveperformance="off" data-title="Make an Impact">
                        
                        <img src="images/main-slider/bk2.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                       
                        <div class="tp-caption tp-resizeme bigtitle text-white rs-parallaxlevel-0" id="slide-2-layer-2" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['280','260','230','180']" data-fontsize="['59','46','40','36']"
                            data-lineheight="['70','60','50','45']" data-fontweight="['600','600','700','700']" data-width="['700','650','600','420']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                            data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on">GRD Offers Garden
                            <br>Design to Clients.
                        </div>
                        
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-2-layer-3" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['450','390','350','290']" data-fontsize="['18','18','16','13']"
                            data-lineheight="['30','30','28','25']" data-fontweight="['400','400','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-100px;opacity:0;s:1000;e:Power3.easeOut;"
                            data-transform_out="x:-100px;opacity:0;s:700;e:Power2.easeInOut" data-start="1800" data-splitin="none" data-splitout="none" data-responsive_offset="on">30+ years of experience our staff keep your property looking
                            <br> and functioning beautifully. Our landscapers are fully licensed
                        </div>
                        
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-2-layer-4" data-x="['left','left','left','left']" data-hoffset="['53','53','53','30']" data-y="['top','top','top','top']" data-voffset="['550','470','440','370']" data-fontsize="['18','18','16','16']"
                            data-lineheight="['30','30','30','30']" data-fontweight="['400','400','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power3.easeInOut;"
                            data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on"><a href="#" class="slider-link-style1">MORE ABOUT OUR COMPANY </a>
                        </div>
                    </li>

                   
                    <li data-index="rs-3" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="images/main-slider/bk8.jpg" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="1500"
                        data-fsslotamount="7" data-saveperformance="off" data-title="Make an Impact">
                       
                        <img src="images/main-slider/bk8.jpg" alt="" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="10" class="rev-slidebg" data-no-retina>
                        
                        <div class="tp-caption tp-resizeme bigtitle text-white rs-parallaxlevel-0" id="slide-3-layer-2" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['280','260','230','180']" data-fontsize="['59','46','40','36']"
                            data-lineheight="['70','60','50','45']" data-fontweight="['600','600','700','700']" data-width="['700','650','600','420']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;s:1500;e:Power3.easeInOut;"
                            data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:0px;s:inherit;e:inherit;" data-mask_out="x:0;y:0;s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on">We Are Certified
                            <br> & Insured landscapers
                        </div>
                      
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-3-layer-3" data-x="['left','left','left','left']" data-hoffset="['50','50','50','30']" data-y="['top','top','top','top']" data-voffset="['450','390','350','290']" data-fontsize="['18','18','16','13']"
                            data-lineheight="['30','30','28','25']" data-fontweight="['400','400','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="x:-100px;opacity:0;s:1000;e:Power3.easeOut;"
                            data-transform_out="x:-100px;opacity:0;s:700;e:Power2.easeInOut" data-start="1800" data-splitin="none" data-splitout="none" data-responsive_offset="on">30+ years of experience our staff keep your property looking
                            <br> and functioning beautifully. Our landscapers are fully licensed
                        </div>
                       
                        <div class="tp-caption tp-resizeme text-white rs-parallaxlevel-0" id="slide-3-layer-4" data-x="['left','left','left','left']" data-hoffset="['53','53','53','30']" data-y="['top','top','top','top']" data-voffset="['550','470','440','370']" data-fontsize="['18','18','16','16']"
                            data-lineheight="['30','30','30','30']" data-fontweight="['400','400','600','600']" data-width="['700','650','600','420']" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power3.easeInOut;"
                            data-transform_out="auto:auto;s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:0px;y:[100%];s:inherit;e:inherit;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on"><a href="#" class="slider-link-style1">MORE ABOUT OUR COMPANY </a>
                        </div>
                    </li> -->

                    <?php
                    }
                    ?>
                </ul>

            </div>
        </section>
        <!--Main Slider  end-->