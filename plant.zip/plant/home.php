        <!--why choose us-->
        <div class="whychooseus_1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12 nopadd">
                        <div class="grd-icon-box grd-icon-box-1 icon-theme-light">
                            <div class="icon-box-wrapter">
                                <a href="#" class="emtry-title">
                                    <p class="title">Emergency
                                        <br> Tree Removal Service.</p>
                                </a>
                                <a href="#" class="icon">
                                    <div class="icon-content">
                                        <span class="svg-icon">
											<i class="flaticon-wifi"></i>
										</span>
                                    </div>
                                </a>
                                <div class="content">
                                    <div class="descreption"><span>1-800-123-4567</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 nopadd">
                        <div class="grd-icon-box grd-icon-box-2 icon-theme-dark radius-5 services-home-1 clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content">
                                        <span class="svg-icon background-1">
										<i class="flaticon-love"></i>
									  </span>
                                    </div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title" title="Tailor-Made Designs">Tailor-Made Designs</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">There anyone loves pursues desires to obtain pain of itself, because it is pain but because occasionally.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12 nopadd">
                        <div class="grd-icon-box grd-icon-box-2 icon-theme-dark radius-5 services-home-2 clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content">
                                        <span class="svg-icon background-2">
										<i class="flaticon-house"></i>
									  </span>
                                    </div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title" title="Tailor-Made Designs">Public Liability Insurance</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">Great explorer off the truth master builder human is happiness one rejects dislikes avoid pleasure.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--why choose us end-->


        <!--about us-->
        <div class="whoweare-3">
            <div class="container">
               
                <div class="row">
                    <div class="col-sm-12 col-md-4 col-xs-12">
                        <div class="wwrlefttext">
                            <h2>14+ Years Experienced Landscapers.</h2>
                            <p>Since 2004 must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born &amp; we will give you.</p>
                            <div class="grd-button-group grd-align-left">
                                <a href="#" class="grd-button  hover-1"><span>READ MORE</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-xs-12">
                        <div class="grd-image-box-5 icon-theme-light">
                            <div class="entry_thumbnail">
                                <img class="" src="images/resources/vision-1.jpg" alt="vision-1" width="370" height="260">
                                <a href="#" class="hover"></a>
                            </div>
                            <div class="show">
                                <div class="entry-title">
                                    <a href="#">
                                        <h4 class="title">Our Mission</h4>
                                    </a>
                                </div>
                                <div class="entry-content">Great explorer of the truth, masters builder of human happinessand dislike pursues desires obtain.</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-xs-12">
                        <div class="grd-image-box-5 icon-theme-light">
                            <div class="entry_thumbnail">
                                <img class="" src="images/resources/vision-2.jpg" alt="vision-1" width="370" height="260">
                                <a href="#" class="hover"></a>
                            </div>
                            <div class="show">
                                <div class="entry-title">
                                    <a href="#">
                                        <h4 class="title">Our Vision</h4>
                                    </a>
                                </div>
                                <div class="entry-content">Great explorer of the truth, masters builder of human happinessand dislike pursues desires obtain.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--about us end-->

         <!--process-->
         <div class="working-process-1">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1 sc-dark text-center margbtm30">
                    <h3 class="title">Working Process</h3>
                    <div class="desc">
                        <p>Contact our office for a free quote! It is always good to have a rough idea on your budget at this stage to enable us to quote as necessary.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-md-3 col-xs-12">
                        <div class="grd-icon-box grd-icon-box-4 icon-theme-dark text-center clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-consulting"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Consultation</p>
                                </a>
                                <div class="content">
                                    <div class="descreption"><span>How all this mistaken idea all off work pleasure.</span></div>
                                </div>
                            </div>
                            <div class="text-footer">Step 2</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12">
                        <div class="grd-icon-box grd-icon-box-4 icon-theme-dark text-center clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-blueprint"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title" title="Design &amp; Planting">Design &amp; Planting</p>
                                </a>
                                <div class="content">
                                    <div class="descreption"><span>Expound the actuals teachings<br> explorer the truth.</span></div>
                                </div>
                            </div>
                            <div class="text-footer">Step 2</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12">
                        <div class="grd-icon-box grd-icon-box-4 icon-theme-dark text-center clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-park"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title" title="Design &amp; Planting">Completion</p>
                                </a>
                                <div class="content">
                                    <div class="descreption"><span>Actual teachings great explorer<br> master-builder.</span></div>
                                </div>
                            </div>
                            <div class="text-footer">Step 2</div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3 col-xs-12">
                        <div class="grd-icon-box grd-icon-box-4 icon-theme-dark text-center clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-gardening"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title" title="Design &amp; Planting">Maintenance</p>
                                </a>
                                <div class="content">
                                    <div class="descreption"><span>To take a trivial example, which of<br> all undertakes labor.</span></div>
                                </div>
                            </div>
                            <div class="text-footer">Step 2</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--process end-->
        <!--services us-->
        <div class="services-1">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="col-xs-12 grd-icon-box grd-icon-box-3 icon-theme-light  border">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content">
                                        <span class="svg-icon"><img src="images/icon/oms-leaf.png" alt=""></span>
                                    </div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Our
                                        <br>Main Services</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">Which includes lawn mowing, fertilizing, spring, fall cleanups and tree care.</div>
                                </div>
                            </div>
                            <div class="box_btn"><a href="#">All Services</a></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="grd-image-box-1 icon-theme-light">
                            <div class="entry-title">
                                <a href="#">
                                    <h4 class="title">Design &amp; Planting</h4>
                                </a>
                            </div>
                            <div class="entry-icon">
                                <span class="svg-icon"><i class="flaticon-hills"></i></span>
                            </div>
                            <div class="entry_thumbnail">
                                <img src="images/services/service-1.png" alt="04" width="600" height="324">
                                <a href="#" class="hover"></a>
                            </div>
                            <div class="entry-content">Complete range of landscaping services all designed to enhance the beauty of your home and property…</div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-12">
                        <div class="grd-image-box-1 icon-theme-light">
                            <div class="entry-title">
                                <a href="#">
                                    <h4 class="title">Lawn & Garden Care</h4>
                                </a>
                            </div>
                            <div class="entry-icon">
                                <span class="svg-icon"><i class="flaticon-lawnmower"></i></span>
                            </div>
                            <div class="entry_thumbnail">
                                <img class="" src="images/services/service-2.jpg" alt="04" width="600" height="324">
                                <a href="#" class="hover"></a>
                            </div>
                            <div class="entry-content">Environmental problems result when exotic plants are placed in the landscape occurs toil some great…</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--services end-->
         <!-- Our team -->
         <div class="team-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-12">
                        <div class="teambanner">
                            <img src="images/team/team-img.jpg" alt="" />
                            <div class="text-banner">
                                <h2>We are looking<br> for good &amp;<br> Knowlagable<br> <b>Landscapers</b></h2>
                                <div class="dl-button"><a href="#">Join With Us</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-9">
                        <div class="grd-section-title  grd_title-type-2 margbtm40">
                            <h3 class="title">Our Product</h3>
                            <div class="desc">
                                <p>Those people behind our succesfull company & service</p>
                            </div>
                        </div>
                        <div class="dl_team_carousel dl_members">
                       
                            <div class="teamslide">
                                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM product ORDER BY pdct_id DESC");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                                <div class="item-team">
                                    <div class="box-member">
                                        <a href="<?php echo $rows["pdct_link"]; ?>"><h3><?php echo $rows["pdct_name"]; ?></h3></a>
                                        <a href="<?php echo $rows["pdct_link"]; ?>">
                                            <div class="box-img">
                                                <img src="admin/<?php echo $rows["pdct_img"]; ?>" class="attachment-full" alt="" width="375" height="361">
                                                <div class="overlay-link">
                                                    
                                                    </div>
                                            </div>
                                        </a>
                                        <div class="job">Rs. <?php echo $rows["pdct_rate"]; ?>/-</div>
                                    </div>
                                </div>
                                <!-- <div class="item-team">
                                    <div class="box-member">
                                        <a href="product.php"><h3>Dan Western</h3></a>
                                        <div class="box-img">
                                        <a href="product.php"><img src="images/product/redsandalwood.jpg" class="attachment-full" alt="" width="375" height="361"></a>
                                            <div class="overlay-link">
                                                
                                            </div>
                                        </div>
                                        <div class="job">Rs. 250/-</div>
                                    </div>
                                </div>
                                <div class="item-team">
                                    <div class="box-member">
                                        <a href="product.php"><h3>Carlose Loneon</h3></a>
                                        <div class="box-img">
                                        <a href="product.php"><img src="images/product/seedred.png" class="attachment-full" alt="" width="375" height="361"></a>
                                            <div class="overlay-link">
                                               
                                            </div>
                                        </div>
                                        <div class="job">Rs. 250/-</div>
                                    </div>
                                </div>
                                <div class="item-team">
                                    <div class="box-member">
                                        <a href="product.php"><h3>Donald Benjamin</h3></a>
                                        <div class="box-img">
                                        <a href="product.php"><img src="images/product/seedred.png" class="attachment-full" alt="" width="375" height="361"></a>
                                            <div class="overlay-link">
                                                
                                            </div>
                                        </div>
                                        <div class="job">Rs. 250/-</div>
                                    </div>
                                </div> -->
                                <?php
                                }
                                ?>
                           </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Our team end -->
       <!--gallery us-->
       <div class="gallery-1">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1 text-center margbtm30">
                    <h3 class="title">Latest Projects</h3>
                    <div class="desc">
                        <p>We have done more than 10,000 succesful projects.</p>
                    </div>
                </div>
                <div class="row grd-portfolio-shortcode">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM gallery ORDER BY glry_id DESC limit 0,4");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <div class="col-sm-6 col-md-3  portfolio-item">
                        <div class="content-item">
                            <div class="entry-header">
                                <a href="<?php echo $rows["glry_link"]; ?>" class="entry-thumbnail"><img alt="Communal Garden" src="admin/<?php echo $rows["glry_img"]; ?>"></a>
                            </div>
                            <div class="entry-content">
                                <div class="entry-title"><a href="<?php echo $rows["glry_link"]; ?>"><h3 class="title"><?php echo $rows["glry_title"]; ?></h3></a>
                                    
                                </div>
                                <div class="readmore">
                                    <a href="<?php echo $rows["glry_link"]; ?>" class="entry-read-more">
                                        <div class="read-more"><span class="svg-icon"><i class="flaticon-right"></i></span> Read more</div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <?php 
                                    }
                    ?>
                </div>
                <div class="grd-button-group grd-align-center">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM gallery ");
                                    $rows = mysqli_fetch_array($result1)
                                    
                                ?>
                    <a href="<?php echo $rows["glry_link"]; ?>" class="grd-button hidden-xs hover-1"><span>View More</span></a>
                </div>
            </div>
        </div>
        <!--gallery end-->



        <!-- counter-->
        <div class="counter-3">
            <div class="container">
                <div class="row">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM counters ");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <div class="col-sm-4">
                        <div class="dl_counter style-2 counter-value">
                            <div class="content">
                                
                                <h3><span class="counter-number"><?php echo $rows["count_num"]; ?></span><span>+</span></h3>
                                <p><?php echo $rows["count_title"]; ?></p>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-sm-3">
                        <div class="dl_counter style-2 counter-value">
                            <div class="content">
                                <div class="border-right"></div>
                                <h3><span class="counter-number">836</span></h3>
                                <p>Completed
                                    <br> Projects</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="dl_counter style-2 counter-value">
                            <div class="content">
                                <h3><span class="counter-number">152</span></h3>
                                <p>Total
                                    <br> Customers</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="dl_counter style-2 counter-value">
                            <div class="content">
                                <h3><span class="counter-number">152</span></h3>
                                <p>Expert
                                    <br> Team Members</p>
                            </div>
                        </div>
                    </div> -->
                    <?php
                                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- counter end-->
         <!--why we are-->
         <div class="whyus-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="grd-section-title sc-dark  grd_title-type-2 margbtm40">
                            <h3 class="title">Industry Covered</h3>
                            <div class="desc">
                                <p>We Designed for Commercial & Non Commercial Industries.</p>
                                <p>Denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness pursue work
                                    encounter consequences that are extremely.</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 coverdimg">
                                <img src="images/resources/industry-img.jpg" alt="" />
                            </div>
                            <div class="col-sm-6">
                                <div class="grd-list icon-theme-dark">
                                    <h3 class="title">WE DESIGNED FOR</h3>
                                    <ul>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Commercial</a></li>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Residential</a></li>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Sports</a></li>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Health &amp; Medical</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-5 col-lg-offset-1 col-sm-12">
                        <div class="icon-box-list">
                            <div class="col-xs-12 icon-box-list-items grd-icon-box-list-1 icon-theme-light ">
                                <div class="icon-box-wrapter">
                                    <a href="#" class="icon">
                                        <div class="icon-content"><span class="svg-icon"><i class="flaticon-clock"></i></span></div>
                                    </a>
                                    <a href="#" class="emtry-title">
                                        <h3 class="title" title="On Time, Every Time">On Time, Every Time</h3>
                                    </a>
                                    <div class="content">
                                        <div class="descreption">Must explain you how this idea of works denouncing pleasure.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 icon-box-list-items grd-icon-box-list-1 icon-theme-light ">
                                <div class="icon-box-wrapter">
                                    <a href="#" class="icon">
                                        <div class="icon-content"><span class="svg-icon"><i class="flaticon-love"></i></span></div>
                                    </a>
                                    <a href="#" class="emtry-title">
                                        <h3 class="title" title="Public Liability Insurance">Public Liability Insurance</h3>
                                    </a>
                                    <div class="content">
                                        <div class="descreption">Denouncing pleasure &amp; praising pain give you a complete account.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 icon-box-list-items grd-icon-box-list-1 icon-theme-light ">
                                <div class="icon-box-wrapter">
                                    <a href="#" class="icon">
                                        <div class="icon-content"><span class="svg-icon"><i class="flaticon-house"></i></span></div>
                                    </a>
                                    <a href="#" class="emtry-title">
                                        <h3 class="title" title="Tailor-Made Designs">Tailor-Made Designs</h3>
                                    </a>
                                    <div class="content">
                                        <div class="descreption">Praising pain was born and we will give the system expound.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--why we are end-->
       
        <!--testimonial -->
        <div class="testimonials-1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="grd-section-title  grd_title-type-2">
                            <h3 class="title">Testimonials</h3>
                            <div class="desc">
                                <p>what our customers says.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="grd-button-group grd-align-right">
                            <a href="#" class="grd-button  hover-2">
                                <span class="svg-icon"><i class="flaticon-right"></i></span>
                                <span>More From Customers</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="dl_testimorial_carousel testone-slide no-star">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM testimonial ");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <div class="item-testi style-1">
                        <div class="box-text">
                            <div class="svg-icon">
                                <i class="flaticon-quotation"></i>
                            </div>
                            <p class="content"> “<?php echo $rows["test_quote"]; ?>”</p>
                        </div>
                        <div class="box-avatar">
                            <img class="" src="admin/<?php echo $rows["test_img"]; ?>" alt="1" title="1" width="80" height="80">
                            <h3> <?php echo $rows["test_name"]; ?></h3>
                            <p class="address"> <?php echo $rows["test_post"]; ?></p>
                            <span class="list-star">
								<i class="fa fa-star"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
							</span>
                        </div>
                    </div>
                    <!-- <div class="item-testi style-1">
                        <div class="box-text">
                            <div class="svg-icon">
                                <i class="flaticon-quotation"></i>
                            </div>
                            <p class="content"> “Lawn Care helped me transform my dated,patchwork front yard into an inviting Southern Garden!.”</p>
                        </div>
                        <div class="box-avatar">
                            <img class="" src="images/testimonial/1.png" alt="1" title="1" width="80" height="80">
                            <h3> Emileny Fernando</h3>
                            <p class="address"> Newyork City</p>
                            <span class="list-star">
								<i class="fa fa-star"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
							</span>
                        </div>
                    </div>
                    <div class="item-testi style-1">
                        <div class="box-text">
                            <div class="svg-icon">
                                <i class="flaticon-quotation"></i>
                            </div>
                            <p class="content"> “Lawn Care helped me transform my dated,patchwork front yard into an inviting Southern Garden!.”</p>
                        </div>
                        <div class="box-avatar">
                            <img class="" src="images/testimonial/1.png" alt="1" title="1" width="80" height="80">
                            <h3> Emileny Fernando</h3>
                            <p class="address"> Newyork City</p>
                            <span class="list-star">
								<i class="fa fa-star"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
								<i class="fa fa-star-o"></i>
							</span>
                        </div>
                    </div> -->
                    <?php
                                    }
                    ?>
                </div>
            </div>
        </div>
        <!-- testimonial end -->

        <!--request form-->
<?php
$message = "";
if(isset($_POST['submit'])){
$apt_name = $_POST['apt_name'];
$apt_email = $_POST['apt_email'];
$apt_phone = $_POST['apt_phone'];
$apt_address = $_POST['apt_address'];
$apt_services = $_POST['apt_services'];
$apt_time = $_POST['apt_time'];
$apt_date = $_POST['apt_date'];
$apt_msg = $_POST['apt_msg'];

// display the results
$sql = "INSERT INTO appointment (apt_name, apt_email, apt_phone, apt_address, apt_services, apt_time, apt_date, apt_msg) VALUES ('$apt_name', '$apt_email', '$apt_phone', '$apt_address', '$apt_services', '$apt_time', '$apt_date','$apt_msg')";
mysqli_query($conn, $sql); 
$message = "Successfully submitted! ";
}  
?>

        <div class="request-form-1 wpcf7" id="request_form">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 pull-right">
                        <div class="grd-section-title  grd_title-type-2 margbtm40">
                            <h3 class="title">Request an Estimate</h3>
                            <div class="desc">
                                <p>Please fill the below required information to get a estimate & make an appoinement with Lawncare, Our experts will contact you very soon.</p>
                            </div>
                        </div>
                        <form action="" method="post" class="wpcf7-form contact-home" novalidate="novalidate">
                            <h4 class="title">Your Information*</h4>
                            <div class="row">
                                <div class="col-md-4">
                                    <input name="apt_name" value="" size="40" placeholder="Your Name*" type="text">
                                </div>
                                <div class="col-md-4">
                                    <input name="apt_email" value="" size="40" placeholder="Email*" type="email">
                                </div>
                                <div class="col-md-4">
                                    <input name="apt_phone" value="" size="40" placeholder="Phone" type="tel">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 pull-right">
                                    <textarea cols="40" rows="10" placeholder="Your Message" name="apt_msg"></textarea>
                                </div>
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input name="apt_address" value="" size="40" placeholder="Address*" type="text">
                                        </div>
                                        <div class="col-md-6">
                                            <input name="apt_services" value="" size="40" placeholder="Services*" type="text">
                                        </div>
                                    </div>
                                    <h4 class="title">Appointment Date &amp; Time <span>(If you need)</span></h4>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <input name="apt_date" value="" size="40" type="text" placeholder="12-12-2020*">
                                        </div>
                                        <div class="col-md-6">
                                            <input name="apt_time" value="" size="40" placeholder="09.00 am" type="text">
                                        </div>
                                    </div>
                                    <p>
                                        <input value="Request a Quote" class="wpcf7-submit" type="submit"  name="submit" value="submit">
                                    </p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--request form end-->

<!--blogs-->
<div class="blogs-style-1 arrow-blog">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1 text-center margbtm30">
                    <h3 class="title">Recent Blog Post</h3>
                    <div class="desc">
                        <p>Go through Our Landscaping & gardening Tips & News</p>
                    </div>
                </div>
                <div class="row">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM blog ORDER BY blog_id DESC limit 0,3");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-wrapper">
                            <div class="entry-thumbnail">
                                <a href="<?php echo $rows["blog_link"]; ?>&id=<?php echo $rows["blog_id"]; ?>"><img src="admin/<?php echo $rows["blog_img"]; ?>" alt="" width="600" height="340" /></a>
                            </div>
                            <header class="entry-header">
                                <div class="entry-meta">
                                    <div class="meta-date"><?php echo $rows["blog_date"]; ?></div>
                                    <span class="meta-author"><span>By </span>
                                    <a href="<?php echo $rows["blog_link"]; ?>&id=<?php echo $rows["blog_id"]; ?>"><?php echo $rows["blog_by"]; ?></a></span>
                                </div>
                                <h2 class="entry-title"><a href="<?php echo $rows["blog_link"]; ?>&id=<?php echo $rows["blog_id"]; ?>"><?php echo $rows["blog_head"]; ?></a></h2>
                            </header>
                        </div>
                    </div>
                    <!-- <div class="col-md-4 col-sm-6">
                        <div class="blog-wrapper">
                            <div class="entry-thumbnail">
                                <a href="blog-single.php"><img src="images/blogs/blog-1-2.png" alt="" width="600" height="340" /></a>
                            </div>
                            <header class="entry-header">
                                <div class="entry-meta">
                                    <div class="meta-date">August 9, 2018</div>
                                    <span class="meta-author"><span>By </span>
                                    <a href="blog-single.php">steeltheme</a></span>
                                </div>
                                <h2 class="entry-title"><a href="blog-single.php">We Won The Best Landscape Company</a></h2>
                            </header>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-wrapper">
                            <div class="entry-thumbnail">
                                <a href="blog-single.php"><img src="images/blogs/blog-1-3.jpg" alt="" width="600" height="340" /></a>
                            </div>
                            <header class="entry-header">
                                <div class="entry-meta">
                                    <div class="meta-date">August 9, 2018</div>
                                    <span class="meta-author"><span>By </span>
                                    <a href="blog-single.php">steeltheme</a></span>
                                </div>
                                <h2 class="entry-title"><a href="blog-single.php">We Won The Best Landscape Company</a></h2>
                            </header>
                        </div>
                    </div> -->
                    <?php
                                    }
                    ?>
                </div>
            </div>
        </div>
        <!--blogs end-->
        <!--customer help-->
        <div class="customer-help-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-6 grd-icon-box grd-icon-box-5 icon-theme-light">
                        <div class="icon-box-wrapter">
                            <a href="#" class="icon">
                                <div class="icon-content"><img class="" src="images/icon/faq.png" alt="faq" width="64" height="58"></div>
                            </a>
                            <a href="#" class="emtry-title">
                                <p class="title">Get Replies
                                    <br>to Your Doubts.</p>
                            </a>
                            <div class="content">
                                <div class="descreption">How all this mistaken idea of pleasure &amp;praising pain completed.</div>
                            </div>
                        </div>
                        <a href="#" class="text-footer"><span class="svg-icon"><i class="flaticon-right"></i></span> Our Locations</a>
                    </div>
                    <div class="col-md-4 col-sm-6 grd-icon-box grd-icon-box-5 icon-theme-light">
                        <div class="icon-box-wrapter">
                            <a href="#" class="icon">
                                <div class="icon-content"><img class="" src="images/icon/location.png" alt="faq" width="64" height="58"></div>
                            </a>
                            <a href="#" class="emtry-title">
                                <p class="title">Get Replies
                                    <br>to Your Doubts.</p>
                            </a>
                            <div class="content">
                                <div class="descreption">How all this mistaken idea of pleasure &amp;praising pain completed.</div>
                            </div>
                        </div>
                        <a href="#" class="text-footer"><span class="svg-icon"><i class="flaticon-right"></i></span> Our Locations</a>
                    </div>
                    <div class="col-md-4 col-sm-6 grd-icon-box grd-icon-box-5 icon-theme-light">
                        <div class="icon-box-wrapter">
                            <a href="#" class="icon">
                                <div class="icon-content"><img class="" src="images/icon/place.png" alt="faq" width="64" height="58"></div>
                            </a>
                            <a href="#" class="emtry-title">
                                <p class="title">Get Replies
                                    <br>to Your Doubts.</p>
                            </a>
                            <div class="content">
                                <div class="descreption">How all this mistaken idea of pleasure &amp;praising pain completed.</div>
                            </div>
                        </div>
                        <a href="#" class="text-footer"><span class="svg-icon"><i class="flaticon-right"></i></span> Our Locations</a>
                    </div>
                </div>
            </div>
        </div>
        <!--customer help end-->
        <!--parteners-->
        <div class="partener-style-2">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1 text-center margbtm60">
                    <h3 class="title">Our Clients & Partners</h3>
                    <div class="desc">
                        <p>WE GIVE 100% SATISFACTION TO OUR CLIENTS & BUSINESS PARTNERS</p>
                    </div>
                </div>
                <div class="carousel-img">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM patners");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <div class="box-img">
                        <a href="#"><img src="admin/<?php echo $rows["pat_logo"]; ?>" class="attachment-full" alt="" width="243" height="50"></a>
                    </div>
                    <!-- <div class="box-img">
                        <a href="#"><img src="images/partener/2.jpg" class="attachment-full" alt="" width="243" height="50"></a>
                    </div>
                    <div class="box-img">
                        <a href="#"><img src="images/partener/3.jpg" class="attachment-full" alt="" width="243" height="50"></a>
                    </div>
                    <div class="box-img">
                        <a href="#"><img src="images/partener/4.jpg" class="attachment-full" alt="" width="243" height="50"></a>
                    </div>
                    <div class="box-img">
                        <a href="#"><img src="images/partener/1.jpg" class="attachment-full" alt="" width="243" height="50"></a>
                    </div> -->
                    <?php
                                    }
                    ?>
                </div>
            </div>
        </div>
        <!--parteners end-->