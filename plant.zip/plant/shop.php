<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--all team-->
        <div class="shopepage pagepadding woocommerce">
            <div class="container">
                <div class="shop-filter clearfix">
                    <p class="result-count col-sm-6"> Showing 1–9 of 17 results</p>
                    <form class="result-ordering col-sm-6">
                        <select class="orderby">
                            <option value="menu_order" selected="selected">Default sorting</option>
                            <option value="popularity">Sort by popularity</option>
                            <option value="rating">Sort by average rating</option>
                            <option value="date">Sort by newness</option>
                        </select>
                    </form>
                </div>
                <ul class="products row">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM product");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="admin/<?php echo $rows["pdct_img"]; ?>" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php"><?php echo $rows["pdct_name"]; ?></a></h4>
                                <span class="price">
									
                                <ins><span>Rs.</span> <?php echo $rows["pdct_rate"]; ?>/-</ins>
                                </span>
                            </div>
                        </div>
                    </li>
                    <!-- <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-7.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Alenit electramutmea</a></h4>
                                <span class="price">
									<span>£</span>18.00
                                </span>
                            </div>
                        </div>
                    </li>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-8.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Alia expetendisat</a></h4>
                                <span class="price">
									<span>£</span>45.00
                                </span>
                            </div>
                        </div>
                    </li>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-1.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Aliquam tincidunt</a></h4>
                                <span class="price">
									<del><span>£</span>65.00</del>
                                <ins><span>£</span>55.00</ins>
                                </span>
                            </div>
                        </div>
                    </li>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-2.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Anti Burst Ball</a></h4>
                                <span class="price">
									<del><span>£</span>20.00</del>
                                <ins><span>£</span>18.00</ins>
                                </span>
                            </div>
                        </div>
                    </li>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-3.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Cuquot forensibus</a></h4>
                                <span class="price">
									<del><span>£</span>42.00</del>
                                <ins><span>£</span>45.00</ins>
                                </span>
                            </div>
                        </div>
                    </li>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-4.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Delicata Liberavisse</a></h4>
                                <span class="price">
									<del><span>£</span>18.00</del>
                                <ins><span>£</span>16.00</ins>
                                </span>
                            </div>
                        </div>
                    </li>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-5.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Ealacerat rationibus</a></h4>
                                <span class="price">
									<del><span>£</span>15.00</del>
                                <ins><span>£</span>20.00</ins>
                                </span>
                            </div>
                        </div>
                    </li>
                    <li class="product col-sm-6 col-md-4">
                        <div class="box-shadow">
                            <div class="box-images">
                                <img src="images/product/p-6.jpg" alt="">
                                <a href="single-product.php" class="button"></a>
                            </div>
                            <div class="box-content">
                                <h4><a href="single-product.php">Nutrive Herbal Tea</a></h4>
                                <span class="price"> 
									<span>£</span>11.00
                                </span>
                            </div>
                        </div>
                    </li> -->
                    <?php
                                }
                                ?>
                </ul>
            </div>
        </div>
        <!--all team end-->

<?php include('footer.php');?>