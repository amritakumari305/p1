 <!--Page header-->
 <div class="page-header  parallax has-image pt-5 pb5">
            <div class="page-header-content">
                <div class="featured-image"></div>
                <div class="container">
                    <div class="header-box">
                        <div class="page-title">
                            <h1><?php echo $_GET["page_name"];?></h1></div>
                        <div class="header-breadcrumb">
                            <nav class="breadcrumbs"><a class="home" href="#"><span>Home</span></a> - <?php echo $_GET["page_name"];?>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--Page header end-->