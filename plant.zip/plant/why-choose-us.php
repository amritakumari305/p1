<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--why choose us-->
        <div class="whychoosepage pagepadding">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1  text-center margbtm80">
                    <h3 class="title">Some Intersting Reason to Choose Us</h3>
                    <div class="desc">
                        <p>People trust us to get a good result.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-xs-12">
                        <div class="grd-icon-box grd-icon-box-9 icon-theme-light  grd-position-icon-left clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-business"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Fully Insured</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">We are fully insured company.
                                        <p>Denouncing pleasure and praising pain was born &amp; we will give you complete account.</p>
                                    </div>
                                    <div class="readmore">
                                        <a href="#"><span class="svg-icon"><i class="flaticon-right"></i></span>Read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="icon-top"><span class="svg-icon"><i class="flaticon-business"></i></span></div>
                        </div>
                        <div class="grd-icon-box grd-icon-box-9 icon-theme-light  grd-position-icon-left clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-safe"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Pet and Kid Safe</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">We are fully insured company.
                                        <p>Denouncing pleasure and praising pain was born &amp; we will give you complete account.</p>
                                    </div>
                                    <div class="readmore">
                                        <a href="#"><span class="svg-icon"><i class="flaticon-right"></i></span>Read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="icon-top"><span class="svg-icon"><i class="flaticon-safe"></i></span></div>
                        </div>
                        <div class="grd-icon-box grd-icon-box-9 icon-theme-light  grd-position-icon-left clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-pilgrim"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Expert Team</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">We are fully insured company.
                                        <p>Denouncing pleasure and praising pain was born &amp; we will give you complete account.</p>
                                    </div>
                                    <div class="readmore">
                                        <a href="#"><span class="svg-icon"><i class="flaticon-right"></i></span>Read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="icon-top"><span class="svg-icon"><i class="flaticon-pilgrim"></i></span></div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-xs-12">
                        <div class="grd-icon-box grd-icon-box-9 icon-theme-light  grd-position-icon-right clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-recommended"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Expert TeamTop Quality Products</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">We are fully insured company.
                                        <p>Denouncing pleasure and praising pain was born &amp; we will give you complete account.</p>
                                    </div>
                                    <div class="readmore">
                                        <a href="#"><span class="svg-icon"><i class="flaticon-right"></i></span>Read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="icon-top"><span class="svg-icon"><i class="flaticon-recommended"></i></span></div>
                        </div>
                        <div class="grd-icon-box grd-icon-box-9 icon-theme-light  grd-position-icon-right clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-meter"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Fast and Reliable</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">We are fully insured company.
                                        <p>Denouncing pleasure and praising pain was born &amp; we will give you complete account.</p>
                                    </div>
                                    <div class="readmore">
                                        <a href="#"><span class="svg-icon"><i class="flaticon-right"></i></span>Read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="icon-top"><span class="svg-icon"><i class="flaticon-meter"></i></span></div>
                        </div>
                        <div class="grd-icon-box grd-icon-box-9 icon-theme-light  grd-position-icon-right clearfix">
                            <div class="icon-box-wrapter">
                                <a href="#" class="icon">
                                    <div class="icon-content"><span class="svg-icon"><i class="flaticon-discount"></i></span></div>
                                </a>
                                <a href="#" class="emtry-title">
                                    <p class="title">Affortable Price</p>
                                </a>
                                <div class="content">
                                    <div class="descreption">We are fully insured company.
                                        <p>Denouncing pleasure and praising pain was born &amp; we will give you complete account.</p>
                                    </div>
                                    <div class="readmore">
                                        <a href="#"><span class="svg-icon"><i class="flaticon-right"></i></span>Read more</a>
                                    </div>
                                </div>
                            </div>
                            <div class="icon-top"><span class="svg-icon"><i class="flaticon-discount"></i></span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--why choose us end-->
<?php include('footer.php');?>