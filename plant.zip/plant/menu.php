<?php 
include("common/config.php");
?>
<body class="home page-template-template-homepage header-transparent   header-sticky header-v3 hide-topbar-mobile">
    <div id="page" class="hfeed site">

        <!-- Preloader-->
        <div class="preloader"></div>

        <!-- masthead -->
        <header id="masthead" class="site-header">
            <div class="header-main clearfix">
                <div class="container">
                    <div class="row menu-row">
                        <div class="site-logo col-lg-3 col-sm-9 col-xs-9">
                        <?php
                            $result1 = mysqli_query($conn,"SELECT * FROM logo");
                            $rows = mysqli_fetch_array($result1)
                            
                        ?>
                        <a href="<?php echo $rows["logo_link"]; ?>" class="logo"> <img src="admin/<?php echo $rows["site_logo"]; ?>" alt="Plant" class="logo"> </a>
                        
                            <h1 class="site-title"><a href="#" rel="home">GRD</a></h1>
                            <h2 class="site-description">Just another WordPress Theme Sites site</h2>
                        </div>
                        <div class="header-content col-sm-9 col-xs-12">
                            <!-- top bar -->
                            <div id="topbar" class="topbar ">
                                <div class="topbar-widgets clearfix">
                                <?php
                                            $result1 = mysqli_query($conn,"SELECT * FROM numb_mail");
                                            $rows = mysqli_fetch_array($result1)
                                            
                                        ?>
                                    <div class="widget">
                                                   
                                        <span class="svg-icon"><i class="flaticon-call-answer"></i></span> +<?php echo $rows["site_numb"]; ?>
                                    </div>

                                    <div class="widget">
                                       
                                        <div class="extra-menu-item menu-item-socials socials">
                                        <?php
                                            $result1 = mysqli_query($conn,"SELECT * FROM social_media");
                                            while($rows = mysqli_fetch_array($result1)){
                                            
                                        ?>
                                            <a href="<?php echo $rows["sm_link"]; ?>" target="_blank"><i class="<?php echo $rows["sm_img"]; ?>"></i></a>
                                            
                                            <?php
                                           }
                                        ?>
                                        </div>
                                        
                                    </div>
                                    <div class="widget">
                                        <div class="quote-content"> <a href="#request_form">Request a Quote</a></div>
                                    </div>
                                </div>
                            </div>
                            <!-- top bar -->
                            <div class="site-menu">
                                <nav id="site-navigation" class="main-nav primary-nav nav">
                                    <ul class="menu">


                                        <?php
                                        $xyz=0;
                                            $result = mysqli_query($conn,"SELECT * FROM menu");
                                    
                                            while($row = mysqli_fetch_array($result)) {
                                                if($row["menu_link"]!='')
                                                {
                                                    
                                        ?>
                                            <li class="<?php if($xyz==0){echo "active"; $xyz++; }?>"><a href="<?php echo $row["menu_link"]; ?>?page_name=<?php echo $row["menuname"]; ?>"><?php echo $row["menuname"]; ?></a></li>


                                        <?php
                                                }   
                                            else
                                            {
                                        ?>
                                        <li class="has-children  <?php if($xyz==0){echo "active"; $xyz++; }?>"><a href="#" class="dropdown-toggle"><?php echo $row["menuname"]; ?></a>
                                            <ul class="sub-menu">
                                            <?php
                                                $result1 = mysqli_query($conn,"SELECT * FROM submenu where menutype=".$row["menu_id"]);
                                                                                
                                                while($row1 = mysqli_fetch_array($result1)) {
                                                
                                            ?>
                                                <li><a href="<?php echo $row1["submenu_link"]; ?>?page_name=<?php echo $row1["submenu_name"]; ?>"><?php echo $row1["submenu_name"]; ?></a></li>

                                                <?php
                                                }
                                                echo " </ul>  </li>";

                                            }


                                        }
                                    ?>
                                        
                                        <li><a href="cart.php"><i class="flaticon-shopping-cart"></i></a></li>
                                        <li id="mf-active-menu" class="mf-active-menu"></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="navbar-toggle col-xs-3"><span id="mf-navbar-toggle" class="navbar-icon"> <span class="navbars-line"></span> </span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- masthead end -->

      