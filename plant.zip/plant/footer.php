<?php 
include("common/config.php");
?>
 <!-- footer -->
        <div class="footer-widgets">
            <div class="container">
                <div class="row">
                    <div class="footer-sidebar footer-1 col-xs-12 col-sm-6 col-md-3">
                        <div class="widget widget_media_image">
                        <?php
                            $result1 = mysqli_query($conn,"SELECT * FROM logo");
                            $rows = mysqli_fetch_array($result1)
                            
                        ?>
                        <a href="<?php echo $rows["logo_link"]; ?>" class="logo"> <img src="admin/<?php echo $rows["site_logo"]; ?>" alt="Plant" class="logo"> </a>
                        </div>
                        <h4> Plant</h4>
                        <p> How all this mistaken idea of pleasure &praising pain completed.</p>
                        <div class="map-link">
                            <a href="#"><span class="svg-icon"><i class="flaticon-right"></i></span> Find Us On Map</a>
                        </div>

                    </div>
                    <div class="footer-sidebar footer-2 col-xs-12 col-sm-6 col-md-3">
                        <div class="widget">
                            <h4 class="widget-title">Usefull Links</h4>
                            <ul class="menu">
                                <li><a href="about-us.php?page_name=About Us">About Us</a></li>
                                <li><a href="shop.php?page_name=Products">Product</a></li>
                                <li><a href="gallery-classic.php?page_name=Gallery">Our Projects</a></li>
                                <li><a href="#request_form">Get a Quote</a></li>
                                <li><a href="services.php?page_name=Sevices">Services</a></li>
                                <li><a href="blog.php?page_name=Blog">Blog</a></li>
                            </ul>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="footer-sidebar footer-3 col-xs-12 col-sm-6 col-md-3">
                        <div class="widget">
                            <h4 class="widget-title">Working Hours</h4>
                            <div class="working">
                                <div> <span>Summer Hours:</span> (May to Nov)</div>
                                <div> Mon - Satday: 9.00 to 18.00
                                    <br> Sunday: <span class="green">Closed</span></div>
                            </div>
                            <div class="working">
                                <div> <span>Winter Hours:</span> (Dec to Apr)</div>
                                <div> Mon - Satday: 9.00 to 17.00
                                    <br> Sunday: <span class="green">Closed</span></div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-sidebar footer-4 col-xs-12 col-sm-6 col-md-3">
                        <div class="widget">
                            <h4 class="widget-title">Subscribe Us</h4>
                            <p> Subscribe us to get latest news and usefull tips.</p>
                            <form method="post" data-id="270" data-name="">
                                <div class="mc4wp-form-fields">
                                    <input name="EMAIL" placeholder="Your email address" required="" type="email">
                                    <input value="Sign up" type="submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- footer end -->

        <!-- footer middle-->
        <div id="footer-widgets-middle" class="footer-widgets widgets-area footer-middle">
            <div class="container">
                <div class="row">
                    <?php
                                            $result1 = mysqli_query($conn,"SELECT * FROM numb_mail");
                                            $rows = mysqli_fetch_array($result1)
                                            
                                        ?>
                    <div class="col-xs-12 col-sm-4 col-md-4 email"><i class="fa fa-envelope"></i> <?php echo $rows["site_mail"]; ?></div>
                    <div class="col-xs-12 col-sm-4 col-md-4 phone">
                   
                        <div>Call Us On</div><span> +<?php echo $rows["site_numb"]; ?></span>
                    </div>
                    <div class="col-xs-12 col-sm-4 col-md-4 social">
                        <div class="socials footer-social">
                           
                        <?php
                                            $result1 = mysqli_query($conn,"SELECT * FROM social_media");
                                            while($rows = mysqli_fetch_array($result1)){
                                            
                                        ?>
                                            <a href="<?php echo $rows["sm_link"]; ?>" target="_blank"><i class="<?php echo $rows["sm_img"]; ?>"></i></a>
                                            
                                            <?php
                                           }
                                        ?>
                           
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- footer middle end-->

        <!-- copyright -->
        <footer id="colophon" class="site-footer">
            <div class="container footer-info">
                <div class="footer-copyright text-center"> Copyrights &copy; <a href="#">Plant</a>. All rights reserved.</div>
            </div>
        </footer>
        <!-- copyright end-->
    </div>
    <!--End pagewrapper-->

    <!--primary-mobile-nav-->
    <div class="primary-mobile-nav" id="primary-mobile-nav" role="navigation">
        <div class="mobile-nav-content">
            <a href="#" class="close-canvas-mobile-panel">×</a>
            <ul class="menu">
                <?php
                                        $xyz=0;
                                            $result = mysqli_query($conn,"SELECT * FROM menu");
                                    
                                            while($row = mysqli_fetch_array($result)) {
                                                if($row["menu_link"]!='')
                                                {
                                                    
                ?>
                <li class="current-menu-item <?php if($xyz==0){echo "active"; $xyz++; }?>"><a href="<?php echo $row["menu_link"]; ?>?page_name=<?php echo $row["menuname"]; ?>"><?php echo $row["menuname"]; ?></a></li>
                <?php
                                                }   
                                            else
                                            {
                                        ?>
               
                <li class="menu-item-has-children <?php if($xyz==0){echo "active"; $xyz++; }?>"><a href="#" class="dropdown-toggle"><?php echo $row["menuname"]; ?></a>
                    <ul class="sub-menu">
                    <?php
                                                $result1 = mysqli_query($conn,"SELECT * FROM submenu where menutype=".$row["menu_id"]);
                                                                                
                                                while($row1 = mysqli_fetch_array($result1)) {
                                                
                                            ?>
                        <li><a href="<?php echo $row1["submenu_link"]; ?>?page_name=<?php echo $row1["submenu_name"]; ?>"><?php echo $row1["submenu_name"]; ?></a></li>
                       
                        <?php
                                                }
                                                echo " </ul>  </li>";

                                            }


                                        }
                                    ?>
                <!-- <li class="menu-item-has-children"><a href="#" class="dropdown-toggle">Services</a>
                    <ul class="sub-menu">
                        <li><a href="design-planting.php">Design & Planting</a></li>
                        <li><a href="lawn-garden-care.php">Lawn & Garden Care</a></li>
                        <li><a href="snow-cleaning.php">Snow Cleaning</a></li>
                        <li><a href="spring-cleanup.php">Spring Cleanup</a></li>
                        <li><a href="hardscaping.php">Hardscaping</a></li>
                        <li class="last-child"><a href="irrigation-system.php">Irrigation System</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="projects.php" class="dropdown-toggle">Gallery</a>
                    <ul class="sub-menu">
                        <li><a href="gallery-classic.php">Gallery Classic</a></li>
                        <li><a href="Gallery-full-width-2.php">Gallery Full Width</a></li>
                        <li><a href="gallery-modern.php">Gallery Modern</a></li>
                        <li class="last-child"><a href="single-gallery.php">Single Gallery</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="#" class="dropdown-toggle">Blog</a>
                    <ul class="sub-menu">
                        <li><a href="blog-default.php">Blog Default</a></li>
                        <li><a href="blog-large-image.php">Blog Large Image</a></li>
                        <li class="last-child"><a href="blog-single.php">Single Post</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="#" class="dropdown-toggle">Shop</a>
                    <ul class="sub-menu">
                        <li><a href="shop.php">Our Products</a></li>
                        <li><a href="single-product.php">Product Single</a></li>
                        <li><a href="cart.php">Shopping Cart</a></li>
                        <li><a href="checkout.php">Checkout</a></li>
                        <li class="last-child"><a href="my-account.php">My account</a></li>
                    </ul>
                </li>
                <li><a href="contact.php">Contact</a></li> -->
            </ul>
        </div>
    </div>
    <div id="off-canvas-layer" class="off-canvas-layer"></div>
    <!--primary-mobile-nav end-->

    <!--Scroll to top-->
    <a id="scroll-top" class="backtotop" href="#page-top"><i class="fa fa-angle-up"></i></a>

    <!-- jquery Liabrary -->
    <script src="js/jquery-1.12.4.min.js"></script>
    <!-- bootstrap v3.3.6 js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- fancybox js -->
    <script src="js/jquery.fancybox.pack.js"></script>
    <script src="js/jquery.fancybox-media.js"></script>
    <script src="../../../unpkg.com/isotope-layout%403.0.6/dist/isotope.pkgd.min.js"></script>
    <!-- owl.carousel js -->
    <script src="js/owl.js"></script>
    <!-- Slick slide js -->
    <script src="js/slick.js"></script>
    <!-- counter js -->
    <script src="js/jquery.countTo.js"></script>
    <!-- validate js -->
    <script src="js/validate.js"></script>

    <!-- REVOLUTION JS FILES -->
    <script type="text/javascript" src="js/revolution/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="js/revolution/jquery.themepunch.revolution.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.actions.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.carousel.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.kenburn.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.layeranimation.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.migration.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.navigation.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.parallax.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.slideanims.min.js"></script>
    <script type="text/javascript" src="js/revolution/extensions/revolution.extension.video.min.js"></script>

    <!-- script JS  -->
    <script src="js/scripts.min.js"></script>
    <script src="js/script.js"></script>
</body>

</html>