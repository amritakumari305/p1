<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--all team-->
        <div class="loginpage pagepadding woocommerce">
            <div class="container">
                <div class="woocommerce">
                    <h2>Login Now</h2>
                    <form class="login">
                        <p class="form-row">
                            <input placeholder="Username*" class="input-text" name="username" id="username" type="text">
                        </p>
                        <p class="form-row">
                            <input class="input-text" placeholder="Password*" name="password" type="password">
                        </p>
                        <p class="form-row submit-button">
                            <input class="woocommerce-Button button" name="login" value="Login" type="submit">
                            <label class="remember">
                                <input name="rememberme" value="forever" type="checkbox"> <span>Remember me</span>
                            </label>
                        </p>
                        <p class="lost_password">
                            <a href="recovery.php">Lost your password?</a>
                        </p>
                        <p class="lost_password">
                            <a href="register.php">No Account? SIGN UP</a>
                        </p>
                    </form>
                </div>
            </div>
        </div>
        <!--all team end-->
<?php include('footer.php');?>