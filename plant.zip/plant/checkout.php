<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--all team-->
        <div class="checkoutpage pagepadding woocommerce">
            <div class="container">
                <div class="row check_out_form">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 submit_form">
                        <h3>Billing Details</h3>

                        <form action="#" class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Country *</span>
                                <input type="text">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <span>First Name *</span>
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <span>Last Name *</span>
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Address</span>
                                <input placeholder="" type="text">
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Town / City *</span>
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Contact Info *</span>
                                <input placeholder="Email Address" type="email">
                                <input placeholder="Phone Number" type="text">
                            </div>
                        </form>
                    </div>
                    <!-- /submit_form -->

                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 submit_form shipping_address">
                        <h3>Shipping Address</h3>
                        <form action="#" class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Country *</span>
                                <input type="text">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <span>First Name *</span>
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <span>Last Name *</span>
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Address</span>
                                <input placeholder="" type="text">
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Town / City *</span>
                                <input placeholder="" type="text">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span>Other Notes</span>
                                <textarea></textarea>
                            </div>
                        </form>
                    </div>
                    <!-- /submit_form -->
                </div>
                <div class="cart_table">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <div class="table-responsive">
                                <table class="table table-1 margtop40">

                                    <tr>
                                        <th><span>Product</span></th>
                                        <th><span>Quantity</span></th>
                                        <th><span>Total</span></th>
                                    </tr>

                                    <tr>
                                        <td class="flex_item clear_fix">
                                            <h6 class="float_left">The Innovator</h6>
                                        </td>
                                        <td>
                                            <input name="quantity" min="0" value="1" type="number">
                                        </td>
                                        <td><span>$25.00</span></td>
                                    </tr>
                                    <!-- /tr -->

                                    <tr>
                                        <td class="flex_item clear_fix">
                                            <h6 class="float_left">Lords of Strategy</h6>
                                        </td>
                                        <td>
                                            <input name="quantity" min="0" value="3" type="number">
                                        </td>
                                        <td><span>$69.00</span></td>
                                    </tr>
                                    <!-- /tr -->

                                    <tr>
                                        <td class="flex_item clear_fix">
                                            <h6 class="float_left">Art of the Start</h6>
                                        </td>
                                        <td>
                                            <input name="quantity" min="0" value="2" type="number">
                                        </td>
                                        <td><span>$29.00</span></td>
                                    </tr>
                                    <!-- /tr -->

                                </table>
                            </div>
                            <!-- /table-responsive -->
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                            <h3>Cart Totals</h3>
                            <div class="table-responsive">
                                <table class="table table-2">
                                    <tbody>
                                        <tr>
                                            <td><span>Cart Subtotal</span></td>
                                            <td><span>$146.00</span></td>
                                        </tr>
                                        <tr>
                                            <td><span>Shipping and Handling</span></td>
                                            <td><span>Free Shipping</span></td>
                                        </tr>
                                        <tr>
                                            <td><span>Order Total</span></td>
                                            <td><span>$146.00</span></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /table-responsive -->
                            <div class="payment_system">
                                <div class="pay1">
                                    <input type="checkbox">
                                    <span>Direct Bank Transfer</span>
                                    <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference.order won’t be shipped until the funds have cleared.</p>
                                </div>
                                <div class="pay1">
                                    <input type="checkbox">
                                    <span>Cheque Payment</span>
                                </div>
                                <div class="pay1">
                                    <input type="checkbox">
                                    <span>Credit Card</span>
                                </div>
                                <div class="pay1">
                                    <input type="checkbox">
                                    <span>Paypal</span>
                                </div>
                                <a href="login.php" class="button alt pull-right">Place Order</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!--all team end-->
<?php include('footer.php');?>