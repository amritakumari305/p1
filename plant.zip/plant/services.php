<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--service details-->
        <div class="single-service pagepadding">
            <div class="container">
                <div class="row">
                    <div class="col-md-9 col-sm-12">
                        <div class="serdetail-left paddright20">
                            <div class="grd-section-title  grd_title-type-2 semibold margbtm30">
                                <h3 class="title">We love your garden just as much as you do</h3>
                            </div>
                            <p>We provide residential lawn maintenance and care services ranging from lawn mowing to fertilization. If you are inter-ested in scheduling regular landscaping and lawn care services, contact our experts at The GRD. Keeping lawn green, vibrant, healthy, and free of weeds is a job for experts. Our team provides regular services designed toensure that your lawn stays looking its best year-round.</p>
                            <img class="margbtm80 margtop30" src="images/services/single-img.jpg" alt="detail-service" />

                            <div class="clearfix margbtm80">
                                <div class="col-sm-4 no-padding">
                                    <div class="careservice">
                                        <div class="grd-section-title sc-dark grd_title-type-2 semibold">
                                            <h3 class="title">Lawn Care Services include</h3>
                                            <div class="desc">
                                                <p>Expound the actual teach- ings of the great explorer of the truth, the master builder of human happiness again is there anyone who loves or pursues or desires.</p>
                                            </div>
                                        </div>
                                        <div class="read-more"><a href="#"><i class="flaticon-right"></i> Read more</a></div>
                                    </div>
                                </div>
                                <div class="col-sm-4 no-padding">
                                    <div class="grd-icon-box grd-icon-box-11 icon-theme-light">
                                        <div class="icon-box-wrapter">
                                            <a href="#" class="icon">
                                                <div class="icon-content"><i class="flaticon-shears"></i></div>
                                            </a>
                                            <a href="#" class="emtry-title">
                                                <p class="title">Pruning &amp; Trimming</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 no-padding">
                                    <div class="grd-icon-box grd-icon-box-11 icon-theme-light">
                                        <div class="icon-box-wrapter">
                                            <a href="#" class="icon">
                                                <div class="icon-content"><i class="flaticon-bug"></i></div>
                                            </a>
                                            <a href="#" class="emtry-title">
                                                <p class="title">Pruning &amp; Trimming</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 no-padding">
                                    <div class="grd-icon-box grd-icon-box-11 icon-theme-light">
                                        <div class="icon-box-wrapter">
                                            <a href="#" class="icon">
                                                <div class="icon-content"><i class="flaticon-cannabis"></i></div>
                                            </a>
                                            <a href="#" class="emtry-title">
                                                <p class="title">Pruning &amp; Trimming</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4 no-padding">
                                    <div class="grd-icon-box grd-icon-box-11 icon-theme-light">
                                        <div class="icon-box-wrapter">
                                            <a href="#" class="icon">
                                                <div class="icon-content"><i class="flaticon-mushroom"></i></div>
                                            </a>
                                            <a href="#" class="emtry-title">
                                                <p class="title">Pruning &amp; Trimming</p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="grd-section-title  grd_title-type-2 semibold margbtm40">
                                <h3 class="title">Yearly Scheduling Packages</h3>
                                <div class="desc">
                                    <p>We also provide our lawn care customers with three unique scheduling packages:</p>
                                </div>
                            </div>
                            <div class="clearfix detail-pricing">
                                <div class="col-sm-4 col-xs-12 no-padding">
                                    <div class="dl_prices_3 style-1 text-dark">
                                        <h3>Standard Plan</h3>
                                        <ul>
                                            <li>Install a Patio or Pathway</li>
                                            <li>Install Landscaping</li>
                                            <li>Waterproof a Deck Costs</li>
                                            <li>-</li>
                                            <li>Remove a Tree Stump</li>
                                        </ul>
                                        <div class="price">
                                            <span class="unit-pr">$</span>
                                            <span class="price-main">99</span>
                                            <span class="text-after">Per<br> month</span>
                                        </div>
                                        <div class="dl-button"><a href="#">comfrim</a></div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-xs-12 no-padding">
                                    <div class="dl_prices_3 style-1 text-dark bg-gray">
                                        <h3>Silver Plan</h3>
                                        <ul>
                                            <li>Install a Patio or Pathway</li>
                                            <li>Install Landscaping</li>
                                            <li>Waterproof a Deck Costs</li>
                                            <li>-</li>
                                            <li>Remove a Tree Stump</li>
                                        </ul>
                                        <div class="price">
                                            <span class="unit-pr">$</span>
                                            <span class="price-main">120</span>
                                            <span class="text-after">Per<br> One Year</span>
                                        </div>
                                        <div class="dl-button"><a href="#">comfrim</a></div>
                                    </div>
                                </div>
                                <div class="col-sm-4 col-xs-12 no-padding">
                                    <div class="dl_prices_3 style-1 text-dark">
                                        <h3>Golden Plan</h3>
                                        <ul>
                                            <li>Install a Patio or Pathway</li>
                                            <li>Install Landscaping</li>
                                            <li>Waterproof a Deck Costs</li>
                                            <li>-</li>
                                            <li>Remove a Tree Stump</li>
                                        </ul>
                                        <div class="price">
                                            <span class="unit-pr">$</span>
                                            <span class="price-main">199</span>
                                            <span class="text-after">Per<br> 5 Years</span>
                                        </div>
                                        <div class="dl-button"><a href="#">comfrim</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-12">
                        <div class="service-sidebar paddleft20">
                            <div class="widget widget_categories">
                                <h4 class="widget-title">Our Services</h4>
                                <ul class="service-category">
                                    <li><a href="#">Design &amp; Planting</a></li>
                                    <li><a href="#">Hardscaping</a></li>
                                    <li><a href="#">Irrigation System</a></li>
                                    <li><a href="#">Lawn &amp; Garden Care</a></li>
                                    <li><a href="#">Snow Cleaning</a></li>
                                    <li><a href="#">Spring &amp; Fall Cleanup</a></li>
                                </ul>
                            </div>
                            <div class="widget">
                                <h4 class="widget-title">Our Brochures</h4>
                                <div class="brochures clearfix">
                                    <div class="col-md-12">
                                        <div class="pull-left"> <i class="fa fa-file-word-o"></i></div>
                                        <div>
                                            <div class="title"> <a href="#">Last Year Growth</a></div>
                                            <div> 1.25 MB</div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="pull-left"> <i class="fa fa-file-word-o"></i></div>
                                        <div>
                                            <div class="title"> <a href="#">Company Profile</a></div>
                                            <div> 2.30 MB</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <form class="wpcf7-form" novalidate="novalidate">
                                <div class="faq-form">
                                    <h2>Ask Your Questions</h2>
                                    <p>
                                        <input name="y-name" value="" size="40" placeholder="Name" type="text">
                                        <br>
                                        <input name="email" value="" size="40" placeholder="Email" type="email">
                                        <br>
                                        <textarea placeholder="Your Question"></textarea>
                                        <input value="Submit Now" class="wpcf7-submit" type="submit">
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--service details end-->
<?php include('footer.php');?>