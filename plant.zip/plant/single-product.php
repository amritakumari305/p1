<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--single product-->
        <div class="shopedetail pagepadding woocommerce">
            <div class="container product">
                <div class="row">
                    <div class="col-sm-5 col-md-5">
                        <div class="pdetail-image">
                            <img src="images/product/p-5-big.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-offset-1 col-md-6">
                        <div class="productinfo">
                            <h2 class="product_title entry-title">Win Your Friends</h2>
                            <div class="star-rating clearfix"><span></span></div>
                            <p class="price">£<span>15.00</span>
                            </p>
                            <div class="woocommerce-product-details__short-description">
                                <p>Working from home meant we couldsnack &amp; coffee breaks change our desks or view, good, drink on the job, even spend getting roughday in pajamas consequences.</p>
                            </div>
                            <form class="cart" action="#" method="post">
                                <div class="quantity">
                                    <span class="decrease"><i class="fa fa-caret-down"></i></span>
                                    <input class="input-text qty text" step="1" min="1" max="20" name="quantity" value="1" title="Qty" size="4" pattern="[0-9]*"  type="number">
                                    <span class="increase"><i class="fa fa-caret-up"></i></span>
                                </div>
                                <button type="submit" class="button alt"><a href="cart.php">Add to Cart</a></button>
                            </form>
                            <div class="product_meta">
                                <span>SKU: <span>woo-album</span></span>
                                <span>Category: <a href="#">Social &amp; Public Sector</a></span>
                                <span>Tags: <a href="#">Experts</a>, 
								<a href="#">Services</a>, 
								<a href="#" rel="tag">Tips</a>, 
								<a href="#" rel="tag">Wealth</a></span>
                            </div>
                        </div>
                    </div>
                </div>
                <!--product tab-->
                <div class="panel with-nav-tabs panel-default woocommerce-tabs">
                    <div class="panel-heading">
                        <ul class="nav nav-tabs tabs">
                            <li class="active"><a href="#tab1default" data-toggle="tab" aria-expanded="true">Description</a></li>
                            <li class=""><a href="#tab3default" data-toggle="tab" aria-expanded="false">Reviews (0)</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="tab-content">
                            <div class="tab-pane panel fade active in" id="tab1default">
                                <h2>Description</h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis orci ac odio dictum tincidunt. Donec ut metus leo. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Sed luctus, dui eu sagittis sodales, nulla nibh sagittis augue, vel porttitor diam enim non metus. Vestibulum aliquam augue neque. Phasellus tincidunt odio eget ullamcorper efficitur. Cras placerat ut turpis pellentesque vulputate. Nam sed consequat tortor. Curabitur finibus sapien dolor. Ut eleifend tellus nec erat pulvinar dignissim. Nam non arcu purus. Vivamus et massa massa.</p>
                            </div>

                            <div class="tab-pane panel fade" id="tab3default">
                                <h2 class="woocommerce-Reviews-title">Reviews</h2>
                                <p>There are no reviews yet.</p>
                                <h3 id="reply-title" class="comment-reply-title mrgtop40">Be The First To Review “The Innovator</h3>
                                <div id="reviews">
                                    <div id="review_form_wrapper">
                                        <div id="review_form">
                                            <div id="respond" class="comment-respond">
                                                <form id="commentform" class="comment-form clearfix" novalidate="">
                                                    <div class="comment-form-rating">
                                                        <p>
                                                            <label>Your Rating</label>
                                                        </p>
                                                        <div class="star-rating">
                                                            <span style="width:100%"></span></div>
                                                    </div>
                                                    <p class="comment-form-comment">
                                                        <label for="comment">Review <span class="required">*</span></label>
                                                        <textarea placeholder="Write Your Comments..." id="comment" name="comment" cols="45" rows="8" required=""></textarea>
                                                    </p>
                                                    <p class="comment-form-author">
                                                        <input id="author" name="author" value="" placeholder="Your Name" size="30" required="" type="text">
                                                    </p>
                                                    <p class="comment-form-email">
                                                        <input id="email" name="email" value="" placeholder="Email Address" size="30" required="" type="email">
                                                    </p>
                                                    <p class="comment-form-url">
                                                        <input id="url" name="url" value="" placeholder="Website" size="30" type="text">
                                                    </p>
                                                    <p class="comment-form-phone">
                                                        <input id="phone" name="phone" placeholder="Phone Num" size="30" type="text">
                                                    </p>
                                                    <div class="clearfix"></div>
                                                    <p class="form-submit">
                                                        <input name="submit" id="submit" class="submit" value="Submit Now" type="submit">
                                                    </p>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="related">
                    <h2 class="related-title mf-heading-primary">Related Products</h2>
                    <ul class="products row">
                        <li class="product col-sm-6 col-md-4">
                            <div class="box-shadow">
                                <div class="box-images">
                                    <img src="images/product/p-1.jpg" alt="">
                                    <a href="#" class="button"></a>
                                </div>
                                <div class="box-content">
                                    <h4><a href="#">Accusata accommodare</a></h4>
                                    <span class="price">
										<del><span>£</span>20.00</del>
                                    <ins><span>£</span>18.00</ins>
                                    </span>
                                </div>
                            </div>
                        </li>
                        <li class="product col-sm-6 col-md-4">
                            <div class="box-shadow">
                                <div class="box-images">
                                    <img src="images/product/p-7.jpg" alt="">
                                    <a href="#" class="button"></a>
                                </div>
                                <div class="box-content">
                                    <h4><a href="#">Alenit electramutmea</a></h4>
                                    <span class="price">
										<span>£</span>18.00
                                    </span>
                                </div>
                            </div>
                        </li>
                        <li class="product col-sm-6 col-md-4">
                            <div class="box-shadow">
                                <div class="box-images">
                                    <img src="images/product/p-8.jpg" alt="">
                                    <a href="#" class="button"></a>
                                </div>
                                <div class="box-content">
                                    <h4><a href="#">Alia expetendisat</a></h4>
                                    <span class="price">
										<span>£</span>45.00
                                    </span>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!--all team end-->

<?php include('footer.php');?>