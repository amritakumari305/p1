<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--blog list-->
        <div class="blogpage pagepadding ">
            <div class="container">
            <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM blog where blog_id=".$_GET["id"]);
                                    $rows = mysqli_fetch_array($result1)
                                    
                                ?>
                <div class="row blog content-sidebar">
                    <div class="col-sm-12 col-md-8 content-area">
                        <div class="blog-details">
                            <header class="entry-header">
                                <div class="entry-thumbnail margbtm30"><img src="admin/<?php echo $rows["blog_img"]; ?>" alt=""></div>
                                <h1 class="entry-title"><?php echo $rows["blog_head"]; ?></h1>
                                <div class="entry-meta">
                                    <a href="#"><?php echo $rows["blog_date"]; ?></a> / by <a href="#"><?php echo $rows["blog_by"]; ?></a>
                                </div>
                            </header>
                            <div class="entry-content">
                                <p><?php echo $rows["blog_cont"]; ?></p>
                                <br>
                                
                               
                               
                                
                              
                                <footer class="entry-footer">
                                    <span class="tags-links">Tags: 
										<a href="#">Assurance</a><span>,</span>
                                    <a href="#">Experts</a><span>,</span>
                                    <a href="#">Flowers</a>
                                    </span>
                                    <div class="footer-socials"><span class="svg-icon"><i class="fa fa-share-alt"></i></span> Share:
                                        <div class="social-links">
                                            <a class="grd-facebook" href="#" target="_blank"><i class="fa fa-facebook-f"></i></a>
                                            <a class="grd-twitter" href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                                            <a class="grd-pinterest" href="#" target="_blank"><i class="fa fa-pinterest-p"></i></a>
                                            <a class="grd-google-plus" href="#" target="_blank"><i class="fa fa-instagram"></i></a>       
                                        </div>
                                    </div>
                                </footer>
                                
                               
                            </div>

                        </div>
                    </div>
                    <div class="primary-sidebar col-sm-12 col-md-4">
                        <div class="">
                            <div class="widget widget_search">
                                <h4 class="widget-title">Search</h4>
                                <form class="search-form" >
                                    <label>
                                        <span class="screen-reader-text">Search for:</span>
                                        <input class="search-field" placeholder="Search …" value="" name="s" type="search">
                                    </label>
                                    <input class="search-submit" value="Search" type="submit">
                                </form>
                            </div>
                            <div class="widget widget_recent_entries">
                                <h4 class="widget-title">Recent Post</h4>
                                <ul>
                                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM blog limit 0,3");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                                    <li> <a href="<?php echo $rows["blog_link"]; ?>"><?php echo $rows["blog_head"]; ?></a> <span class="post-date"><?php echo $rows["blog_date"]; ?></a></span></li>
                                    <!-- <li> <a href="#">Special Message Regarding Garden</a> <span class="post-date">August 9, 2018</span></li>
                                    <li> <a href="#">Media Hacks for the Entrepreneur</a> <span class="post-date">August 9, 2018</span></li> -->
                                <?php
                                    }
                                ?>
                                </ul>
                            </div>
                            <div class="widget widget_categories">
                                <h4 class="widget-title">Categories</h4>
                                <ul>
                                <?php
                                    $result3 = mysqli_query($conn,"SELECT * FROM blog limit 0,5");
                                    while($row1 = mysqli_fetch_array($result3)) {
                                    
                                ?>
                                    <li><a href="<?php echo $row1["blog_link"]; ?>"><?php echo $row1["blog_cat"]; ?></a></li>
                                   
                                <?php
                                    }
                                ?>
                                </ul>
                            </div>
                            <div class="widget widget_tag_cloud">
                                <h4 class="widget-title">Tag Cloud</h4>
                                <div class="tagcloud">
                                <?php
                                    $result3 = mysqli_query($conn,"SELECT * FROM blog");
                                    while($row1 = mysqli_fetch_array($result3)) {
                                    
                                ?>
                                    <a href="#"><?php echo $row1["blog_tag"]; ?></a>
                                    <!-- <a href="#">Experts</a>
                                    <a href="#">Flowers</a>
                                    <a href="#">Irrigatio</a>
                                    <a href="#">Irrigation</a>
                                    <a href="#">Plants</a>
                                    <a href="#">Tips</a> -->
                                <?php
                                    }
                                ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--blog list end-->

       

<?php include('footer.php');?>