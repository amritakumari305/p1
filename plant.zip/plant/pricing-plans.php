<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--all team-->
        <div class="pricingpage pagepadding">
            <div class="container">
                <div class="grd-section-title  grd_title-type-2 margbtm20">
                    <h3 class="title  fsize30">Gardening Service</h3>
                </div>
                <div class="dl_prices_1 text-dark ">
                    <div class="title-price form">
                        <div>Type of garden service</div>
                        <div>Specific services</div>
                        <div></div>
                    </div>
                    <div class="main_table form">
                        <div class="srvtype">
                            <h3>Garden maintenance</h3></div>
                        <div>
                            <ul>
                                <li><i class="fa fa-leaf"></i>Jet Washing</li>
                                <li><i class="fa fa-leaf"></i>Sourcing &amp; Supplying</li>
                                <li><i class="fa fa-leaf"></i>Sourcing &amp; Supplying</li>
                            </ul>
                        </div>
                        <div class="pvariation">
                            <p><span>$50</span><span>/Sq.Ft</span></p>
                        </div>
                    </div>
                    <div class="main_table form">
                        <div class="srvtype">
                            <h3>Lawn Care</h3></div>
                        <div>
                            <ul>
                                <li><i class="fa fa-leaf"></i>Jet Washing</li>
                                <li><i class="fa fa-leaf"></i>Sourcing &amp; Supplying</li>
                                <li><i class="fa fa-leaf"></i>Gutter Cleaning</li>
                            </ul>
                        </div>
                        <div class="pvariation active">
                            <p><span>$140</span><span>/Sq.Ft</span></p>
                        </div>
                    </div>
                    <div class="main_table form">
                        <div class="srvtype">
                            <h3>Plant Care</h3></div>
                        <div>
                            <ul>
                                <li><i class="fa fa-leaf"></i>Jet Washing</li>
                                <li><i class="fa fa-leaf"></i>Sourcing &amp; Supplying</li>
                                <li><i class="fa fa-leaf"></i>Gutter Cleaning</li>
                            </ul>
                        </div>
                        <div class="pvariation">
                            <p><span>$54</span><span>/Sq.Ft</span></p>
                        </div>
                    </div>
                    <div class="main_table form">
                        <div class="srvtype">
                            <h3>"Soft" landscaping</h3></div>
                        <div>
                            <ul>
                                <li><i class="fa fa-leaf"></i>Jet Washing</li>
                                <li><i class="fa fa-leaf"></i>Sourcing &amp; Supplying</li>
                                <li><i class="fa fa-leaf"></i>Gutter Cleaning</li>
                            </ul>
                        </div>
                        <div class="pvariation">
                            <p><span>$282</span><span>/Sq.Ft</span></p>
                        </div>
                    </div>
                </div>
                <div class="grd-section-title  grd_title-type-1  text-center margbtm40">
                    <h3 class="title">Landscaping Service</h3>
                </div>
                <div class="dl_prices_2 text-light ">
                    <div class="title-price form">
                        <div class="active">Landscaping Services</div>
                        <div>Estimated Price</div>
                    </div>
                    <div class="main_price form">
                        <div class="graybg">
                            <p>Installing raised planters (if the area is already laid to lawn)</p>
                        </div>
                        <div>
                            <p>$265 - $900</p>
                        </div>
                    </div>
                    <div class="main_price form">
                        <div>
                            <p>Fencing (Includes price of labour plus materials)</p>
                        </div>
                        <div class="graybg">
                            <p>$800 - $1200</p>
                        </div>
                    </div>
                    <div class="main_price form">
                        <div class="graybg">
                            <p>Laying ornamental gravel paths</p>
                        </div>
                        <div>
                            <p>$265 - $850</p>
                        </div>
                    </div>
                    <div class="main_price form">
                        <div>
                            <p>Decking (to build a decked area that is already flat &amp; laid to lawn)</p>
                        </div>
                        <div class="graybg">
                            <p>$800 - $1200</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--all team end-->

<?php include('footer.php');?>