<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--all team-->
        <div class="cartpage pagepadding woocommerce">
            <div class="container">
                <form class="woocommerce-cart-form table-responsive">
                    <table class="shop_table" cellspacing="0">
                        <thead>
                            <tr>
                                <th class="product-name">Product</th>
                                <th class="product-quantity">Quantity</th>
                                <th class="product-price">Price</th>
                                <th class="product-subtotal">Total</th>
                                <th class="product-remove">&nbsp;</th>
                            </tr>
                        </thead>
                        <tr class="cart_item">
                            <td class="product-name">
                                <a href="#"><img src="images/product/p-1.jpg"></a><a href="#">Win Your Friends</a>
                                <div class="hidden-sm visible-xs show-mobile">
                                    <div class="price"> <span>Price :</span><span>£</span>15.00</div>
                                    <div class="subtotal"> <span>Subtotal :</span><span>£</span>45.00</div>
                                </div>
                            </td>
                            <td class="product-quantity">
                                <div class="quantity"> <span class="decrease"><i class="fa fa-caret-down"></i></span>
                                    <label for="">Quantity</label>
                                    <input id="" class="input-text qty text" step="1" min="0" max="" value="3" title="Qty" size="4" pattern="[0-9]*" inputmode="numeric" type="number">
                                    <span class="increase"><i class="fa fa-caret-up"></i></span>
                                </div>
                            </td>
                            <td class="product-price"><span>£</span>15.00</td>
                            <td class="product-subtotal"><span>£</span>45.00</td>
                            <td class="product-remove"> <a href="#" class="remove"><i class="flaticon-wrong-sign"></i></a></td>
                        </tr>
                        <tr class="cart_item">
                            <td class="product-name">
                                <a href="#"><img src="images/product/p-2.jpg"></a><a href="#">Win Your Friends</a>
                                <div class="hidden-sm visible-xs show-mobile">
                                    <div class="price"> <span>Price :</span><span>£</span>15.00</div>
                                    <div class="subtotal"> <span>Subtotal :</span><span>£</span>45.00</div>
                                </div>
                            </td>
                            <td class="product-quantity">
                                <div class="quantity"> <span class="decrease"><i class="fa fa-caret-down"></i></span>
                                    <label for="">Quantity</label>
                                    <input id="" class="input-text qty text" step="1" min="0" max="" value="3" title="Qty" size="4" pattern="[0-9]*" inputmode="numeric" type="number">
                                    <span class="increase"><i class="fa fa-caret-up"></i></span>
                                </div>
                            </td>
                            <td class="product-price"><span>£</span>15.00</td>
                            <td class="product-subtotal"><span>£</span>45.00</td>
                            <td class="product-remove"> <a href="#" class="remove"><i class="flaticon-wrong-sign"></i></a></td>
                        </tr>
                        <tr class="cart_item">
                            <td class="product-name">
                                <a href="#"><img src="images/product/p-3.jpg"></a><a href="#">Win Your Friends</a>
                                <div class="hidden-sm visible-xs show-mobile">
                                    <div class="price"> <span>Price :</span><span>£</span>15.00</div>
                                    <div class="subtotal"> <span>Subtotal :</span><span>£</span>45.00</div>
                                </div>
                            </td>
                            <td class="product-quantity">
                                <div class="quantity"> <span class="decrease"><i class="fa fa-caret-down"></i></span>
                                    <label for="">Quantity</label>
                                    <input id="" class="input-text qty text" step="1" min="0" max="" value="3" title="Qty" size="4" pattern="[0-9]*" inputmode="numeric" type="number">
                                    <span class="increase"><i class="fa fa-caret-up"></i></span>
                                </div>
                            </td>
                            <td class="product-price"><span>£</span>15.00</td>
                            <td class="product-subtotal"><span>£</span>45.00</td>
                            <td class="product-remove"> <a href="#" class="remove"><i class="flaticon-wrong-sign"></i></a></td>
                        </tr>
                        <tr>
                            <td colspan="6" class="actions">
                                <div class="coupon">
                                    <input name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="Enter Coupon Code..." type="text">
                                    <input class="button" name="apply_coupon" value="Apply Coupon" type="submit">
                                </div>
                                <input class="button update-cart" name="update_cart" value="Update Cart" disabled="" type="submit">
                            </td>
                        </tr>
                    </table>
                </form>
                <div class="cart-collaterals">
                    <div class="cart_totals ">
                        <h2>Cart totals</h2>
                        <table class="shop_table shop_table_responsive" cellspacing="0">
                            <tbody>
                                <tr class="cart-subtotal">
                                    <th>Subtotal</th>
                                    <td data-title="Subtotal"><span>£</span>63.00</td>
                                </tr>
                                <tr class="order-total">
                                    <th>Total</th>
                                    <td><strong><span>£</span>63.00</strong></td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="wc-proceed-to-checkout"> <a href="checkout.php" class="checkout-button button alt wc-forward"> Proceed to checkout</a></div>
                    </div>
                </div>

            </div>
        </div>
        <!--all team end-->
<?php include('footer.php');?>