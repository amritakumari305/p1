<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>


 <!--blogs-->
<div class="blogs-style-1 arrow-blog">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1 text-center margbtm30">
                    <h3 class="title">Recent Blog Post</h3>
                    <div class="desc">
                        <p>Go through Our Landscaping & gardening Tips & News</p>
                    </div>
                </div>
                <div class="row">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM blog ORDER BY blog_id DESC");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-wrapper">
                            <div class="entry-thumbnail">
                                <a href="<?php echo $rows["blog_link"]; ?>&id=<?php echo $rows["blog_id"]; ?>"><img src="admin/<?php echo $rows["blog_img"]; ?>" alt="" width="600" height="340" /></a>
                            </div>
                            <header class="entry-header">
                                <div class="entry-meta">
                                    <div class="meta-date"><?php echo $rows["blog_date"]; ?></div>
                                    <span class="meta-author"><span>By </span>
                                    <a href="<?php echo $rows["blog_link"]; ?>&id=<?php echo $rows["blog_id"]; ?>"><?php echo $rows["blog_by"]; ?></a></span>
                                </div>
                                <h2 class="entry-title"><a href="<?php echo $rows["blog_link"]; ?>&id=<?php echo $rows["blog_id"]; ?>"><?php echo $rows["blog_head"]; ?></a></h2>
                            </header>
                        </div>
                    </div>
                    <!-- <div class="col-md-4 col-sm-6">
                        <div class="blog-wrapper">
                            <div class="entry-thumbnail">
                                <a href="blog-single.php"><img src="images/blogs/blog-1-2.png" alt="" width="600" height="340" /></a>
                            </div>
                            <header class="entry-header">
                                <div class="entry-meta">
                                    <div class="meta-date">August 9, 2018</div>
                                    <span class="meta-author"><span>By </span>
                                    <a href="blog-single.php">steeltheme</a></span>
                                </div>
                                <h2 class="entry-title"><a href="blog-single.php">We Won The Best Landscape Company</a></h2>
                            </header>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="blog-wrapper">
                            <div class="entry-thumbnail">
                                <a href="blog-single.php"><img src="images/blogs/blog-1-3.jpg" alt="" width="600" height="340" /></a>
                            </div>
                            <header class="entry-header">
                                <div class="entry-meta">
                                    <div class="meta-date">August 9, 2018</div>
                                    <span class="meta-author"><span>By </span>
                                    <a href="blog-single.php">steeltheme</a></span>
                                </div>
                                <h2 class="entry-title"><a href="blog-single.php">We Won The Best Landscape Company</a></h2>
                            </header>
                        </div>
                    </div> -->
                    <?php
                                    }
                    ?>
                </div>
            </div>
        </div>
        <!--blogs end-->



<?php include('footer.php');?>