<?php
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "myDB";
// Create connection
$conn = mysqli_connect('localhost', 'root', '', 'plant');

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>