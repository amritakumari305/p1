<?php 
include('header.php');
include('menu.php');
include('slider.php');
include('home.php');
include('footer.php');
?>