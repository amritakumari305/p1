<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Plant</title>
    <!-- Stylesheets -->
    <!-- bootstrap v3.3.6 css -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- font-awesome css -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- flaticon css -->
    <link href="css/flaticon.css" rel="stylesheet">
    <!-- animate css -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- slick slide css -->
    <link href="css/slick.css" rel="stylesheet">
    <link href="css/slick-theme.css" rel="stylesheet">
    <!-- fancybox css -->
    <link href="css/jquery.fancybox.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <!-- revolution slider css -->
    <link rel="stylesheet" type="text/css" href="css/revolution/settings.css">
    <link rel="stylesheet" type="text/css" href="css/revolution/layers.css">
    <link rel="stylesheet" type="text/css" href="css/revolution/navigation.css">

    <!--Favicon-->
    <link rel="shortcut icon" href="images/logoc.png" type="image/x-icon">
    <link rel="icon" href="images/logoc.png" type="image/x-icon">
    <!-- Responsive -->
    
    <link href="css/responsive.css" rel="stylesheet">
</head>