<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--about us-->
        <div class="aboutus-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">

                    </div>
                </div>

            </div>
            <div class="container">
                <div class="grd-section-title  grd_title-type-1 text-center margbtm50">
                    <h3 class="title">Who We Are</h3>
                    <div class="desc">
                        <p>We are most trusted gardening & landscaping Designer in Chicago.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="aboutweare">
                            <h4>We Are</h4>
                            <h3>14+ Years Experienced <br>Landscapers.</h3>
                            <p>Since 2004 must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born &amp; we will give you a complete account of the system, and expound the actual teachings.</p>
                            <p>Idea of denouncing pleasure and praising pain was born &amp; we will give you a account of the system, and expound the actual teachings.</p>
                            <p>Stephen Rose,<span class="textgreen">CEO &amp; Owner</span></p>
                            <div class="grd-button-group grd-align-left">
                                <a href="#" class="grd-button  hover-1 rndbtngrn"><span>READ MORE</span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="aboutweimg">
                            <img src="images/resources/banner-1.png" alt="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--about us end-->
<!--Mission and value-->
<div class="missionvalue pagepadding">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-xs-12">
                        <div class="grd-section-title  grd_title-type-2">
                            <h3 class="title">Our Mission</h3>
                            <div class="desc">
                                <p>How all this mistaken idea of denouncing pleasure & praising pain was born and we will give you a complete account of that system, and expound the actual teachings.</p>
                            </div>
                        </div>
                        <div class="grd-section-title  grd_title-type-2">
                            <h3 class="title">Our Vision</h3>
                            <div class="desc">
                                <p>Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasional in which toil and pain can procure.</p>
                            </div>
                        </div>
                        <img src="images/resources/banner-2.jpg" alt="" />
                    </div>

                    <div class="col-sm-6 col-xs-12">
                        <div class="grd-section-title  grd_title-type-2">
                            <h3 class="title">Core Values</h3>
                            <div class="desc">
                                <p>To take a trivial example, which of us ever undertakes laborious except to obtain some advantage.</p>
                            </div>
                        </div>
                        <div class="grd-list icon-theme-dark">
                            <h3 class="title textgreen">Quality:</h3>
                            <ul>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Use the best material</a></li>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Hire the best team</a></li>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Commit to the safest work</a></li>
                            </ul>
                        </div>
                        <div class="grd-list icon-theme-dark">
                            <h3 class="title textgreen">Teamwork:</h3>
                            <ul>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span>Show respect to all</a></li>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span>Support cooperation</a></li>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span>Effective communication to all</a></li>
                            </ul>
                        </div>
                        <div class="grd-list icon-theme-dark">
                            <h3 class="title textgreen">Profitability:</h3>
                            <ul>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span>High standards in quality & service</a></li>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span>Be good environmental stewards</a></li>
                                <li><a href="#"><span class="fa fa-leaf svg-icon"></span>Act with professionalism</a></li>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!--Mission and value end-->
        <!--why choose us-->
        <div class="whyus-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="grd-section-title sc-dark  grd_title-type-2 margbtm40">
                            <h3 class="title">Industry Covered</h3>
                            <div class="desc">
                                <p>We Designed for Commercial &amp; Non Commercial Industries.</p>
                                <p>Denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness pursue work encounter consequences that are extremely.</p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 coverdimg">
                                <img src="images/resources/industry-img.jpg" alt="">
                            </div>
                            <div class="col-sm-6">
                                <div class="grd-list icon-theme-dark">
                                    <h3 class="title">WE DESIGNED FOR</h3>
                                    <ul>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Commercial</a></li>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Residential</a></li>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Sports</a></li>
                                        <li><a href="#"><span class="fa fa-leaf svg-icon"></span> Health &amp; Medical</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-5 col-lg-offset-1 col-sm-12">
                        <div class="icon-box-list">
                            <div class="col-xs-12 icon-box-list-items grd-icon-box-list-1 icon-theme-light ">
                                <div class="icon-box-wrapter">
                                    <a href="#" class="icon">
                                        <div class="icon-content"><span class="svg-icon"><i class="flaticon-clock"></i></span></div>
                                    </a>
                                    <a href="#" class="emtry-title">
                                        <h3 class="title" title="On Time, Every Time">On Time, Every Time</h3>
                                    </a>
                                    <div class="content">
                                        <div class="descreption">Must explain you how this idea of works denouncing pleasure.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 icon-box-list-items grd-icon-box-list-1 icon-theme-light ">
                                <div class="icon-box-wrapter">
                                    <a href="#" class="icon">
                                        <div class="icon-content"><span class="svg-icon"><i class="flaticon-love"></i></span></div>
                                    </a>
                                    <a href="#" class="emtry-title">
                                        <h3 class="title" title="Public Liability Insurance">Public Liability Insurance</h3>
                                    </a>
                                    <div class="content">
                                        <div class="descreption">Denouncing pleasure &amp; praising pain give you a complete account.</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 icon-box-list-items grd-icon-box-list-1 icon-theme-light ">
                                <div class="icon-box-wrapter">
                                    <a href="#" class="icon">
                                        <div class="icon-content"><span class="svg-icon"><i class="flaticon-house"></i></span></div>
                                    </a>
                                    <a href="#" class="emtry-title">
                                        <h3 class="title" title="Tailor-Made Designs">Tailor-Made Designs</h3>
                                    </a>
                                    <div class="content">
                                        <div class="descreption">Praising pain was born and we will give the system expound.</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--why choose us end-->

        <!-- counter-->
        <div class="counter-3">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="dl_counter style-2 counter-value">
                            <div class="content">
                                <div class="border-right"></div>
                                <h3><span class="counter-number">40</span><span>+</span></h3>
                                <p>Years of
                                    <br> Experienece</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="dl_counter style-2 counter-value">
                            <div class="content">
                                <div class="border-right"></div>
                                <h3><span class="counter-number">836</span></h3>
                                <p>Completed
                                    <br> Projects</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="dl_counter style-2 counter-value">
                            <div class="content">
                                <h3><span class="counter-number">152</span></h3>
                                <p>Expert
                                    <br> Team Members</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- counter end-->


<?php include('footer.php');?>