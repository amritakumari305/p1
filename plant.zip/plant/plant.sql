-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2021 at 09:11 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `plant`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `aptmnt_id` int(11) NOT NULL,
  `apt_name` varchar(255) NOT NULL,
  `apt_email` varchar(255) NOT NULL,
  `apt_phone` int(11) NOT NULL,
  `apt_address` varchar(255) NOT NULL,
  `apt_services` varchar(255) NOT NULL,
  `apt_time` time NOT NULL,
  `apt_date` date NOT NULL,
  `apt_msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`aptmnt_id`, `apt_name`, `apt_email`, `apt_phone`, `apt_address`, `apt_services`, `apt_time`, `apt_date`, `apt_msg`) VALUES
(1, 'wwww kumari', 'a@gmail.com', 2147483647, 'wswswswsws', 'gf', '08:00:00', '0000-00-00', 'gyyyyyh');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL,
  `blog_head` varchar(255) NOT NULL,
  `blog_date` date NOT NULL,
  `blog_by` varchar(255) NOT NULL,
  `blog_cont` text NOT NULL,
  `blog_cat` varchar(255) NOT NULL,
  `blog_img` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `blog_link` text NOT NULL,
  `blog_tag` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `blog_head`, `blog_date`, `blog_by`, `blog_cont`, `blog_cat`, `blog_img`, `status`, `blog_link`, `blog_tag`) VALUES
(1, 'We Won The Best Landscape Company', '2020-12-23', 'Steeltheme', '<p>How all this mistaken idea of denouncing pleasure and praising pain was born and I will give complete account of the system, and expound the actual teachings of the great explorer of the truth, the mas- ter-builder of human happiness one rejects, dislikes, or avoids pleasure itself, because it is pleasure but because those who do not know how to pursue pleasure.</p>\r\n\r\n<p>Denouncing pleasure and praising pain was born and I will give complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human one work rejects, dislikes, or avoids pleasure itself.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3>Highlight Your Words</h3>\r\n\r\n<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\">Master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure encounter consequences that are extremely painful.</div>\r\n', 'Gardern & Landscape Care', 'images/blog-1-1.jpg', 1, 'blog-single.php?page_name=Blog Single', 'Assurance, Experts,  Flowers,  Irrigatio,  Irrigation,  Plants, Tips'),
(2, 'We Won The Best Landscape Company', '2020-12-23', 'Steeltheme', '<p>How all this mistaken idea of denouncing pleasure and praising pain was born and I will give complete account of the system, and expound the actual teachings of the great explorer of the truth, the mas- ter-builder of human happiness one rejects, dislikes, or avoids pleasure itself, because it is pleasure but because those who do not know how to pursue pleasure.</p>\r\n\r\n<p>Denouncing pleasure and praising pain was born and I will give complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human one work rejects, dislikes, or avoids pleasure itself.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3>Highlight Your Words</h3>\r\n\r\n<div style=\"background:#eeeeee; border:1px solid #cccccc; padding:5px 10px\">Master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure encounter consequences that are extremely painful.</div>\r\n', 'Gardern & Landscape Care', 'images/blog-1-2.png', 1, 'blog-single.php?page_name=Blog Single', 'Assurance, Experts, Flowers, Irrigatio, Irrigation, Plants, Tips'),
(3, 'Special Message Regarding Garden', '2020-12-23', 'Steeltheme', '<p>How all this mistaken idea of denouncing pleasure and praising pain was born and I will give complete account of the system, and expound the actual teachings of the great explorer of the truth, the mas- ter-builder of human happiness one rejects, dislikes, or avoids pleasure itself, because it is pleasure but because those who do not know how to pursue pleasure.</p>\r\n\r\n<p>Denouncing pleasure and praising pain was born and I will give complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human one work rejects, dislikes, or avoids pleasure itself.</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<h3>Highlight Your Words</h3>\r\n\r\n<p>Master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure encounter consequences that are extremely painful.</p>\r\n', 'Maintenanace & Tips', 'images/blog-1-4.jpg', 1, 'blog-single.php?page_name=Blog Single', 'Assurance, Experts, Flowers, Irrigatio, Irrigation, Plants, Tips');

-- --------------------------------------------------------

--
-- Table structure for table `counters`
--

CREATE TABLE `counters` (
  `count_id` int(11) NOT NULL,
  `count_title` varchar(255) NOT NULL,
  `count_num` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `counters`
--

INSERT INTO `counters` (`count_id`, `count_title`, `count_num`, `status`) VALUES
(1, 'Years of Experienece', '250', 1),
(4, 'Total Projects', '250', 1),
(5, 'Total Customers', '25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `enq_id` int(11) NOT NULL,
  `y_name` varchar(255) NOT NULL,
  `y_email` varchar(255) NOT NULL,
  `y_subject` text NOT NULL,
  `y_question` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`enq_id`, `y_name`, `y_email`, `y_subject`, `y_question`) VALUES
(1, 'wwww kumari', 'a@gmail.com', 'Pleasure', 'Enjoy a pleasure that has no consequences?');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `faq_id` int(11) NOT NULL,
  `faq_q` varchar(255) NOT NULL,
  `faq_a` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faq_id`, `faq_q`, `faq_a`, `status`) VALUES
(1, 'Mistaken idea denouncing your pleasure?', 'Great explorer of the truth, the master-builder of human happiness one rejects, dislikes, or avoids pleasure who loves or pursues or desires to obtain.', 1),
(3, 'Enjoy a pleasure that has no consequences?', 'Desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure take a trivial example, which of us ever.', 1),
(4, 'Mistaken idea denouncing your pleasure?', 'Great explorer of the truth, the master-builder of human happiness one rejects, dislikes, or avoids pleasure who loves or pursues or desires to obtain.', 1);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `glry_id` int(11) NOT NULL,
  `glry_title` varchar(255) NOT NULL,
  `glry_img` varchar(255) NOT NULL,
  `glry_link` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`glry_id`, `glry_title`, `glry_img`, `glry_link`, `status`) VALUES
(1, 'Communal Garden', 'images/g-2-2.jpg', 'gallery-classic.php?page_name=Gallery', 1),
(2, 'Garden', 'images/g-2-4.jpg', 'gallery-classic.php?page_name=Gallery', 1),
(3, 'Communal Garden', 'images/g-2-6.jpg', 'gallery-classic.php?page_name=Gallery', 1),
(4, 'Communal Garden', 'images/g-2-5.jpg', 'gallery-classic.php?page_name=Gallery', 1),
(6, 'Communal Garden', 'images/g-2-2.jpg', 'gallery-classic.php?page_name=Gallery', 1);

-- --------------------------------------------------------

--
-- Table structure for table `logo`
--

CREATE TABLE `logo` (
  `logo_id` int(11) NOT NULL,
  `site_logo` varchar(255) NOT NULL,
  `logo_link` text NOT NULL,
  `status` tinyint(4) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logo`
--

INSERT INTO `logo` (`logo_id`, `site_logo`, `logo_link`, `status`) VALUES
(7, 'images/logo.png', 'index.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(11) NOT NULL,
  `menuname` varchar(255) NOT NULL,
  `menu_link` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `menuname`, `menu_link`, `status`) VALUES
(12, 'Home', 'index.php', 1),
(13, 'About Us', '', 1),
(14, 'Services', 'services.php', 1),
(15, 'Gallery ', 'gallery-classic.php', 1),
(16, 'Blog', 'blog.php', 1),
(17, 'Products', 'shop.php', 1),
(18, 'Shop', '', 1),
(19, 'Contact', 'contact.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `numb_mail`
--

CREATE TABLE `numb_mail` (
  `numid_id` int(11) NOT NULL,
  `site_numb` int(11) NOT NULL,
  `site_mail` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `numb_mail`
--

INSERT INTO `numb_mail` (`numid_id`, `site_numb`, `site_mail`, `status`) VALUES
(6, 2147483647, 'a@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `patners`
--

CREATE TABLE `patners` (
  `pat_id` int(11) NOT NULL,
  `pat_logo` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patners`
--

INSERT INTO `patners` (`pat_id`, `pat_logo`, `status`) VALUES
(1, 'images/1.jpg', 1),
(2, 'images/2.jpg', 1),
(3, 'images/4.jpg', 1),
(5, 'images/3.jpg', 1),
(6, 'images/1.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pdct_id` int(11) NOT NULL,
  `pdct_name` varchar(255) NOT NULL,
  `pdct_rate` double(10,2) NOT NULL,
  `pdct_link` text NOT NULL,
  `pdct_img` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pdct_id`, `pdct_name`, `pdct_rate`, `pdct_link`, `pdct_img`, `status`) VALUES
(1, 'White Sandalwood', 250.00, 'shop.php?page_name=Products', 'images/sandalwood-white.jpg', 0),
(2, 'Red Seed', 200.00, 'shop.php?page_name=Products', 'images/seedred.png', 0),
(4, 'Red Sandalwood', 250.00, 'shop.php?page_name=Products', 'images/redsandalwood.jpg', 0),
(5, 'Red Sandalwood', 250.00, 'shop.php?page_name=Products', 'images/sandalwood-white.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `sld_id` int(11) NOT NULL,
  `sld_title` varchar(255) NOT NULL,
  `sld_subtitle` varchar(255) NOT NULL,
  `sld_link` text NOT NULL,
  `sld_img` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`sld_id`, `sld_title`, `sld_subtitle`, `sld_link`, `sld_img`, `status`) VALUES
(6, '<p>GRD&nbsp;Offers&nbsp;Garden<br />\r\nDesign&nbsp;to&nbsp;Clients</p>\r\n', '<p>30+&nbsp;years&nbsp;of&nbsp;experience&nbsp;our&nbsp;staff&nbsp;keep&nbsp;your&nbsp;property&nbsp;looking<br />\r\nand&nbsp;functioning&nbsp;beautifully.&nbsp;Our&nbsp;landscapers&nbsp;are&nbsp;fully&nbsp;licensed</p>\r\n', 'about-us.php?page_name=About Us', 'images/bk7.jpg', 1),
(9, '<p>GRD&nbsp;Offers&nbsp;Garden<br />\r\nDesign&nbsp;to&nbsp;Clients</p>\r\n', '<p>30+ years of experience our staff keep your property looking<br />\r\nand functioning beautifully. Our landscapers are fully licensed</p>\r\n', 'about-us.php?page_name=About Us', 'images/bk8.jpg', 1),
(10, '<p>GRD Offers Garden<br />\r\nDesign to Clients.</p>\r\n', '<p>30+ years of experience our staff keep your property looking<br />\r\nand functioning beautifully. Our landscapers are fully licensed</p>\r\n', 'about-us.php?page_name=About Us', 'images/bk2.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `social_media`
--

CREATE TABLE `social_media` (
  `sm_id` int(11) NOT NULL,
  `sm_img` varchar(255) NOT NULL,
  `sm_link` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `social_media`
--

INSERT INTO `social_media` (`sm_id`, `sm_img`, `sm_link`, `status`) VALUES
(2, 'fa fa-facebook', '', 1),
(3, 'fa fa-twitter', '', 1),
(4, 'fa fa-skype', '', 1),
(5, 'fa fa-instagram', '', 1),
(6, 'fa fa-whatsapp', '', 1),
(7, 'fa fa-youtube', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `sub_id` int(11) NOT NULL,
  `menutype` varchar(255) NOT NULL,
  `submenu_name` varchar(255) NOT NULL,
  `submenu_link` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`sub_id`, `menutype`, `submenu_name`, `submenu_link`, `status`) VALUES
(8, '13', 'About Our Company', 'about-us.php', 1),
(9, '13', 'Why Choose Us', 'why-choose-us.php', 1),
(11, '13', 'Meet Our Team', 'meet-our-team.php', 1),
(12, '13', 'Faq', 'faqs.php', 1),
(13, '13', 'Pricing', 'pricing-plans.php', 1),
(14, '18', 'Shoping Cart', 'cart.php', 1),
(15, '18', 'My Account', 'login.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `test_id` int(11) NOT NULL,
  `test_quote` varchar(255) NOT NULL,
  `test_name` varchar(255) NOT NULL,
  `test_post` varchar(255) NOT NULL,
  `test_img` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`test_id`, `test_quote`, `test_name`, `test_post`, `test_img`, `status`) VALUES
(1, ' Lawn Care helped me transform my dated ,patchwork front yard into an inviting Southern Garden.', ' Emileny Fernando', 'Admin', 'images/1.png', 1),
(2, ' Lawn Care helped me transform my dated, patchwork front yard into an inviting Southern Garden!.', ' Emileny Fernando', 'Admin', 'images/cl1.png', 1),
(3, ' Lawn Care helped me transform my dated, patchwork front yard into an inviting Southern Garden!.', ' Emileny Fernando', 'Admin', 'images/cl2.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `pas` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `pas`) VALUES
(1, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`aptmnt_id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `counters`
--
ALTER TABLE `counters`
  ADD PRIMARY KEY (`count_id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`enq_id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`glry_id`);

--
-- Indexes for table `logo`
--
ALTER TABLE `logo`
  ADD PRIMARY KEY (`logo_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `numb_mail`
--
ALTER TABLE `numb_mail`
  ADD PRIMARY KEY (`numid_id`);

--
-- Indexes for table `patners`
--
ALTER TABLE `patners`
  ADD PRIMARY KEY (`pat_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pdct_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`sld_id`);

--
-- Indexes for table `social_media`
--
ALTER TABLE `social_media`
  ADD PRIMARY KEY (`sm_id`);

--
-- Indexes for table `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`test_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `aptmnt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `counters`
--
ALTER TABLE `counters`
  MODIFY `count_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `enq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `faq_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `glry_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `logo`
--
ALTER TABLE `logo`
  MODIFY `logo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `numb_mail`
--
ALTER TABLE `numb_mail`
  MODIFY `numid_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `patners`
--
ALTER TABLE `patners`
  MODIFY `pat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pdct_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `sld_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `social_media`
--
ALTER TABLE `social_media`
  MODIFY `sm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `submenu`
--
ALTER TABLE `submenu`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
