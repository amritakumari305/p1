<?php
include("../common/config.php");
include("header.php"); 
include("sidemenu.php");
include("menu.php");

?>


<!-- Mobile Menu end -->
 <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add Product</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php

$message = "";
if(isset($_POST['submit'])){
$pdct_name = $_POST['pdct_name'];
$pdct_rate = $_POST['pdct_rate'];
$pdct_link = $_POST['pdct_link'];
$status = $_POST['status'];
$file_name = $_FILES['pdct_img']['name'];

$temp_path=$_FILES['pdct_img']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);

// display the results
$sql = "INSERT INTO product (pdct_name, pdct_rate, pdct_link, pdct_img, status) VALUES ('$pdct_name', '$pdct_rate', '$pdct_link',  '$destination',  '$status')";
mysqli_query($conn, $sql);  
$message = "Successfull! ";
}  
?>
        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                        <h4>Add Product </h4>
                            <div class="add-product">
                                <a href="productlist.php">Product List</a>
                            </div>
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php echo $message; ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Add Product Name  </label>
                                                                  
                                                                    <input type="text" id="pdct_name" name="pdct_name" class="form-control" placeholder="Product Name">
               
                                                                </div>
                                                                
                                                                <div class="form-group">
                                                                    <label>Add Product Rate </label>
                                                                    <input id="pdct_rate" name="pdct_rate" type="text" class="form-control" placeholder="Product Rate">
                                                                </div>
                                                               
                                                               
                                                                <div class="form-group">
                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                        <option value="1">Active</option>
                                                                        <option value="0">Inactive</option>
                                                                    </select>
                                                                </div>
                                                            
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Add Product Link </label>
                                                                   
                                                                    <input type="text" id="pdct_link" name="pdct_link" class="form-control" placeholder="Product Link">
               
                                                                    
                                                                </div>
                                                                <div class="form-group">
                                                                    <label>Add Product Images </label>
                                                                    <input name="pdct_img" id="pdct_img" type="file" class="form-control" placeholder="images">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                    <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light">Add</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       
        
<?php include("footer.php"); ?>
<script>
    CKEDITOR.replace( 'sld_title' );
    CKEDITOR.replace( 'sld_subtitle' );
</script>