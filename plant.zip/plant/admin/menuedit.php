<?php
include("../common/config.php");
include("header.php"); 
include("sidemenu.php");
include("menu.php");
?>

<!-- Mobile Menu end -->
<div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add & Update Menu</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>
</div>
<?php
$message = "";
if(count($_POST)>0) {
    mysqli_query($conn,"UPDATE menu set menuname='" . $_POST['menuname'] . "',  menu_link='" . $_POST['menu_link'] . "', status='" . $_POST['status']. "' WHERE menu_id='" . $_POST['id'] . "'");
   
    
    
    
    $message = "Record Modified Successfully";
    }
    
    
    $result = mysqli_query($conn,"SELECT * FROM menu WHERE menu_id='" . $_GET['id'] . "'");
    $row= mysqli_fetch_array($result);

 
?>
        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                        <h4>Update Menu</h4>
                        <div class="add-product">
                                <a href="menulist.php"> Menu List</a>
                            </div>
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php echo $message; ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <input type="hidden" name="id" class="txtField" value="<?php echo $row['menu_id']; ?>">
                                                               
                                                                <div class="form-group">
                                                                    <input name="menuname" type="text" class="form-control" placeholder="menu name" value="<?php echo $row['menuname'];?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <input name="menu_link" type="text" class="form-control" placeholder="menu LINK" value="<?php echo $row['menu_link'];?>">
                                                                </div>
                                                                
                                                                <div class="form-group">
                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                        <option value="1" <?php if($row['status']==1); echo"selected"?>>Active</option>
                                                                        <option value="0" <?php if($row['status']==0); echo"selected"?>>Inactive</option>
                                                                    </select>
                                                                </div>
                                                            
                                                            </div>
                                                            
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light">Edit</button>
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php include("footer.php"); ?>