<?php
include("../common/config.php");
include("header.php"); 
include("sidemenu.php");
include("menu.php");
$btnname= "Add";

if(isset($_GET['action']) && $_GET['action']=="delete")
{
   // echo "<meta http-equiv='refresh' content='0'>";
    $sql1 = "DELETE FROM patners WHERE pat_id='" . $_GET["id"] . "'";
        if (mysqli_query($conn, $sql1)) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . mysqli_error($conn);
        }
            unset($_GET);
                                                
}

if(isset($_GET['action']) && $_GET['action']=="edit")
{
    $btnname="update";
    $result = mysqli_query($conn,"SELECT * FROM patners WHERE pat_id='" . $_GET['id'] . "'");
    $row= mysqli_fetch_array($result);
}

?>


<!-- Mobile Menu end -->
 <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add/Edit patners</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
$message = "";
if(isset($_POST['submit'])){

$status = $_POST['status'];

$file_name = $_FILES['pat_logo']['name'];

$temp_path=$_FILES['pat_logo']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);
// display the results
if($_POST['id5']=="")
{
  $sql = "INSERT INTO patners (pat_logo, status) VALUES ('$destination', '$status')";
  
}

else
{
    if($_FILES['pat_logo']['name']!='')
    {
        $file_name = $_FILES['pat_logo']['name'];
    
        $temp_path=$_FILES['pat_logo']['tmp_name'];
        $destination="images/".$file_name;
        if(move_uploaded_file($temp_path, $destination)){
            unlink($_POST['old_img']); // for delete file from server
        }
    
        $sql ="UPDATE patners set pat_logo='" . $destination. "', status='" . $_POST['status']. "' WHERE pat_id='" . $_POST['id5'] . "'";
    }else{
    
    
        $sql = "UPDATE patners set pat_logo='" . $_POST['old_img'] . "', status='" . $_POST['status']. "' WHERE pat_id='" . $_POST['id5'] . "'";
    }
    

}

   mysqli_query($conn, $sql);  
    $message = "Successfull! ";
}  
?>
        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                        <h4>Add/Edit Patners </h4>
                            
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php echo $message; ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <input type="hidden" name="id5" class="txtField" value="<?php echo @$row['pat_id']; ?>">
                                                                <div class="form-group">
                                                                    <label>Patners Image </label>
                                                                    <input name="pat_logo" type="file" class="form-control" placeholder="patners">
                                                                    <img src="<?php echo $row['pat_logo']; ?>" />
                                                                    <input type="hidden" name="old_img" value="<?php echo $row['pat_logo']; ?>">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">

                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                    <option value="1" <?php if(@$row['status']==1); echo"selected"?>>Active</option>
                                                                        <option value="0" <?php if(@$row['status']==0); echo"selected"?>>Inactive</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                    <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light"><?php echo $btnname; ?></button>
                                                                
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
$result = mysqli_query($conn,"SELECT * FROM patners");
?>
        <div class="product-status mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap drp-lst">
                            <h4>patners List</h4>
                           
                            <div class="asset-inner">
                            <?php
                                                if (mysqli_num_rows($result) > 0) {
                                                ?>
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th width="1%">No</th>
                                        <th width="20%">patners</th>
                                       
                                        <th width="10%">Status</th>
                                        <th width="15%">Setting</th>
                                    </tr>
                                    </thead>
                                   <tbody>
                                   <?php
                                                                $i=1;
                                                                while($row = mysqli_fetch_array($result)) {
                                                                ?>
                                   <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><img src="<?php echo $row["pat_logo"]; ?>" class="img-circle img-thumbnail img-responsive messange_img"></td>
                                      
                                        <td>
                                           <button class="pd-setting"><?php  if($row["status"]==1) echo "active"; else echo "Inactive"; ?></button>
                                        </td>
                                        <td>
                                            <a  href="patnersadd.php?action=edit&id=<?php echo $row["pat_id"]; ?>" data-toggle="tooltip" title="Edit" class="pd-setting-ed"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            <a  href="patnersadd.php?action=delete&id=<?php echo $row["pat_id"]; ?>" data-toggle="tooltip" title="Trash" class="pd-setting-ed"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                                      
                                       
                                        </td>
                                    </tr>
                                    <?php
                                                                $i++;
                                                                }
                                                                ?>
                                   </tbody>
                                    
                                </table>
                                <?php
                                                            }
                                                            else{
                                                                echo "No result found";
                                                            }
                                                            ?>
                            </div>
                            <div class="custom-pagination">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

               
        
<?php include("footer.php"); ?>
