<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="index.html"><img class="main-logo" src="img/logo/logo.png" width="120" alt="" /></a>
                <strong><a href="index.html"><img src="img/logo/logo.png" width="120" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a href="index.php"><span class="educate-icon educate-home icon-wrap"></span><span class="mini-click-non">Dashboard</span></a>

                        </li>
                        <li>
                            <a title="Landing Page" href="events.html" aria-expanded="false"><span class="educate-icon educate-event icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Event</span></a>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Menu</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="menulist.php"><span class="mini-sub-pro">All Menu</span></a></li>
                                <li><a title="Add Professor" href="menuadd.php"><span class="mini-sub-pro">Add Menu</span></a></li>
                               
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Sub Menu</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="submenulist.php"><span class="mini-sub-pro">All Sub Menu</span></a></li>
                                <li><a title="Add Professor" href="submenuadd.php"><span class="mini-sub-pro">Add Sub Menu</span></a></li>
                               
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Slider</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="sliderlist.php"><span class="mini-sub-pro">All Slider</span></a></li>
                                <li><a title="Add Professor" href="slideradd.php"><span class="mini-sub-pro">Add Slider</span></a></li>
                               
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Services</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Students" href="serviceslist.php"><span class="mini-sub-pro">All Services</span></a></li>
                                <li><a title="Add Students" href="servicesadd.php"><span class="mini-sub-pro">Add Services</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Products</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Students" href="productlist.php"><span class="mini-sub-pro">All Products</span></a></li>
                                <li><a title="Add Students" href="productadd.php"><span class="mini-sub-pro">Add Products</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Gallery</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Students" href="gallerylist.php"><span class="mini-sub-pro">All Gallery</span></a></li>
                                <li><a title="Add Students" href="galleryadd.php"><span class="mini-sub-pro">Add Gallery</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Counters</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                
                                <li><a title="Add Students" href="countersadd.php"><span class="mini-sub-pro">Add Counters</span></a></li>
                                
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Testimonial</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Library" href="testimonaillist.php"><span class="mini-sub-pro">All Testimonial</span></a></li>
                                <li><a title="Add Library" href="testimonailadd.php"><span class="mini-sub-pro">Add Testimonial</span></a></li>
                               
                            </ul>
                        </li>
                        <li>
                            <a title="Landing Page" href="appointment.php" aria-expanded="false"><span class="educate-icon educate-message  icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Appointment</span></a>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-department icon-wrap"></span> <span class="mini-click-non">Blog</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Departments List" href="bloglist.php"><span class="mini-sub-pro">Blog List</span></a></li>
                                <li><a title="Add Departments" href="blogadd.php"><span class="mini-sub-pro">Add Blog</span></a></li>
                               
                            </ul>
                        </li>
                        <li>
                            <a title="Landing Page" href="patnersadd.php" aria-expanded="false"><span class="educate-icon educate-message  icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Patners</span></a>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-course icon-wrap"></span> <span class="mini-click-non">FAQ</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Courses" href="faqlist.php"><span class="mini-sub-pro">All FAQ</span></a></li>
                                <li><a title="Add Courses" href="addfaq.php"><span class="mini-sub-pro">Add FAQ</span></a></li>
                                
                            </ul>
                        </li>
                       
                       

                        <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Social Media</span></a>
                            <ul class="submenu-angle interface-mini-nb-dp" aria-expanded="false">
                                <li><a title="Google Map" href="google-map.html"><span class="mini-sub-pro">Google Map</span></a></li>
                                <li><a title="Data Maps" href="data-maps.html"><span class="mini-sub-pro">Data Maps</span></a></li>
                                <li><a title="Pdf Viewer" href="pdf-viewer.html"><span class="mini-sub-pro">Pdf Viewer</span></a></li>
                                <li><a title="X-Editable" href="x-editable.html"><span class="mini-sub-pro">X-Editable</span></a></li>
                                <li><a title="Code Editor" href="code-editor.html"><span class="mini-sub-pro">Code Editor</span></a></li>
                                <li><a title="Tree View" href="tree-view.html"><span class="mini-sub-pro">Tree View</span></a></li>
                                <li><a title="Preloader" href="preloader.html"><span class="mini-sub-pro">Preloader</span></a></li>
                                <li><a title="Images Cropper" href="images-cropper.html"><span class="mini-sub-pro">Images Cropper</span></a></li>
                            </ul>
                        </li>

                        <li>
                            <a title="Landing Page" href="events.html" aria-expanded="false"><span class="educate-icon educate-message  icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Contact Details</span></a>
                        </li>
                        <li id="removable">
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-pages icon-wrap"></span> <span class="mini-click-non">Pages</span></a>
                            <ul class="submenu-angle page-mini-nb-dp" aria-expanded="false">
                               
                                <li><a title="Password Recovery" href="password-recovery.php"><span class="mini-sub-pro">Password Recovery</span></a></li>

                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>