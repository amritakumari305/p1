<?php
include("../common/config.php");
include("header.php"); 
include("sidemenu.php");
include("menu.php");

?>


<!-- Mobile Menu end -->
 <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add Testimonial</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php

$message = "";
if(isset($_POST['submit'])){
$test_quote = $_POST['test_quote'];

$test_name = $_POST['test_name'];
$test_post = $_POST['test_post'];
$status = $_POST['status'];
$file_name = $_FILES['test_img']['name'];

$temp_path=$_FILES['test_img']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);

// display the results
$sql = "INSERT INTO testimonial (test_quote, test_name, test_post, test_img, status) VALUES ('$test_quote', '$test_name', '$test_post', '$destination',  '$status')";
mysqli_query($conn, $sql);  
$message = "Successfull! ";
}  
?>
        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                        <h4>Add Testimonial </h4>
                            <div class="add-product">
                                <a href="testimonaillist.php">Testimonial List</a>
                            </div>
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php echo $message; ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Add Testimonial Quotes</label>
                                                                   
                                                                    <textarea name="test_quote" id="test_quote" class="form-control" placeholder="Testimonials Quotes" cols="30" rows="10"></textarea>
                                                                    
                                                                </div>
                                                                <div class="form-group">
                                                                    <label>Add Name  </label>
                                                                  
                                                                    <input type="text" id="test_name" name="test_name" class="form-control" placeholder="Testimonials Name">
               
                                                                </div>
                                                                
                                                                <div class="form-group">
                                                                    <label>Add Post </label>
                                                                   
                                                                    <input type="text" id="test_post" name="test_post" class="form-control" placeholder="Testimonials Link">
               
                                                                    
                                                                </div>
                                                               
                                                                
                                                                <div class="form-group">
                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                        <option value="1">Active</option>
                                                                        <option value="0">Inactive</option>
                                                                    </select>
                                                                </div>
                                                            
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                               
                                                                <div class="form-group">
                                                                    <label>Add Testimonail Images </label>
                                                                    <input name="test_img" id="test_img" type="file" class="form-control" placeholder="images">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                    <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light">Add</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       
        
<?php include("footer.php"); ?>
<script>
    CKEDITOR.replace( 'sld_title' );
    CKEDITOR.replace( 'sld_subtitle' );
</script>