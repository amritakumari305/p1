<?php
include("../common/config.php");
include("header.php"); 
include("sidemenu.php");
include("menu.php");


?>

<!-- Mobile Menu end -->
 <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Edit Product</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Single pro tab review Start-->

<?php
$message = "";
if(count($_POST)>0) {

    if($_FILES['glry_img']['name']!='')
    {
        $file_name = $_FILES['glry_img']['name'];
    
        $temp_path=$_FILES['glry_img']['tmp_name'];
        $destination="images/".$file_name;
        if(move_uploaded_file($temp_path, $destination)){
            unlink($_POST['old_img']); // for delete file from server
        }
    
        mysqli_query($conn,"UPDATE gallery set glry_title='" . $_POST['glry_title'] . "', glry_link='" . $_POST['glry_link'] . "', glry_img='" . $destination. "', status='" . $_POST['status']. "' WHERE glry_id='" . $_POST['id'] . "'");
    }else{
    
    
        mysqli_query($conn,"UPDATE gallery set glry_title='" . $_POST['glry_title'] . "', glry_link='" . $_POST['glry_link'] . "', glry_img='" . $_POST['old_img'] . "', status='" . $_POST['status']. "' WHERE glry_id='" . $_POST['id'] . "'");
    }
    
    
    
    $message = "Record Modified Successfully";
    }
    
    
    $result = mysqli_query($conn,"SELECT * FROM gallery WHERE glry_id='" . $_GET['id'] . "'");
    $row= mysqli_fetch_array($result);
?>
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                            <h4>Gallery Edit</h4>
                            <div class="add-product">
                                <a href="gallerylist.php">Gallery List</a>
                            </div>
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php if(isset($message)) { echo $message; } ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <input type="hidden" name="id" class="txtField" value="<?php echo $row['glry_id']; ?>">
                                                                <div class="form-group">
                                                                    <label>Edit Gallery Name  </label>
                                                                  
                                                                    <input type="text" id="glry_title" name="glry_title" class="form-control" placeholder="Product Name" value="<?php echo $row['glry_title']; ?>">
               
                                                                </div>
                                                                
                                                                <div class="form-group">
                                                                    <label>Edit Gallery Link </label>
                                                                   
                                                                    <input type="text" id="glry_link" name="glry_link" class="form-control" placeholder="Product Link" value="<?php echo $row['glry_link']; ?>">
               
                                                                    
                                                                </div>
                                                               
                                                                <div class="form-group">
                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                    <option value="1" <?php if($row['status']==1); echo"selected"?> >Active</option>
                                                                        <option value="0" <?php if($row['status']==0); echo"selected"?> >InActive</option>
                                                                    </select>
                                                                </div>
                                                            
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                
                                                                <div class="form-group">
                                                                    <label>Edit Gallery Images </label>
                                                                    <input name="glry_img" type="file" class="form-control" placeholder="images" value="">
                                                                    <img src="<?php echo $row['glry_img']; ?>" />
                                                                    <input type="hidden" name="old_img" value="<?php echo $row['glry_img']; ?>">
                                                                </div>
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                    <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light">Edit</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        
<?php include("footer.php"); ?>
<script>
                        CKEDITOR.replace( 'sld_title' );
                        CKEDITOR.replace( 'sld_subtitle' );
</script>