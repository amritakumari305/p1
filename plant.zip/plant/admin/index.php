<?php 
session_start();
if(!isset($_SESSION['user'])){
	header('location:userlogin.php');
}
include('../common/config.php');
?>
<?php include('header.php')?>
<?php include('sidemenu.php')?>
<?php include('menu.php')?>
<?php include('home.php')?>
<?php include('footer.php')?>