<?php
include("../common/config.php");
include("header.php"); 
include("sidemenu.php");
include("menu.php");

?>


<!-- Mobile Menu end -->
 <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add Blog</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php

$message = "";
if(isset($_POST['submit'])){
$blog_head = $_POST['blog_head'];
$blog_date = $_POST['blog_date'];
$blog_by = $_POST['blog_by'];
$blog_cont = $_POST['blog_cont'];
$blog_cat = $_POST['blog_cat'];
$blog_link = $_POST['blog_link'];
$blog_tag = $_POST['blog_tag'];
$status = $_POST['status'];
$file_name = $_FILES['blog_img']['name'];

$temp_path=$_FILES['blog_img']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);

// display the blog_img
$sql = "INSERT INTO Blog (blog_head, blog_date, blog_by, blog_cont, blog_cat, blog_link, blog_tag, blog_img, status) VALUES ('$blog_head', '$blog_date', '$blog_by', '$blog_cont', '$blog_cat', '$blog_link', '$blog_tag','$destination',  '$status')";
mysqli_query($conn, $sql);  
$message = "Successfull! ";
}  
?>
        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                            <h4>Add Blog </h4>
                            <div class="add-product">
                                <a href="bloglist.php">Blog List</a>
                            </div>
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php echo $message; ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Add Blog Heading</label>
                                                                   
                                                                    
                                                                    <input type="text" id="blog_head" name="blog_head" class="form-control" placeholder="Blogs Heading">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label>Blog Date  </label>
                                                                  
                                                                    <input type="date" id="blog_date" name="blog_date" class="form-control" placeholder="Blogs Date">
               
                                                                </div>
                                                                
                                                                <div class="form-group">
                                                                    <label>Blog By  </label>
                                                                   
                                                                    <input type="text" id="blog_by" name="blog_by" class="form-control" placeholder="Blogs By">
               
                                                                    
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="blog_cont">Blog Content </label>
                                                                    <textarea name="blog_cont" id="blog_cont" class="form-control" placeholder="Blogs Content"></textarea>
               
                                                                </div>
                                                                
                                                                <div class="form-group">
                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                        <option value="1">Active</option>
                                                                        <option value="0">Inactive</option>
                                                                    </select>
                                                                </div>
                                                            
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <label>Blog Categories </label>
                                                                    <input name="blog_cat" id="blog_cat" type="text" class="form-control" placeholder="Blog Categories">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label>Blog Link </label>
                                                                    <input name="blog_link" id="blog_link" type="text" class="form-control" placeholder="Blog Link">
                                                                </div>
                                                                <div class="form-group">
                                                                    <label for="blog_cont">Blog Tags </label>
                                                                    <textarea name="blog_tag" id="blog_tag" class="form-control" placeholder="Blogs Tags"></textarea>
               
                                                                </div>
                                                                <div class="form-group">
                                                                    <label>Add Blog Images </label>
                                                                    <input name="blog_img" id="blog_img" type="file" class="form-control" placeholder="images">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                    <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light">Add</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       
        
<?php include("footer.php"); ?>
<script>
    CKEDITOR.replace( 'blog_cont' );
    
</script>