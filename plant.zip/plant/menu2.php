<?php 
include("common/config.php");
?>
<body class="home header-sticky header-v1 hide-topbar-mobile">
    <div id="page" class="hfeed site">

        <!-- Preloader-->
        <div class="preloader"></div>

        <!-- masthead -->
        <header id="masthead" class="site-header">
            <div class="header-main clearfix">
                <div class="container">
                    <div class="row menu-row">
                        <div class="site-logo col-lg-3 col-xs-9">
                        
                             <a href="index.php" class="logo"> <img src="images/logo1.png" alt="Plant" class="logo"> </a>
                        
                            <h1 class="site-title"><a href="#">GRD</a></h1>
                            <h2 class="site-description">Just another Html Template  site</h2>
                        </div>
                        <div class="header-content col-lg-9 col-md-12 col-xs-12 pull-right">
                            <!-- top bar -->
                            <div id="topbar" class="topbar ">
                                <div class="topbar-widgets clearfix">
                                    <div class="widget">
                                        <ul class="socials">
                                        <?php
                                            $result1 = mysqli_query($conn,"SELECT * FROM social_media");
                                            while($rows = mysqli_fetch_array($result1)){
                                            
                                        ?>
                                            <li><a href="<?php echo $rows["sm_link"]; ?>" target="_blank"><i class="<?php echo $rows["sm_img"]; ?>"></i></a></li>
                                            
                                            <?php
                                           }
                                        ?>
                                        </ul>
                                    </div>
                                    <div class="widget">
                                        <div class="pull-left"><span class="svg-icon"><i class="flaticon-call-answer"></i></span></div>
                                        <div class="pull-right">
                                            <div>Call Us</div>
                                            <?php
                                            $result1 = mysqli_query($conn,"SELECT * FROM numb_mail");
                                            $rows = mysqli_fetch_array($result1)
                                            
                                        ?>
                                            <div>+<?php echo $rows["site_numb"]; ?></div>
                                        </div>
                                    </div>
                                    <div class="widget">
                                        <div class="pull-left"><span class="svg-icon"><i class="flaticon-timer"></i></span></div>
                                        <div class="pull-right">
                                            <div class="title">Business Hrs</div>
                                            <div class="sub-title">Mon-Sat: 09:00 - 17:00</div>
                                        </div>
                                    </div>
                                    <div class="menu-block-right"></div>
                                </div>
                            </div>
                            <!-- top bar -->
                            <div class="site-menu">
                                <nav id="site-navigation" class="main-nav primary-nav nav">
                                    <ul class="menu">
                                    <?php
                                        $xyz=0;
                                            $result = mysqli_query($conn,"SELECT * FROM menu");
                                    
                                            while($row = mysqli_fetch_array($result)) {
                                                if($row["menu_link"]!='')
                                                {
                                                    
                                        ?>
                                            <li class="<?php if($xyz==0){echo "active"; $xyz++; }?>"><a   href="<?php echo $row["menu_link"]; ?>?page_name=<?php echo $row["menuname"]; ?>"><?php echo $row["menuname"]; ?></a></li>


                                        <?php
                                                }   
                                            else
                                            {
                                        ?>
                                        <li class="has-children  <?php if($xyz==0){echo "active"; $xyz++; }?>"><a href="#" class="dropdown-toggle"><?php echo $row["menuname"]; ?></a>
                                            <ul class="sub-menu">
                                            <?php
                                                $result1 = mysqli_query($conn,"SELECT * FROM submenu where menutype=".$row["menu_id"]);
                                                                                
                                                while($row1 = mysqli_fetch_array($result1)) {
                                                
                                            ?>
                                                <li><a href="<?php echo $row1["submenu_link"]; ?>?page_name=<?php echo $row1["submenu_name"]; ?>"><?php echo $row1["submenu_name"]; ?></a></li>

                                                <?php
                                                }
                                                echo " </ul>  </li>";

                                            }


                                        }
                                    ?>
                                        
                                        <li id="mf-active-menu" class="mf-active-menu"></li>
                                    </ul>
                                </nav>
                                <ul class="menu-extra">
                                    <li class="extra-menu-item menu-item-cart mini-cart woocommerce">
                                        <a class="cart-contents" href="#">
                                            <span class="text-mobile">Shopping Cart</span>
                                            <span class="svg-icon"><i class="flaticon-shopping-cart"></i></span>
                                        </a>
                                        <div class="grd-mini-cart-content">
                                            <div class="widget_shopping_cart_content">
                                                <p class="woocommerce-mini-cart__empty-message">No products in the cart.</p>
                                            </div>
                                        </div>
                                    </li>
                                   
                                </ul>
                            </div>
                        </div>
                        <div class="navbar-toggle col-xs-3">
                            <span id="mf-navbar-toggle" class="navbar-icon"> <span class="navbars-line"></span> </span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- masthead end -->