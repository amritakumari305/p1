<?php 
include('common/config.php');
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--all team-->
        <div class="faqpage pagepadding">
            <div class="container">
                <div class="row">
                    <div class="col-xs-2 col-sm-1 no-padding"><img src="images/icon/faqicon.png" alt=""></div>
                    <div class="col-xs-10 col-sm-11  no-padding grd-section-title  grd_title-type-4 ">
                        <h3 class="title fsize30 margbtm0">Customers Frequently Asked Questions</h3>
                        <div class="desc">
                            <p>Cant’t find your answer here? Contact our team.</p>
                        </div>
                    </div>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-9 col-md-9 col-sm-12">
                        <div class="dl_faq">
                        <?php
                                       
                                            $result = mysqli_query($conn,"SELECT * FROM faq");
                                    
                                            while($rows = mysqli_fetch_array($result)) {
                                               
                                                    
                                        ?>
                            <div class="side_faq style-2 text-dark">
                                <div class="row">
                                    <div class="col-sm-4 question">
                                        <h2>Q</h2>
                                        <h3><?php echo $rows["faq_q"]; ?></h3></div>
                                    <div class="col-sm-8 asked">
                                        <h2>A</h2>
                                        <p><?php echo $rows["faq_a"]; ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php
                                            }
                            ?>
                            <!-- <div class="side_faq style-2 text-dark">
                                <div class="row">
                                    <div class="col-sm-4 question">
                                        <h2>Q</h2>
                                        <h3>Enjoy a pleasure that has no consequences?</h3></div>
                                    <div class="col-sm-8 asked">
                                        <h2>A</h2>
                                        <p>Desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure take a trivial example, which of us ever.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="side_faq style-2 text-dark">
                                <div class="row">
                                    <div class="col-sm-4 question">
                                        <h2>Q</h2>
                                        <h3>Mistaken idea denouncing your pleasure?</h3></div>
                                    <div class="col-sm-8 asked">
                                        <h2>A</h2>
                                        <p>Great explorer of the truth, the master-builder of human happiness one rejects, dislikes, or avoids pleasure who loves or pursues or desires to obtain.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="side_faq style-2 text-dark">
                                <div class="row">
                                    <div class="col-sm-4 question">
                                        <h2>Q</h2>
                                        <h3>Enjoy a pleasure that has no consequences?</h3></div>
                                    <div class="col-sm-8 asked">
                                        <h2>A</h2>
                                        <p>Desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure take a trivial example, which of us ever.</p>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>

<?php
$message = "";
if(isset($_POST['submit'])){
$y_name = $_POST['y_name'];
$y_email = $_POST['y_email'];
$y_subject = $_POST['y_subject'];
$y_question = $_POST['y_question'];
// display the results
$sql = "INSERT INTO enquiry (y_name, y_email, y_subject, y_question) VALUES ('$y_name', '$y_email', '$y_subject', '$y_question')";
mysqli_query($conn, $sql); 
$message = "Successfully submitted! ";
}  
?>                    
                    <div class="col-lg-3 col-md-3 col-sm-12">
                        <form class="wpcf7-form" novalidate="novalidate" action=" " method="POST">
                            <div class="faq-form">
                                <h2>Ask Your Questions</h2>
                                <p>
                                    <input name="y_name" value=""  placeholder="Name" type="text">
                                    <br>
                                    <input name="y_email" value=""  placeholder="Email" type="email">
                                    <br>
                                    <select name="y_subject">
                                        <option value="Subject">Subject</option>
                                        <option value="Mistaken">Mistaken</option>
                                        <option value="Pleasure">Pleasure</option>
                                        <option value="Consequences">Consequences</option>
                                    </select>
                                    <label>Your Question</label>
                                    <input name="y_question" value=""  type="text">
                                    <br>
                                    <input value="Submit Now" class="wpcf7-submit"  type="submit"  name="submit" value="submit">
                                </p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--all team end-->

<?php include('footer.php');?>