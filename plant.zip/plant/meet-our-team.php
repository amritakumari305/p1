<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

        <!--all team-->
        <div class="teampage pagepadding">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1  text-center margbtm50">
                    <h3 class="title">Team Behind Our Successful Service</h3>
                    <div class="desc">
                        <p>These are the reason to get you good service</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-1 style-1">
                            <div class="box-member">
                                <h3>Donald Benjamin</h3>
                                <div class="box-img"><img alt="Donald Benjamin" src="images/team/ava4.jpg">
                                    <div class="overlay-link">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            <li><a href="#"><i class="fa fa-paper-plane"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="job">CEO &amp; Owner</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-1 style-1">
                            <div class="box-member">
                                <h3>Dan Western</h3>
                                <div class="box-img"><img alt="Donald Benjamin" src="images/team/ava5.jpg">
                                    <div class="overlay-link">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            <li><a href="#"><i class="fa fa-paper-plane"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="job">Sales Manager</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-1 style-1">
                            <div class="box-member">
                                <h3>Carlose Loneon</h3>
                                <div class="box-img"><img alt="Donald Benjamin" src="images/team/ava6.jpg">
                                    <div class="overlay-link">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            <li><a href="#"><i class="fa fa-paper-plane"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="job">Senior Landscaper</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-1 style-1">
                            <div class="box-member">
                                <h3>John Harris</h3>
                                <div class="box-img"><img alt="Donald Benjamin" src="images/team/ava7.jpg">
                                    <div class="overlay-link">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            <li><a href="#"><i class="fa fa-paper-plane"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="job">Supervisor</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-1 style-1">
                            <div class="box-member">
                                <h3>Portzzman Lee</h3>
                                <div class="box-img"><img alt="Donald Benjamin" src="images/team/ava8.jpg">
                                    <div class="overlay-link">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            <li><a href="#"><i class="fa fa-paper-plane"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="job">Design Assistant</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-1 style-1">
                            <div class="box-member">
                                <h3>Tony Hazzlewood</h3>
                                <div class="box-img"><img alt="Donald Benjamin" src="images/team/ava9.jpg">
                                    <div class="overlay-link">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            <li><a href="#"><i class="fa fa-paper-plane"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="job">Maintenance Supervisor</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-1 style-1">
                            <div class="box-member">
                                <h3>Cindey Journey</h3>
                                <div class="box-img"><img alt="Donald Benjamin" src="images/team/ava10.jpg">
                                    <div class="overlay-link">
                                        <ul>
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                            <li><a href="#"><i class="fa fa-paper-plane"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="job">Landscaper</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-lg-4 col-sm-6">
                        <div class="dl_members box-2 style-1 text-dark bordernone">
                            <div class="box-img"><img alt="" src="images/team/team-bg-1.jpg"></div>
                            <div class="box-text">
                                <h2>We looking for good landscapers.</h2>
                                <div class="btn-team"><span class="svg-icon"><i class="flaticon-right"></i></span>
                                    <div class="dl-button "><a href="#">Join with us</a></div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--all team end-->
        <?php include('footer.php');?>