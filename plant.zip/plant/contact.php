<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>
   <!--contact form-->
<div class="contactpage">
            <div class="container">
                <div class="grd-section-title  grd_title-type-2 margbtm20">
                    <h3 class="title  fsize30">Hi, here you can reach out to us for any inquiry</h3>
                    <div class="desc">
                        <p>There are lots of ways to stay touch with us.</p>
                    </div>
                </div>
               
                <div class="row">
                    <div class="col-sm-5">
                        <div class="contact-pagebox">
                            <div class="grd-contact-box">
                                <div class="grd-section-title  grd_title-type-2 margbtm20">
                                    <h3 class="title  fsize30">Quick contact</h3>
                                </div>
                                <ul>
                                    <li>
                                        <p class="name">Phone</p>
                                        <p class="value">+0 321-654-0987</p>
                                    </li>
                                    <li>
                                        <p class="name">Email</p>
                                        <p class="value">Landscapingservice@grd.com</p>
                                    </li>
                                    <li>
                                        <p class="name">Working Hours</p>
                                    </li>
                                    <li>
                                        <p class="seasons">Summer</p>
                                        <p class="value"><span class="text-green">(May to Nov): </span>Mon - Satday: 9.00 to 18.00</p>
                                    </li>
                                    <li>
                                        <p class="seasons">Winter</p>
                                        <p class="value"><span class="text-green">(Dec to Apr): </span>Mon - Satday: 9.00 to 17.00</p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <form method="post" action="http://st.ourhtmldemo.com/template/GRD-html/ajax/mail.php" class="wpcf7-form" id="contact-form" novalidate="novalidate">
                            <div class="contactpage-form">
                                <p>Feel free to ask any landscaping or gardening questions over the phone, or get in touch via our contact form below.</p>
                                <div class="row">
                                    <div class="col-md-6 col-xs-12 col-sm-12">
                                        <p>
                                            <input name="name" value="" size="40" placeholder="Your Name*" type="text">
                                        </p>
                                    </div>
                                    <div class="col-md-6 col-xs-12 col-sm-12">
                                        <p>
                                            <input name="email" value="" size="40" placeholder="Email Address*" type="email">
                                        </p>
                                    </div>
                                    <div class="col-md-12 col-xs-12 col-sm-12">
                                        <p>
                                            <input name="phone" value="" size="40" placeholder="Phone Number" type="text">
                                        </p>
                                    </div>
                                    <div class="col-md-12 col-xs-12 col-sm-12 mf-textarea-field">
                                        <p>
                                            <textarea name="message" cols="40" rows="4" placeholder="Enter Your Message..."></textarea>
                                        </p>
                                    </div>
                                    <div class="text-center mf-submit col-md-12 col-xs-12 col-sm-12">
                                        <button type="submit" class="btn-style-two">Send Message Us</button>
                                    </div>
                                </div>
                            </div>
							<div class="contact-form-message"></div>
                            <div id="loading" class="form-loader"><img src="images/ajax-loader.png" alt="loading"></div>
                        </form>
                    </div>
                </div>

            </div>

            <!--contact form end-->

            <div class="contact-branches">
                <div class="container">

                    <div class="branch-item heading">
                        <div class="grd-section-title  grd_title-type-2 margbtm20">
                            <h3 class="title  fsize30">Other Branches</h3>
                        </div>
                    </div>
                    <div class="branch-item">
                        <h3>Newyork</h3>
                        <p>54 N. Lakewood Avenue, IL 60640</p>
                        <p>+0 321-654-0987</p>
                        <p>Support@grdnewyok.com</p>
                    </div>
                    <div class="branch-item">
                        <h3>California</h3>
                        <p>2b Starclub Str, CA 92024</p>
                        <p>+0 123-456-7890</p>
                        <p>Support@grdcalifornia.com</p>
                    </div>
                    <div class="branch-item">
                        <h3>Los Angeles</h3>
                        <p>1419 Westwood Blvd</p>
                        <p> +0 321-654-0987</p>
                        <p>Support@grdlosangeles.com</p>
                    </div>

                </div>
            </div>
           
</div>


<?php include('footer.php');?>