<?php 
include('header.php');
include('menu2.php');
include('banner.php');
?>

       <!--gallery us-->
       <div class="gallery-1">
            <div class="container">
                <div class="grd-section-title  grd_title-type-1 text-center margbtm30">
                    <h3 class="title">Latest Projects</h3>
                    <div class="desc">
                        <p>We have done more than 10,000 succesful projects.</p>
                    </div>
                </div>
                <div class="row grd-portfolio-shortcode">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM gallery limit 0,20");
                                    while($rows = mysqli_fetch_array($result1)) {
                                    
                                ?>
                    <div class="col-sm-6 col-md-3  portfolio-item">
                        <div class="content-item">
                            <div class="entry-header">
                                <a href="<?php echo $rows["glry_link"]; ?>" class="entry-thumbnail"><img alt="Communal Garden" src="admin/<?php echo $rows["glry_img"]; ?>"></a>
                            </div>
                            <div class="entry-content">
                                <div class="entry-title"><a href="<?php echo $rows["glry_link"]; ?>"><h3 class="title"><?php echo $rows["glry_title"]; ?></h3></a>
                                    
                                </div>
                                <div class="readmore">
                                    <a href="<?php echo $rows["glry_link"]; ?>" class="entry-read-more">
                                        <div class="read-more"><span class="svg-icon"><i class="flaticon-right"></i></span> Read more</div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <?php 
                                    }
                    ?>
                </div>
                <div class="grd-button-group grd-align-center">
                <?php
                                    $result1 = mysqli_query($conn,"SELECT * FROM gallery ");
                                    $rows = mysqli_fetch_array($result1)
                                    
                                ?>
                    <a href="<?php echo $rows["glry_link"]; ?>" class="grd-button hidden-xs hover-1"><span>See More</span></a>
                </div>
            </div>
        </div>
        <!--gallery end-->
<?php include('footer.php');?>