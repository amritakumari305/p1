<div class="page-wrapper">
        <header class="header header-all-coralf header-coral">
            <div class="header-top">
                <div class="container">
                    <div class="header-left">
                        <a href="tel:9521132592" class="">
                            <i class="icon-phone h6 second-primary-color"></i>Call: +91-9521132592</a>
                    </div>

                    <div class="header-right font-weight-normal">
                        <ul class="top-menu">
                            <li><a href="#">Menu</a>
                                <ul>
                                    <li>
                                        <div class="header-dropdown">
                                            <a href="#"><i class="icon-map-marker"></i> Jaipur</a>
                                            <div class="header-menu">
                                                <ul>
                                                    <li><a href="#">Jaipur</a></li>
                                                    <li><a href="#">Alwar</a></li>
                                                    <li><a href="#">Udaipur</a></li>
                                                    <li><a href="#">Ajmer</a></li>
                                                </ul>
                                            </div>

                                        </div>
                                    </li>
                                    <li><a href="#signin-modal" data-toggle="modal">Sign in / Sign up</a></li>
                                </ul>
                            </li>
                        </ul>

                    </div>

                </div>

            </div>

            <div class="header-middle">
                <div class="container">
                    <div class="header-left">
                        <button class="mobile-menu-toggler">
                            <span class="sr-only">Toggle mobile menu</span>
                            <i class="icon-bars"></i>
                        </button>

                        <a href="index.php" class="logo">
                            <img src="assets/images/logo.jpg" alt="coralc Logo" width="180" height="25">
                        </a>
                    </div>

                    <div class="header-center">
                        <div class="header-search header-search-visible header-search-no-radius">
                            <a href="#" class="search-toggle" role="button">
                                <i class="icon-search"></i>
                            </a>
                            <form action="#" method="get">
                                <div class="header-search-wrapper search-wrapper-wide">

                                    <div class="select-custom">
                                        <select id="cat" name="cat">
                                            <option value="">All Departments</option>
                                            <option value="1">Fashion</option>
                                            <option value="2">- Women</option>
                                            <option value="3">- Shoes</option>
                                            <option value="4">- Jewellery</option>
                                            <option value="5">Accessories</option>
                                            <option value="6">- Belt</option>
                                            <option value="7">- Bag</option>
                                            <option value="8">- Cap</option>
                                        </select>
                                    </div>

                                    <label for="ssearch" class="sr-only">Search</label>
                                    <input type="search" class="form-control" name="ssearch" id="ssearch" placeholder="Search product ..." required>

                                    <button class="btn btn-primary" type="submit">
                                        <i class="icon-search"></i>
                                    </button>
                                </div>

                            </form>
                        </div>

                    </div>

                    <div class="header-right">
                        <div class="header-dropdown-link">
                            <div class="wishlist">
                                <a href="wishlist.php" title="Wishlist">
                                    <div class="icon">
                                        <i class="icon-heart-o"></i>
                                        <span class="wishlist-count badge">3</span>
                                    </div>

                                </a>
                            </div>


                            <div class="dropdown cart-dropdown">
                                <a href="#" class="dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static">
                                    <div class="icon">
                                        <i class="icon-shopping-cart"></i>
                                        <span class="cart-count">2</span>
                                    </div>

                                </a>

                                <div class="dropdown-menu dropdown-menu-right">
                                    <div class="dropdown-cart-products">
                                        <div class="product">
                                            <div class="product-cart-details">
                                                <h4 class="product-title letter-spacing-normal font-size-normal">
                                                    <a href="#">shoes</a>
                                                </h4>

                                                <span class="cart-product-info">
                                                    <span class="cart-product-qty">1</span> x $84.00
                                                </span>
                                            </div>

                                            <figure class="product-image-container">
                                                <a href="#" class="product-image">
                                                    <img src="assets/images/products/cart/product-1.jpg" alt="product" width="200" height="300">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-remove" title="Remove Product">
                                                <i class="icon-close"></i>
                                            </a>
                                        </div>

                                        <div class="product">
                                            <div class="product-cart-details">
                                                <h4 class="product-title letter-spacing-normal font-size-normal">
                                                    <a href="#">Blue denim dress</a>
                                                </h4>

                                                <span class="cart-product-info">
                                                    <span class="cart-product-qty">1</span> x $76.00
                                                </span>
                                            </div>
                                            <figure class="product-image-container">
                                                <a href="#" class="product-image">
                                                    <img src="assets/images/products/cart/product-2.jpg" alt="product">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-remove" title="Remove Product">
                                                <i class="icon-close"></i>
                                            </a>
                                        </div>

                                        <div class="product">
                                            <div class="product-cart-details">
                                                <h4 class="product-title letter-spacing-normal font-size-normal">
                                                    <a href="#">Blue denim dress</a>
                                                </h4>

                                                <span class="cart-product-info">
                                                    <span class="cart-product-qty">1</span> x $76.00
                                                </span>
                                            </div>

                                            <figure class="product-image-container">
                                                <a href="#" class="product-image">
                                                    <img src="assets/images/products/cart/product-2.jpg" alt="product">
                                                </a>
                                            </figure>
                                            <a href="#" class="btn-remove" title="Remove Product">
                                                <i class="icon-close"></i>
                                            </a>
                                        </div>

                                    </div>

                                    <div class="dropdown-cart-total">
                                        <span>Total</span>

                                        <span class="cart-total-price">$160.00</span>
                                    </div>

                                    <div class="dropdown-cart-action">
                                        <a href="cart.php" class="btn btn-primary">View Cart</a>
                                        <a href="checkout.php" class="btn btn-outline-primary-2">
                                            <span>Checkout</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </a>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>

                </div>

            </div>

            <div class="header-bottom sticky-header" style="background: #f0ebff;">
                <div class="container">
                    <div class="header-center">
                        <nav class="main-nav">
                            <ul class="menu sf-arrows">
                                <li class="megamenu-container active">
                                    <a href="index.php">Home</a>


                                </li>
                                <li>
                                    <a href="#" class="sf-with-ul">Shop</a>

                                    <div class="megamenu megamenu-md">
                                        <div class="row no-gutters">
                                            <div class="col-md-8">
                                                <div class="menu-col">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="menu-title">Shop By Categories</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Dresses</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Accessories</a>
                                                                </li>

                                                                <li>
                                                                    <a href="#">
                                                                        <span>Shoes
                                                                            <span class="tip tip-new">New</span>
                                                                        </span>
                                                                    </a>
                                                                </li>
                                                            </ul>

                                                            <div class="menu-title">Shop By Brand</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">
                                                                        <span>Puma
                                                                            <span class="tip tip-hot">Hot</span>
                                                                        </span>
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Nayaka</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Trends</a>
                                                                </li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-6">
                                                            <div class="menu-title">Shop By Offer</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">50% Off</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">
                                                                        <span>20% off 
                                                                            <span class="tip tip-new">New</span>
                                                                        </span>
                                                                    </a>
                                                                </li>
                                                            </ul>
                                                            <div class="menu-title">Shop By To Searches</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Sleevless T-Shirt</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">V-Nack T-shirt</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Shirt</a>
                                                                </li>

                                                            </ul>
                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                            <div class="col-md-4">
                                                <div class="banner banner-overlay">
                                                    <a href="" class="banner banner-menu">
                                                        <img src="assets/images/menu/banner-1.jpg" alt="Banner" width="218" height="314">

                                                        <div class="banner-content banner-content-top">
                                                            <div class="banner-title text-white">Last
                                                                <br>Chance
                                                                <br>
                                                                <span>
                                                                    <strong>Sale</strong>
                                                                </span>
                                                            </div>

                                                        </div>

                                                    </a>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </li>

                                <li>
                                    <a href="#" class="sf-with-ul">Women's </a>

                                    <div class="megamenu megamenu-md">
                                        <div class="row no-gutters">
                                            <div class="col-md-12">
                                                <div class="menu-col">
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <div class="menu-title">Ethinic Wear</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Lehnga</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Churidar</a>
                                                                </li>

                                                                <li>
                                                                    <a href="#">Salwar Kameez</a>
                                                                </li>
                                                            </ul>

                                                            <div class="menu-title">Wester Wear</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Dresse</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Gowm</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Top</a>
                                                                </li>
                                                            </ul>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="menu-title">Footware</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Sneeker</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Sports shose</a>
                                                                </li>
                                                            </ul>
                                                            <div class="menu-title">Sports Ware</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Lower</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Shorts</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">T-shirt</a>
                                                                </li>

                                                            </ul>
                                                        </div>

                                                        <div class="col-md-4">
                                                            <div class="menu-title">Footware</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Sneeker</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Sports shose</a>
                                                                </li>
                                                            </ul>
                                                            <div class="menu-title">Sports Ware</div>

                                                            <ul>
                                                                <li>
                                                                    <a href="#">Lower</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">Shorts</a>
                                                                </li>
                                                                <li>
                                                                    <a href="#">T-shirt</a>
                                                                </li>

                                                            </ul>
                                                        </div>

                                                    </div>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </li>

                                <li>
                                    <a href="#" class="sf-with-ul">Summer Sale</a>

                                    <div class="megamenu megamenu-sm">
                                        <div class="row no-gutters">
                                            <div class="col-md-6">
                                                <div class="menu-col">
                                                    <div class="menu-title">Product Categories</div>

                                                    <ul>
                                                        <li>
                                                            <a href="#">Cotton Shirt</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">T-Shirt</a>
                                                        </li>
                                                        <li>
                                                            <a href="">
                                                                <span>Chicken Kurta
                                                                    <span class="tip tip-new">New</span>
                                                                </span>
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Plazo</a>
                                                        </li>
                                                        <li>
                                                            <a href="#">Cotton Pant</a>
                                                        </li>
                                                    </ul>
                                                </div>

                                            </div>


                                            <div class="col-md-6">
                                                <div class="banner banner-overlay">
                                                    <a href="#">
                                                        <img src="assets/images/menu/banner-2.jpg" alt="Banner" width="218" height="310">

                                                        <div class="banner-content banner-content-bottom">
                                                            <div class="banner-title text-white">New Collection
                                                                <br>
                                                                <span>
                                                                    <strong>Summer 2021</strong>
                                                                </span>
                                                            </div>

                                                        </div>

                                                    </a>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </li>
                                <li>
                                    <a href="#" class="sf-with-ul">CLOTHING</a>

                                    <ul>
                                        <li>
                                            <a href="#" class="sf-with-ul">Womens</a>

                                            <ul>
                                                <li>
                                                    <a href="#">Western</a>
                                                </li>
                                                <li>
                                                    <a href="E">Indian</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#" class="sf-with-ul">Men</a>

                                            <ul>
                                                <li>
                                                    <a href="#">Upper</a>
                                                </li>
                                                <li>
                                                    <a href="#">Bottom</a>
                                                </li>
                                            </ul>
                                        </li>

                                    </ul>
                                </li>
                                <li>
                                    <a href="blog.php">New Arrival</a>


                                </li>
                                <li>
                                    <a href="">Sale</a>


                                </li>
                                <li>
                                    <a href="blog.php">Blog</a>


                                </li>

                            </ul>

                        </nav>

                    </div>


                    <div class="header-right">
                        <i class="la la-lightbulb-o"></i>
                        <p class="text-dark"><a href="">Deal Of The Day</a></p>
                    </div>
                </div>

            </div>
            <!-- End header-bottom -->
        </header>
        <!-- End header -->