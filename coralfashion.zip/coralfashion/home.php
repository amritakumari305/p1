

<div class="container newsletter-popup-container mfp-hide" id="newsletter-popup-form">
    <div class="row justify-content-center">
        <div class="col-10">
            <div class="row  bg-white newsletter-popup-content">
                <div class="col-xl-12 col-lg-7 banner-content-wrap">
                    <div class="banner-content text-center mb-3">
                        <img src="assets/images/logo.jpg" class="logo" alt="logo" width="100" height="20">
                        <h2 class="banner-title">get
                            <span>25</span>
                            <mark style="background: #ffdfe7;">%</mark> off
                        </h2>
                        <p>Subscribe to the Coral Fashion newsletter to receive timely updates.</p>
                        <form action="#">
                            <div class="input-group input-group-round">
                                <input type="email" class="form-control form-control-white" placeholder="Your Email Address" aria-label="Email Adress" required>
                                <div class="input-group-append">
                                    <button class="btn" type="submit">
                                        <span>go</span>
                                    </button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<main class="main" style="background: #fafafa;">
    <div class="intro-section">
        <div class="container-fluid mt-1">
            <div class="row">
                <!-- <div class="col-lg-5cols d-none d-lg-block">
                            <div class="banner banner-overlay bg-image h-100 mb-0" style="background-color: #f1f1f1; background-image: url(assets/images/demos/demo-26/banners/banner-1.jpg); ">
                                <div class="banner-content position-relative pt-0 pb-md-7 d-flex flex-column">
                                    <div class="title text-center text-uppercase text-dark font-weight-bold mb-0">
                                        Phantom 3
                                        <br>Professional
                                    </div>
                                    <div class="price text-center">
                                        <sup class="text-dark font-weight-normal">from
                                            <span class="text-primary font-weight-normal">$</span>
                                        </sup>
                                        <span class="text-primary font-weight-bold">
                                            599.
                                        </span>
                                        <sup class="text-primary font-weight-bold" style="font-size: 55%; top: -.6em;">99</sup>
                                    </div>
                                </div>

                            </div>
                        </div> -->

                <div class="col-lg-3-5cols col-md-9 col-12 mb-md-0 mb-2">
                    <div class="intro-slider-container">
                        <div class="intro-slider owl-carousel owl-theme owl-nav-inside row cols-1" data-toggle="owl" data-owl-options='{
                                        "nav": false,
                                        "dots": true,
                                        "autoplay": false,
                                        "autoplayTimeout": 10000,
                                        "animateOut": "fadeOut"
                                    }'>
                            <div class="intro-slide bg-image d-flex align-items-center">
                                <img src="assets/images/banner-2.jpg" alt="">
                            </div>

                            <div class="intro-slide bg-image d-flex align-items-center">

                                <img src="assets/images/banner-3.jpg" alt="">


                            </div>

                            <div class="intro-slide bg-image d-flex align-items-center">
                                <img src="assets/images/banner-1.jpg" alt="">

                            </div>

                        </div>

                        <!-- 
                                    <span class="slider-loader"></span>
                                End slider-loader -->
                    </div>
                </div>


                <div class="col-lg-5cols col-md-3 col-12 mb-md-0 mb-2 d-none d-md-block">
                    <div class="banner banner-overlay bg-image h-100 mb-0" style="background-color: #f1f1f1; background-image: url(assets/images/bnrsd.jpg); ">
                        <div class="banner-content position-relative pt-0 pb-md-7 d-flex flex-column">

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid icon-boxes-section">
        <div class="icon-boxes-container pt-3 px-3 mb-1 mt-1">
            <div class="owl-carousel carousel-simple owl-theme carousel-equal-height shadow-carousel row cols-1 cols-md-2 cols-lg-3 cols-xl-4" data-toggle="owl" data-owl-options='{
                        "dots": true,
                        "nav": false, 
                        "loop": false,
                        "margin": 13,
                        "responsive": {
                            "0": {
                                "items": 1
                            },
                            "575": {
                                "items": 2
                            },
                            "992": {
                                "items": 3
                            },
                            "1200": {
                                "items": 4
                            }
                        }
                    }'>
                <div class="icon-box mb-0 d-md-flex align-items-md-center text-center text-md-left mx-md-0 mx-auto">
                    <span class="icon-box-icon text-dark mb-0">
                        <i class="icon-truck py-2 pt-0"></i>
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title font-size-normal mb-0 font-weight-bold text-uppercase">Payment &amp; Delivery</h3>
                        <p class="font-weight-light ">Free shipping for orders over $50</p>
                    </div>
                </div>
                <div class="icon-box mb-0 d-md-flex align-items-md-center text-center text-md-left mx-md-0 mx-auto">
                    <span class="icon-box-icon text-dark mb-0">
                        <i class="icon-rotate-left py-2 pt-0 "></i>
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title font-size-normal mb-0 font-weight-bold text-uppercase">Return &amp; Refund</h3>
                        <p class="font-weight-light">Free 100% money back guarantee</p>
                    </div>
                </div>
                <div class="icon-box mb-0 d-md-flex align-items-md-center text-center text-md-left mx-md-0 mx-auto">
                    <span class="icon-box-icon text-dark mb-0">
                        <i class="icon-life-ring py-2 pt-0"></i>
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title font-size-normal mb-0 font-weight-bold text-uppercase">Quality Support</h3>
                        <p class="font-weight-light">Alway online feedback 24/7</p>
                    </div>
                </div>
                <div class="icon-box mb-0 d-md-flex align-items-md-center text-center text-md-left mx-md-0 mx-auto">
                    <span class="icon-box-icon text-dark mb-0">
                        <i class="icon-envelope py-2 pt-0"></i>
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title font-size-normal mb-0 font-weight-bold text-uppercase">JOIN OUR NEWSLETTER</h3>
                        <p class="font-weight-light">10% off by subscribing to our newsletter</p>
                    </div>
                </div>
            </div>
        </div>
        <hr class="mt-1 mb-0">
    </div>

    <div class="pt-3 pb-3">
        <div class="container">
            <div class="banner-group">
                <div class="row">
                    <div class="col-sm-6 col-lg-4">
                        <div class="banner banner-overlay banner-lg">
                            <a href="#">
                                <img src="assets/images/demos/demo-9/banners/banner-1.jpg" alt="Banner">
                            </a>

                            <div class="banner-content banner-content-bottom">
                                <h4 class="banner-subtitle text-white"><a href="#">Clearance</a></h4>

                                <h3 class="banner-title text-white"><a href="#">Dresse</a></h3>

                                <div class="banner-text text-white"><a href="#">from $19.00</a></div>

                                <a href="#" class="btn btn-outline-white banner-link">Discover Now</a>
                            </div>

                        </div>

                    </div>

                    <div class="col-sm-6 col-lg-4 order-lg-last">
                        <div class="banner banner-overlay banner-lg">
                            <a href="#">
                                <img src="assets/images/demos/demo-9/banners/banner-4.jpg" alt="Banner">
                            </a>

                            <div class="banner-content banner-content-top">
                                <h4 class="banner-subtitle text-white"><a href="#">On Sale</a></h4>

                                <h3 class="banner-title text-white"><a href="#">Women's<br>Sportswear</a></h3>

                                <div class="banner-text text-white"><a href="#">from $20.00</a></div>

                                <a href="#" class="btn btn-outline-white banner-link">Discover Now</a>
                            </div>

                        </div>

                    </div>

                    <div class="col-12 col-lg-4">
                        <div class="row">
                            <div class="col-sm-6 col-lg-12">
                                <div class="banner banner-overlay">
                                    <a href="#">
                                        <img src="assets/images/demos/demo-9/banners/banner-2.jpg" alt="Banner">
                                    </a>

                                    <div class="banner-content">
                                        <h4 class="banner-subtitle text-white"><a href="#">New Arrivals</a></h4>

                                        <h3 class="banner-title text-white"><a href="#">Accessories<br>and Shoes</a></h3>

                                        <a href="#" class="btn btn-outline-white banner-link">Shop Now</a>
                                    </div>

                                </div>

                            </div>

                            <div class="col-sm-6 col-lg-12">
                                <div class="banner banner-overlay">
                                    <a href="#">
                                        <img src="assets/images/demos/demo-9/banners/banner-3.jpg" alt="Banner">
                                    </a>

                                    <div class="banner-content">
                                        <h4 class="banner-subtitle text-white"><a href="#">New Arrivals</a></h4>

                                        <h3 class="banner-title text-white"><a href="#">Summer 2019</a></h3>

                                        <a href="#" class="btn btn-outline-white banner-link">Shop Now</a>
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>



    <div class="container banner-group-1">
        <div class="categories mb-3">
            <h3 class="title text-center font-weight-bold mt-2">Explore Popular Categories</h3>
            <div class="owl-carousel carousel-theme carousel-simple carousel-with-shadow row cols-2 cols-xs-3 cols-sm-4 cols-md-5 cols-lg-6 cols-xl-8" data-toggle="owl" data-owl-options='{
                                "nav": false, 
                                "dots": false,
                                "margin": 10,
                                "loop": false,
                                "responsive": {
                                    "0": {
                                        "items":2
                                    },
                                    "480": {
                                        "items":3
                                    },
                                    "576": {
                                        "items":3
                                    },
                                    "768": {
                                        "items":5
                                    },
                                    "992": {
                                        "items":6
                                    },
                                    "1200": {
                                        "items":8
                                    }
                                }
                            }'>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Westerns</a>
                    </div>
                </div>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images2.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Sports</a>
                    </div>
                </div>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images1.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Dresses</a>
                    </div>
                </div>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images3.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Indian</a>
                    </div>
                </div>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images4.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Night Ware</a>
                    </div>
                </div>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images5.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Footware</a>
                    </div>
                </div>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images6.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Glasses</a>
                    </div>
                </div>
                <div class="category position-relative">
                    <div class="category-image">
                        <a href="#">
                            <img src="assets/images/images7.jpg" class="w-100" alt="" width="166" height="160">
                        </a>
                    </div>
                    <div class="category-body letter-spacing-normal font-size-normal text-center position-absolute text-uppercase">
                        <a href="#" class="category-title text-truncate font-weight-normal">Watches</a>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- deal-section -->
    <div class="container deal-section">
        <h3 class="title text-center mt-5 font-weight-bold">Today's Best Deal</h3>
        <div class="deal-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-md-3 cols-lg-4 cols-xl-5" data-toggle="owl" data-owl-options='{
                        "nav": true, 
                        "dots": false,
                        "margin": 0,
                        "loop": false,
                        "responsive": {
                            "0": {
                                "items":2
                            },
                            "480": {
                                "items":2
                            },
                            "767": {
                                "items":3
                            },
                            "992": {
                                "items":4
                            },
                            "1200": {
                                "items":5
                            },
                            "1600": {
                                "items":5
                            }
                        }
                    }'>
            <div class="product d-flex flex-column overflow-hidden">
                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                    <span class="product-label label-sale">SALE</span>
                    <a href="#" class="w-100">
                        <img src="assets/images/p/pd1.jpg" alt="Product image" class="product-image" width="239" height="239">
                        <img src="assets/images/p/pd2.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                    </a>

                    <div class="product-countdown" data-until="+55h" data-relative="true" data-labels-short="true"></div>

                    <div class="product-action-vertical">
                        <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                            <span></span>
                        </a>
                        <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                            <span></span>
                        </a>

                    </div>
                </figure>


                <div class="product-body pb-1">


                    <h3 class="product-title letter-spacing-normal  text-left mb-0">
                        <a href="#">Item Title</a>
                    </h3>

                    <div class="product-price mb-1">
                        <div class="new-price">$251.99</div>
                        <div class="old-price font-size-normal font-weight-normal">$290.00</div>
                    </div>


                    <div class="product-nav product-nav-dots">
                        <a href="#" class="active" style="background: #69b4ff;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #ff887f;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #333333;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #f1f1f1;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #c00b1b;">
                            <span class="sr-only">Color name</span>
                        </a>
                    </div>
                </div>
                <div class="product-action position-relative visible">
                    <a href="#" class="btn-product btn-cart text-uppercase  text-decoration-none" title="Add to cart">
                        <span class="shadow-none">add to cart</span>
                    </a>
                </div>

            </div>

            <div class="product d-flex flex-column overflow-hidden">
                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                    <a href="#" class="w-100">
                        <img src="assets/images/p/pd3.jpg" alt="Product image" class="product-image" width="239" height="239">
                        <img src="assets/images/p/pd4.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                    </a>

                    <div class="product-action-vertical">
                        <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                            <span></span>
                        </a>
                        <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                            <span></span>
                        </a>

                    </div>
                </figure>

                <div class="product-body pb-1">


                    <h3 class="product-title letter-spacing-normal  text-left mb-0">
                        <a href="#">Item Title</a>
                    </h3>

                    <div class="product-price mb-1">
                        <div class="new-price">$179.99</div>
                        <div class="old-price font-size-normal font-weight-normal">$190.00</div>
                    </div>

                    <div class="product-nav product-nav-dots">
                        <a href="#" class="active" style="background: #69b4ff;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #ff887f;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #333333;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #f1f1f1;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #c00b1b;">
                            <span class="sr-only">Color name</span>
                        </a>
                    </div>
                </div>

                <div class="product-action position-relative visible">
                    <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                        <span class="shadow-none">add to cart</span>
                    </a>
                </div>

            </div>

            <div class="product d-flex flex-column overflow-hidden">
                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                    <span class="product-label label-new">New</span>
                    <a href="#" class="w-100">
                        <img src="assets/images/p/pd5.jpg" alt="Product image" class="product-image" width="239" height="239">
                        <img src="assets/images/p/pd6.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                    </a>

                    <div class="product-action-vertical">
                        <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                            <span></span>
                        </a>
                        <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                            <span></span>
                        </a>

                    </div>
                </figure>

                <div class="product-body pb-1">


                    <h3 class="product-title letter-spacing-normal  text-left mb-0">
                        <a href="#">Item Title</a>
                    </h3>

                    <div class="product-price mb-1">
                        <div class="new-price">$74.00</div>
                        <div class="old-price font-size-normal font-weight-normal">$90.00</div>
                    </div>

                    <div class="product-nav product-nav-dots">
                        <a href="#" class="active" style="background: #69b4ff;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #ff887f;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #333333;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #f1f1f1;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #c00b1b;">
                            <span class="sr-only">Color name</span>
                        </a>
                    </div>

                </div>

                <div class="product-action position-relative visible">
                    <a href="#" class="btn-product btn-cart text-uppercase  text-decoration-none" title="Add to cart">
                        <span class="shadow-none">add to cart</span>
                    </a>
                </div>

            </div>

            <div class="product d-flex flex-column overflow-hidden">
                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                    <span class="product-label label-top">Top</span>

                    <a href="#" class="w-100">
                        <img src="assets/images/p/pd7.jpg" alt="Product image" class="product-image" width="239" height="239">
                        <img src="assets/images/p/pd8.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                    </a>

                    <div class="product-countdown" data-until="+55h" data-relative="true" data-labels-short="true"></div>

                    <div class="product-action-vertical">
                        <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                            <span></span>
                        </a>
                        <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                            <span></span>
                        </a>

                    </div>
                </figure>

                <div class="product-body pb-1">


                    <h3 class="product-title letter-spacing-normal  text-left mb-0">
                        <a href="#">Item Title</a>
                    </h3>

                    <div class="product-price mb-1">
                        <div class="new-price">$779.99</div>
                        <div class="old-price font-size-normal font-weight-normal">$990.00</div>
                    </div>


                    <div class="product-nav product-nav-dots">
                        <a href="#" class="active" style="background: #69b4ff;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #ff887f;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #333333;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #f1f1f1;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #c00b1b;">
                            <span class="sr-only">Color name</span>
                        </a>
                    </div>
                </div>
                <div class="product-action position-relative visible">
                    <a href="#" class="btn-product btn-cart text-uppercase  text-decoration-none" title="Add to cart">
                        <span class="shadow-none">add to cart</span>
                    </a>
                </div>

            </div>


            <div class="product d-flex flex-column overflow-hidden">
                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                    <span class="product-label label-top">Top</span>
                    <a href="#" class="w-100">
                        <img src="assets/images/p/pd9.jpg" alt="Product image" class="product-image" width="239" height="239">
                        <img src="assets/images/p/pd10.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                    </a>

                    <div class="product-action-vertical">
                        <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                            <span></span>
                        </a>
                        <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                            <span></span>
                        </a>

                    </div>
                </figure>

                <div class="product-body pb-1">


                    <h3 class="product-title letter-spacing-normal  text-left mb-0">
                        <a href="#">Item Title</a>
                    </h3>

                    <div class="product-price mb-1">
                        <div class="new-price">$282.99</div>
                        <div class="old-price font-size-normal font-weight-normal">$349.99</div>
                    </div>

                    <div class="product-nav product-nav-dots">
                        <a href="#" class="active" style="background: #69b4ff;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #ff887f;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #333333;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #f1f1f1;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #c00b1b;">
                            <span class="sr-only">Color name</span>
                        </a>
                    </div>
                </div>

                <div class="product-action position-relative visible">
                    <a href="#" class="btn-product btn-cart text-uppercasetext-decoration-none" title="Add to cart">
                        <span class="shadow-none">add to cart</span>
                    </a>
                </div>
            </div>


            <div class="product d-flex flex-column overflow-hidden">
                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                    <span class="product-label label-top">Top</span>
                    <a href="#" class="w-100">
                        <img src="assets/images/p/pd11.jpg" alt="Product image" class="product-image" width="239" height="239">
                        <img src="assets/images/p/pd12.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                    </a>

                    <div class="product-action-vertical">
                        <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                            <span></span>
                        </a>
                        <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                            <span></span>
                        </a>

                    </div>
                </figure>
                <!-- End .product-media bg-white d-flex justify-content-center align-items-center -->

                <div class="product-body pb-1">

                    <!-- End .product-cat  -->
                    <h3 class="product-title letter-spacing-normal  text-left mb-0">
                        <a href="#">Item Title</a>
                    </h3>
                    <!-- End .product-title letter-spacing-normal font-size-normal -->
                    <div class="product-price mb-1">
                        <div class="new-price">$282.99</div>
                        <div class="old-price font-size-normal font-weight-normal">$349.99</div>
                    </div>
                    <!-- End .product-price -->
                    <div class="product-nav product-nav-dots">
                        <a href="#" class="active" style="background: #69b4ff;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #ff887f;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #333333;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #f1f1f1;">
                            <span class="sr-only">Color name</span>
                        </a>
                        <a href="#" style="background: #c00b1b;">
                            <span class="sr-only">Color name</span>
                        </a>
                    </div>
                </div>
                <!-- End product-body -->
                <div class="product-action position-relative visible">
                    <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                        <span class="shadow-none">add to cart</span>
                    </a>
                </div>
                <!-- End product-action -->

            </div>
            <!-- End product -->
        </div>
    </div>
    <!-- End deal-section -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="banner banner-rad mt-5">
                    <div class="bg-image d-flex justify-content-center pt-5 pb-4 mb-4" style="background-image: url(assets/images/bg1.jpg);">
                        <div class="banner-content position-relative pt-0">
                            <h4 class="banner-subtitle banner-bg letter-spacing-normal font-size-normal text-white text-center pt-1 mb-1">
                                <a href="#">Discount</a>
                            </h4>

                            <h3 class="banner-title text-white text-center font-weight-bold mb-0">
                                <a href="#">For All Summer Collection
                                    <br> Of Women's Item</a>
                            </h3>

                            <h4 class="banner-text text-secondary text-center font-weight-light text-uppercase">Sale Up 35% Off</h4>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- new arrival shop -->
    <div class="container new-arrival">
        <div class="heading heading-center mb-3">
            <h2 class="title">NEW ARRIVALS</h2>

            <ul class="nav nav-pills justify-content-center" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="new-women-link" data-toggle="tab" href="#new-women-tab" role="tab" aria-controls="new-women-tab" aria-selected="true">Womens Clothing</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="new-men-link" data-toggle="tab" href="#new-men-tab" role="tab" aria-controls="new-men-tab" aria-selected="false">Mens Clothing</a>
                </li>
            </ul>
        </div>
        <!-- End heading -->

        <div class="tab-content">
            <div class="tab-pane p-0 fade active show" id="new-women-tab" role="tabpanel" aria-labelledby="new-women-link">
                <div class="products">
                    <div class="row justify-content-center">
                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">

                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-2-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-2-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Tie-detail top</a></h3>

                                    <div class="product-price">
                                        <span class="new-price">$50.00</span>
                                        <span class="old-price">$84.00</span>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-5-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-5-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Dress with a belt</a></h3>

                                    <div class="product-price">
                                        $120.99
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-8-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-8-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Linen-blend paper bag trousers</a></h3>

                                    <div class="product-price">
                                        $60.00
                                    </div>

                                    <div class="product-nav product-nav-dots">
                                        <a href="#" class="active" style="background: #d5ad81;"><span class="sr-only">Color name</span></a>
                                        <a href="#" style="background: #333333;"><span class="sr-only">Color name</span></a>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">

                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-11-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-11-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>


                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Paper straw shopper</a></h3>

                                    <div class="product-price">
                                        $80.95
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-14-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-14-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Trainers</a></h3>

                                    <div class="product-price">
                                        $56.00
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">

                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-11-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-11-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Hooded top </a></h3>

                                    <div class="product-price">
                                        <span class="new-price">$50.00</span>
                                        <span class="old-price">$84.00</span>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-12-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-12-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>
                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Vest dress</a></h3>

                                    <div class="product-price">
                                        $89.99
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-13-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-13-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Long-sleeved blouse</a></h3>

                                    <div class="product-price">
                                        $84.00
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-4-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-4-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Denim jacket</a></h3>

                                    <div class="product-price">
                                        $80.95
                                    </div>

                                    <div class="product-nav product-nav-dots">
                                        <a href="#" class="active" style="background: #7ba1c9;"><span class="sr-only">Color name</span></a>
                                        <a href="#" style="background: #333333;"><span class="sr-only">Color name</span></a>
                                        <a href="#" style="background: #feb143;"><span class="sr-only">Color name</span></a>
                                        <a href="#" style="background: #f0c7b7;"><span class="sr-only">Color name</span></a>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-7-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-7-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Sunglasses</a></h3>

                                    <div class="product-price">
                                        $56.00
                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="tab-pane p-0 fade" id="new-men-tab" role="tabpanel" aria-labelledby="new-men-link">
                <div class="products">
                    <div class="row justify-content-center">
                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-8-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-8-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Linen-blend paper bag trousers</a></h3>

                                    <div class="product-price">
                                        $60.00
                                    </div>

                                    <div class="product-nav product-nav-dots">
                                        <a href="#" class="active" style="background: #d5ad81;"><span class="sr-only">Color name</span></a>
                                        <a href="#" style="background: #333333;"><span class="sr-only">Color name</span></a>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">

                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-11-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-11-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>
                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Paper straw shopper</a></h3>

                                    <div class="product-price">
                                        $80.95
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-12-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-12-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Trainers</a></h3>

                                    <div class="product-price">
                                        $56.00
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">

                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-2-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-2-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Hooded top </a></h3>

                                    <div class="product-price">
                                        <span class="new-price">$50.00</span>
                                        <span class="old-price">$84.00</span>
                                    </div>

                                </div>

                            </div>

                        </div>

                        <div class="col-6 col-md-4 col-lg-3 col-xl-5col">
                            <div class="product product-7 text-center">
                                <figure class="product-media">
                                    <a href="">
                                        <img src="assets/images/demos/demo-7/products/product-12-1.jpg" alt="Product image" class="product-image">
                                        <img src="assets/images/demos/demo-7/products/product-12-2.jpg" alt="Product image" class="product-image-hover">
                                    </a>

                                    <div class="product-action-vertical">
                                        <a href="#" class="btn-product-icon btn-wishlist btn-expandable"><span></span></a>
                                        <a href="" class="btn-product-icon btn-quickview" title=""><span></span></a>
                                    </div>

                                    <div class="product-action">
                                        <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                                    </div>

                                </figure>

                                <div class="product-body">
                                    <h3 class="product-title"><a href="">Vest dress</a></h3>

                                    <div class="product-price">
                                        $89.99
                                    </div>


                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <div class="more-container text-center mt-2">
            <a href="#" class="btn btn-outline-dark-3 btn-more"><span>Load more</span><i class="icon-long-arrow-right"></i></a>
        </div>
    </div>
    <!--end new arrival shop -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="banner">
                    <img src="assets/images/banner-4.jpg" alt="" width="100%">
                </div>
            </div>
        </div>
    </div>


    <!-- clothing tab shop -->
    <div class="container electronics fashion mb-5">
        <div class="trending-products">
            <div class="heading heading-flex">
                <div class="heading-left">
                    <h2 class="title font-weight-bold mb-1">Fashion &amp; Clothing</h2>

                </div>

                <div class="heading-right">
                    <ul class="nav nav-pills justify-content-center mr-n3" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link font-size-normal second-primary-color font-weight-normal text-uppercase active" id="fashion-best-link" data-toggle="tab" href="#fashion-best-tab" role="tab" aria-controls="fashion-best-tab" aria-selected="true">Best Sellers</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link font-size-normal second-primary-color font-weight-normal text-uppercase" id="fashion-trending-link" data-toggle="tab" href="#fashion-trending-tab" role="tab" aria-controls="fashion-trending-tab" aria-selected="false">Trending</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link font-size-normal second-primary-color font-weight-normal text-uppercase" id="fashion-woman-link" data-toggle="tab" href="#fashion-woman-tab" role="tab" aria-controls="fashion-woman-tab" aria-selected="false">Woman</a>
                        </li>
                        <!-- <li class="nav-item">
                                    <a class="nav-link font-size-normal second-primary-color font-weight-normal text-uppercase" id="fashion-man-link" data-toggle="tab" href="#fashion-man-tab" role="tab" aria-controls="fashion-man-tab" aria-selected="false">Man</a>
                                </li> -->
                        <li class="nav-item">
                            <a class="nav-link font-size-normal second-primary-color font-weight-normal text-uppercase" id="fashion-shoes-link" data-toggle="tab" href="#fashion-shoes-tab" role="tab" aria-controls="fashion-shoes-tab" aria-selected="false">Shoes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link font-size-normal second-primary-color font-weight-normal text-uppercase" id="fashion-accessories-link" data-toggle="tab" href="#fashion-accessories-tab" role="tab" aria-controls="fashion-accessories-tab" aria-selected="false">Accessories</a>
                        </li>
                    </ul>
                </div>

            </div>

            <div class="tab-content tab-content-carousel position-relative">
                <div class="tab-pane p-0 fade show active" id="fashion-best-tab" role="tabpanel" aria-labelledby="fashion-best-link">
                    <div class="electronic-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-sm-3 cols-lg-4 cols-xl-5 cols-xxl-6" data-toggle="owl" data-owl-options='{
                                    "nav": false, 
                                    "dots": false,
                                    "margin": 0,
                                    "loop": false,
                                    "responsive": {
                                        "0": {
                                            "items":2
                                        },
                                        "480": {
                                            "items":2
                                        },
                                        "576": {
                                            "items":3
                                        },
                                        "992": {
                                            "items":4
                                        },
                                        "1200": {
                                            "items":5
                                        },
                                        "1400": {
                                            "items":6
                                        }
                                    }
                                }'>
                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <a href="" class="w-100">
                                    <img src="assets/images/p/1.1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/1.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Elasticated cotton shorts</a>
                                </h3>

                                <div class="product-price mb-1">
                                    $29.99
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-top">Top</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/2.1.jpeg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/2.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>
                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Tie-detail top</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    $11.00
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>


                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-sale">Sale</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/3.1.jpeg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/3.2.jpeg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Loafers</a>
                                </h3>

                                <div class="product-price mb-1">
                                    <div class="new-price">$24.00</div>
                                    <div class="old-price font-size-normal">$49.00</div>
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <a href="" class="w-100">
                                    <img src="assets/images/p/4.1.jpeg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/4.2.jpeg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">

                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Trainers</a>
                                </h3>

                                <div class="product-price mb-1">
                                    $39.99
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-top">Top</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/5.1.jpeg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/5.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Backpack</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    $42.00
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase btn-select text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">Select Options</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-top">Top</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/6.1.jpeg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/6.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Backpack</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    $42.00
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase btn-select text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">Select Options</span>
                                </a>
                            </div>

                        </div>

                    </div>

                </div>

                <div class="tab-pane p-0 fade" id="fashion-trending-tab" role="tabpanel" aria-labelledby="fashion-trending-link">
                    <div class="electronic-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-md-3 cols-lg-4 cols-xl-5 cols-xxl-6" data-toggle="owl" data-owl-options='{
                                    "nav": false, 
                                    "dots": false,
                                    "margin": 0,
                                    "loop": false,
                                    "responsive": {
                                        "0": {
                                            "items":2
                                        },
                                        "480": {
                                            "items":2
                                        },
                                        "576": {
                                            "items":3
                                        },
                                        "992": {
                                            "items":4
                                        },
                                        "1200": {
                                            "items":5
                                        },
                                        "1400": {
                                            "items":6
                                        }
                                    }
                                }'>
                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <a href="" class="w-100">
                                    <img src="assets/images/p/7.1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/7.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Elasticated cotton shorts</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    $29.99
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-top">Top</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/demos/demo-26/products/product-26.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/demos/demo-26/products/product-26-2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>
                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Tie-detail top</a>
                                </h3>

                                <div class="product-price mb-1">
                                    $11.00
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase  text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-sale">Sale</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/demos/demo-26/products/product-3.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/demos/demo-26/products/product-3-2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Loafers</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    <div class="new-price">$24.00</div>
                                    <div class="old-price font-size-normal">$49.00</div>
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                    </div>

                </div>

                <div class="tab-pane p-0 fade" id="fashion-woman-tab" role="tabpanel" aria-labelledby="fashion-woman-link">
                    <div class="electronic-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-md-3 cols-lg-4 cols-xl-5 cols-xxl-6" data-toggle="owl" data-owl-options='{
                                    "nav": false, 
                                    "dots": false,
                                    "margin": 0,
                                    "loop": false,
                                    "responsive": {
                                        "0": {
                                            "items":2
                                        },
                                        "480": {
                                            "items":2
                                        },
                                        "576": {
                                            "items":3
                                        },
                                        "992": {
                                            "items":4
                                        },
                                        "1200": {
                                            "items":5
                                        },
                                        "1400": {
                                            "items":6
                                        }
                                    }
                                }'>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-top">Top</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/demos/demo-26/products/product-26.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/demos/demo-26/products/product-26-2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>
                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Tie-detail top</a>
                                </h3>

                                <div class="product-price mb-1">
                                    $11.00
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-sale">Sale</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/7.1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/7.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">

                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Loafers</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    <div class="new-price">$24.00</div>
                                    <div class="old-price font-size-normal">$49.00</div>
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <a href="" class="w-100">
                                    <img src="assets/images/demos/demo-26/products/product-6.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/demos/demo-26/products/product-6-2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Trainers</a>
                                </h3>

                                <div class="product-price mb-1">
                                    $39.99
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                    </div>

                </div>


                <div class="tab-pane p-0 fade" id="fashion-shoes-tab" role="tabpanel" aria-labelledby="fashion-shoes-link">
                    <div class="electronic-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-md-3 cols-lg-4 cols-xl-5 cols-xxl-6" data-toggle="owl" data-owl-options='{
                                    "nav": false, 
                                    "dots": false,
                                    "margin": 0,
                                    "loop": false,
                                    "responsive": {
                                        "0": {
                                            "items":2
                                        },
                                        "480": {
                                            "items":2
                                        },
                                        "576": {
                                            "items":3
                                        },
                                        "992": {
                                            "items":4
                                        },
                                        "1200": {
                                            "items":5
                                        },
                                        "1400": {
                                            "items":6
                                        }
                                    }
                                }'>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-top">Top</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/7.1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/7.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">
                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Backpack</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    $42.00
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>


                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-top">Top</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/7.1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/7.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>


                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Backpack</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    $42.00
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                    </div>

                </div>

                <div class="tab-pane p-0 fade" id="fashion-accessories-tab" role="tabpanel" aria-labelledby="fashion-accessories-link">
                    <div class="electronic-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-md-3 cols-lg-4 cols-xl-5 cols-xxl-6" data-toggle="owl" data-owl-options='{
                                    "nav": false, 
                                    "dots": false,
                                    "margin": 0,
                                    "loop": false,
                                    "responsive": {
                                        "0": {
                                            "items":2
                                        },
                                        "480": {
                                            "items":2
                                        },
                                        "576": {
                                            "items":3
                                        },
                                        "992": {
                                            "items":4
                                        },
                                        "1200": {
                                            "items":5
                                        },
                                        "1400": {
                                            "items":6
                                        }
                                    }
                                }'>
                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <span class="product-label label-sale">Sale</span>
                                <a href="" class="w-100">
                                    <img src="assets/images/p/7.1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/7.2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Loafers</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    <div class="new-price">$24.00</div>
                                    <div class="old-price font-size-normal">$49.00</div>
                                </div>

                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                        <div class="product d-flex flex-column overflow-hidden">
                            <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                <a href="" class="w-100">
                                    <img src="assets/images/p/4.1.jpeg" alt="Product image" class="product-image" width="192" height="192">
                                    <img src="assets/images/p/4.2.jpeg" alt="Product image" class="product-image-hover" width="192" height="192">
                                </a>

                                <div class="product-action-vertical">
                                    <a href="#" class="btn-product-icon text-dark btn-wishlist" title="">
                                        <span></span>
                                    </a>
                                    <a href="" class="btn-product-icon text-dark btn-quickview" title="">
                                        <span></span>
                                    </a>

                                </div>

                            </figure>

                            <div class="product-body">


                                <h3 class="product-title letter-spacing-normal font-size-normal mb-0 text-left">
                                    <a href="">Trainers</a>
                                </h3>

                                <div class="product-price mb-1 ">
                                    $39.99
                                </div>


                            </div>

                            <div class="product-action position-relative visible">
                                <a href="#" class="btn-product btn-cart text-uppercase text-decoration-none" title="Add to cart">
                                    <span class="shadow-none">add to cart</span>
                                </a>
                            </div>

                        </div>

                    </div>

                </div>

                <div class="banner banner-overlay mb-0 bg-image position-md-relative position-absolute" style="background-image: url(assets/images/j.jpg);">

                    <div class="banner-content position-relative d-flex flex-column">
                        <h3 class="banner-title text-white font-weight-bold mb-2 text-left">Women's
                            <br>Sportswear &amp; Joggers
                        </h3>
                        <a href="#" class="btn-product text-decoration-none text-uppercase text-dark btn-rounded" title="">
                            <span class="shadow-none">Discover Now&nbsp;&nbsp;
                                <i class="icon-long-arrow-right d-inline-block"></i>
                            </span>
                        </a>
                    </div>
                </div>

            </div>

            <div class="more-container text-center mt-4">
                <a href="#" class="btn btn-outline-dark-3 btn-more"><span>See more</span><i class="icon-long-arrow-right"></i></a>
            </div>

        </div>
    </div>
    <!-- end clothing tab shop -->

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="banner">
                    <img src="assets/images/banner-5.png" alt="" width="100%">
                </div>
            </div>
        </div>
    </div>



    <!-- brands shop -->
    <div class="bg-white brand-section pt-3 pb-3">
        <div class="container">
            <h3 class="title text-center  font-weight-bold">Top Brands</h3>
            <div class="owl-carousel owl-simple brands-carousel row cols-2 cols-xs-3 cols-sm-4 cols-lg-5 cols-xxl-6" data-toggle="owl" data-owl-options='{
                            "nav": false, 
                            "dots": false,
                            "margin":  0,
                            "loop": false,
                            "responsive": {
                                "0": {
                                    "items":2
                                },
                                "480": {
                                    "items":3
                                },
                                "576": {
                                    "items":4
                                },
                                "992": {
                                    "items":5
                                },
                                "1600": {
                                    "items":6
                                }
                            }
                        }'>
                <a href="#" class="brand">
                    <img src="assets/images/brands/1.png" alt="Brand Name" width='85' height='35'>
                </a>

                <a href="#" class="brand">
                    <img src="assets/images/brands/2.png" alt="Brand Name" width='85' height='35'>
                </a>

                <a href="#" class="brand">
                    <img src="assets/images/brands/3.png" alt="Brand Name" width='85' height='35'>
                </a>

                <a href="#" class="brand">
                    <img src="assets/images/brands/4.png" alt="Brand Name" width='85' height='35'>
                </a>

                <a href="#" class="brand">
                    <img src="assets/images/brands/5.png" alt="Brand Name" width='85' height='35'>
                </a>

                <a href="#" class="brand">
                    <img src="assets/images/brands/6.png" alt="Brand Name" width='85' height='35'>
                </a>

                <a href="#" class="brand">
                    <img src="assets/images/brands/7.png" alt="Brand Name" width='85' height='35'>
                </a>
            </div>
        </div>
    </div>
    <!-- end brands shop -->

    <!-- recomended shop -->
    <div class="container product-group mb-lg-4 mb-3">
        <div class="row justify-content-center">
            <div class="arrivals col-lg-6 col-md-6 mb-2 mb-xl-0">
                <div class="heading heading-flex align-items-center">
                    <div class="heading-left">
                        <h2 class="title mb-0 font-weight-bold">New Arrivals</h2>
                    </div>


                    <div class="heading-right mt-0">
                        <a href="" class="title-link font-size-normal text-uppercase font-weight-normal shadow-none">View More
                            <i class="icon-long-arrow-right"></i>
                        </a>
                    </div>

                </div>
                <div class="products d-flex flex-column justify-content-between bg-white mt-2 mt-xl-0">
                    <div class="product d-flex flex-row overflow-hidden mb-0 p-0 ">
                        <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                            <a href="">
                                <img src="assets/images/p/small/1.jpg" alt="Product image" class="product-image" width="100" height="100" />
                            </a>
                        </figure>

                        <div class="product-body">


                            <h3 class="product-title letter-spacing-normal  text-left mb-0">
                                <a href="">Product Title</a>
                            </h3>

                            <div class="product-price mb-1 ">
                                $229.99
                            </div>

                            <div class="ratings-container mb-0">
                                <div class="ratings font-size-normal">
                                    <div class="ratings-val font-size-normal" style="width: 80%;"></div>

                                </div>

                                <span class="ratings-text ml-2">( 3 Reviews )</span>
                            </div>

                        </div>

                    </div>

                    <div class="product d-flex flex-row overflow-hidden mb-0 p-0 ">
                        <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                            <a href="">
                                <img src="assets/images/p/small/2.jpg" alt="Product image" class="product-image">
                            </a>
                        </figure>

                        <div class="product-body">


                            <h3 class="product-title letter-spacing-normal  text-left mb-0">
                                <a href="">Product Title</a>
                            </h3>

                            <div class="product-price mb-1 ">
                                $138.99
                            </div>

                            <div class="ratings-container mb-0">
                                <div class="ratings font-size-normal">
                                    <div class="ratings-val font-size-normal" style="width: 100%;"></div>

                                </div>

                                <span class="ratings-text ml-2">( 10 Reviews )</span>
                            </div>

                        </div>

                    </div>

                    <div class="product d-flex flex-row overflow-hidden mb-0 p-0 ">
                        <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                            <a href="">
                                <img src="assets/images/p/small/3.jpg" alt="Product image" class="product-image" width="100" height="100" />
                            </a>
                        </figure>

                        <div class="product-body">


                            <h3 class="product-title letter-spacing-normal  text-left mb-0">
                                <a href="">Product Title</a>
                            </h3>

                            <div class="product-price mb-1 ">
                                $129.99
                            </div>

                            <div class="ratings-container mb-0">
                                <div class="ratings font-size-normal">
                                    <div class="ratings-val font-size-normal" style="width: 60%;"></div>

                                </div>

                                <span class="ratings-text ml-2">( 5 Reviews )</span>
                            </div>

                        </div>

                    </div>

                </div>
            </div>
            <div class="recommend col-lg-6 mb-2 mb-xl-0 order-lg-0 order-md-first">
                <div class="heading heading-flex align-items-center">
                    <div class="heading-left">
                        <h2 class="title mb-0 font-weight-bold">Recommended Products</h2>

                    </div>

                    <div class="heading-right mt-0">
                        <a href="" class="title-link font-size-normal text-uppercase font-weight-normal shadow-none">View More
                            <i class="icon-long-arrow-right"></i>
                        </a>
                    </div>

                </div>
                <div class="products d-flex flex-column justify-content-between bg-white mt-2 mt-xl-0">
                    <div class="product d-flex flex-row overflow-hidden mb-0 p-0 ">
                        <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                            <a href="">
                                <img src="assets/images/p/small/4.jpg" alt="Product image" class="product-image" width="100" height="100" />
                            </a>
                        </figure>

                        <div class="product-body">


                            <h3 class="product-title letter-spacing-normal  text-left mb-0">
                                <a href="">Product Title</a>
                            </h3>

                            <div class="product-price mb-1 ">
                                $169.99
                            </div>

                            <div class="ratings-container mb-0">
                                <div class="ratings font-size-normal">
                                    <div class="ratings-val font-size-normal" style="width: 60%;"></div>

                                </div>

                                <span class="ratings-text ml-2">( 2 Reviews )</span>
                            </div>

                        </div>

                    </div>

                    <div class="product d-flex flex-row overflow-hidden mb-0 p-0 ">
                        <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                            <a href="">
                                <img src="assets/images/p/small/5.png" alt="Product image" class="product-image">
                            </a>
                        </figure>

                        <div class="product-body">


                            <h3 class="product-title letter-spacing-normal  text-left mb-0">
                                <a href="">Product Title</a>
                            </h3>

                            <div class="product-price mb-1">
                                $549.00
                            </div>

                            <div class="ratings-container mb-0">
                                <div class="ratings font-size-normal">
                                    <div class="ratings-val font-size-normal" style="width: 60%;"></div>

                                </div>

                                <span class="ratings-text ml-2">( 4 Reviews )</span>
                            </div>


                        </div>

                    </div>


                    <div class="product d-flex flex-row overflow-hidden mb-0 p-0 ">
                        <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">

                            <a href="">
                                <img src="assets/images/p/small/6.jpg" alt="Product image" class="product-image" width="100" height="100" />
                            </a>
                        </figure>

                        <div class="product-body">


                            <h3 class="product-title letter-spacing-normal  text-left mb-0">
                                <a href="">Product Title</a>
                            </h3>

                            <div class="product-price mb-1 ">
                                <div class="new-price">$329.99</div>
                                <div class="old-price font-size-normal">$399.99</div>
                            </div>

                            <div class="ratings-container mb-0">
                                <div class="ratings font-size-normal">
                                    <div class="ratings-val font-size-normal" style="width: 100%;"></div>

                                </div>

                                <span class="ratings-text ml-2">( 10 Reviews )</span>
                            </div>

                        </div>

                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- end recomended shop -->

    <!--app section -->
    <div class="container banner-group-2 mb-3 pt-3" style="background:rgb(241, 238, 243)">
        <div class="row">
            <div class="col-md-8">
                <div class="app-banner">
                    <div class="banner-content banner-content-left position-relative">
                        <h4 class="banner-subtitle letter-spacing-normal  mb-1 text-lg">
                            <a href="#">The Coral Fashion App</a>
                        </h4>

                        <h3 class="banner-title font-weight-bold mb-3 mt-2">
                            <a href="#">Download Andriod
                                <br>&amp; and IOS App</a>
                        </h3>


                        <div class="app-icons-download">
                            <a href="#" class="app-download text-decoration-none ">
                                <img src="assets/images/app-store.svg" alt="App Store" width="209" height="60">
                            </a>
                            <a href="#" class="app-download text-decoration-none ">
                                <img src="assets/images/play-store.svg" alt="Play Store" width="209" height="60">
                            </a>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-md-4 d-none d-sm-none d-md-block">
                <div class="text-center">
                    <img src="assets/images/app.png" alt="App icons" width="">
                </div>
            </div>
        </div>
    </div>
    <!--end app section -->
</main>