<?php
include("header.php");
include("menu.php");
?>
<main class="main">
    <!-- breadcrumb -->
    <div class="page-header text-center" style="background-image: url('assets/images/about-bg.jpg')">
        <div class="container">
            <h1 class="page-title text-white"> <mark style="background: #4625bc;padding: 1px 15px;color:#fff">Wishlist</mark> </h1>
        </div>
    </div>
    <!-- pagination -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active"><a href="shop.php">Shop</a></li>
                <li class="breadcrumb-item active">Cart</li>
            </ol>
        </div>
    </nav>
    <!-- End breadcrumb-nav -->
    <div class="page-content">
        <div class="cart">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <table class="table table-cart table-mobile">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>	Stock Status</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <td class="product-col">
                                        <div class="product border-0">
                                            <figure class="product-media">
                                                <a href="#">
                                                    <img src="assets/images/products/table/product-1.jpg" alt="Product image">
                                                </a>
                                            </figure>

                                            <h3 class="product-title">
                                                <a href="#">Product Title Here</a>
                                            </h3>
                                            
                                        </div>
                                        
                                    </td>
                                    <td class="price-col">$84.00</td>
                                    <td class="stock-col"><span class="in-stock">In stock</span></td>
                                    <td class="action-col">
									    <button class="btn btn-block btn-outline-primary-2"><i class="icon-cart-plus"></i>Add to Cart</button>
								    </td>
                                    <td class="remove-col"><button class="btn-remove"><i class="icon-close"></i></button></td>
                                </tr>
                                <tr>
                                    <td class="product-col">
                                        <div class="product border-0">
                                            <figure class="product-media">
                                                <a href="#">
                                                    <img src="assets/images/products/table/product-2.jpg" alt="Product image">
                                                </a>
                                            </figure>

                                            <h3 class="product-title">
                                                <a href="#">Product Title Here</a>
                                            </h3>
                                            
                                        </div>
                                    </td>
                                    <td class="price-col">$76.00</td>
                                    <td class="stock-col"><span class="in-stock">In stock</span></td>
                                    <td class="action-col">
									    <button class="btn btn-block btn-outline-primary-2"><i class="icon-cart-plus"></i>Add to Cart</button>
								    </td>
                                    <td class="remove-col"><button class="btn-remove"><i class="icon-close"></i></button></td>
                                </tr>



                                <tr>
                                    <td class="product-col">
                                        <div class="product border-0">
                                            <figure class="product-media">
                                                <a href="#">
                                                    <img src="assets/images/products/table/product-2.jpg" alt="Product image">
                                                </a>
                                            </figure>

                                            <h3 class="product-title">
                                                <a href="#">Product Title Here</a>
                                            </h3>
                                            
                                        </div>
                                    </td>
                                    <td class="price-col">$76.00</td>
                                    <td class="stock-col"><span class="out-of-stock">Out of stock</span></td>
                                    <td class="action-col">
									    <button class="btn btn-block btn-outline-primary-2"><i class="icon-cart-plus"></i>Add to Cart</button>
								    </td>
                                    <td class="remove-col"><button class="btn-remove"><i class="icon-close"></i></button></td>
                                </tr>
                            </tbody>
                        </table>
                        
                        
                    </div>
                   
                </div>
                
            </div>
            
        </div>
        
    </div>
</main>
<!-- End main -->


<?php include("footer.php"); ?>