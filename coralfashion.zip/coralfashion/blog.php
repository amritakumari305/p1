<?php
include("header.php");
include("menu.php");
?>
<main class="main">
    <!-- breadcrumb -->
    <div class="page-header text-center" style="background-image: url('assets/images/about-bg.jpg')">
        <div class="container">
            <h1 class="page-title text-white"> <mark style="background: #4625bc;padding: 1px 15px;color:#fff">Blog</mark> </h1>
        </div>
    </div>
    <!-- pagination -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                <li class="breadcrumb-item active">Blog</li>
            </ol>
        </div>
    </nav>
    <!-- page content -->
    <div class="page-content">
                <div class="container">
                    <nav class="blog-nav">
                        <ul class="menu-cat entry-filter justify-content-center">
                            <li class="active"><a href="#" data-filter="*">All Blog Posts<span>(2)</span></a></li>
                            <li><a href="#" data-filter=".lifestyle">Lifestyle<span>(2)</span></a></li>
                            <li><a href="#" data-filter=".shopping">Shopping<span>(2)</span></a></li>
                            <li><a href="#" data-filter=".fashion">Fashion<span>(2)</span></a></li>
                            <li><a href="#" data-filter=".travel">Travel<span>(2)</span></a></li>
                            <li><a href="#" data-filter=".hobbies">Hobbies<span>(2)</span></a></li>
                        </ul>
                    </nav>
<hr>
                    <div class="entry-container">
                        <div class="entry-item lifestyle shopping col-sm-6 col-lg-4">
                            <article class="entry entry-mask">
                                <figure class="entry-media">
                                    <a href="singleblog.php">
                                        <img src="assets/images/blog/mask/masonry/post-1.jpg" alt="image desc">
                                    </a>
                                </figure>

                                <div class="entry-body">
                                    <div class="entry-meta">
                                        <a href="#">Nov 22, 2018</a>
                                       
                                    </div>

                                    <h2 class="entry-title">
                                        <a href="singleblog.php">Cras ornare tristique elit.</a>
                                    </h2>

                                    <div class="entry-cats">
                                        in <a href="#">Lifestyle</a>,
                                        <a href="#">Shopping</a>
                                    </div>
                                </div>
                            </article>
                        </div>

                        <div class="entry-item hobbies col-sm-6 col-lg-4">
                            <article class="entry entry-mask">
                                <figure class="entry-media">
                                    <a href="singleblog.php">
                                        <img src="assets/images/blog/mask/masonry/post-2.jpg" alt="image desc">
                                    </a>
                                </figure>
                                
                                <div class="entry-body">
                                    <div class="entry-meta">
                                        <a href="#">Nov 10, 2018</a>
                                       
                                    </div>

                                    <h2 class="entry-title">
                                        <a href="singleblog.php">Aenean dignissim pellente squefelis.</a>
                                    </h2>

                                    <div class="entry-cats">
                                        in <a href="#">Hobbies</a>
                                    </div>
                                </div>
                            </article>
                        </div>

                        <div class="entry-item lifestyle fashion col-sm-6 col-lg-4">
                            <article class="entry entry-mask">
                                <figure class="entry-media entry-gallery">
                                    <a href="singleblog.php">
                                        <img src="assets/images/blog/mask/masonry/post-3.jpg" alt="image desc">
                                    </a>
                                </figure>

                                <div class="entry-body">
                                    <div class="entry-meta">
                                        <a href="#">Nov 18, 2018</a>
                                        
                                    </div>

                                    <h2 class="entry-title">
                                        <a href="singleblog.php">Utaliquam sollicitudin leo.</a>
                                    </h2>

                                    <div class="entry-cats">
                                        in <a href="#">Fashion</a>,
                                        <a href="#">Lifestyle</a>
                                    </div>
                                </div>
                            </article>
                        </div>

                        
                        

                      

                        <div class="entry-item travel col-sm-6 col-lg-4">
                            <article class="entry entry-mask">
                                <figure class="entry-media">
                                    <a href="singleblog.php">
                                        <img src="assets/images/blog/mask/masonry/post-7.jpg" alt="image desc">
                                    </a>
                                </figure>

                                <div class="entry-body">
                                    <div class="entry-meta">
                                        <a href="#">Nov 11, 2018</a>
                                        
                                    </div>

                                    <h2 class="entry-title">
                                        <a href="singleblog.php">Quisque a lectus. </a>
                                    </h2>

                                    <div class="entry-cats">
                                        in <a href="#">Travel</a>
                                    </div>
                                </div>
                            </article>
                        </div>

                        <div class="entry-item travel col-sm-6 col-lg-4">
                            <article class="entry entry-mask">
                                <figure class="entry-media entry-gallery">
                                    <a href="singleblog.php">
                                        <img src="assets/images/blog/mask/masonry/post-9.jpg" alt="image desc">
                                    </a>
                                </figure>

                                <div class="entry-body">
                                    <div class="entry-meta">
                                        <a href="#">Nov 07, 2018</a>
                                        
                                    </div>

                                    <h2 class="entry-title">
                                        <a href="singleblog.php">Utaliquam sollicitudin leo.</a>
                                    </h2>

                                    <div class="entry-cats">
                                        in <a href="#">Travel</a>
                                    </div>
                                </div>
                            </article>
                        </div>

                        <div class="entry-item fashion col-sm-6 col-lg-4">
                            <article class="entry entry-mask">
                                <figure class="entry-media">
                                    <a href="singleblog.php">
                                        <img src="assets/images/blog/mask/masonry/post-8.jpg" alt="image desc">
                                    </a>
                                </figure>

                                <div class="entry-body">
                                    <div class="entry-meta">
                                        <a href="#">July 07, 2021</a>
                                       
                                    </div>

                                    <h2 class="entry-title">
                                        <a href="singleblog.php">Fusce pellentesque suscipit.</a>
                                    </h2>

                                    <div class="entry-cats">
                                        in <a href="#">Fashion</a>
                                    </div>
                                </div>
                            </article>
                        </div>
                    </div>

                    <div class="mb-3"></div>

                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center">
                            <li class="page-item disabled">
                                <a class="page-link page-link-prev" href="#" aria-label="Previous" tabindex="-1" aria-disabled="true">
                                    <span aria-hidden="true"><i class="icon-long-arrow-left"></i></span>Prev
                                </a>
                            </li>
                            <li class="page-item active" aria-current="page"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item">
                                <a class="page-link page-link-next" href="#" aria-label="Next">
                                    Next <span aria-hidden="true"><i class="icon-long-arrow-right"></i></span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
</main>
<!-- End main -->


<?php include("footer.php"); ?>