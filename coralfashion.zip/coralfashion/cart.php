<?php
include("header.php");
include("menu.php");
?>
<main class="main">
    <!-- breadcrumb -->
    <div class="page-header text-center" style="background-image: url('assets/images/about-bg.jpg')">
        <div class="container">
            <h1 class="page-title text-white"> <mark style="background: #4625bc;padding: 1px 15px;color:#fff">Cart</mark> </h1>
        </div>
    </div>
    <!-- pagination -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active"><a href="shop.php">Shop</a></li>
                <li class="breadcrumb-item active">Cart</li>
            </ol>
        </div>
    </nav>
    <!-- End breadcrumb-nav -->
    <div class="page-content">
        <div class="cart">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <table class="table table-cart table-mobile">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <td class="product-col">
                                        <div class="product border-0">
                                            <figure class="product-media">
                                                <a href="#">
                                                    <img src="assets/images/products/table/product-1.jpg" alt="Product image">
                                                </a>
                                            </figure>

                                            <h3 class="product-title">
                                                <a href="#">Product Title Here</a>
                                            </h3>
                                            
                                        </div>
                                        
                                    </td>
                                    <td class="price-col">$84.00</td>
                                    <td class="quantity-col">
                                        <div class="cart-product-quantity">
                                            <input type="number" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required>
                                        </div>
                                    </td>
                                    <td class="total-col">$84.00</td>
                                    <td class="remove-col"><button class="btn-remove"><i class="icon-close"></i></button></td>
                                </tr>
                                <tr>
                                    <td class="product-col">
                                        <div class="product border-0">
                                            <figure class="product-media">
                                                <a href="#">
                                                    <img src="assets/images/products/table/product-2.jpg" alt="Product image">
                                                </a>
                                            </figure>

                                            <h3 class="product-title">
                                                <a href="#">Product Title Here</a>
                                            </h3>
                                            
                                        </div>
                                    </td>
                                    <td class="price-col">$76.00</td>
                                    <td class="quantity-col">
                                        <div class="cart-product-quantity">
                                            <input type="number" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required>
                                        </div>
                                        
                                    </td>
                                    <td class="total-col">$76.00</td>
                                    <td class="remove-col"><button class="btn-remove"><i class="icon-close"></i></button></td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <div class="cart-bottom">
                            <div class="cart-discount">
                                <form action="#">
                                    <div class="input-group">
                                        <input type="text" class="form-control" required placeholder="coupon code">
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-primary-2" type="submit"><i class="icon-long-arrow-right"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            
                            <a href="#" class="btn btn-outline-dark-2"><span>UPDATE CART</span><i class="icon-refresh"></i></a>
                        </div>
                    </div>
                   
                    <aside class="col-lg-3">
                        <div class="summary summary-cart">
                            <h3 class="summary-title">Cart Total</h3>
                            <table class="table table-summary">
                                <tbody>
                                    <tr class="summary-subtotal">
                                        <td>Subtotal:</td>
                                        <td>$160.00</td>
                                    </tr>
                                    
                                    <tr class="summary-shipping">
                                        <td>Shipping:</td>
                                        <td>&nbsp; Free Shipping</td>
                                    </tr>

                                    
                                    
                                    
                                    
                                    
                                     <tr class="summary-shipping-estimate">
                                        <td>Change Location<br> <a href="dashboard.php">Change address</a></td>
                                        <td>&nbsp;</td>
                                    </tr>
                                    
                                    <tr class="summary-total">
                                        <td>Total:</td>
                                        <td>$160.00</td>
                                    </tr>
                                   
                                </tbody>
                            </table>
                            
                            <a href="checkout.php" class="btn btn-outline-primary-2 btn-order btn-block">CHECKOUT</a>
                        </div>
                        
                        <a href="shop.php" class="btn btn-outline-dark-2 btn-block mb-3"><span>CONTINUE SHOPPING</span><i class="icon-refresh"></i></a>
                    </aside>
                    
                </div>
                
            </div>
            
        </div>
        
    </div>
</main>
<!-- End main -->


<?php include("footer.php"); ?>