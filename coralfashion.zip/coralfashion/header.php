<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Coral Clothing</title>

    <script>
        WebFontConfig = {
            google: {
                families: ['Poppins:200,400,500,600,700']
            }
        };
        (function(d) {
            var wf = d.createElement('script'),
                s = d.scripts[0];
            wf.src = 'assets/js/webfont.js';
            wf.async = true;
            s.parentNode.insertBefore(wf, s);
        })(document);
    </script>
    <meta name="keywords" content="Coral Clothing">
    <meta name="description" content="Coral Clothing website">
    <meta name="author" content="Coral IT">

    <link rel="stylesheet" href="assets/vendor/line-awesome/line-awesome/line-awesome/css/line-awesome.min.css">
    <!-- extra CSS File -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/extra/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="assets/css/extra/jquery.countdown.css">
    <link rel="stylesheet" href="assets/css/extra/magnific-popup/magnific-popup.css">
    <!-- price range css -->
    <!-- <link rel="stylesheet" href="assets/css/extra/nouislider/nouislider.css"> -->
    <!-- Main CSS File -->
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/coralf.css">
    <link rel="stylesheet" href="assets/css/coralc.css">

</head>

<body>