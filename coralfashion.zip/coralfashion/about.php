<?php
include("header.php");
include("menu.php");
?>
<main class="main">
    <!-- breadcrumb -->
    <div class="page-header text-center" style="background-image: url('assets/images/about-bg.jpg')">
        <div class="container">
            <h1 class="page-title text-white"> <mark style="background: #4625bc;padding: 1px 15px;color:#fff">About us</mark> </h1>
        </div>
    </div>
    <!-- pagination -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                <li class="breadcrumb-item active">About Us</li>
            </ol>
        </div>
    </nav>
    <!-- page content -->
    <div class="page-content pb-3">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="about-text text-center">
                        <h2 class="title text-center mb-2">About Company</h2>
                        <p>Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Suspendisse potenti. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Suspendisse potenti. Sed egestas, ante et vulputate volutpat, uctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. Praesent elementum hendrerit tortor. Sed semper lorem at felis. </p>

                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-lg-4 offset-lg-1 col-sm-6">
                    <div class="icon-box icon-box-sm text-center">
                        <span class="icon-box-icon">
                            <i class="icon-puzzle-piece"></i>
                        </span>
                        <div class="icon-box-content">
                            <h3 class="icon-box-title">Our Vision</h3>
                            <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero <br>eu augue.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 offset-lg-1 col-sm-6">
                    <div class="icon-box icon-box-sm text-center">
                        <span class="icon-box-icon">
                            <i class="icon-life-ring"></i>
                        </span>
                        <div class="icon-box-content">
                            <h3 class="icon-box-title">Our Mission</h3>
                            <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero <br>eu augue.</p>
                        </div>
                    </div>
                </div>




            </div>
        </div>

        <div class="mb-2"></div>
        <!-- counter -->
        <div class="bg-image pt-3 pb-3 pt-md-5 pb-md-3" style="background-image: url(assets/images/counter-bg.jpg)">
            <div class="container">
                <div class="row">
                    <div class="col-6 col-md-3">
                        <div class="count-container text-center">
                            <div class="count-wrapper text-white">
                                <span class="count" data-from="0" data-to="40" data-speed="3000" data-refresh-interval="50">0</span>k+
                            </div>
                            <h3 class="count-title text-white">Happy Customer</h3>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="count-container text-center">
                            <div class="count-wrapper text-white">
                                <span class="count" data-from="0" data-to="20" data-speed="3000" data-refresh-interval="50">0</span>+
                            </div>
                            <h3 class="count-title text-white">Years in Business</h3>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="count-container text-center">
                            <div class="count-wrapper text-white">
                                <span class="count" data-from="0" data-to="95" data-speed="3000" data-refresh-interval="50">0</span>%
                            </div>
                            <h3 class="count-title text-white">Return Clients</h3>
                        </div>
                    </div>

                    <div class="col-6 col-md-3">
                        <div class="count-container text-center">
                            <div class="count-wrapper text-white">
                                <span class="count" data-from="0" data-to="15" data-speed="3000" data-refresh-interval="50">0</span>
                            </div>
                            <h3 class="count-title text-white">Awards Won</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- testimonials -->
        <div class="about-testimonials  pt-4 pb-2">
            <div class="container">
                <h2 class="title text-center mb-3">What Customer Say About Us</h2>

                <div class="owl-carousel owl-simple owl-testimonials-photo owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                                &quot;nav&quot;: false, 
                                &quot;dots&quot;: true,
                                &quot;margin&quot;: 20,
                                &quot;loop&quot;: false,
                                &quot;responsive&quot;: {
                                    &quot;1200&quot;: {
                                        &quot;nav&quot;: true
                                    }
                                }
                            }">
                    <div class="owl-stage-outer">
                        <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 2376px;">
                            <div class="owl-item active" style="width: 1168px; margin-right: 20px;">
                                <blockquote class="testimonial text-center">
                                    <img src="assets/images/testimonials/user-1.jpg" alt="user">
                                    <p>“ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Pellentesque aliquet nibh nec urna. <br>In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. ”</p>
                                    <cite>
                                        Jenson Gregory

                                    </cite>
                                </blockquote>
                            </div>
                            <div class="owl-item" style="width: 1168px; margin-right: 20px;">
                                <blockquote class="testimonial text-center">
                                    <img src="assets/images/testimonials/user-2.jpg" alt="user">
                                    <p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusandae! Doloremque quidem error eum quis similique doloribus natus qui ut ipsum.Velit quos ipsa exercitationem, vel unde obcaecati impedit eveniet non. ”</p>

                                    <cite>
                                        Victoria Ventura

                                    </cite>
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="owl-nav">
                        <button type="button" role="presentation" class="owl-prev disabled">
                            <i class="icon-angle-left"></i>
                        </button>
                        <button type="button" role="presentation" class="owl-next">
                            <i class="icon-angle-right"></i></button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</main>
<!-- End main -->


<?php include("footer.php"); ?>