<?php
include("header.php");
include("menu.php");
?>
<main class="main">

    <!-- pagination -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active"><a href="shop.php">Shop</a></li>
                <li class="breadcrumb-item active">Product</li>
            </ol>
        </div>
    </nav>
    <!-- End breadcrumb-nav -->

    <div class="page-content">
        <div class="container">
            <div class="product-details-top">
                <div class="row">
                    <div class="col-md-6">
                        <div class="product-gallery product-gallery-vertical">
                            <div class="row">
                                <figure class="product-main-image">
                                    <img id="product-zoom" src="assets/images/products/single/1.jpg" data-zoom-image="assets/images/products/single/1-big.jpg" alt="product image">

                                    <a href="#" id="btn-product-gallery" class="btn-product-gallery">
                                        <i class="icon-arrows"></i>
                                    </a>
                                </figure><!-- End .product-main-image -->

                                <div id="product-zoom-gallery" class="product-image-gallery">
                                    <a class="product-gallery-item active" href="#" data-image="assets/images/products/single/1.jpg" data-zoom-image="assets/images/products/single/1-big.jpg">
                                        <img src="assets/images/products/single/1-small.jpg" alt="product side">
                                    </a>

                                    <a class="product-gallery-item" href="#" data-image="assets/images/products/single/2-big.jpg" data-zoom-image="assets/images/products/single/2-big.jpg">
                                        <img src="assets/images/products/single/2-small.jpg" alt="product cross">
                                    </a>

                                    <a class="product-gallery-item" href="#" data-image="assets/images/products/single/3-big.jpg" data-zoom-image="assets/images/products/single/3-big.jpg">
                                        <img src="assets/images/products/single/3-small.jpg" alt="product with model">
                                    </a>

                                    <a class="product-gallery-item" href="#" data-image="assets/images/products/single/4-big.jpg" data-zoom-image="assets/images/products/single/4-big.jpg">
                                        <img src="assets/images/products/single/4-small.jpg" alt="product back">
                                    </a>
                                </div><!-- End .product-image-gallery -->
                            </div><!-- End .row -->
                        </div><!-- End .product-gallery -->
                    </div><!-- End .col-md-6 -->

                    <div class="col-md-5 offset-lg-1">
                        <div class="product-details">
                            <h1 class="product-title">Product Title Here</h1>

                            <div class="ratings-container">
                                <div class="ratings">
                                    <div class="ratings-val" style="width: 80%;"></div>
                                </div>
                                <a class="ratings-text" href="#product-review-link" id="review-link">( 2 Reviews )</a>
                            </div>

                            <div class="product-price">
                                $84.00
                            </div>

                            <div class="product-content">
                                <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. </p>
                            </div>

                            <div class="details-filter-row details-row-size">
                                <label>Color:</label>

                                <div class="product-nav product-nav-dots">
                                    <a href="#" class="active" style="background: #7ba1c9;"><span class="sr-only">Color name</span></a>
                                    <a href="#" style="background: #333333;"><span class="sr-only">Color name</span></a>
                                    <a href="#" style="background: #feb143;"><span class="sr-only">Color name</span></a>
                                    <a href="#" style="background: #f0c7b7;"><span class="sr-only">Color name</span></a>
                                </div>
                            </div>
                            <div class="details-filter-row details-row-size">
                                <label for="size">Size:</label>
                                <div class="select-custom">
                                    <select name="size" id="size" class="form-control">
                                        <option value="#" selected="selected">Select a size</option>
                                        <option value="s">S</option>
                                        <option value="m">M</option>
                                        <option value="l">L</option>
                                        <option value="xl">XL</option>
                                    </select>
                                </div>
                            </div>

                            <div class="details-filter-row details-row-size">
                                <label for="qty">Qty:</label>
                                <div class="product-details-quantity">
                                    <input type="number" id="qty" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required>
                                </div><!-- End .product-details-quantity -->
                            </div><!-- End .details-filter-row -->

                            <div class="product-details-action">
                                <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>

                                <div class="details-action-wrapper">
                                    <a href="#" class="btn-product btn-wishlist" title="Wishlist">Wishlist</a>

                                </div>
                            </div>
                            <div class="pincode-deliveryContainer my-3">
                                <h4>Delivery Options</h4>
                                <div class="Address-switcher-container">
                                    <div class="Address-address-box Address-pincode-input Address-pdp-box">
                                        <input type="tel" placeholder="Enter a PIN code" value="">
                                        <button type="submit" class="Address-address-button" style="color: rgb(191, 192, 198);">CHECK</button>
                                    </div>
                                </div>
                                <p class="pincode-enterPincode">Please enter PIN code to check delivery time &amp; Pay on Delivery Availability</p>
                                <ul class="pincode-serviceability-list"></ul>
                            </div>
                            <div class="product-details-footer">
                                <div class="product-cat">
                                    <span>Category:</span>
                                    <a href="#">Women</a>,
                                    <a href="#">Dresses</a>,
                                    <a href="#">Yellow</a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <div class="product-details-tab">
                <ul class="nav nav-pills" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="product-desc-link" data-toggle="tab" href="#product-desc-tab" role="tab" aria-controls="product-desc-tab" aria-selected="true">Description</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="product-info-link" data-toggle="tab" href="#product-info-tab" role="tab" aria-controls="product-info-tab" aria-selected="false">Additional information</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="product-shipping-link" data-toggle="tab" href="#product-shipping-tab" role="tab" aria-controls="product-shipping-tab" aria-selected="false">Shipping & Returns</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="product-review-link" data-toggle="tab" href="#product-review-tab" role="tab" aria-controls="product-review-tab" aria-selected="false">Reviews (2)</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="product-desc-tab" role="tabpanel" aria-labelledby="product-desc-link">
                        <div class="product-desc-content">
                            <h3>Product Information</h3>
                            <p>Maroon solid woven tiered maxi dress, has a square neck, short sleeves, concealed zip closure, an attached lining, and flounce hem Comes with a belt </p>
                            <ul>
                                <li>100% Original Products</li>
                                <li>Pay on delivery might be available</li>
                                <li>Easy 30 days returns and exchanges</li>
                            </ul>

                        </div>
                    </div>
                    <div class="tab-pane fade" id="product-info-tab" role="tabpanel" aria-labelledby="product-info-link">
                        <div class="product-desc-content">
                            <h3>Information</h3>
                            <p>Maroon solid woven tiered maxi dress, has a square neck, short sleeves, concealed zip closure, an attached lining, and flounce hem Comes with a belt</p>

                            <h3>Fabric & care</h3>
                            <ul>
                                <li>Faux suede fabric</li>
                                <li>Gold tone metal hoop handles.</li>
                                <li>Try & Buy might be available/li>
                                <li>100% Original Products</li>
                                <li>Pay on delivery might be available</li>
                                <li>Easy 30 days returns and exchanges</li>
                                <li> Height: 31cm; Width: 32cm; Depth: 12cm; Handle Drop: 61cm</li>
                            </ul>

                            <h3>Size</h3>
                            <p>one size</p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="product-shipping-tab" role="tabpanel" aria-labelledby="product-shipping-link">
                        <div class="product-desc-content">
                            <h3>Delivery & returns</h3>
                            <p>We deliver to all over states around the India. For full details of the delivery options we offer, please view our <a href="#">Delivery information</a><br>
                                We hope you’ll love every purchase, but if you ever need to return an item you can do so within a month of receipt. For full details of how to make a return, please view our <a href="#">Returns information</a></p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="product-review-tab" role="tabpanel" aria-labelledby="product-review-link">
                        <div class="reviews">
                            <h3>Reviews (2)</h3>
                            <div class="review">
                                <div class="row no-gutters">
                                    <div class="col-auto">
                                        <h4><a href="#">Samanta J.</a></h4>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 80%;"></div>
                                            </div>
                                        </div>
                                        <span class="review-date">6 days ago</span>
                                    </div>
                                    <div class="col">
                                        <h4>Good, perfect size</h4>

                                        <div class="review-content">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus cum dolores assumenda asperiores facilis porro reprehenderit animi culpa atque blanditiis commodi perspiciatis doloremque, possimus, explicabo, autem fugit beatae quae voluptas!</p>
                                        </div>

                                        
                                    </div>
                                </div>
                            </div>

                            <div class="review">
                                <div class="row no-gutters">
                                    <div class="col-auto">
                                        <h4><a href="#">John Doe</a></h4>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 100%;"></div>
                                            </div>
                                        </div>
                                        <span class="review-date">5 days ago</span>
                                    </div>
                                    <div class="col">
                                        <h4>Very good</h4>

                                        <div class="review-content">
                                            <p>Sed, molestias, tempore? Ex dolor esse iure hic veniam laborum blanditiis laudantium iste amet. Cum non voluptate eos enim, ab cumque nam, modi, quas iure illum repellendus, blanditiis perspiciatis beatae!</p>
                                        </div>

                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            

            <h2 class="title text-center mb-4">You May Also Like</h2>

            <div class="owl-carousel owl-simple carousel-equal-height carousel-with-shadow" data-toggle="owl" data-owl-options='{
                            "nav": false, 
                            "dots": true,
                            "margin": 20,
                            "loop": false,
                            "responsive": {
                                "0": {
                                    "items":1
                                },
                                "480": {
                                    "items":2
                                },
                                "768": {
                                    "items":3
                                },
                                "992": {
                                    "items":4
                                },
                                "1200": {
                                    "items":4,
                                    "nav": true,
                                    "dots": false
                                }
                            }
                        }'>
                <div class="product product-7 text-center">
                    <figure class="product-media">
                       
                        <a href="shop.php">
                            <img src="assets/images/products/product-4.jpg" alt="Product image" class="product-image">
                        </a>

                        <div class="product-action-vertical">
                            <a href="#" class="btn-product-icon btn-wishlist btn-expandable"></a>
                            <a href="" class="btn-product-icon btn-quickview" title="Quick view"></a>
                            
                        </div>

                        <div class="product-action">
                            <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                        </div>
                    </figure>

                    <div class="product-body">
                        
                        <h3 class="product-title"><a href="shop.php">Product Title Here</a></h3>
                        <div class="product-price">
                            $60.00
                        </div>
                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 20%;"></div>
                            </div>
                            <span class="ratings-text">( 2 Reviews )</span>
                        </div>

                        
                    </div>
                </div>

                <div class="product product-7 text-center">
                    <figure class="product-media">
                        
                        <a href="shop.php">
                            <img src="assets/images/products/product-6.jpg" alt="Product image" class="product-image">
                        </a>

                        <div class="product-action-vertical">
                            <a href="#" class="btn-product-icon btn-wishlist btn-expandable"></a>
                            <a href="" class="btn-product-icon btn-quickview" title="Quick view"></a>
                           
                        </div>

                        <div class="product-action">
                            <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                        </div>
                    </figure>

                    <div class="product-body">
                        
                        <h3 class="product-title"><a href="shop.php">Product Title Here</a></h3>
                        <div class="product-price">
                            <span class="out-price">$120.00</span>
                        </div>
                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 80%;"></div>
                            </div>
                            <span class="ratings-text">( 6 Reviews )</span>
                        </div>
                    </div>
                </div>

                <div class="product product-7 text-center">
                    <figure class="product-media">
                       
                        <a href="shop.php">
                            <img src="assets/images/products/product-7.jpg" alt="Product image" class="product-image">
                        </a>

                        <div class="product-action-vertical">
                            <a href="#" class="btn-product-icon btn-wishlist btn-expandable"></a>
                            <a href="" class="btn-product-icon btn-quickview" title="Quick view"></a>
                           
                        </div>
                        <div class="product-action">
                            <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                        </div>
                    </figure>

                    <div class="product-body">
                        
                        <h3 class="product-title"><a href="shop.php">Product Title Here</a></h3>
                        <div class="product-price">
                            $110.00
                        </div>
                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 80%;"></div>
                            </div>
                            <span class="ratings-text">( 1 Reviews )</span>
                        </div>
                    </div>
                </div>

                <div class="product product-7 text-center">
                    <figure class="product-media">
                        <a href="shop.php">
                            <img src="assets/images/products/product-10.jpg" alt="Product image" class="product-image">
                        </a>

                        <div class="product-action-vertical">
                            <a href="#" class="btn-product-icon btn-wishlist btn-expandable"></a>
                            <a href="" class="btn-product-icon btn-quickview" title="Quick view"></a>
                            
                        </div>

                        <div class="product-action">
                            <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                        </div>
                    </figure>

                    <div class="product-body">
                        
                        <h3 class="product-title"><a href="shop.php">Product Title Here</a></h3>
                        <div class="product-price">
                            $56.00
                        </div>
                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 0%;"></div>
                            </div>
                            <span class="ratings-text">( 0 Reviews )</span>
                        </div>
                    </div>
                </div>

                <div class="product product-7 text-center">
                    <figure class="product-media">
                        <a href="shop.php">
                            <img src="assets/images/products/product-7.jpg" alt="Product image" class="product-image">
                        </a>

                        <div class="product-action-vertical">
                            <a href="#" class="btn-product-icon btn-wishlist btn-expandable"></a>
                            <a href="" class="btn-product-icon btn-quickview" title="Quick view"></a>
                            
                        </div>

                        <div class="product-action">
                            <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
                        </div>
                    </figure>

                    <div class="product-body">
                       
                        <h3 class="product-title"><a href="shop.php">Product Title Here</a></h3>
                        <div class="product-price">
                            $76.00
                        </div>
                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 20%;"></div>
                            </div>
                            <span class="ratings-text">( 2 Reviews )</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- End main -->

<!-- Sticky Bar -->
<div class="sticky-bar">
    <div class="container">
        <div class="row">
            <div class="col-6">
                <figure class="product-media">
                    <a href="shop.php">
                        <img src="assets/images/products/sticky/product-1.jpg" alt="Product image">
                    </a>
                </figure>
                <h4 class="product-title"><a href="shop.php">Product Title Here</a></h4>
            </div>

            <div class="col-6 justify-content-end">
                <div class="product-price">
                    $84.00
                </div>
                <div class="product-details-quantity">
                    <input type="number" id="sticky-cart-qty" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required>
                </div>

                <div class="product-details-action">
                    <a href="#" class="btn-product btn-cart text-white"><span>add to cart</span></a>
                    <a href="#" class="btn-product btn-wishlist px-3" title="Wishlist"></a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>