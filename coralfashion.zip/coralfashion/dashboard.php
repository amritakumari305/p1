<?php
include("header.php");
include("menu.php");
?>
<main class="main">
    <!-- breadcrumb -->
    <div class="page-header text-center" style="background-image: url('assets/images/about-bg.jpg')">
        <div class="container">
            <h1 class="page-title text-white"> <mark style="background: #4625bc;padding: 1px 15px;color:#fff">Account</mark> </h1>
        </div>
    </div>
    <!-- pagination -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                <li class="breadcrumb-item active">Account</li>
            </ol>
        </div>
    </nav>
    <!-- End breadcrumb-nav -->
    <div class="page-content">
        <div class="dashboard">
            <div class="container">
                <div class="row">
                    <aside class="col-md-4 col-lg-3">
                        <ul class="nav nav-dashboard flex-column mb-3 mb-md-0" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="tab-dashboard-link" data-toggle="tab" href="#tab-dashboard" role="tab" aria-controls="tab-dashboard" aria-selected="true">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-orders-link" data-toggle="tab" href="#tab-orders" role="tab" aria-controls="tab-orders" aria-selected="false">Orders</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-cards-link" data-toggle="tab" href="#tab-cards" role="tab" aria-controls="tab-cards" aria-selected="false">Cards</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-address-link" data-toggle="tab" href="#tab-address" role="tab" aria-controls="tab-address" aria-selected="false">Adresses</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-account-link" data-toggle="tab" href="#tab-account" role="tab" aria-controls="tab-account" aria-selected="false">Profile Details</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-coupons-link" data-toggle="tab" href="#tab-coupons" role="tab" aria-controls="tab-coupons" aria-selected="false">Coupons</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Sign Out</a>
                            </li>
                        </ul>
                    </aside>

                    <div class="col-md-8 col-lg-9">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="tab-dashboard" role="tabpanel" aria-labelledby="tab-dashboard-link">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="dash-board-show">
                                            <div class="person-infoWrapper">
                                                <div class="person-imageHolder">
                                                    <div class="person-defaultImage">
                                                        <img src="assets/images/testimonials/user-2.jpg" alt="">
                                                    </div>
                                                </div>
                                                <div class="person-infoHolder">
                                                    <a class="person-editProfile" href="edit.php"> Edit Profile </a>
                                                    <div class="person-info">

                                                        <div>
                                                            coralfashion@gmail.com

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <a class="dash-link-card" href="/my/orders">
                                            <div class="link-content">
                                                <img class="link-icon" src="assets/images/icons/profile-orders.png">
                                                <div class="link-labels">
                                                    <div class="link-label">
                                                        Orders
                                                    </div>
                                                    <div class="link-subLabel">
                                                        Check your order status
                                                    </div>
                                                </div>
                                                <div class="link-arrow"><span class="icon-icon icon-chevron_right " style="font-size: 11px;"></span></div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4">
                                        <a class="dash-link-card" href="/my/orders">
                                            <div class="link-content">
                                                <img class="link-icon" src="assets/images/icons/profile-collections.png">
                                                <div class="link-labels">
                                                    <div class="link-label">
                                                        Collections &amp; Wishlist
                                                    </div>
                                                    <div class="link-subLabel">
                                                        All your curated product collections
                                                    </div>
                                                </div>
                                                <div class="link-arrow"><span class="icon-icon icon-chevron_right " style="font-size: 11px;"></span></div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4">
                                        <a class="dash-link-card" href="/my/orders">
                                            <div class="link-content">
                                                <img class="link-icon" src="assets/images/icons/profile-edit.png">
                                                <div class="link-labels">
                                                    <div class="link-label">
                                                        Profile Details
                                                    </div>
                                                    <div class="link-subLabel">
                                                        Change your profile details and password
                                                    </div>
                                                </div>
                                                <div class="link-arrow"><span class="icon-icon icon-chevron_right " style="font-size: 11px;"></span></div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4">
                                        <a class="dash-link-card" href="/my/orders">
                                            <div class="link-content">
                                                <img class="link-icon" src="assets/images/icons/profile-address.png">
                                                <div class="link-labels">
                                                    <div class="link-label">
                                                        Address
                                                    </div>
                                                    <div class="link-subLabel">
                                                        Save address for hassle-free checkout
                                                    </div>
                                                </div>
                                                <div class="link-arrow"><span class="icon-icon icon-chevron_right " style="font-size: 11px;"></span></div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4">
                                        <a class="dash-link-card" href="/my/orders">
                                            <div class="link-content">
                                                <img class="link-icon" src="assets/images/icons/profile-cards.png">
                                                <div class="link-labels">
                                                    <div class="link-label">
                                                        Saved Cards
                                                    </div>
                                                    <div class="link-subLabel">
                                                        save your card for faster checkout
                                                    </div>
                                                </div>
                                                <div class="link-arrow"><span class="icon-icon icon-chevron_right " style="font-size: 11px;"></span></div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-4">
                                        <a class="dash-link-card" href="/my/orders">
                                            <div class="link-content">
                                                <img class="link-icon" src="assets/images/icons/profile-coupons.png">
                                                <div class="link-labels">
                                                    <div class="link-label">
                                                        Coupons
                                                    </div>
                                                    <div class="link-subLabel">
                                                        Manage coupons for additional discount
                                                    </div>
                                                </div>
                                                <div class="link-arrow"><span class="icon-icon icon-chevron_right " style="font-size: 11px;"></span></div>
                                            </div>
                                        </a>
                                    </div>

                                </div>
                            </div>

                            <div class="tab-pane fade" id="tab-orders" role="tabpanel" aria-labelledby="tab-orders-link">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="order-box">
                                            <a href="order-details">
                                                <div class="row">
                                                    <div class="col-md-2">
                                                        <div class="order-img">
                                                            <img src="assets/images/products/product-7.jpg" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="order-d">

                                                            <div class="order-text">
                                                                <span class="order-title">Fast Colors Striped Round Neck White,...</span>
                                                                <div class="order-properties">
                                                                    <span class="order-c">
                                                                        <span class="order-c-value">Color: </span>
                                                                        <span class="order-color">White,Blue</span>
                                                                    </span>
                                                                    <span class="order-s">
                                                                        <span class="order-s-value">Size: </span>
                                                                        <span class="order-size">L</span>
                                                                    </span>
                                                                    <span class="_3dOR_a"></span>
                                                                </div>
                                                                <div class="order-price">₹399</div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="order-d-status ">
                                                            <div>
                                                                <div class="order-d-icon"></div>
                                                                <span class="order-d-title">Delivered on Jun 17</span>
                                                                <div class="order-d-text">Your item has been delivered</div>


                                                            </div>




                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <div class="order-r text-right">
                                                <a class="order-r-text" href="">

                                                    <i class="icon-star"></i> Rate &amp; Review Product
                                                </a>
                                            </div>
                                        </div>
                                        <div class="order-box">
                                            <a href="order-details">
                                                <div class="row">
                                                    <div class="col-md-2">
                                                        <div class="order-img">
                                                            <img src="assets/images/products/product-7.jpg" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="order-d">

                                                            <div class="order-text">
                                                                <span class="order-title">Fast Colors Striped Round Neck White,...</span>
                                                                <div class="order-properties">
                                                                    <span class="order-c">
                                                                        <span class="order-c-value">Color: </span>
                                                                        <span class="order-color">White,Blue</span>
                                                                    </span>
                                                                    <span class="order-s">
                                                                        <span class="order-s-value">Size: </span>
                                                                        <span class="order-size">L</span>
                                                                    </span>
                                                                    <span class="_3dOR_a"></span>
                                                                </div>
                                                                <div class="order-price">₹399</div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4">
                                                        <div class="order-d-status ">
                                                            <div>
                                                                <div class="order-d-icon"></div>
                                                                <span class="order-d-title">Delivered on Jun 17</span>
                                                                <div class="order-d-text">Your item has been delivered</div>


                                                            </div>




                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <div class="order-r text-right">
                                                <a class="order-r-text" href="">

                                                    <i class="icon-star"></i> Rate &amp; Review Product
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="tab-cards" role="tabpanel" aria-labelledby="tab-cards-link">
                                <div class="profile-detais-box">
                                    <form action="#">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>Card Number *</label>
                                                <input type="text" class="form-control" required>
                                            </div><!-- End .col-sm-6 -->

                                            <div class="col-sm-6">
                                                <label>Valid date*</label>
                                                <input type="date" class="form-control" required>
                                            </div><!-- End .col-sm-6 -->

                                            <div class="col-sm-6">
                                                <label>Name On Card *</label>
                                                <input type="text" class="form-control" required>
                                            </div><!-- End .col-sm-6 -->
                                        </div><!-- End .row -->





                                        <button type="submit" class="btn btn-outline-primary-2">
                                            <span>SAVE CHANGES</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </button>
                                        <small class="form-text mt-2">Your card details would be securely saved for faster payments. Your CVV will not be stored</small>

                                    </form>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="tab-address" role="tabpanel" aria-labelledby="tab-address-link">
                                <p>The following addresses will be used on the checkout page by default.</p>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="card card-dashboard">
                                            <div class="card-body">
                                                <h3 class="card-title">Billing Address</h3>

                                                <p>User Name<br>
                                                    User Company<br>

                                                    New York, NY 10001<br>
                                                    1-234-987-6543<br>
                                                    yourmail@mail.com<br>
                                                    <a href="#">Edit <i class="icon-edit"></i></a>
                                                </p>
                                            </div><!-- End .card-body -->
                                        </div><!-- End .card-dashboard -->
                                    </div><!-- End .col-lg-6 -->

                                    <div class="col-lg-6">
                                        <div class="card card-dashboard">
                                            <div class="card-body">
                                                <h3 class="card-title">Billing Address</h3>

                                                <p>User Name<br>
                                                    User Company<br>

                                                    New York, NY 10001<br>
                                                    1-234-987-6543<br>
                                                    yourmail@mail.com<br>
                                                    <a href="#">Edit <i class="icon-edit"></i></a>
                                                </p>
                                            </div><!-- End .card-body -->
                                        </div><!-- End .card-dashboard -->
                                    </div><!-- End .col-lg-6 -->
                                </div><!-- End .row -->
                            </div><!-- .End .tab-pane -->

                            <div class="tab-pane fade" id="tab-account" role="tabpanel" aria-labelledby="tab-account-link">
                                <div class="profile-detais-box">
                                    <form action="#">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>First Name *</label>
                                                <input type="text" class="form-control" required>
                                            </div><!-- End .col-sm-6 -->

                                            <div class="col-sm-6">
                                                <label>Last Name *</label>
                                                <input type="text" class="form-control" required>
                                            </div><!-- End .col-sm-6 -->
                                        </div><!-- End .row -->

                                        <label>Display Name *</label>
                                        <input type="text" class="form-control" required>
                                        <small class="form-text">This will be how your name will be displayed in the account section and in reviews</small>

                                        <label>Email address *</label>
                                        <input type="email" class="form-control" required>

                                        <label>Current password (leave blank to leave unchanged)</label>
                                        <input type="password" class="form-control">

                                        <label>New password (leave blank to leave unchanged)</label>
                                        <input type="password" class="form-control">

                                        <label>Confirm new password</label>
                                        <input type="password" class="form-control mb-2">

                                        <button type="submit" class="btn btn-outline-primary-2">
                                            <span>SAVE CHANGES</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </button>
                                    </form>
                                </div>
                            </div><!-- .End .tab-pane -->

                            <div class="tab-pane fade" id="tab-coupons" role="tabpanel" aria-labelledby="tab-coupons-link">
                                <div class="row order-box">
                                    <div class="col-sm-6">
                                        <div class="coupon bg-white rounded mb-3 d-flex justify-content-between">
                                            <div class="kiri p-3">
                                                <div class="icon-container ">
                                                    <div class="icon-container_box">
                                                       30% OFF
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tengah py-3 d-flex w-100 justify-content-start">
                                                <div>
                                                    <span class="badge badge-success">Valid</span>
                                                    <h3 class="lead">On minimum purchase of Rs. 0 </h3>
                                                    <p class="text-muted mb-0">Code: BEAUTYGET30</p>
                                                </div>
                                            </div>
                                            <div class="kanan">
                                                <div class="info m-3 d-flex align-items-center">
                                                    <div class="w-100">
                                                        <div class="block">
                                                            <span class="time font-weight-light">
                                                                <span>Expiry: <b>JUL 31 2021</b></span>
                                                            </span>
                                                        </div>
                                                        <a href="#" target="_blank" class="btn btn-sm btn-outline-danger btn-block">
                                                            show
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="coupon bg-white rounded mb-3 d-flex justify-content-between">
                                            <div class="kiri p-3">
                                                <div class="icon-container ">
                                                    <div class="icon-container_box">
                                                    30% OFF
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="tengah py-3 d-flex w-100 justify-content-start">
                                                <div>
                                                    <span class="badge badge-success">Valid</span>
                                                    <h3 class="lead">On minimum purchase of Rs. 0 </h3>
                                                    <p class="text-muted mb-0">Code: BEAUTYGET30</p>
                                                </div>
                                            </div>
                                            <div class="kanan">
                                                <div class="info m-3 d-flex align-items-center">
                                                    <div class="w-100">
                                                        <div class="block">
                                                            <span class="time font-weight-light">
                                                                <span>Expiry: <b>JUL 31 2021</b></span>
                                                            </span>
                                                        </div>
                                                        <a href="#" target="_blank" class="btn btn-sm btn-outline-danger btn-block">
                                                            show
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!-- .End .tab-pane -->
                        </div>
                    </div><!-- End .col-lg-9 -->
                </div><!-- End .row -->
            </div><!-- End .container -->
        </div><!-- End .dashboard -->
    </div><!-- End .page-content -->
</main>
<!-- End main -->


<?php include("footer.php"); ?>