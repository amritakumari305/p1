<!--footer -->
<footer class="footer footer-2 " style="background-color: #161027">

    <div class="container">
        <hr class="mt-0 mb-0" style="border-color: #444;">
    </div>
    <div class="footer-middle border-0">
        <div class="container">
            <div class="row">
                <div class="col-12 col-lg-2-5cols">
                    <div class="widget widget-about mb-4">
                        <img src="assets/images/logo.jpg" class="footer-logo" alt="Footer Logo" width="200" height="30">
                        <p>Praesent dapibus, neque id cursus ucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus. </p>

                        <div class="widget-about-info">
                            <div class="row">
                                <div class="col-sm-6 col-md-4">
                                    <span class="widget-about-title text-white">Got Question? Call us</span>
                                    <a href="tel:9521132592" class="">91-9521132592</a>
                                </div>

                                <div class="col-sm-6 col-md-8">
                                    <span class="pl-3 widget-about-title text-white">Payment Method</span>
                                    <figure class="pl-3 mb-0 footer-payments">
                                        <img src="assets/images/payments.png" alt="Payment methods" width="272" height="20">
                                    </figure>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>


                <div class="col-sm-4 col-lg-5cols">
                    <div class="widget mb-4">
                        <h4 class="widget-title text-white">Information</h4>


                        <ul class="widget-list">
                            <li>
                                <a href="about.php">About </a>
                            </li>
                            <li>
                                <a href="contact.php">Contact us</a>
                            </li>
                            <li>
                                <a href="shop.php">Shop</a>
                            </li>
                            <li>
                                <a href="blog.php">Blog</a>
                            </li>
                            <li>
                                <a href="faq.php">FAQ</a>
                            </li>

                            
                        </ul>

                    </div>

                </div>


                <div class="col-sm-4 col-lg-5cols">
                    <div class="widget mb-4">
                        <h4 class="widget-title text-white">Customer Service</h4>


                        <ul class="widget-list">
                            <li>
                                <a href="payments.php">Payment Methods</a>
                            </li>

                            <li>
                                <a href="faq.php">Returns & Refund</a>
                            </li>
                            <li>
                                <a href="faq.php">Shipping</a>
                            </li>
                            <li>
                                <a href="terms_condition.php">Terms and conditions</a>
                            </li>
                            <li>
                                <a href="privacy_policy.php">Privacy Policy</a>
                            </li>
                        </ul>

                    </div>

                </div>


                <div class="col-sm-4 col-lg-5cols">
                    <div class="widget mb-4">
                        <h4 class="widget-title text-white">My Account</h4>
                        <ul class="widget-list">
                            
                            <li>
                                <a href="cart.php">View Cart</a>
                            </li>
                            <li>
                                <a href="wishlist.php">My Wishlist</a>
                            </li>
                            <li>
                                <a href="#">Track My Order</a>
                            </li>
                            <li>
                                <a href="dashboard.php">My Account</a>
                            </li>
                            <li>
                                <a href="#">Help</a>
                            </li>
                        </ul>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <div class="footer-bottom font-weight-normal">
        <div class="container">
            <p class="footer-copyright font-weight-normal ml-lg-2 ">&copy; 2021 Coral Fashion. All Rights Reserved. <a href="https://coralitsolution.com/" class="text-center">| Designed &amp; Developed By : <img src="assets/images/coral-logo.png" alt="" width="150" class="d-inline"></a></p>




            <div class="social-icons  justify-content-center">
                <span class="social-label">Social Media : </span>
                <a href="#" class="social-icon social-facebook" title="Facebook" target="_blank">
                    <i class="icon-facebook-f"></i>
                </a>
                <a href="#" class="social-icon social-twitter" title="Twitter" target="_blank">
                    <i class="icon-twitter"></i>
                </a>
                <a href="#" class="social-icon social-instagram" title="Instagram" target="_blank">
                    <i class="icon-instagram"></i>
                </a>
                <a href="#" class="social-icon social-youtube" title="Youtube" target="_blank">
                    <i class="icon-youtube"></i>
                </a>
                <a href="#" class="social-icon social-pinterest" title="Pinterest" target="_blank">
                    <i class="icon-pinterest"></i>
                </a>
            </div>

        </div>

    </div>

</footer>
<!--end footer-->
</div>

<!-- Scroll To Top Icon -->
<button id="scroll-top" title="Back to Top">
    <i class="icon-arrow-up"></i>
</button>
<!-- End scroll To Top Icon -->

<!-- mobil-menu-overlay-->
<div class="mobile-menu-overlay"></div>
<!-- End mobil-menu-overlay -->

<!--mobil-menu-model -->
<div class="mobile-menu-container">
    <div class="mobile-menu-wrapper">
        <span class="mobile-menu-close">
            <i class="icon-close"></i>
        </span>

        <form action="#" method="get" class="mobile-search">
            <label for="mobile-search" class="sr-only">Search</label>
            <input type="search" class="form-control" name="mobile-search" id="mobile-search" placeholder="Search in..." required>
            <button class="btn btn-primary" type="submit">
                <i class="icon-search"></i>
            </button>
        </form>

        <ul class="nav nav-pills-mobile" role="tablist">
            <li class="nav-item">
                <a class="nav-link font-size-normal second-primary-color  text-uppercase active" id="mobile-menu-link" data-toggle="tab" href="#mobile-menu-tab" role="tab" aria-controls="mobile-menu-tab" aria-selected="true">Menu</a>
            </li>
            <li class="nav-item">
                <a class="nav-link font-size-normal second-primary-color  text-uppercase" id="mobile-cats-link" data-toggle="tab" href="#mobile-cats-tab" role="tab" aria-controls="mobile-cats-tab" aria-selected="false">Categories</a>
            </li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane fade show active" id="mobile-menu-tab" role="tabpanel" aria-labelledby="mobile-menu-link">
                <nav class="mobile-nav">
                    <ul class="mobile-menu">
                        <li class="active"><a href="index.php">Home</a></li>
                        <li>
                            <a href="">Shop</a>
                            <ul>
                                <li>
                                    <a href="shop.php">Dresses</a>
                                </li>
                                <li>
                                    <a href="shop.php">Accessories</a>
                                </li>
                                <li>
                                    <a href="shop.php">
                                        <span>Inner Ware
                                            <span class="tip tip-hot">Hot</span>
                                        </span>
                                    </a>
                                </li>

                                <li>
                                    <a href="shop.php">
                                        <span>Footware
                                            <span class="tip tip-new">New</span>
                                        </span>
                                    </a>
                                </li>

                            </ul>
                        </li>

                        <li>
                            <a href="#">Clothing</a>
                            <ul>
                                <li>
                                    <a href="#">Women</a>

                                    <ul>
                                        <li>
                                            <a href="shop.php">Western</a>
                                        </li>
                                        <li>
                                            <a href="shop.php">Indian</a>
                                        </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="">Men</a>

                                    <ul>
                                        <li>
                                            <a href="shop.php">Upper</a>
                                        </li>
                                        <li>
                                            <a href="shop.php">Bottom</a>
                                        </li>
                                    </ul>
                                </li>

                            </ul>
                        </li>
                        <li><a href="shop.php">New Arrival</a></li>
                        <li><a href="shop.php">Sale</a></li>
                        <li><a href="blog.php">Blog</a></li>
                    </ul>
                </nav>

            </div>

            <div class="tab-pane fade" id="mobile-cats-tab" role="tabpanel" aria-labelledby="mobile-cats-link">
                <nav class="mobile-cats-nav">
                    <ul class="mobile-cats-menu">

                        <li>
                            <a class="mobile-cats-lead" href="#">Deal Of The Day</a>
                        </li>
                        <li>
                            <a href="shop.php">Clothing</a>
                        </li>
                        <li>
                            <a href="shop.php">Accessories</a>
                        </li>
                        <li>
                            <a href="shop.php">Footware</a>
                        </li>
                        <li>
                            <a href="shop.php">Summer &amp;Collection</a>
                        </li>
                        <li>
                            <a href="shop.php">New &amp;Arrival</a>
                        </li>

                    </ul>

                </nav>

            </div>

        </div>

    </div>

</div>
<!--end mobil-menu-model -->

<!-- Sign in / Register Modal -->
<div class="modal fade" id="signin-modal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">
                        <i class="icon-close"></i>
                    </span>
                </button>

                <div class="form-box">
                    <div class="form-tab">
                        <ul class="nav nav-pills nav-fill" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link font-size-normal second-primary-color active" id="signin-tab" data-toggle="tab" href="#signin" role="tab" aria-controls="signin" aria-selected="true">Sign In</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link font-size-normal second-primary-color" id="register-tab" data-toggle="tab" href="#register" role="tab" aria-controls="register" aria-selected="false">Register</a>
                            </li>
                        </ul>
                        <div class="tab-content" id="tab-content-5">
                            <div class="tab-pane fade show active" id="signin" role="tabpanel" aria-labelledby="signin-tab">
                                <form action="#">
                                    <div class="form-group">
                                        <label for="singin-email">Username or email address *</label>
                                        <input type="text" class="form-control" id="singin-email" name="singin-email" required>
                                    </div>


                                    <div class="form-group">
                                        <label for="singin-password">Password *</label>
                                        <input type="password" class="form-control" id="singin-password" name="singin-password" required>
                                    </div>


                                    <div class="form-footer">
                                        <button type="submit" class="btn btn-outline-primary-2">
                                            <span>LOG IN</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </button>

                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="signin-remember">
                                            <label class="custom-control-label" for="signin-remember">Remember Me</label>
                                        </div>


                                        <a href="#" class="forgot-link">Forgot Your Password?</a>
                                    </div>

                                </form>
                            </div>

                            <div class="tab-pane fade" id="register" role="tabpanel" aria-labelledby="register-tab">
                                <form action="#">
                                    <div class="form-group">
                                        <label for="register-email">Your email address *</label>
                                        <input type="email" class="form-control" id="register-email" name="register-email" required>
                                    </div>


                                    <div class="form-group">
                                        <label for="register-password">Password *</label>
                                        <input type="password" class="form-control" id="register-password" name="register-password" required>
                                    </div>


                                    <div class="form-footer">
                                        <button type="submit" class="btn btn-outline-primary-2">
                                            <span>SIGN UP</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </button>

                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="register-policy" required>
                                            <label class="custom-control-label" for="register-policy">I agree to the
                                                <a href="#">privacy policy</a> *</label>
                                        </div>

                                    </div>

                                </form>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>
<!-- End modal -->


<!-- extra JS File -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/jquery.hoverIntent.min.js"></script>
<script src="assets/js/jquery.waypoints.min.js"></script>
<script src="assets/js/superfish.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/bootstrap-input-spinner.js"></script>
<script src="assets/js/jquery.elevateZoom.min.js"></script>
<script src="assets/js/jquery.plugin.min.js"></script>
<script src="assets/js/jquery.countdown.min.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
<!-- price range js -->
<!-- <script src="assets/js/nouislider.min.js"></script> -->
<!-- <script src="assets/js/wNumb.js"></script> -->
<!-- counter js -->
<script src="assets/js/jquery.countTo.js"></script>
<!-- Main JS File -->
<script src="assets/js/main.js"></script>

</body>

</html>