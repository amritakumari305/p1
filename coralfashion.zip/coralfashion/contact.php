<?php
include("header.php");
include("menu.php");
?>
<main class="main">
    <!-- breadcrumb -->
    <div class="page-header text-center" style="background-image: url('assets/images/about-bg.jpg')">
        <div class="container">
            <h1 class="page-title text-white"> <mark style="background: #4625bc;padding: 1px 15px;color:#fff">Contact us</mark> </h1>
        </div>
    </div>
    <!-- pagination -->
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>

                <li class="breadcrumb-item active">About Us</li>
            </ol>
        </div>
    </nav>
    <!-- page content -->
    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-2 mb-lg-0">
                    <h2 class="title mb-1">Contact Information</h2>
                    <p class="para-c mb-3">Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.</p>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="contact-info">
                                <h3>Office Address</h3>

                                <ul class="contact-list">
                                    <li>
                                        <i class="icon-map-marker"></i>
                                        28A, Brijlalpura Near Ganga Jamuna Petrol Pump, Gopalpura Bypass, Jaipur, Rajasthan, India
                                    </li>
                                    <li>
                                        <i class="icon-phone"></i>
                                        <a href="tel:9521132592">+91-9521132592</a>
                                    </li>
                                    <li>
                                        <i class="icon-envelope"></i>
                                        <a href="mailto:admin@coralitsolution.com">admin@coralitsolution.com</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6">
                    <h2 class="title mb-1">Any Questions?</h2>
                    <p class="para-c mb-2">Use the form below to get in touch with us</p>

                    <form action="#" class="contact-form mb-3">
                        <div class="row">
                            <div class="col-sm-6">
                                <label for="cname" class="sr-only">Name</label>
                                <input type="text" class="form-control" id="cname" placeholder="Name *" required>
                            </div>

                            <div class="col-sm-6">
                                <label for="cemail" class="sr-only">Email</label>
                                <input type="email" class="form-control" id="cemail" placeholder="Email *" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-sm-6">
                                <label for="cphone" class="sr-only">Phone</label>
                                <input type="tel" class="form-control" id="cphone" placeholder="Phone">
                            </div>

                            <div class="col-sm-6">
                                <label for="csubject" class="sr-only">Subject</label>
                                <input type="text" class="form-control" id="csubject" placeholder="Subject">
                            </div>
                        </div>

                        <label for="cmessage" class="sr-only">Message</label>
                        <textarea class="form-control" cols="30" rows="4" id="cmessage" required placeholder="Message *"></textarea>

                        <button type="submit" class="btn btn-outline-primary-2 btn-minwidth-sm">
                            <span>SUBMIT</span>
                            <i class="icon-long-arrow-right"></i>
                        </button>
                    </form>
                </div>
            </div>

            <hr class="mt-2 ">

            <div class="row">
                <div class="col-md-12">
                    <div class="map_wrap">
                        <iframe src="  https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d113877.88414632417!2d75.68817329434634!3d26.88178293512002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x396db4f798006cbb%3A0x1ba3f77f1a1f2382!2scoral+it+solutions+jaipur!3m2!1d26.881800199999997!2d75.75821359999999!5e0!3m2!1sen!2sin!4v1531460342957" width="100%" height="250" frameborder="0" style="border:0" allowfullscreen="">
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- End main -->


<?php include("footer.php"); ?>