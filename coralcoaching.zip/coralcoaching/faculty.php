<?php 
include("header.php");
include("menu.php");
?>

<!-- breadcrumb -->
<div class="homes">
    <div class="home_background_container prlx_parent">
        <div class="home_background prlx" style="background-image:url(images/contact_background.jpg)"></div>
    </div>
        <div class="home_content">
        <h1>Faculty</h1>
    </div>
</div>


<div class="teachers page_section">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3  col-sm-6 teacher">
                        <div class="card">
                            <div class="card_img">
                                <div class="card_plus trans_200 text-center"><a href="#">+</a></div>
                                <img class="card-img-top trans_200" src="images/teacher_1.jpg" alt="">
                            </div>
                            <div class="card-body text-center">
                                <div class="card-title"><a href="#">Faculty Name</a></div>
                                <div class="card-text">Polity</div>
                                
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6  teacher">
                        <div class="card">
                            <div class="card_img">
                                <div class="card_plus trans_200 text-center"><a href="#">+</a></div>
                                <img class="card-img-top trans_200" src="images/teacher_2.jpg" alt="">
                            </div>
                            <div class="card-body text-center">
                                <div class="card-title"><a href="#">Faculty Name</a></div>
                                <div class="card-text">English</div>
                                
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-sm-6  teacher">
                        <div class="card">
                            <div class="card_img">
                                <div class="card_plus trans_200 text-center"><a href="#">+</a></div>
                                <img class="card-img-top trans_200" src="images/teacher_3.jpg" alt="">
                            </div>
                            <div class="card-body text-center">
                                <div class="card-title"><a href="#">Faculty Name</a></div>
                                <div class="card-text">Maths</div>
                                
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3  col-sm-6 teacher">
                        <div class="card">
                            <div class="card_img">
                                <div class="card_plus trans_200 text-center"><a href="#">+</a></div>
                                <img class="card-img-top trans_200" src="images/teacher_4.jpg" alt="">
                            </div>
                            <div class="card-body text-center">
                                <div class="card-title"><a href="#">Faculty Name</a></div>
                                <div class="card-text">Economics</div>
                                
                            </div>
                        </div>
                    </div>

                   

                    <div class="col-lg-3  col-sm-6 teacher">
                        <div class="card">
                            <div class="card_img">
                                <div class="card_plus trans_200 text-center"><a href="#">+</a></div>
                                <img class="card-img-top trans_200" src="images/teacher_6.jpg" alt="">
                            </div>
                            <div class="card-body text-center">
                                <div class="card-title"><a href="#">Faculty Name</a></div>
                                <div class="card-text">Geography</div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<?php include("footer.php")?>