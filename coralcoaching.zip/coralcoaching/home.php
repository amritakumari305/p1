<!-- home slider -->
<div class="home">
    <div class="hero_slider_container">
        <div class="hero_slider owl-carousel">

                <div class="hero_slide">
                    <div class="hero_slide_background" style="background-image:url(images/coaching.jpg)"></div>
                    <div class="hero_slide_container d-flex flex-column align-items-center justify-content-center">
                        <div class="hero_slide_content text-center">
                            <h1 data-animation-in="fadeInUp" data-animation-out="animate-out fadeOut">Get your <span>Education</span> today!</h1>
                        </div>
                    </div>
                </div>

                <div class="hero_slide">
                    <div class="hero_slide_background" style="background-image:url(images/laibrary.jpg)"></div>
                    <div class="hero_slide_container d-flex flex-column align-items-center justify-content-center">
                        <div class="hero_slide_content text-center">
                            <h1 data-animation-in="fadeInUp" data-animation-out="animate-out fadeOut">Coral <span> Coaching</span>  Classes!</h1>
                        </div>
                    </div>
                </div>

                <div class="hero_slide">
                    <div class="hero_slide_background" style="background-image:url(images/Higher.jpg)"></div>
                    <div class="hero_slide_container d-flex flex-column align-items-center justify-content-center">
                        <div class="hero_slide_content text-center">
                            <h1 data-animation-in="fadeInUp" data-animation-out="animate-out fadeOut">Best  <span>Coaching</span> In Jaipur!</h1>
                        </div>
                    </div>
                </div>
        </div>
        <div class="hero_slider_left hero_slider_nav trans_200"><span class="trans_200"><i class="fas fa-chevron-left"></i></span></div>
        <div class="hero_slider_right hero_slider_nav trans_200"><span class="trans_200"><i class="fas fa-chevron-right"></i></span></div>
    </div>
</div>

<div class="hero_boxes">
    <div class="hero_boxes_inner">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 hero_box_col">
                    <div class="hero_box d-flex flex-row align-items-center justify-content-start">
                        <img src="images/earth-globe.svg" class="svg" alt="">
                        <div class="hero_box_content">
                            <h2 class="hero_box_title">Online Courses</h2>
                            <a href="courses.php" class="hero_box_link">view more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 hero_box_col">
                    <div class="hero_box d-flex flex-row align-items-center justify-content-start">
                        <img src="images/books.svg" class="svg" alt="">
                        <div class="hero_box_content">
                            <h2 class="hero_box_title">Study Materials</h2>
                            <a href="courses.php" class="hero_box_link">view more</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 hero_box_col">
                    <div class="hero_box d-flex flex-row align-items-center justify-content-start">
                        <img src="images/professor.svg" class="svg" alt="">
                        <div class="hero_box_content">
                            <h2 class="hero_box_title">Our Faculty</h2>
                            <a href="teachers.php" class="hero_box_link">view more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- about -->
<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="white-box-large">
                <div class="section-title">
                    <div>
                        <h3>Welcome to Coral Coaching Classes</h3>
                        <div class="bar"></div>
                    </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis</p>
                <ul class="themeioan_ul_icon">
                    <li><i class="fas fa-check-circle"></i> Coaching Courses for Life</li>
                    <li><i class="fas fa-check-circle"></i> Every Video included in package</li>
                    <li><i class="fas fa-check-circle"></i> We have best support community</li>
                    <li><i class="fas fa-check-circle"></i> Call us 24/7 we are Online</li>
                </ul>
                <div class="mt-5 mb-5">
                    <a href="about_us.php" class="color-two btn-custom ">Read More <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="about-img">
                <img src="images/about1.png" alt="" width="100%">
            </div>
        </div>
    </div>
</div>

<!-- milestones counter -->
<div class="milestones">
    <div class="milestones_container">
        <div class="milestones_background" style="background-image:url(images/milestones_background.jpg)"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_1.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="750">750</div>
                        <div class="milestone_text">Current Students</div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_2.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="120">720</div>
                        <div class="milestone_text">Certified Teachers</div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_3.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="39">39</div>
                        <div class="milestone_text">Total  Courses</div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_4.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="3500" data-sign-before="+">3500</div>
                        <div class="milestone_text">Graduate Students</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- popular Courses -->
<div class="popular page_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-titles">
                    <div>
                        <h3>Popular Courses</h3>
                        <div class="bar"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row course_boxes">
            <div class="col-lg-4 course_box">
                <div class="card">
                    <img class="card-img-top" src="images/course_1.jpg" alt="courses.php">
                    <div class="card-body text-center">
                        <div class="card-title"><a href="courses.php">RAS Online Course</a></div>
                        <div class="card-text">RAS Pre and Mains Online Course...</div>
                    </div>
                    <div class="price_box d-flex flex-row align-items-center">
                                
                        <div class="course_author_name"><a href="courses.php">See More</a></div>
                        <div class="course_price d-flex flex-column align-items-center justify-content-center"><a href="courses.php"><i class="fas fa-eye"></i></a></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 course_box">
                <div class="card">
                    <img class="card-img-top" src="images/course_2.jpg" alt="https://unsplash.com/@cikstefan">
                    <div class="card-body text-center">
                        <div class="card-title"><a href="courses.php">RAS Online Course</a></div>
                        <div class="card-text">RAS Pre and Mains Online Course...</div>
                    </div>
                    <div class="price_box d-flex flex-row align-items-center">
                                
                        <div class="course_author_name"><a href="courses.php">See More</a></div>
                        <div class="course_price d-flex flex-column align-items-center justify-content-center"><a href="courses.php"><i class="fas fa-eye"></i></a></div>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 course_box">
                <div class="card">
                    <img class="card-img-top" src="images/course_3.jpg" alt="https://unsplash.com/@dsmacinnes">
                    <div class="card-body text-center">
                        <div class="card-title"><a href="courses.php">RAS Online Course</a></div>
                        <div class="card-text">RAS Pre and Mains Online Course...</div>
                    </div>
                    <div class="price_box d-flex flex-row align-items-center">
                                
                        <div class="course_author_name"><a href="courses.php">See More</a></div>
                        <div class="course_price d-flex flex-column align-items-center justify-content-center"><a href="courses.php"><i class="fas fa-eye"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Video Section -->
<section class="ftco-section-3 img" style="background-image: url(images/bg_3.jpg);">
    <div class="overlay"></div>
    <div class="container">
        <div class="row d-md-flex justify-content-center">
            <div class="col-md-9 about-video text-center">
                <h2 class="ftco-animate">Coral Coaching is a Leading Schools Around the World</h2>
                <div class="video d-flex justify-content-center">
                    <a href="https://www.youtube.com/watch?v=wegDmw_E8Bg" class="button popup-vimeo d-flex justify-content-center align-items-center"><i class="fas fa-play"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<div class="services page_section"  style="background-image: url(images/course-shape.png);">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-titles pt-5">
                    <div>
                        <h3>Our Services</h3>
                        <div class="bar"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row services_row">
            <div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
                <div class="icon_container d-flex flex-column justify-content-end">
                    <img src="images/earth-globe.svg" alt="">
                </div>
                <h3>Online Courses</h3>
                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
            </div>
            <div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
                <div class="icon_container d-flex flex-column justify-content-end">
                    <img src="images/exam.svg" alt="">
                </div>
                <h3>Indoor Courses</h3>
                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
            </div>
            <div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
                <div class="icon_container d-flex flex-column justify-content-end">
                    <img src="images/books.svg" alt="">
                </div>
                <h3>PDF's and Online Test</h3>
                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
            </div>
            <div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
                <div class="icon_container d-flex flex-column justify-content-end">
                    <img src="images/professor.svg" alt="">
                </div>
                <h3>Exceptional Professors</h3>
                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
            </div>
            <div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
                <div class="icon_container d-flex flex-column justify-content-end">
                    <img src="images/blackboard.svg" alt="">
                </div>
                <h3>E-Notes</h3>
                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
            </div>
            <div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
                <div class="icon_container d-flex flex-column justify-content-end">
                    <img src="images/mortarboard.svg" alt="">
                </div>
                <h3>Get Certification</h3>
                <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
            </div>
        </div>
    </div>
</div>

<!-- Register form Section -->
<div class="register">
    <div class="container-fluid">
        <div class="row row-eq-height">
            <div class="col-lg-6 nopadding">
                <div class="register_section d-flex flex-column align-items-center justify-content-center">
                    <div class="register_content text-center">
                        <h1 class="register_title">Register now and get a discount <span>20%</span> discount until 1 January</h1>
                        <p class="register_text">In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum. Aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempo.</p>
                        <div class="button button_1 register_button mx-auto trans_200"><a href="#">See More Courses</a></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 nopadding">
                <div class="search_section d-flex flex-column align-items-center justify-content-center">
                    <div class="search_background" style="background-image:url(images/search_background.jpg);"></div>
                    <div class="search_content">
                        <h1 class="search_title">Enquire Now</h1>
                        <form id="search_form" class="search_form" action="">
                            <input id="search_form_name" class="input_field search_form_name" type="text" placeholder="Name" required="required" data-error="Course name is required.">
                            <input id="search_form_name" class="input_field search_form_name" type="text" placeholder="Course Name" required="required" >
                            <input id="search_form_category" class="input_field search_form_category" type="email" placeholder="Email">
                            <input id="search_form_degree" class="input_field search_form_degree" type="number" placeholder="No..">
                            <button id="search_submit_button" type="submit" class="search_submit_button trans_200" value="Submit">Submit Request</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Future section -->
<div class="container py-5">
    <div class="row">
        <div class="col-lg-6">
            <div class="about-img">
                <img src="images/sec-img.png" alt="" width="100%">
            </div>
        </div>
        <div class="col-lg-6">
            <div class="white-box-large">
                <div class="section-title">
                    <div>
                        <h3>Your Future, Your Way</h3>
                        <div class="bar"></div>
                    </div>
                </div>
                <p>Learn the Skills you Need to Succeed Today.</p>
                <ul class="themeioan_ul_icon">
                    <li><i class="fas fa-check-circle"></i>Access to ALL our courses.</li>
                    <li><i class="fas fa-check-circle"></i> Access to ALL our courses.</li>
                    <li><i class="fas fa-check-circle"></i>Educator support.</li>
                    
                </ul>
                <div class="mt-5 mb-5">
                    <a href="about_us.php" class="color-two btn-custom ">Read More <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        </div>
        
    </div>
</div>

<!-- testimonial section -->
<div class="testimonials page_section"  style="background-image: url(images/testimoniakl-bg.png);">
    <div class="container">
            <div class="row">
                        <div class="col-lg-12">
                            <div class="section-titles">
                                <div>
                                    <h3>Student Testimonials</h3>
                                    <div class="bar"></div>
                                   
                                </div>
                            </div>
                        </div>
            </div>
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="testimonials_slider_container">

                    <div class="owl-carousel owl-theme testimonials_slider">

                        <div class="owl-item">
                            <div class="testimonials_item text-center">
                                <div class="quote">“</div>
                                <p class="testimonials_text">In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.In aliquam, augue a gravida rutrum, ante nisl fermentum nulla,
                                    vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
                                <div class="testimonial_user">
                                    
                                    <div class="testimonial_name">james cooper</div>
                                    <!-- <div class="testimonial_title">Graduate Student</div> -->
                                </div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="testimonials_item text-center">
                                <div class="quote">“</div>
                                <p class="testimonials_text">In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.In aliquam, augue a gravida rutrum, ante nisl fermentum nulla,
                                    vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
                                <div class="testimonial_user">
                                    
                                    <div class="testimonial_name">james cooper</div>
                                
                                </div>
                            </div>
                        </div>

                        <div class="owl-item">
                            <div class="testimonials_item text-center">
                                <div class="quote">“</div>
                                <p class="testimonials_text">In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.In aliquam, augue a gravida rutrum, ante nisl fermentum nulla,
                                    vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum.</p>
                                <div class="testimonial_user">
                                    
                                    <div class="testimonial_name">james cooper</div>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- latest Blog -->


<div class="events page_section" style="background-image: url(images/img/bg.png);">
    <div class="container">
            <div class="row">
                        <div class="col-lg-12">
                            <div class="section-titles pt-4">
                                <div>
                                    <h3>Our Blog And Latest News</h3>
                                    <div class="bar"></div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="event_items">

                    <div class="row event_item">
                        <div class="col">
                            <div class="row d-flex flex-row align-items-end">
                                <div class="col-lg-2 order-lg-1 order-2">
                                    <div class="event_date d-flex flex-column align-items-center justify-content-center">
                                        <div class="event_day">07</div>
                                        <div class="event_month">January</div>
                                    </div>
                                </div>
                                <div class="col-lg-6 order-lg-2 order-3">
                                    <div class="event_content">
                                        <div class="event_name"><a class="trans_200" href="#">Student Festival</a></div>
                                        <div class="event_location">By: Admin</div>
                                        <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor.</p>
                                    </div>
                                </div>
                                <div class="col-lg-4 order-lg-3 order-1">
                                    <div class="event_image">
                                        <img src="images/event_1.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row event_item">
                        <div class="col">
                            <div class="row d-flex flex-row align-items-end">
                                <div class="col-lg-2 order-lg-1 order-2">
                                    <div class="event_date d-flex flex-column align-items-center justify-content-center">
                                        <div class="event_day">07</div>
                                        <div class="event_month">January</div>
                                    </div>
                                </div>
                                <div class="col-lg-6 order-lg-2 order-3">
                                    <div class="event_content">
                                        <div class="event_name"><a class="trans_200" href="#">Open day in the Univesrsity campus</a></div>
                                        <div class="event_location">By: Admin</div>
                                        <p>In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor.</p>
                                    </div>
                                </div>
                                <div class="col-lg-4 order-lg-3 order-1">
                                    <div class="event_image">
                                        <img src="images/event_2.jpg" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                </div>
     </div>
</div>


<!-- free trail  -->
<section class="ftco-freeTrial">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="d-flex align-items-center">
                    <div class="free-trial ftco-animate fadeInUp ftco-animated">
                        <h3>Try our free trial course</h3>
                        <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life</p>
                    </div>
                    <div class="btn-join ftco-animate fadeInUp ftco-animated">
                        <p><a href="#" class="btn btn-primary py-3 px-4">Join now!</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- how can help -->
<section id="how-can-i-help-you" class="ts-block ts-xs-text-center text-center" style="background-image: url(images/course-shape.png);">
    <div class="container">
                    
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-titles py-5">
                                <div>
                                    <h3>How Can I Help You</h3>
                                    <div class="bar"></div>
                                    <p>We can discuss your problems</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--end ts-title-->
                    <div class="row pb-5">
                        <div class="col-sm-6 col-md-4 col-xl-4">
                            <div class="ts-item ts-fadeInUp animated" data-animate="ts-fadeInUp" style="visibility: visible;">
                                <div class="ts-item-content">
                                    <div class="ts-item-header">
                                        <figure class="icon mb-4">
                                            <img src="images/img/icon-head-question.png" alt="">
                                        </figure>
                                        <!--end icon-->
                                    </div>
                                    <!--end ts-item-header-->
                                    <div class="ts-item-body">
                                        <h4>Don’t Know Where to Go?</h4>
                                        <p class="mb-0">
                                            Morbi et nisl a sapien malesuada scelerisque. Suspendisse tempor turpis mattis
                                        </p>
                                    </div>
                                    <!--end ts-item-body-->
                                </div>
                                <!--end ts-item-content-->
                            </div>
                            <!--end ts-item-->
                        </div>
                        <!--end col-xl-4-->
                        <div class="col-sm-6 col-md-4 col-xl-4">
                            <div class="ts-item ts-fadeInUp animated" data-animate="ts-fadeInUp" data-delay="0.1s" style="animation-delay: 0.1s; visibility: visible;">
                                <div class="ts-item-content">
                                    <div class="ts-item-header">
                                        <figure class="icon mb-4">
                                            <img src="images/img/icon-sitting.png" alt="">
                                        </figure>
                                        <!--end icon-->
                                    </div>
                                    <!--end ts-item-header-->
                                    <div class="ts-item-body">
                                        <h4>We’ll Sit and Talk</h4>
                                        <p class="mb-0">
                                            Suspendisse eget semper justo, a laoreet sapien. Ut a est vitae
                                        </p>
                                    </div>
                                    <!--end ts-item-body-->
                                </div>
                                <!--end ts-item-content-->
                            </div>
                            <!--end ts-item-->
                        </div>
                        <!--end col-xl-4-->
                        <div class="col-sm-6 offset-sm-4 col-md-4 offset-md-0 col-xl-4">
                            <div class="ts-item ts-fadeInUp animated" data-animate="ts-fadeInUp" data-delay="0.2s" style="animation-delay: 0.2s; visibility: visible;">
                                <div class="ts-item-content">
                                    <div class="ts-item-header">
                                        <figure class="icon mb-4">
                                            <img src="images/img/icon-hands-heart.png" alt="">
                                        </figure>
                                        <!--end icon-->
                                    </div>
                                    <!--end ts-item-header-->
                                    <div class="ts-item-body">
                                        <h4>And Find The Solution</h4>
                                        <p class="mb-0">
                                            In non turpis convallis nunc fermentum porttitor sed quis sapien. Etiam et neque
                                        </p>
                                    </div>
                                    <!--end ts-item-body-->
                                </div>
                                <!--end ts-item-content-->
                            </div>
                            <!--end ts-item-->
                        </div>
                        <!--end col-xl-4-->
                    </div>
                    <!--end row-->
    </div>
                <!--end container-->
</section>