<?php 
include("header.php");
include("menu.php");
?>

<div class="homes">
    <div class="home_background_container prlx_parent">
        <div class="home_background prlx" style="background-image:url(images/contact_background.jpg)"></div>
    </div>
    <div class="home_content">
        <h1>Contact Us</h1>
    </div>
</div>

<div class="contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">

                <div class="contact_form">
                    <div class="contact_title">Get in touch</div>
                    <div class="contact_form_container">
                        <form action="">
                            <input id="contact_form_name" class="input_field contact_form_name" type="text" placeholder="Name" required="required" data-error="Name is required.">
                            <input id="contact_form_email" class="input_field contact_form_email" type="email" placeholder="E-mail" required="required" data-error="Valid email is required.">
                            <textarea id="contact_form_message" class="text_field contact_form_message " name="message" placeholder="Message" required="required" data-error="Please, write us a message."></textarea>
                            <button id="contact_send_btn" type="button" class="contact_send_btn trans_200" value="Submit">send message</button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="about">
                    <div class="about_title">Join Courses</div>
                    <p class="about_text">In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum. Etiam eu purus nec eros varius luctus. Praesent finibus risus facilisis ultricies. Etiam eu purus nec eros varius luctus.</p>
                    <div class="contact_info">
                        <ul>
                            <li class="contact_info_item">
                                <div class="contact_info_icon">
                                <img src="images/placeholder.svg" alt="">
                                </div>
                                28A, Brijlalpura Near Ganga Jamuna Petrol Pump, Gopalpura Bypass, Jaipur, Rajasthan, India
                            </li>
                            <li class="contact_info_item">
                                <div class="contact_info_icon">
                                <img src="images/smartphone.svg" alt="">
                                </div>
                                +91-9521132592
                            </li>
                            <li class="contact_info_item">
                                <div class="contact_info_icon">
                                <img src="images/envelope.svg" alt="">
                                </div><a href="#" >coralcoaching@gmail.com</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div id="google_map">
                    <div class="map_container">
                        <div id="map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.682956007697!2d75.75606491491477!3d26.881812267891316!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db4f798006cbb%3A0x1ba3f77f1a1f2382!2sCoral%20IT%20Solutions!5e0!3m2!1sen!2sin!4v1615977178062!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php")?>