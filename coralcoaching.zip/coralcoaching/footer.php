<footer class="footer" style="background-image: url('images/home_03-bg3caf.jpg');">
    <div class="container">

        <div class="newsletter">
           
            <div class="row">
                        <div class="col-lg-12">
                            <div class="section-titles">
                                <div>
                                    <h3>Subscribe to newsletter</h3>
                                    <div class="bar"></div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
            <div class="row">
                <div class="col text-center">
                    <div class="newsletter_form_container mx-auto">
                        <form action="">
                            <div class="newsletter_form d-flex flex-md-row flex-column flex-xs-column align-items-center justify-content-center">
                                <input id="newsletter_email" class="newsletter_email" type="email" placeholder="Email Address" required="required" >
                                <button id="newsletter_submit" type="submit" class="newsletter_submit_btn trans_300" value="Submit">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer_content">
                    <div class="row">

                        <div class="col-lg-4 col-md-12 col-sm-12 col-12 footer_col">

                            <div class="logo_container">
                                <div class="logo">
                                    <img src="images/logocccl.png" alt="" width="200">
                                   
                                </div>
                            </div>
                            <p class="footer_about_text">In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum, tempor lacus.</p>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-6 footer_col">
                            <div class="footer_column_title">Menu</div>
                            <div class="footer_column_content">
                                <ul>
                                    <li class="footer_list_item"><a href="#">Home</a></li>
                                    <li class="footer_list_item"><a href="#">About Us</a></li>
                                    <li class="footer_list_item"><a href="courses.php">Courses</a></li>
                                    <li class="footer_list_item"><a href="news.php">News</a></li>
                                    <li class="footer_list_item"><a href="contact.php">Contact</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-4 col-sm-6 col-6 footer_col">
                            <div class="footer_column_title">Usefull Links</div>
                            <div class="footer_column_content">
                                <ul>
                                    <li class="footer_list_item"><a href="#">Testimonials</a></li>
                                    <li class="footer_list_item"><a href="#">FAQ</a></li>
                                    <li class="footer_list_item"><a href="#">Community</a></li>
                                    <li class="footer_list_item"><a href="#">Campus Pictures</a></li>
                                    <li class="footer_list_item"><a href="#">Tuitions</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-4 col-md-4 col-sm-12 col-12 footer_col">
                            <div class="footer_column_title">Contact</div>
                            <div class="footer_column_content">
                                <ul>
                                    <li class="footer_contact_item">
                                        <div class="footer_contact_icon">
                                            <img src="images/placeholder.svg" alt="">
                                        </div>
                                        28A, Brijlalpura Near Ganga Jamuna Petrol Pump, Gopalpura Bypass, Jaipur, Rajasthan, India
                                    </li>
                                    <li class="footer_contact_item">
                                        <div class="footer_contact_icon">
                                            <img src="images/smartphone.svg" alt="">
                                        </div>
                                        +91-9521132592
                                    </li>
                                    <li class="footer_contact_item">
                                        <div class="footer_contact_icon">
                                            <img src="images/envelope.svg" alt="">
                                        </div><a href="" >coralcoaching@gmail.com</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
        </div>

        <div class="footer_bar d-flex flex-column flex-sm-row align-items-center">
                    <div class="footer_copyright">
                        <span>&copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Designed & Developed By : <a href="https://coralitsolution.com/" target="_blank"><img src="images/coral-logo.png" alt="" width="120"></a>
                        </span>
                    </div>
                    <div class="footer_social ml-sm-auto">
                        <ul class="menu_social">
                            <li class="menu_social_item"><a href="#"><i class="fab fa-pinterest"></i></a></li>
                            <li class="menu_social_item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            <li class="menu_social_item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                            <li class="menu_social_item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li class="menu_social_item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                        </ul>
                    </div>
        </div>
    </div>
</footer>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="vendor/greensock/TweenMax.min.js"></script>
<script src="vendor/greensock/TimelineMax.min.js"></script>
<script src="vendor/scrollmagic/ScrollMagic.min.js"></script>
<script src="vendor/greensock/animation.gsap.min.js"></script>

<script src="vendor/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="vendor/progressbar/progressbar.min.js"></script>
<script src="vendor/scrollTo/jquery.scrollTo.min.js"></script>
<script src="vendor/easing/easing.js"></script>
<script src="js/custom.js"></script>


</body>
</html>