<?php 
include("header.php");
include("menu.php");
?>

<!-- breadcrumb -->
<div class="homes">
    <div class="home_background_container prlx_parent">
        <div class="home_background prlx" style="background-image:url(images/contact_background.jpg)"></div>
    </div>
        <div class="home_content">
        <h1>Admission Form</h1>
    </div>
</div>




<div class="container pb-4">
    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-titles pt-5">
                                <div>
                                    <h3>Admission Form</h3>
                                    <div class="bar"></div>
                                    <p class="text-center">Fillup The Below Form For Admission</p>
                                </div>
                            </div>
                        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="contact_forms">
                <form action="">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="course">Select Course<span class="star">*</span></label>
                                <select class="form-control" name="course" id="course" onchange="getbatch(this.value);" required>
                                    <option value="">select course</option>
                                                                <option value="1">REET 1ST LEVEL</option>';
                                                                <option value="2">REET 2nd LEVEL(S.ST)</option>';
                                                                <option value="3">REET 2nd LEVEL (SCIENCE)</option>';
                                                                <option value="4">1ST GRADE G.K</option>';
                                                                <option value="14">SSC CGL</option>';
                                                                <option value="17">SI (Raj.Police)</option>';
                                                                <option value="18">RAS PRE</option>';
                                                                <option value="20">SSC GD</option>';
                                                                <option value="22">PATWARI</option>';
                                                                <option value="26">AIRFORCE Y GROUP</option>';
                                                                <option value="28">2nd Grade G.K.</option>';
                                                                <option value="34">GRAM SEVAK</option>';
                                                                <option value="57">Agriculture Supervisor </option>';
                                                                <option value="64">Bank PO & Clerk </option>';
                                                                <option value="66">IAS Pre and Mains</option>';
                                                                <option value="67">RAS Pre+Mains</option>';
                                                                <option value="70">RJS Pre+main+Interview </option>';
                                                                <option value="74">Vanpal-Vanrakshak </option>';
                                                                <option value="75">CLAT</option>';
                                                                <option value="76">AIRFORCE X GROUP</option>';
                                                                <option value="77">HIGH COURT GROUP D & LDC</option>';
                                                                <option value="78">REET Special (Common for ALL)</option>';
                                                        
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="batch">Select Batch<span class="star">*</span></label>
                                <select class="form-control" name="batch" id="batch" style="width:100%" required>
                                    <option value="">select batch</option>
                                    <option value="">BAtch No.2 4PM to 8pm</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="c_amt">Batch Course Fee <span class="star">*</span></label>
                                <input type="text" name="c_amt" id="c_amt" value="120000"  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="s_no">Student Aadhar Card Number<span class="star">*</span></label>
                                <input type="text" name="s_no" id="s_no" value=""  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="s_name">Student Name<span class="star">*</span></label>
                                <input type="text" name="s_name" id="s_name" value=""  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="a_fname">Student Father's/Husband's Name<span class="star">*</span></label>
                                <input type="text" name="a_fname" id="a_fname" value=""  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="s_no">Student Mobile Number<span class="star">*</span></label>
                                <input type="number" name="s_no" id="s_no" value=""  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="e_mail">Student Email<span class="star">*</span></label>
                                <input type="email" name="e_mail" id="e_mail" value=""  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="gender">Gender<span class="star">*</span></label>
                                <select class="form-control" name="gender" id="gender" style="width:100%" required>
                                    <option value="">Select Gender</option>
                                    <option value="">Male</option>
                                    <option value="">Female</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="d_o_b">Date Of Birth<span class="star">*</span></label>
                                <input type="date" name="d_o_b" id="d_o_b" value=""  class="form-control">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="state">State<span class="star">*</span></label>
                                <select class="form-control" name="state" id="state" style="width:100%" required>
                                    <option value="">Select State</option>
                                    <option value="">Bihar</option>
                                    <option value="">Rajasthan</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="dist">District<span class="star">*</span></label>
                                <select class="form-control" name="dist" id="dist" style="width:100%" required>
                                    <option value="">Select District</option>
                                    <option value="">Jaipur</option>
                                    <option value="">Jodhpur</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="dist">Address<span class="star">*</span></label>
                                <textarea name="adrs" id="adrs" class="form-control"></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="u_ph">Upload Photo<span class="star">*</span></label>
                                <input name="u_ph" id="u_ph"  type="file" class="form-control">
                            </div>
                        </div>
                        <button id="contact_send_btn" type="button" class="contact_send_btn trans_200" value="Submit">Submit </button>
                    </div>
                </form>    
            </div>
        </div>
    </div>
</div>


<?php include("footer.php")?>