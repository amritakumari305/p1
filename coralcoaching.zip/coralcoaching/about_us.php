<?php 
include("header.php");
include("menu.php");
?>

<!-- breadcrumb -->
<div class="homes">
    <div class="home_background_container prlx_parent">
        <div class="home_background prlx" style="background-image:url(images/contact_background.jpg)"></div>
    </div>
        <div class="home_content">
        <h1>About Us</h1>
    </div>
</div>

<!-- about -->
<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="white-box-large">
                <div class="section-title">
                    <div>
                        <h3>Welcome to Coral Coaching Classes</h3>
                        <div class="bar"></div>
                    </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis</p>
                <ul class="themeioan_ul_icon">
                    <li><i class="fas fa-check-circle"></i> Coaching Courses for Life</li>
                    <li><i class="fas fa-check-circle"></i> Every Video included in package</li>
                    <li><i class="fas fa-check-circle"></i> We have best support community</li>
                    <li><i class="fas fa-check-circle"></i> Call us 24/7 we are Online</li>
                </ul>
               
            </div>
        </div>
        <div class="col-lg-6">
            <div class="about-img">
                <img src="images/about1.png" alt="" width="100%">
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="white-box-large">
                <div class="section-title">
                    <div>
                        <h3>Our Mission</h3>
                        <div class="bar"></div>
                    </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis</p>
               
               
            </div>
        </div>
        <div class="col-lg-6">
            <div class="white-box-large">
                <div class="section-title">
                    <div>
                        <h3>Our Vision</h3>
                        <div class="bar"></div>
                    </div>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis</p>
               
               
            </div>
        </div>
    </div>
</div>

<!-- milestones counter -->
<div class="milestones">
    <div class="milestones_container">
        <div class="milestones_background" style="background-image:url(images/milestones_background.jpg)"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_1.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="750">750</div>
                        <div class="milestone_text">Current Students</div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_2.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="120">720</div>
                        <div class="milestone_text">Certified Teachers</div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_3.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="39">39</div>
                        <div class="milestone_text">Total  Courses</div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-6 milestone_col">
                    <div class="milestone text-center">
                        <div class="milestone_icon"><img src="images/milestone_4.svg" alt=""></div>
                        <div class="milestone_counter" data-end-value="3500" data-sign-before="+">3500</div>
                        <div class="milestone_text">Graduate Students</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- become a teacher -->
<div class="become">
    <div class="container">
        <div class="row row-eq-height">
                    <div class="col-lg-6 order-2 order-lg-1">
                        <div class="become_title">
                            <h1>Become a teacher</h1>
                        </div>
                        <p class="become_text">In aliquam, augue a gravida rutrum, ante nisl fermentum nulla, vitae tempor nisl ligula vel nunc. Proin quis mi malesuada, finibus tortor fermentum. Etiam eu purus nec eros varius luctus. Praesent finibus risus facilisis ultricies
                            venenatis. Suspendisse fermentum sodales lacus, lacinia gravida elit dapibus sed. Cras in lectus elit. Maecenas tempus nunc vitae mi egestas venenatis. Aliquam rhoncus, purus in vehicula porttitor, lacus ante consequat purus,
                            id elementum enim purus nec enim. In sed odio rhoncus, tristique ipsum id, pharetra neque.</p>
                        <div class="become_button text-center trans_200">
                            <a href="#">Send Request</a>
                        </div>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2">
                        <div class="become_image">
                            <img src="images/become.jpg" alt="">
                        </div>
                    </div>
        </div>
    </div>
</div>

<?php include("footer.php")?>