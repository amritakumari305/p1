<?php 
include("header.php");
include("menu.php");
?>

<!-- breadcrumb -->
<div class="homes">
    <div class="home_background_container prlx_parent">
        <div class="home_background prlx" style="background-image:url(images/contact_background.jpg)"></div>
    </div>
        <div class="home_content">
        <h1>Courses Details</h1>
    </div>
</div>


<section class="page_section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-titles">
                    <div>
                        <h3>Courses Complete Title</h3>
                        <div class="bar"></div>
                       
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8">
               <div class="row course_details">
                    <div class="col-md-6">
                        <img src="images/news_2.jpg" alt="" width="100%">

                    </div>
                    <div class="col-md-6">
                        <div class="discription">
                            <h3>Course Title</h3>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis</p>
                        </div>

                    </div>
                    <div class="col-md-12">
                        <div class="buy_course">
                            <h4>Select The Course</h4>
                            <p>Online Classes</p>
                            <span>₹ 1800.00/-</span>
                            <del>Price: ₹10000.00/-</del>
                        
                        <a href="" class="btn btn-primary float-right">Buy Courses</a>
                        </div>
                    </div>
                    <div class="col-md-12 my-4">
                        <div class="exam_oveview">
                            <h3>Exam Overview</h3>
                            <p>The Railway Recruitment Board conducts the Non-Technical Popular Categories (NTPC) exam for the recruitment of posts such as Junior Clerk cum Typist, Accounts Clerk cum Typist, Junior Time Keeper, Trains Clerk, Commercial cum Ticket Clerk, Traffic Assistant, Goods Guard, Senior Commercial cum Ticket Clerk, Senior Clerk cum Typist, Junior Account Assistant cum Typist, Senior Time Keeper, Commercial Apprentice, and Station Master.</p>
                        </div>
                    </div>
                    <div class="col-md-12 my-4">
                        <div class="Course_Features">
                                    <h3>Course Features</h3>   
                        </div> 
                        <div class="row">
                            <div class="col-md-6">
                                <div class="Course_Features_title">
                                    <i class="far fa-file-pdf"></i>
                                   <h4>E-Notes</h4>     
                                   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et</p>
                                </div> 
                            </div>
                            <div class="col-md-6">
                                <div class="Course_Features_title">
                                <i class="fas fa-video"></i>
                               
                                   <h4>Live Classes</h4>     
                                   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et</p>
                                </div> 
                            </div>
                            <div class="col-md-6">
                                <div class="Course_Features_title">
                                <i class="fab fa-youtube"></i>
                                   <h4>Live Quiz</h4>     
                                   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et</p>
                                </div> 
                            </div>
                            <div class="col-md-6">
                                <div class="Course_Features_title">
                                    <i class="fas fa-file-video"></i>
                                   <h4>Video Lectures</h4>     
                                   <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et</p>
                                </div> 
                            </div>
                        </div>
                    </div>
               </div>
            </div>
            <div class="col-md-4">
               <div class="course_aside mb-3">
                    <ul>
                        <li><a href="course.php"><i class="fas fa-check-circle"></i> Course Title Complete</a></li>
                        <li><a href="course.php"><i class="fas fa-check-circle"></i> Course Title Complete</a></li>
                        <li><a href="course.php"><i class="fas fa-check-circle"></i> Course Title Complete</a></li>
                        <li><a href="course.php"><i class="fas fa-check-circle"></i> Course Title Complete</a></li>

                        <li><a href="course.php"><i class="fas fa-check-circle"></i> Course Title Complete</a></li>
                        <li><a href="course.php"><i class="fas fa-check-circle"></i> Course Title Complete</a></li>


                    </ul>
               </div>
               <div class="course_apply">
                    <img src="images/woo_cta_image.png" alt="" width="100%">
               </div>
            </div>
        </div>

    </div>
</section>


<?php include("footer.php")?>