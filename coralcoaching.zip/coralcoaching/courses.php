<?php 
include("header.php");
include("menu.php");
?>

<!-- breadcrumb -->
<div class="homes">
    <div class="home_background_container prlx_parent">
        <div class="home_background prlx" style="background-image:url(images/contact_background.jpg)"></div>
    </div>
        <div class="home_content">
        <h1>Courses</h1>
    </div>
</div>


<section class="page_section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-titles">
                    <div>
                        <h3>Complete courses List</h3>
                        <div class="bar"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-4">
                <div class="courses_list">
                    <div class="course_heading">
                        <h3>Exam Name Title</h3>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                         <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>

                </div>
                <div class="courses_list">
                    <div class="course_heading">
                        <h3>Exam Name Title</h3>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    

                </div>
            </div>
            <div class="col-md-4">
                <div class="courses_list">
                    <div class="course_heading">
                        <h3>Exam Name Title</h3>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                         <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>

                </div>
            </div>
            <div class="col-md-4">
                <div class="courses_list">
                    <div class="course_heading">
                        <h3>Exam Name Title</h3>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                        <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>
                    <div class="course_name">
                         <a href="course_details.php" title="click to see details">Course Name Title Text (Live From Classroom)</a>
                    </div>

                </div>
            </div>
        </div>

    </div>
</section>


<?php include("footer.php")?>