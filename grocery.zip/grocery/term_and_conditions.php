<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
        <div class="coral-Breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Term and Conditions</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="all-product-grid">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="job-main-dt">
                            <h2>Coral Term and Conditions</h2>
                            <span>These Terms of Use ("Terms") were last updated on March 2, 2021.</span>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Personal Information</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum turpis vitae facilisis tempus. Donec in blandit risus, eget pretium mauris. Aliquam nec venenatis massa. Ut vel nulla id velit dictum rutrum nec vel ex. Phasellus
                                sit amet faucibus massa, in feugiat augue. Maecenas eget dapibus turpis, a finibus justo. Suspendisse pretium lorem non lorem faucibus, non sagittis nisi finibus. Sed efficitur massa ac nibh condimentum interdum. Orci varius
                                natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse luctus, ex ut congue interdum, nibh turpis malesuada orci, vel vulputate arcu velit condimentum orci. Ut sed dictum lacus.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Services overview</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae, pretium eu elit. Integer sagittis eu purus eget venenatis. Ut rhoncus tempor velit vitae consequat. Quisque consequat, enim eu cursus eleifend, velit mi viverra arcu, sed elementum
                                dolor odio eget neque.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Eligibility</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum turpis vitae facilisis tempus. Donec in blandit risus, eget pretium mauris. Aliquam nec venenatis massa. Ut vel nulla id velit dictum rutrum nec vel ex. Phasellus
                                sit amet faucibus massa, in feugiat augue. Maecenas eget dapibus turpis, a finibus justo. Suspendisse pretium lorem non lorem faucibus, non sagittis nisi finibus. Sed efficitur massa ac nibh condimentum interdum. Orci varius
                                natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse luctus, ex ut congue interdum, nibh turpis malesuada orci, vel vulputate arcu velit condimentum orci. Ut sed dictum lacus.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>License & Site access</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae, pretium eu elit. Integer sagittis eu purus eget venenatis. Ut rhoncus tempor velit vitae consequat. Quisque consequat, enim eu cursus eleifend, velit mi viverra arcu, sed elementum
                                dolor odio eget neque.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>With whom your information will be shared</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum turpis vitae facilisis tempus. Donec in blandit risus, eget pretium mauris. Aliquam nec venenatis massa. Ut vel nulla id velit dictum rutrum nec vel ex. Phasellus
                                sit amet faucibus massa, in feugiat augue. Maecenas eget dapibus turpis, a finibus justo. Suspendisse pretium lorem non lorem faucibus, non sagittis nisi finibus. Sed efficitur massa ac nibh condimentum interdum. Orci varius
                                natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse luctus, ex ut congue interdum, nibh turpis malesuada orci, vel vulputate arcu velit condimentum orci. Ut sed dictum lacus.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Account & Registration Obligations</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae, pretium eu elit. Integer sagittis eu purus eget venenatis. Ut rhoncus tempor velit vitae consequat. Quisque consequat, enim eu cursus eleifend, velit mi viverra arcu, sed elementum
                                dolor odio eget neque.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Pricing</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum turpis vitae facilisis tempus. Donec in blandit risus, eget pretium mauris. Aliquam nec venenatis massa. Ut vel nulla id velit dictum rutrum nec vel ex. Phasellus
                                sit amet faucibus massa, in feugiat augue. Maecenas eget dapibus turpis, a finibus justo. Suspendisse pretium lorem non lorem faucibus, non sagittis nisi finibus. Sed efficitur massa ac nibh condimentum interdum. Orci varius
                                natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse luctus, ex ut congue interdum, nibh turpis malesuada orci, vel vulputate arcu velit condimentum orci. Ut sed dictum lacus.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Cancellation by Site / Customer</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Return & Refunds</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>You Agree and Confirm</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Contact Information</h4>
                            <ul class="joby-list-dt">
                                <li>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                </li>
                                <li>
                                    <p>Sed ut dui et tellus euismod accumsan.</p>
                                </li>
                                <li>
                                    <p>Aenean sed neque vitae nisi commodo ultricies sed ut sapien.</p>
                                </li>
                                <li>
                                    <p>Sed euismod urna vel lacus porta imperdiet.</p>
                                </li>
                                <li>
                                    <p>Proin id neque condimentum, eleifend ipsum sed, luctus nisi.</p>
                                </li>
                                <li>
                                    <p>Ut eu sem eget dolor bibendum tempor.</p>
                                </li>
                                <li>
                                    <p>Sed scelerisque purus id nunc semper, in elementum quam fringilla.</p>
                                </li>
                                <li>
                                    <p>Donec pulvinar enim vel convallis egestas.</p>
                                </li>
                            </ul>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Modification of Terms & Conditions of Service</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Governing Law and Jurisdiction</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum turpis vitae facilisis tempus. Donec in blandit risus, eget pretium mauris. Aliquam nec venenatis massa. Ut vel nulla id velit dictum rutrum nec vel ex. Phasellus
                                sit amet faucibus massa, in feugiat augue. Maecenas eget dapibus turpis, a finibus justo. Suspendisse pretium lorem non lorem faucibus, non sagittis nisi finibus. Sed efficitur massa ac nibh condimentum interdum. Orci varius
                                natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse luctus, ex ut congue interdum, nibh turpis malesuada orci, vel vulputate arcu velit condimentum orci. Ut sed dictum lacus.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Copyright & Trademark</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Objectionable Material</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum turpis vitae facilisis tempus. Donec in blandit risus, eget pretium mauris. Aliquam nec venenatis massa. Ut vel nulla id velit dictum rutrum nec vel ex. Phasellus
                                sit amet faucibus massa, in feugiat augue. Maecenas eget dapibus turpis, a finibus justo. Suspendisse pretium lorem non lorem faucibus, non sagittis nisi finibus. Sed efficitur massa ac nibh condimentum interdum. Orci varius
                                natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse luctus, ex ut congue interdum, nibh turpis malesuada orci, vel vulputate arcu velit condimentum orci. Ut sed dictum lacus.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Indemnity</h4>
                            <p>Donec maximus lorem vitae risus molestie sollicitudin. Ut sem lorem, consequat et tortor sit amet, viverra porttitor erat. Suspendisse aliquet arcu vel auctor maximus. Nunc in euismod purus. Aliquam non varius quam. Sed eros
                                magna, tempus ullamcorper auctor vitae.</p>
                        </div>
                        <div class="job-des-dt142 policy-des-dt">
                            <h4>Termination</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras rutrum turpis vitae facilisis tempus. Donec in blandit risus, eget pretium mauris. Aliquam nec venenatis massa. Ut vel nulla id velit dictum rutrum nec vel ex. Phasellus
                                sit amet faucibus massa, in feugiat augue. Maecenas eget dapibus turpis, a finibus justo. Suspendisse pretium lorem non lorem faucibus, non sagittis nisi finibus. Sed efficitur massa ac nibh condimentum interdum. Orci varius
                                natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Suspendisse luctus, ex ut congue interdum, nibh turpis malesuada orci, vel vulputate arcu velit condimentum orci. Ut sed dictum lacus.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php 
include("footer.php");
?>