

<div class="wrapper">
   
    <div id="demo" class="carousel slide " data-ride="carousel" >

    <!-- Indicators -->
    <!-- <ul class="carousel-indicators">
        <li data-target="#demo" data-slide-to="0" class="active"></li>
        <li data-target="#demo" data-slide-to="1"></li>
        <li data-target="#demo" data-slide-to="2"></li>
    </ul> -->
    
    <!-- The slideshow -->
    <div class="carousel-inner">
        <div class="carousel-item active">
        <img src="images/slide-1-h3.jpg" alt="Los Angeles" width="100%">
        </div>
        <div class="carousel-item">
            <img src="images/block-img-3-3.jpg" alt="Los Angeles" width="100%">
        </div>
        <div class="carousel-item">
            <img src="images/slide-1-h3.jpg" alt="Los Angeles" width="100%">
        </div>
    </div>
    
    <!-- Left and right controls -->
    <a class="carousel-control-prev" href="#demo" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </a>
    <a class="carousel-control-next" href="#demo" data-slide="next">
        <span class="carousel-control-next-icon"></span>
    </a>
    </div>



        <!-- <div class="main-banner-slider pt-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="owl-carousel offers-banner owl-theme">
                            <div class="item">
                                <div class="offer-item">
                                    <div class="offer-item-img">
                                        <div class="coral-overlay"></div>
                                        <img src="images/banners/offer-1.jpg" alt="">
                                    </div>
                                    <div class="offer-text-dt">
                                        <div class="offer-top-text-banner">
                                            <p>6% Off</p>
                                            <div class="top-text-1">Buy More & Save More</div>
                                            <span>Fresh Vegetables</span>
                                        </div>
                                        <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="offer-item">
                                    <div class="offer-item-img">
                                        <div class="coral-overlay"></div>
                                        <img src="images/banners/offer-2.jpg" alt="">
                                    </div>
                                    <div class="offer-text-dt">
                                        <div class="offer-top-text-banner">
                                            <p>5% Off</p>
                                            <div class="top-text-1">Buy More & Save More</div>
                                            <span>Fresh Fruits</span>
                                        </div>
                                        <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="offer-item">
                                    <div class="offer-item-img">
                                        <div class="coral-overlay"></div>
                                        <img src="images/banners/offer-3.jpg" alt="">
                                    </div>
                                    <div class="offer-text-dt">
                                        <div class="offer-top-text-banner">
                                            <p>3% Off</p>
                                            <div class="top-text-1">Hot Deals on New Items</div>
                                            <span>Daily Essentials Eggs & Dairy</span>
                                        </div>
                                        <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="offer-item">
                                    <div class="offer-item-img">
                                        <div class="coral-overlay"></div>
                                        <img src="images/banners/offer-4.jpg" alt="">
                                    </div>
                                    <div class="offer-text-dt">
                                        <div class="offer-top-text-banner">
                                            <p>2% Off</p>
                                            <div class="top-text-1">Buy More & Save More</div>
                                            <span>Beverages</span>
                                        </div>
                                        <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="offer-item">
                                    <div class="offer-item-img">
                                        <div class="coral-overlay"></div>
                                        <img src="images/banners/offer-5.jpg" alt="">
                                    </div>
                                    <div class="offer-text-dt">
                                        <div class="offer-top-text-banner">
                                            <p>3% Off</p>
                                            <div class="top-text-1">Buy More & Save More</div>
                                            <span>Nuts & Snacks</span>
                                        </div>
                                        <a href="#" class="Offer-shop-btn hover-btn">Shop Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->


        <div class="section145">
            <div class="container">
                <div class="row">
                    <!-- <div class="col-md-12">
                        <div class="main-title-tt">
                            <div class="main-title-left">
                                <span>Shop By</span>
                                <h2>Categories</h2>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-md-12">
                        <div class="owl-carousel cate-slider owl-theme">
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon1.png" alt="">
                                    </div>
                                    <h4>Vegetables & Fruits</h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon2.png" alt="">
                                    </div>
                                    <h4> Grocery & Staples </h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon3.svg" alt="">
                                    </div>
                                    <h4> Dairy & Eggs </h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon4.svg" alt="">
                                    </div>
                                    <h4> Beverages </h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon5.png" alt="">
                                    </div>
                                    <h4> Snacks </h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon-6.svg" alt="">
                                    </div>
                                    <h4> Home Care </h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon7.png" alt="">
                                    </div>
                                    <h4> Noodles & Sauces </h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon8.png" alt="">
                                    </div>
                                    <h4> Personal Care </h4>
                                </a>
                            </div>
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon9.png" alt="">
                                    </div>
                                    <h4> Pet Care </h4>
                                </a>
                            </div>
                            
                            <div class="item">
                                <a href="#" class="category-item">
                                    <div class="cate-img">
                                        <img src="images/category/icon10.png" alt="">
                                    </div>
                                    <h4> Electronics </h4>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="section145">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt">
                            <div class="main-title-left">
                                <span>For You</span>
                                <h2>Top Featured Products</h2>
                            </div>
                            <a href="#" class="see-more-btn">See All</a>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="owl-carousel featured-slider owl-theme">
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-12.jpg" alt="">
                                        <div class="product-absolute-options">
                                            
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$12 <span>$15</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-17.png" alt="">
                                        <div class="product-absolute-options">
                                          
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$10 <span>$13</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-18.png" alt="">
                                        <div class="product-absolute-options">
                                           
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                     
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$5 <span>$8</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-19.png" alt="">
                                        <div class="product-absolute-options">
                                           
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$15 <span>$20</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-22.jpg" alt="">
                                        <div class="product-absolute-options">
                                           
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$9 <span>$10</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-23.jpg" alt="">
                                        <div class="product-absolute-options">
                                            
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                        
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$6.95 <span>$7</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-24.jpg" alt="">
                                        <div class="product-absolute-options">
                                            
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$8 <span>$10</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="section145">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt">
                            <div class="main-title-left">
                                <span>Offers</span>
                                <h2>Best Values</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-6">
                        <a href="#" class="best-offer-item">
                            <img src="images/offers/img12.jpg" alt="" width="100%">
                        </a>
                    </div>
                    <!-- <div class="col-lg-4 col-md-6">
                        <a href="#" class="best-offer-item">
                            <img src="images/best-offers/offer-2.jpg" alt="">
                        </a>
                    </div> -->
                    <div class="col-lg-4 col-md-6">
                        <a href="#" class="best-offer-item offr-none">
                            <img src="images/best-offers/offer-3.jpg" alt="">
                            <div class="cmtk_dt">
                                <div class="product_countdown-timer offer-counter-text" data-countdown="2021/03/06"></div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-12">
                        <a href="#" class="code-offer-item">
                            <img src="images/best-offers/banner1.png" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>


        <div class="section145">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt">
                            <div class="main-title-left">
                                <span>For You</span>
                                <h2>Fresh Vegetables & Fruits</h2>
                            </div>
                            <a href="#" class="see-more-btn">See All</a>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="owl-carousel featured-slider owl-theme">
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-11.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">6% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$12 <span>$15</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-12.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">2% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$10 <span>$13</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-13.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">5% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$5 <span>$8</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-12.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">3% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$15 <span>$20</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-5.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">2% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$9 <span>$10</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-6.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">2% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$7 <span>$8</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-14.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">1% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$6.95 <span>$7</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-3.jpg" alt="">
                                        <div class="product-absolute-options">
                                            <span class="offer-badge-1">3% off</span>
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                         <!-- <p>Available<span>(In Stock)</span></p> -->
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$8 <span>$10</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<section class="section145">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <img src="images/grcerybg.png" alt="" width="100%">        
            </div>
        </div>
    </div>
</section>
        <div class="section145">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main-title-tt">
                            <div class="main-title-left">
                                <span>For You</span>
                                <h2>Added New Products</h2>
                            </div>
                            <a href="#" class="see-more-btn">See All</a>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="owl-carousel featured-slider owl-theme">
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-16.jpg" alt="">
                                        <div class="product-absolute-options">
                                            
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$12 <span>$15</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-17.jpg" alt="">
                                        <div class="product-absolute-options">
                                           
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$10</div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-18.jpg" alt="">
                                        <div class="product-absolute-options">
                                           
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                      
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$5</div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-19.jpg" alt="">
                                        <div class="product-absolute-options">
                                            
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                      
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$15 <span>$16</span></div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-20.jpg" alt="">
                                        <div class="product-absolute-options">
                                           
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                      
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$9</div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="product-item">
                                    <a href="single_product_view.php" class="product-img">
                                        <img src="images/product/img-21.jpg" alt="">
                                        <div class="product-absolute-options">
                                           
                                            <span class="like-icon" title="wishlist"></span>
                                        </div>
                                    </a>
                                    <div class="product-text-dt">
                                       
                                        <h4>Product Title Here</h4>
                                        <div class="product-price">$7</div>
                                        <div class="qty-cart">
                                            <div class="quantity buttons_added">
                                                <input type="button" value="-" class="minus minus-btn">
                                                <input type="number" step="1" name="quantity" value="1" class="input-text qty text">
                                                <input type="button" value="+" class="plus plus-btn">
                                            </div>
                                            <span class="cart-icon"><i class="uil uil-shopping-cart-alt"></i></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

<section class="section145" >
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="background-color: rgb(247, 220, 212, 0.5);padding:10px 10px">
                <img src="images/why-img.jpg" alt="" width="100%">        
            </div>
            
        </div>
    </div>
</section>
<!-- <div class="section146">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12">
              
                        <div class="main-title-tt">
                            <div class="main-title-left">
                                <span>Client</span>
                                <h2>Client Testimonial</h2>
                            </div>
                           
                        </div>
                   
                <div class="col-testimonails mb-4">
                    <div class="slideshow-container">

                        <div class="mySlides">
                            <q>“This website is great. Now I won’t have to fish through the newspaper trying to find your ad. I didn’t realize you had prescriptions there too!”</q>
                            <p class="author mt-3">- John Keats</p>
                        </div>

                        <div class="mySlides">
                            <q>But man is not made for defeat. A man can be destroyed but not defeated.</q>
                            <p class="author mt-3">- Ernest Hemingway</p>
                        </div>

                        <div class="mySlides">
                            <q>I have not failed. I've just found 10,000 ways that won't work.</q>
                            <p class="author mt-3">- Thomas A. Edison</p>
                        </div>

                        <a class="prev" onclick="plusSlides(-1)">❮</a>
                        <a class="next" onclick="plusSlides(1)">❯</a>

                    </div>

                    <div class="dot-container">
                        <span class="dot" onclick="currentSlide(1)"></span> 
                        <span class="dot" onclick="currentSlide(2)"></span> 
                        <span class="dot" onclick="currentSlide(3)"></span> 
                    </div>
                </div>       
            </div>
            <div class="col-lg-6 col-md-12">
               <div class="img-test">
                   <img src="images/side-test.jpg" alt="" width="100%">
               </div>        
            </div>
        </div>
    </div>
</div>

<script>
    var slideIndex = 1;
    showSlides(slideIndex);

    function plusSlides(n) {
    showSlides(slideIndex += n);
    }

    function currentSlide(n) {
    showSlides(slideIndex = n);
    }

    function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    if (n > slides.length) {slideIndex = 1}    
    if (n < 1) {slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";  
    dots[slideIndex-1].className += " active";
    }
</script> -->
<div class="life-coral">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="default-title">
                            <h2>Testimonials</h2>
                            
                            
                        </div>
                        <div class="dd-content">
                            <div class="owl-carousel testimonial-slider owl-theme">
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                            <!-- <div class="team-avatar">
                                                <img src="images/avatar/img-12.jpg" alt="">
                                            </div> -->
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                <!-- <p>Senior UX Designer</p> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                            <!-- <div class="team-avatar">
                                                <img src="images/avatar/img-2.jpg" alt="">
                                            </div> -->
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                <!-- <p>Senior Manager</p> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                            <!-- <div class="team-avatar">
                                                <img src="images/avatar/img-3.jpg" alt="">
                                            </div> -->
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                <!-- <p>Senior Manager</p> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testi-item">
                                        <div class="testi-text">
                                            <div class="qoute-icon"><i class="fas fa-quote-left"></i></div>
                                            <div class="testo-text">Sed ut mattis enim. Nunc id semper eros. Donec luctus venenatis quam at tincidunt. In tristique nibh eget porta cursus. Integer volutpat tincidunt nibh et mattis.</div>
                                        </div>
                                        <div class="team-dt">
                                            <!-- <div class="team-avatar">
                                                <img src="images/avatar/img-4.jpg" alt="">
                                            </div> -->
                                            <div class="team-emp-dt">
                                                <h4>Admin</h4>
                                                <!-- <p>Head Customer Support</p> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
</div>
<section class="section145" >
    <div class="container">
        <div class="row">
            <div class="col-md-12" style="background-color: #ffffff;padding:10px 10px">
                <img src="images/4.jpg" alt="" width="100%">        
            </div>
        </div>
    </div>
</section>

<div class="blog-coral">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-5">
                        <div class="pdpt-bg-left mt-0 d-none d-sm-none d-md-block">
                            <div class="pdpt-title">
                                <h4>Most Viewed Posts</h4>
                            </div>
                            <ul class="top-posts">
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a>
                                        <span class="blog-time">8 May, 2021</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">Vestibulum venenatis sem eu venenatis vulputate.</a>
                                        <span class="blog-time">7 May, 2021</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">In ac diam vitae ex luctus viverra eu eu quam.</a>
                                        <span class="blog-time">4 May, 2021</span>
                                    </div>
                                </li>
                                
                            </ul>
                        </div>
                        <div class="pdpt-bg-left mb-30 d-none d-sm-none d-md-none d-lg-block">
                            <img src="images/offers/blog-side.jpg" alt="" width="100%">
                            
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-7">
                        <div class="blog-item">
                            <a href="blog_detail_view.php" class="blog-img">
                                <img src="images/blog/blog1.png" alt="">
                                <div class="blog-cate-badge">Food & Life Style</div>
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">15 May, 2021</div>
                                <ul class="like-share-icons">
                                    
                                    <li>
                                        <a href="#" class="like-share"><i class="uil uil-user"></i> : Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-detail">
                                <h4>Blog Title Here</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. </p>
                                <a href="blog_detail_view.php">Read More</a>
                            </div>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
</div>

<section class="section148" >
    <div class="container">
        <div class="row" style="background-color: #ffffff;padding:10px">
            <div class="col-md-12">
                <div class="main-title-tt pt-3">
                            <div class="main-title-left">
                                <span>Best Offers</span>
                                <h2>Best Offers On Product</h2>
                            </div>
                           
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6 mb-3">
                <a href=""><img src="images/offers/1.png" alt="" width="100%"></a>
            </div>
            <div class="col-md-3 col-sm-6 col-6 mb-3">
               <a href=""> <img src="images/offers/2.png" alt="" width="100%"></a>
            </div>
            <div class="col-md-3 col-sm-6 col-6 mb-3">
                <a href=""><img src="images/offers/3.png" alt="" width="100%"></a>
            </div>
            <div class="col-md-3 col-sm-6 col-6 mb-3">
                <a href=""><img src="images/offers/4.png" alt="" width="100%"></a>
            </div>
        </div>
    </div>
</section>

<div class="section147 pt-4">
    <div class="container">
        <div class="row  coralg-row" style="background-color: #fff;">
            <div class="col-md-3 col-sm-6 col-6">
               <div class="why-sec">
                    <div class=" coralg-icon-box-content">
                        <img src="images/footer-icons/truck.png" alt="">
                        <h2 class=" coralg-icon-box-title"> 
                            <span>Free Shipping</span>
                        </h2>
                        <p class=" coralg-icon-box-description">Capped at $39 per order</p>
                    </div>
               </div> 
                
            </div>
            <div class="col-md-3 col-sm-6 col-6">
               <div class="why-sec">
                    <div class=" coralg-icon-box-content">
                         <img src="images/footer-icons/credit-card.png" alt="">
                        <h2 class=" coralg-icon-box-title"> 
                            <span>Securety Payments</span>
                        </h2>
                        <p class=" coralg-icon-box-description">Capped at $39 per order</p>
                    </div>
               </div> 
                
            </div>
            <div class="col-md-3 col-sm-6 col-6">
               <div class="why-sec">
                    <div class=" coralg-icon-box-content">
                         <img src="images/footer-icons/exchange.png" alt="">
                        <h2 class=" coralg-icon-box-title"> 
                            <span>14-Day Returns</span>
                        </h2>
                        <p class=" coralg-icon-box-description">Capped at $39 per order</p>
                    </div>
               </div> 
                
            </div>
            <div class="col-md-3 col-sm-6 col-6">
               <div class="why-sec">
                    <div class=" coralg-icon-box-content">
                         <img src="images/footer-icons/customer-service.png" alt="">
                        <h2 class=" coralg-icon-box-title"> 
                            <span>24X7 Support</span>
                        </h2>
                        <p class=" coralg-icon-box-description">Capped at $39 per order</p>
                    </div>
               </div> 
                
            </div>
        </div>
    </div>
</div>


</div> 