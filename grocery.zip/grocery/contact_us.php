<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
        <div class="coral-Breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="all-product-grid">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="adrrs-sec">
                            <div class="adrrs-title">
                                <a href="#">
                                    <i class="uil uil-location-point chck_icon"></i>Office Address
                                </a>
                            </div>
                            <div class="adrrs-body">
                                       Jaipur Head Office:<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Jaipur, Rajasthan<br> Jaipur-302020<br>
                                        
                            </div>
                        </div>
                        <div class="adrrs-sec">
                            <div class="adrrs-title">
                                <a href="#">
                                    <i class="uil uil-location-point chck_icon"></i>Call US
                                </a>
                            </div>
                            <div class="adrrs-body">
                            <div class="color-pink">Tel: 0000-000-000</div>
                                        
                            </div>
                        </div>
                        <div class="adrrs-sec">
                            <div class="adrrs-title">
                                <a href="#">
                                    <i class="uil uil-location-point chck_icon"></i>Office Address
                                </a>
                            </div>
                            <div class="adrrs-body">
                            <div class="color-pink">E-mail: coralgrocery@gmail.com</div>
                                        
                            </div>
                        </div>
                        <div class="map mt-4">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227748.38256739752!2d75.6504717531237!3d26.88544791551138!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c4adf4c57e281%3A0xce1c63a0cf22e09!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1614594550963!5m2!1sen!2sin" width="100%" height="210" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                        
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="contact-title">
                            <h2>Submit Request</h2>
                            <p>If you have a question about our service or have an issue to report, please send a request and we will get back to you as soon as possible.</p>
                        </div>
                        <div class="contact-form">
                            <form>
                                <div class="form-group mt-1">
                                    <label class="control-label">Full Name*</label>
                                    <div class="ui search focus">
                                        <div class="ui left icon input swdh11 swdh19">
                                            <input class="prompt srch_explore" type="text" name="sendername" id="sendername" required="" placeholder="Your Full">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-1">
                                    <label class="control-label">Email Address*</label>
                                    <div class="ui search focus">
                                        <div class="ui left icon input swdh11 swdh19">
                                            <input class="prompt srch_explore" type="email" name="emailaddress" id="emailaddress" required="" placeholder="Your Email Address">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-1">
                                    <label class="control-label">Subject*</label>
                                    <div class="ui search focus">
                                        <div class="ui left icon input swdh11 swdh19">
                                            <input class="prompt srch_explore" type="text" name="sendersubject" id="sendersubject" required="" placeholder="Subject">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-1">
                                    <div class="field">
                                        <label class="control-label">Message*</label>
                                        <textarea rows="2" class="form-control" id="sendermessage" name="sendermessage" required="" placeholder="Write Message"></textarea>
                                    </div>
                                </div>
                                <button class="next-btn16 hover-btn mt-3" type="submit" data-btntext-sending="Sending...">Submit Request</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php include("footer.php");?>