<?php 
include("header.php");
include("menu.php");
?>

<div class="wrapper">
        <div class="coral-Breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="all-product-grid">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="adrrs-sec">
                            <div class="adrrs-title">
                                <a href="#">
                                    <i class="uil uil-location-point chck_icon"></i>Office Address
                                </a>
                            </div>
                            <div class="adrrs-body">
                                       Jaipur Head Office:<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Ludhiana, Punjab<br> Ludhiana- 141001<br>
                                        
                            </div>
                        </div>
                        <div class="adrrs-sec">
                            <div class="adrrs-title">
                                <a href="#">
                                    <i class="uil uil-location-point chck_icon"></i>Call US
                                </a>
                            </div>
                            <div class="adrrs-body">
                            <div class="color-pink">Tel: 0000-000-000</div>
                                        
                            </div>
                        </div>
                        <div class="adrrs-sec">
                            <div class="adrrs-title">
                                <a href="#">
                                    <i class="uil uil-location-point chck_icon"></i>Office Address
                                </a>
                            </div>
                            <div class="adrrs-body">
                            <div class="color-pink">E-mail: coralgrocery@gmail.com</div>
                                        
                            </div>
                        </div>
                        <div class="map mt-4">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227748.38256739752!2d75.6504717531237!3d26.88544791551138!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c4adf4c57e281%3A0xce1c63a0cf22e09!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1614594550963!5m2!1sen!2sin" width="100%" height="210" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                        <!-- <div class="panel-group accordion" id="accordion0">
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingOne">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseOne" href="#" aria-expanded="false" aria-controls="collapseOne">
                                            <i class="uil uil-location-point chck_icon"></i>Jaipur Head Office
                                        </a>
                                    </div>
                                </div>
                                <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" data-parent="#accordion0" style="">
                                    <div class="panel-body">
                                        Ludhiana Head Office:<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Ludhiana, Punjab<br> Ludhiana- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingTwo">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseTwo" href="#" aria-expanded="false" aria-controls="collapseTwo">
                                            <i class="uil uil-location-point chck_icon"></i>Delhi Brunch Office
                                        </a>
                                    </div>
                                </div>
                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo" data-parent="#accordion0">
                                    <div class="panel-body">
                                        Gurugram Branch :<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Gurugram, Haryana<br> Gurugram- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingThree">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseThree" href="#" aria-expanded="false" aria-controls="collapseThree">
                                            <i class="uil uil-location-point chck_icon"></i>New Delhi
                                        </a>
                                    </div>
                                </div>
                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" data-parent="#accordion0">
                                    <div class="panel-body">
                                        New Delhi Branch :<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, New Delhi<br> New Delhi- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingfour">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapsefour" href="#" aria-expanded="false" aria-controls="collapsefour">
                                            <i class="uil uil-location-point chck_icon"></i>Bangaluru
                                        </a>
                                    </div>
                                </div>
                                <div id="collapsefour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingfour" data-parent="#accordion0">
                                    <div class="panel-body">
                                        Bangaluru Branch :<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Bangaluru<br> Bangaluru- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingfive">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapsefive" href="#" aria-expanded="false" aria-controls="collapsefive">
                                            <i class="uil uil-location-point chck_icon"></i>Mumbai
                                        </a>
                                    </div>
                                </div>
                                <div id="collapsefive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingfive" data-parent="#accordion0">
                                    <div class="panel-body">
                                        Mumbai Branch :<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Mumbai<br> Mumbai- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingsix">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapsesix" href="#" aria-expanded="false" aria-controls="collapsesix">
                                            <i class="uil uil-location-point chck_icon"></i>Hyderabad
                                        </a>
                                    </div>
                                </div>
                                <div id="collapsesix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingsix" data-parent="#accordion0">
                                    <div class="panel-body">
                                        Hyderabad Branch :<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Hyderabad<br> Hyderabad- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingseven">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseseven" href="#" aria-expanded="false" aria-controls="collapseseven">
                                            <i class="uil uil-location-point chck_icon"></i>Kolkata
                                        </a>
                                    </div>
                                </div>
                                <div id="collapseseven" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingseven" data-parent="#accordion0">
                                    <div class="panel-body">
                                        Kolkata Branch :<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Kolkata<br> Kolkata- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" id="headingeight">
                                    <div class="panel-title">
                                        <a class="collapsed" data-toggle="collapse" data-target="#collapseeight" href="#" aria-expanded="false" aria-controls="collapseeight">
                                            <i class="uil uil-location-point chck_icon"></i>Chandigrah
                                        </a>
                                    </div>
                                </div>
                                <div id="collapseeight" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingeight" data-parent="#accordion0">
                                    <div class="panel-body">
                                        Chandigrah Branch :<br> #0000, St No. 0, Lorem ipsum dolor sit amet, Main road, Chandigrah<br> Chandigrah- 141001<br>
                                        <div class="color-pink">Tel: 0000-000-000</div>
                                    </div>
                                </div>
                            </div>
                        </div> -->

                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="contact-title">
                            <h2>Submit Request</h2>
                            <p>If you have a question about our service or have an issue to report, please send a request and we will get back to you as soon as possible.</p>
                        </div>
                        <div class="contact-form">
                            <form>
                                <div class="form-group mt-1">
                                    <label class="control-label">Full Name*</label>
                                    <div class="ui search focus">
                                        <div class="ui left icon input swdh11 swdh19">
                                            <input class="prompt srch_explore" type="text" name="sendername" id="sendername" required="" placeholder="Your Full">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-1">
                                    <label class="control-label">Email Address*</label>
                                    <div class="ui search focus">
                                        <div class="ui left icon input swdh11 swdh19">
                                            <input class="prompt srch_explore" type="email" name="emailaddress" id="emailaddress" required="" placeholder="Your Email Address">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-1">
                                    <label class="control-label">Subject*</label>
                                    <div class="ui search focus">
                                        <div class="ui left icon input swdh11 swdh19">
                                            <input class="prompt srch_explore" type="text" name="sendersubject" id="sendersubject" required="" placeholder="Subject">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mt-1">
                                    <div class="field">
                                        <label class="control-label">Message*</label>
                                        <textarea rows="2" class="form-control" id="sendermessage" name="sendermessage" required="" placeholder="Write Message"></textarea>
                                    </div>
                                </div>
                                <button class="next-btn16 hover-btn mt-3" type="submit" data-btntext-sending="Sending...">Submit Request</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php include("footer.php");?>