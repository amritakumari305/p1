<?php 
include("header.php");
include("menu.php");
?>


<div class="wrapper">
        <div class="coral-Breadcrumb">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Blog</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <div class="blog-coral">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-5">
                        <div class="pdpt-bg-left mt-0">
                            <div class="pdpt-title">
                                <h4>Most Viewed Posts</h4>
                            </div>
                            <ul class="top-posts">
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a>
                                        <span class="blog-time">2 March, 2021</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">Vestibulum venenatis sem eu venenatis vulputate.</a>
                                        <span class="blog-time">2 March, 2021</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">In ac diam vitae ex luctus viverra eu eu quam.</a>
                                        <span class="blog-time">2 March, 2021</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">Nullam commodo felis sed lacus lobortis ullamcorper.</a>
                                        <span class="blog-time">2 March, 2021</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="blog-top-item">
                                        <a href="blog_detail_view.php" class="top-post-link">Aenean vel ligula pulvinar, ornare urna sed, luctus lacus.</a>
                                        <span class="blog-time">2 March, 2021</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="pdpt-bg-left mb-30">
                            <div class="pdpt-title">
                                <h4>Contact With Us</h4>
                            </div>
                            <div class="cntct-social">
                                <ul class="team-social">
                                    <li><a href="#" class="scl-btn hover-btn"><i class="fab fa-facebook-f"></i></a></li>
                                    <li><a href="#" class="scl-btn hover-btn"><i class="fab fa-twitter"></i></a></li>
                                    <li><a href="#" class="scl-btn hover-btn"><i class="fab fa-instagram"></i></a></li>
                                    <li><a href="#" class="scl-btn hover-btn"><i class="fab fa-linkedin-in"></i></a></li>
                                    <li><a href="#" class="scl-btn hover-btn"><i class="fab fa-youtube"></i></a></li>
                                    <li><a href="#" class="scl-btn hover-btn"><i class="fab fa-pinterest-p"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-7">
                        <div class="blog-item">
                            <a href="blog_detail_view.php" class="blog-img">
                                <img src="images/blog/img-1.jpg" alt="">
                                <div class="blog-cate-badge">Food & Life Style</div>
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">2 March, 2021</div>
                                <ul class="like-share-icons">
                                <li>
                                        <a href="#" class="like-share"><i class="uil uil-user"></i> : Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-detail">
                                <h4>Blog Title Here</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas felis arcu, pulvinar id cursus eget, ultrices ac metus. Mauris condimentum tortor sapien, laoreet ornare nibh iaculis
                                    eu. Donec posuere ipsum at malesuada egestas. Pellentesque accumsan lacus urna, sed suscipit ipsum bibendum sit amet.</p>
                                <a href="blog_detail_view.php">Read More</a>
                            </div>
                        </div>
                        <div class="blog-item">
                            <a href="blog_detail_view.php" class="blog-img">
                                <img src="images/blog/img-2.jpg" alt="">
                                <div class="blog-cate-badge">Food & Life Style</div>
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">2 March, 2021</div>
                                <ul class="like-share-icons">
                                <li>
                                        <a href="#" class="like-share"><i class="uil uil-user"></i> : Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-detail">
                                <h4>Blog Title Here</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas felis arcu, pulvinar id cursus eget, ultrices ac metus. Mauris condimentum tortor sapien, laoreet ornare nibh iaculis
                                    eu. Donec posuere ipsum at malesuada egestas. Pellentesque accumsan lacus urna, sed suscipit ipsum bibendum sit amet.</p>
                                <a href="blog_detail_view.php">Read More</a>
                            </div>
                        </div>
                       
                        
                    </div>
                    <div class="col-lg-4 col-md-7">
                        <div class="blog-item">
                            <a href="blog_detail_view.php" class="blog-img">
                                <img src="images/blog/img-1.jpg" alt="">
                                <div class="blog-cate-badge">Food & Life Style</div>
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">2 March, 2021</div>
                                <ul class="like-share-icons">
                                <li>
                                        <a href="#" class="like-share"><i class="uil uil-user"></i> : Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-detail">
                                <h4>Blog Title Here</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas felis arcu, pulvinar id cursus eget, ultrices ac metus. Mauris condimentum tortor sapien, laoreet ornare nibh iaculis
                                    eu. Donec posuere ipsum at malesuada egestas. Pellentesque accumsan lacus urna, sed suscipit ipsum bibendum sit amet.</p>
                                <a href="blog_detail_view.php">Read More</a>
                            </div>
                        </div>
                        <div class="blog-item">
                            <a href="blog_detail_view.php" class="blog-img">
                                <img src="images/blog/img-2.jpg" alt="">
                                <div class="blog-cate-badge">Food & Life Style</div>
                            </a>
                            <div class="date-icons-group">
                                <div class="blog-time sz-14">2 March, 2021</div>
                                <ul class="like-share-icons">
                                <li>
                                        <a href="#" class="like-share"><i class="uil uil-user"></i> : Admin</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="blog-detail">
                                <h4>Blog Title Here</h4>
                                <p>Maecenas viverra odio sed mauris mattis blandit. Nullam et dolor vitae erat scelerisque vulputate. Maecenas felis arcu, pulvinar id cursus eget, ultrices ac metus. Mauris condimentum tortor sapien, laoreet ornare nibh iaculis
                                    eu. Donec posuere ipsum at malesuada egestas. Pellentesque accumsan lacus urna, sed suscipit ipsum bibendum sit amet.</p>
                                <a href="blog_detail_view.php">Read More</a>
                            </div>
                        </div>
                       
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>


<?php 
include("footer.php");
?>