<?php
session_start();
include("common/config.php");
include("common/crud.php");
$crud=new CRUD();
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: index.php");
  exit;
}
 

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    
    
        // Prepare a select statement
		$cond="email_id='".$_POST['email_id']."' and password='".$_POST['password']."'";
		$user_data = $crud->FindAll('user', array(), array($cond));
		if(is_array($user_data) && count($user_data)>0){
			foreach($user_data as $vd){
				session_start();
				$_SESSION["loggedin"] = true;
				$_SESSION["id"] = $vd['user_id'];
				$_SESSION["username"] = $vd['email_id'];                            
				  header("location: index.php");
			} 
        }
		
		else{
                echo "Oops! Something went wrong. Please try again later.";
        }

            // Close statement
    }
  
?>

<?php 
include("header.php");
include("menu.php")
?>

  <div class="sign-inup">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="sign-form">
                        <div class="sign-inner">
                            
                            <div class="form-dt">
                                <div class="form-inpts checout-address-step">
                                    <form method="POST" action="" id="loginForm">
                                        <div class="form-title">
                                            <h6>Sign In</h6>
                                        </div>
                                        <div class="form-group pos_rel">
                                            <input id="email_id" name="email_id" type="text" placeholder="Email Address" class="form-control lgn_input" required="">
                                            <i class="uil uil-envelope lgn_icon"></i>
                                        </div>
                                        <div class="form-group pos_rel">
                                            <input id="password" name="password" type="password" placeholder="Enter Password" class="form-control lgn_input" required="">
                                            <i class="uil uil-padlock lgn_icon"></i>
                                        </div>
                                        <button class="login-btn hover-btn" type="submit" name="submit" value="Submit">Sign In Now</button>
                                    </form>
                                </div>
                                <div class="password-forgor">
                                    <a href="forgot_password.php">Forgot Password?</a>
                                </div>
                                <div class="signup-link">
                                    <p>Don't have an account? - <a href="sign_up.php">Sign Up Now</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </div>
<?php include("footer.php");?>
