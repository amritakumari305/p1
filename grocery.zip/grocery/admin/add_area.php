<?php 
include("header.php");
include("menu.php");
include("sidenav.php");
?>
<div id="layoutSidenav_content">
<main>
                <div class="container-fluid">
                    <h2 class="mt-30 page-title">Areas</h2>
                    <ol class="breadcrumb mb-30">
                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="areas.php">Areas</a></li>
                        <li class="breadcrumb-item active">Add Area</li>
                    </ol>
                    <div class="row">
                        <div class="col-lg-5 col-md-6">
                            <div class="card card-static-2 mb-30">
                                <div class="card-title-2">
                                    <h4>Add New Area</h4>
                                </div>
                                <div class="card-body-table">
                                    <div class="news-content-right pd-20">
                                        <div class="form-group">
                                            <label class="form-label">Name*</label>
                                            <input type="text" type="text" class="form-control" placeholder="Area Name">
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Location*</label>
                                            <select id="location" name="location" class="form-control">
                                                <option selected>--Select Location--</option>
                                                <option value="1">Jaipur</option>
                                                <option value="2">Chandigarh</option>
                                                <option value="3">New Delhi</option>
                                                <option value="4">Bangaluru</option>
                                                <option value="5">Mumbai</option>
                                                <option value="6">Hyderabad</option>
                                                <option value="7">Kolkata</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="form-label">Status*</label>
                                            <select id="status" name="status" class="form-control">
                                                <option selected>Active</option>
                                                <option value="1">Inactive</option>
                                            </select>
                                        </div>
                                        <button class="save-btn hover-btn" type="submit">Add New</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
<?php 
include("footer.php");
?> 