<?php 
include("header.php");
include("menu.php");
include("sidenav.php");
?>
<div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h2 class="mt-30 page-title">Posts</h2>
                    <ol class="breadcrumb mb-30">
                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Posts</li>
                    </ol>
                    <div class="row justify-content-between">
                        <div class="col-lg-12">
                            <a href="add_post.php" class="add-btn hover-btn">Add New Post</a>
                        </div>
                        <div class="col-lg-3 col-md-4">
                            <div class="bulk-section mt-30">
                                <div class="input-group">
                                    <select id="action" name="action" class="form-control">
<option selected>Bulk Actions</option>
<option value="1">Publish</option>
<option value="2">Move to Draft</option>
<option value="3">Delete</option>
</select>
                                    <div class="input-group-append">
                                        <button class="status-btn hover-btn" type="submit">Apply</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 col-md-6">
                            <div class="bulk-section mt-30">
                                <div class="search-by-name-input">
                                    <input class="form-control" placeholder="Search by name">
                                </div>
                                <div class="input-group">
                                    <select id="categeory" name="categeory" class="form-control">
<option selected>--All Category--</option>
<option value="1">Category 01</option>
<option value="2">Category 02</option>
<option value="3">Category 03</option>
<option value="3">Category 04</option>
<option value="3">Category 05</option>
</select>
                                    <div class="input-group-append">
                                        <button class="status-btn hover-btn" type="submit">Search News</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12">
                            <div class="card card-static-2 mt-30 mb-30">
                                <div class="card-title-2">
                                    <h4>All Posts</h4>
                                </div>
                                <div class="card-body-table">
                                    <div class="table-responsive">
                                        <table class="table ucp-table table-hover">
                                            <thead>
                                                <tr>
                                                    <th style="width:60px"><input type="checkbox" class="check-all"></th>
                                                    <th>Name</th>
                                                    <th style="width:150px">Category</th>
                                                    <th style="width:150px">Author</th>
                                                    <th style="width:130px">Date</th>
                                                    <th style="width:130px">Status</th>
                                                    <th style="width:100px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><input type="checkbox" class="check-item" name="ids" value="4"></td>
                                                    <td>
                                                        <a href="#" target="_blank">Post Title Here</a>
                                                    </td>
                                                    <td>Food &amp; Lifestyle</td>
                                                    <td>System Admin</td>
                                                    <td>
                                                        <span class="delivery-time">6/03/2021</span>
                                                    </td>
                                                    <td><span class="badge-item badge-status">Publish</span></td>
                                                    <td class="action-btns">
                                                        <a href="#" class="edit-btn"><i class="fas fa-edit"></i> Edit</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><input type="checkbox" class="check-item" name="ids" value="3"></td>
                                                    <td>
                                                        <a href="#" target="_blank">Post Title Here</a>
                                                    </td>
                                                    <td>Uncategory</td>
                                                    <td>System Admin</td>
                                                    <td>
                                                        <span class="delivery-time">6/03/2021</span>
                                                    </td>
                                                    <td><span class="badge-item badge-status">Publish</span></td>
                                                    <td class="action-btns">
                                                        <a href="#" class="edit-btn"><i class="fas fa-edit"></i> Edit</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><input type="checkbox" class="check-item" name="ids" value="2"></td>
                                                    <td>
                                                        <a href="#" target="_blank">Post Title Here</a>
                                                    </td>
                                                    <td>Food News</td>
                                                    <td>System Admin</td>
                                                    <td>
                                                        <span class="delivery-time">6/03/2021</span>
                                                    </td>
                                                    <td><span class="badge-item badge-status">Draft</span></td>
                                                    <td class="action-btns">
                                                        <a href="#" class="edit-btn"><i class="fas fa-edit"></i> Edit</a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><input type="checkbox" class="check-item" name="ids" value="1"></td>
                                                    <td>
                                                        <a href="#" target="_blank">Post Title Here</a>
                                                    </td>
                                                    <td>Recipes</td>
                                                    <td>System Admin</td>
                                                    <td>
                                                        <span class="delivery-time">6/03/2021</span>
                                                    </td>
                                                    <td><span class="badge-item badge-status">Publish</span></td>
                                                    <td class="action-btns">
                                                        <a href="#" class="edit-btn"><i class="fas fa-edit"></i> Edit</a>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
<?php 
include("footer.php");
?> 