<?php 
include("header.php");
include("menu.php");
include("sidenav.php");
?>

<div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h2 class="mt-30 page-title">General Setting</h2>
                    <ol class="breadcrumb mb-30">
                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">General Setting</li>
                    </ol>
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="left-side-tabs">
                                <div class="dashboard-left-links">
                                    <a href="general_setting.php" class="user-item"><i class="fas fa-cogs"></i>Site Setting</a>
                                    <a href="general_setting_logo.php" class="user-item"><i class="far fa-image"></i>Logo</a>
                                    <a href="general_setting_favicon.php" class="user-item active"><i class="far fa-image"></i>Favicon</a>
                                   
                                    <a href="general_setting_contact.php" class="user-item"><i class="fas fa-briefcase"></i>Contact Setting</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-6">
                            <div class="card card-static-2 mb-30">
                                <div class="card-title-2">
                                    <h4>Favicon Setting</h4>
                                </div>
                                <div class="card-body-table">
                                    <div class="news-content-right pd-20">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="site-logo-1">
                                                    <img src="images/fav.png" alt="">
                                                    <a href="#" class="img-delete"><i class="fas fa-trash-alt"></i></a>
                                                </div>
                                                <div class="img-add">
                                                    <input type="file" id="file">
                                                    <label for="file">Upload Image</label>
                                                </div>
                                                <button class="save-btn hover-btn" type="submit">Save Changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
<?php 
include("footer.php");
?> 