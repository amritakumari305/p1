<footer class="py-4 bg-footer mt-auto">
                <div class="container-fluid">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted-1">&copy; 2020 <b>Coral Supermarket</b>. by <a href="#">Coral Grocery</a></div>
                        <div class="footer-links">
                            <a href="http://localhost/grocery/privacy_policy.php">Privacy Policy</a>
                            <a href="http://localhost/grocery/term_and_conditions.php">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="js/jquery-3.4.1.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/chart/highcharts.js"></script>
    <script src="vendor/chart/exporting.js"></script>
    <script src="vendor/chart/export-data.js"></script>
    <script src="vendor/chart/accessibility.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/chart.js"></script>
</body>

</html>