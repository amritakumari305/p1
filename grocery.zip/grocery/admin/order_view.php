<?php 
include("header.php");
include("menu.php");
include("sidenav.php");
?>
<div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h2 class="mt-30 page-title">Orders</h2>
                    <ol class="breadcrumb mb-30">
                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="orders.php">Orders</a></li>
                        <li class="breadcrumb-item active">Order View</li>
                    </ol>
                    <div class="row">
                        <div class="col-xl-12 col-md-12">
                            <div class="card card-static-2 mb-30">
                                <div class="card-title-2">
                                    <h2 class="title1458">Invoice</h2>
                                    <span class="order-id">Order #ORDR123456</span>
                                </div>
                                <div class="invoice-content">
                                    <div class="row">
                                        <div class="col-lg-6 col-sm-6">
                                            <div class="ordr-date">
                                                <b>Order Date :</b> 06 March 2021
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-sm-6">
                                            <div class="ordr-date right-text">
                                                <b>Order Date :</b><br> 28A<br> Santosh Nagar,<br> Brijlalpura,<br> Jaipur,<br> Rajasthan,
                                                <br> 302019
                                                <br>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="card card-static-2 mb-30 mt-30">
                                                <div class="card-title-2">
                                                    <h4>Recent Orders</h4>
                                                </div>
                                                <div class="card-body-table">
                                                    <div class="table-responsive">
                                                        <table class="table ucp-table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th style="width:130px">#</th>
                                                                    <th>Item</th>
                                                                    <th style="width:150px" class="text-center">Price</th>
                                                                    <th style="width:150px" class="text-center">Qty</th>
                                                                    <th style="width:100px" class="text-center">Total</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>1</td>
                                                                    <td>
                                                                        <a href="#" target="_blank">Product Title Here</a>
                                                                    </td>
                                                                    <td class="text-center">$15</td>
                                                                    <td class="text-center">1</td>
                                                                    <td class="text-center">$15</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>2</td>
                                                                    <td>
                                                                        <a href="#" target="_blank">Product Title Here</a>
                                                                    </td>
                                                                    <td class="text-center">$12</td>
                                                                    <td class="text-center">1</td>
                                                                    <td class="text-center">$12</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-7"></div>
                                        <div class="col-lg-5">
                                            <div class="order-total-dt">
                                                <div class="order-total-left-text">
                                                    Sub Total
                                                </div>
                                                <div class="order-total-right-text">
                                                    $27
                                                </div>
                                            </div>
                                            <div class="order-total-dt">
                                                <div class="order-total-left-text">
                                                    Delivery Fees
                                                </div>
                                                <div class="order-total-right-text">
                                                    $0
                                                </div>
                                            </div>
                                            <div class="order-total-dt">
                                                <div class="order-total-left-text fsz-18">
                                                    Total Amount
                                                </div>
                                                <div class="order-total-right-text fsz-18">
                                                    $27
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-7"></div>
                                        <div class="col-lg-5">
                                            <div class="select-status">
                                                <label for="status">Status*</label>
                                                <div class="status-active">
                                                    Pending
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
<?php 
include("footer.php");
?>            