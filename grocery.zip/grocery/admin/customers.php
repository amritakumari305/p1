<?php 
include("header.php");
include("menu.php");
include("sidenav.php");
?>
<div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h2 class="mt-30 page-title">Customers</h2>
                    <ol class="breadcrumb mb-30">
                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Customers</li>
                    </ol>
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="card card-static-2 mb-30">
                                <div class="card-title-2">
                                    <h4>All Customers</h4>
                                </div>
                                <div class="card-body-table">
                                    <div class="table-responsive">
                                        <table class="table ucp-table table-hover">
                                            <thead>
                                                <tr>
                                                    <th style="width:60px"><input type="checkbox" class="check-all"></th>
                                                    <th style="width:60px">ID</th>
                                                    <th style="width:100px">Image</th>
                                                    <th>Name</th>
                                                    <th>Email</th>
                                                    <th>Phone</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><input type="checkbox" class="check-item" name="ids[]" value="10"></td>
                                                    <td>1</td>
                                                    <td>
                                                        <div class="cate-img-6">
                                                            <img src="images/avatar/img-1.jpg" alt="">
                                                        </div>
                                                    </td>
                                                    <td>Sam</td>
                                                    <td><a href="#">coralitsolution@gmail.com</a></td>
                                                    <td>+911234567890</td>
                                                    <td class="action-btns">
                                                        <a href="customer_view.php" class="view-shop-btn" title="View"><i class="fas fa-eye"></i></a>
                                                        <a href="customer_edit.php" class="edit-btn" title="Edit"><i class="fas fa-edit"></i></a>
                                                        <a href="#" class="delete-btn" title="Edit"><i class="fas fa-trash-alt"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td><input type="checkbox" class="check-item" name="ids[]" value="5"></td>
                                                    <td>2</td>
                                                    <td>
                                                        <div class="cate-img-6">
                                                            <img src="images/avatar/img-2.jpg" alt="">
                                                        </div>
                                                    </td>
                                                    <td>Sam</td>
                                                    <td><a href="#">coralitsolution@gmail.com</a></td>
                                                    <td>+911234567890</td>
                                                    <td class="action-btns">
                                                        <a href="customer_view.php" class="view-shop-btn" title="View"><i class="fas fa-eye"></i></a>
                                                        <a href="customer_edit.php" class="edit-btn" title="Edit"><i class="fas fa-edit"></i></a>
                                                        <a href="#" class="delete-btn" title="Edit"><i class="fas fa-trash-alt"></i></a>
                                                    </td>
                                                </tr>
                                                
                                               
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
<?php 
include("footer.php");
?> 