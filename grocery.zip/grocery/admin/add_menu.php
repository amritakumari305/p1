<?php 
include("header.php");
include("menu.php");
include("sidenav.php");
?>
<div id="layoutSidenav_content">
            <main>
                <div class="container-fluid">
                    <h2 class="mt-30 page-title">Menu</h2>
                    <ol class="breadcrumb mb-30">
                        <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="menu.php">Menu</a></li>
                        <li class="breadcrumb-item active">Add Menu</li>
                    </ol>
                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="card card-static-2 mb-30">
                                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingOne">
                                            <div class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                        Page
                                                        </a>
                                            </div>
                                        </div>
                                        <div id="collapseOne" class="panel-collapse collapse show" role="tabpanel" aria-labelledby="headingOne">
                                            <div class="panel-body">
                                                <div class="menu-search">
                                                    <input type="text" class="form-control" placeholder="Search...">
                                                </div>
                                                <ul class="add-menu-list">
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                        <input type="checkbox" value="1">
                                                        Home Page
                                                        </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                            <input type="checkbox" value="2">
                                                            About Page
                                                            </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                            <input type="checkbox" value="3">
                                                            Offers Page
                                                            </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <button class="save-btn hover-btn" type="submit">Add to Menu</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingTwo">
                                            <div class="panel-title">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                New Products
                                                </a>
                                            </div>
                                        </div>
                                        <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                            <div class="panel-body">
                                                <div class="menu-search">
                                                    <input type="text" class="form-control" placeholder="Search...">
                                                </div>
                                                <ul class="add-menu-list">
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                            <input type="checkbox" value="1">
                                                            Menu 1
                                                            </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                            <input type="checkbox" value="2">
                                                            Menu 2
                                                            </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                            <input type="checkbox" value="3">
                                                            Menu 3
                                                            </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <button class="save-btn hover-btn" type="submit">Add to Menu</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingThree">
                                            <div class="panel-title">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                            Featured Products
                                                            </a>
                                            </div>
                                        </div>
                                        <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree" style="">
                                            <div class="panel-body">
                                                <div class="menu-search">
                                                    <input type="text" class="form-control" placeholder="Search...">
                                                </div>
                                                <ul class="add-menu-list">
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                <input type="checkbox" value="1">
                                                                Menu 1
                                                                </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                <input type="checkbox" value="2">
                                                                Menu 2
                                                                </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                <input type="checkbox" value="3">
                                                                Menu 3
                                                                </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <button class="save-btn hover-btn" type="submit">Add to Menu</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingfour">
                                            <div class="panel-title">
                                                <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
                                                    <i class="uil uil-check chck_icon"></i>Pages
                                                </a>
                                            </div>
                                        </div>
                                        <div id="collapsefour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingfour" style="">
                                            <div class="panel-body">
                                                <div class="menu-search">
                                                    <input type="text" class="form-control" placeholder="Search...">
                                                </div>
                                                <ul class="add-menu-list">
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                    <input type="checkbox" value="1">
                                                                    Menu 1
                                                                    </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                    <input type="checkbox" value="2">
                                                                    Menu 2
                                                                    </label>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="form-group">
                                                            <label class="control-label">
                                                                    <input type="checkbox" value="3">
                                                                    Menu 3
                                                                    </label>
                                                        </div>
                                                    </li>
                                                </ul>
                                                <button class="save-btn hover-btn" type="submit">Add to Menu</button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-6">
                            <div class="card card-static-2 mb-30">
                                <div class="card-title-2">
                                    <h4>Menu items</h4>
                                </div>
                                <div class="card-body-table">
                                    <div class="news-content-right pd-20">
                                        <div class="row">
                                            <div class="col-lg-6">
                                                <div class="panel-group-1" id="accordion" role="tablist" aria-multiselectable="true">
                                                    <div class="panel panel-default-1">
                                                        <div class="panel-heading-1" role="tab" id="menu-1">
                                                            <div class="panel-title-1">
                                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapseMenuOne" aria-expanded="true" aria-controls="collapseMenuOne">
                                                                    <span class="attr-menu-left">Home Page</span>
                                                                    <span class="attr-menu-right">Page</span>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div id="collapseMenuOne" class="panel-collapse collapse show" role="tabpanel" aria-labelledby="menu-1">
                                                            <div class="panel-body-1">
                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <div class="menu-search">
                                                                            <label class="form-label">Menu Name*</label>
                                                                            <input type="text" class="form-control" placeholder="Home Page">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <div class="menu-search">
                                                                            <label class="form-label">Class*</label>
                                                                            <input type="text" class="form-control" placeholder="">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-6">
                                                                        <div class="menu-search">
                                                                            <label class="form-label">target*</label>
                                                                            <select id="status" name="status" class="form-control">
                                                                                <option selected>Normal</option>
                                                                                <option value="1">Open new tab</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-lg-12">
                                                                        <div class="bb-bottom">
                                                                            <a href="#" class="menu-delete">Delete</a>
                                                                           
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="menu-configs">
                                                    <h4>Menu Configs</h4>
                                                    <label class="control-label">
                                                        <input type="checkbox" value="primary">
                                                        Primary
                                                        </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="menu-save-btn">
                                        <button class="save-btn hover-btn mt-0" type="submit">Save Menu</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
<?php 
include("footer.php");
?>            