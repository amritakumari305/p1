<?php 
include("Common/config.php");
include("Common/crud.php");

if(isset($_POST['submit']))

{

$crud = new CRUD('user','user_id');
$saveData = array();	
$saveData['email_id']=$_POST['email_id'];
$saveData['phone_no']=$_POST['phone_no'];
$saveData['password']=$_POST['password'];




$insert_id=$crud->save($saveData);
header("location: index.php");


}


?>
<?php 
include("header.php");
include("menu.php")
?>
 <div class="sign-inup">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="sign-form">
                        <div class="sign-inner">
                           
                            <div class="form-dt">
                                <div class="form-inpts checout-address-step">
                                    <form method="POST" action="">
                                        <div class="form-title">
                                            <h6>Sign Up</h6>
                                        </div>
                                        
                                        <div class="form-group pos_rel">
                                            <input id="email_id" name="email_id" type="text" placeholder="Email Address" class="form-control lgn_input" required="">
                                            <i class="uil uil-envelope lgn_icon"></i>
                                        </div>
                                        <div class="form-group pos_rel">
                                            <input id="phone_no" name="phone_no" type="number" placeholder="Phone Number" class="form-control lgn_input" required="">
                                            <i class="uil uil-mobile-android-alt lgn_icon"></i>
                                        </div>
                                        
                                        <!-- <div class="form-group pos_rel">
                                            <label class="control-label">Enter Code</label>
                                            <ul class="code-alrt-inputs signup-code-list">
                                                <li>
                                                    <input id="code[1]" name="number" type="text" placeholder="" class="form-control input-md" required="">
                                                </li>
                                                <li>
                                                    <input id="code[2]" name="number" type="text" placeholder="" class="form-control input-md" required="">
                                                </li>
                                                <li>
                                                    <input id="code[3]" name="number" type="text" placeholder="" class="form-control input-md" required="">
                                                </li>
                                                <li>
                                                    <input id="code[4]" name="number" type="text" placeholder="" class="form-control input-md" required="">
                                                </li>
                                                <li>
                                                    <a class="chck-btn hover-btn code-btn145" href="#">Send</a>
                                                </li>
                                            </ul>
                                            <a href="#" class="resend-link">Resend Code</a>
                                        </div> -->
                                        <div class="form-group pos_rel">
                                            <input id="password" name="password" type="password" placeholder="New Password" class="form-control lgn_input" required="">
                                            <i class="uil uil-padlock lgn_icon"></i>
                                        </div>
                                        <button class="login-btn hover-btn" type="submit" name="submit" value="Submit">Sign Up Now</button>
                                    </form>
                                </div>
                                <div class="signup-link">
                                    <p>I have an account? - <a href="sign_in.php">Sign In Now</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
</div>
<?php 
include("footer.php");

?>