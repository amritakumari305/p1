<?php 
include("header.php");
include("menu.php");
include("home.php");
include("footer.php");
?>