<main class="main">
            <div class="offers-banners bg-dark mt-12 py-4">
                <div class="container deal-section">

                    <div class="deal-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-md-3 cols-lg-4 cols-xl-5 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                        &quot;nav&quot;: true, 
                        &quot;dots&quot;: false,
                        &quot;margin&quot;: 0,
                        &quot;loop&quot;: false,
                        &quot;responsive&quot;: {
                            &quot;0&quot;: {
                                &quot;items&quot;:2
                            },
                            &quot;480&quot;: {
                                &quot;items&quot;:2
                            },
                            &quot;767&quot;: {
                                &quot;items&quot;:3
                            },
                            &quot;992&quot;: {
                                &quot;items&quot;:4
                            },
                            &quot;1200&quot;: {
                                &quot;items&quot;:4
                            },
                            &quot;1600&quot;: {
                                &quot;items&quot;:4
                            }
                        }
                    }">

                        <!-- End .product -->
                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(-280px, 0px, 0px); transition: all 0.4s ease 0s; width: 1680px;">
                                <div class="owl-item" style="width: 280px;">
                                    <div class="product d-flex flex-column overflow-hidden">
                                        <figure class="mb-0 product-media d-flex justify-content-center align-items-center">

                                            <a href="" class="w-100">
                                                <img src="assets/images/p1.jpg" alt="Product image" class="product-image" width="239" height="239">
                                                <img src="assets/images/p1.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                                            </a>
                                        </figure>


                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 280px;">
                                    <div class="product d-flex flex-column overflow-hidden">
                                        <figure class="mb-0 product-media d-flex justify-content-center align-items-center">
                                            <a href="" class="w-100">
                                                <img src="assets/images/p2.jpg" alt="Product image" class="product-image" width="239" height="239">
                                                <img src="assets/images/p2.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                                            </a>


                                        </figure>

                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 280px;">
                                    <div class="product d-flex flex-column overflow-hidden">
                                        <figure class="mb-0 product-media  d-flex justify-content-center align-items-center">

                                            <a href="" class="w-100">
                                                <img src="assets/images/p3.jpg" alt="Product image" class="product-image" width="239" height="239">
                                                <img src="assets/images/p3.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                                            </a>


                                        </figure>


                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 280px;">
                                    <div class="product d-flex flex-column overflow-hidden">
                                        <figure class="mb-0 product-media  d-flex justify-content-center align-items-center">

                                            <a href="" class="w-100">
                                                <img src="assets/images/p1.jpg" alt="Product image" class="product-image" width="239" height="239">
                                                <img src="assets/images/p1.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                                            </a>




                                        </figure>


                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 280px;">
                                    <div class="product d-flex flex-column overflow-hidden">
                                        <figure class="mb-0 product-media  d-flex justify-content-center align-items-center">

                                            <a href="" class="w-100">
                                                <img src="assets/images/p2.jpg" alt="Product image" class="product-image" width="239" height="239">
                                                <img src="assets/images/p2.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                                            </a>


                                        </figure>

                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 280px;">
                                    <div class="product d-flex flex-column overflow-hidden">
                                        <figure class="mb-0 product-media  d-flex justify-content-center align-items-center">

                                            <a href="" class="w-100">
                                                <img src="assets/images/p3.jpg" alt="Product image" class="product-image" width="239" height="239">
                                                <img src="assets/images/p3.jpg" alt="Product image" class="product-image-hover" width="239" height="239">
                                            </a>


                                        </figure>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="owl-nav"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next disabled"><i class="icon-angle-right"></i></button></div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>

            <div class="container icon-boxes-section">
                <div class="icon-boxes-container">
                    <div class="owl-carousel carousel-simple owl-theme carousel-equal-height shadow-carousel row cols-1 cols-md-2 cols-lg-3 cols-xl-4 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                                &quot;dots&quot;: true,
                                &quot;nav&quot;: false, 
                                &quot;loop&quot;: false,
                                &quot;margin&quot;: 13,
                                &quot;responsive&quot;: {
                                    &quot;0&quot;: {
                                        &quot;items&quot;: 1
                                    },
                                    &quot;575&quot;: {
                                        &quot;items&quot;: 2
                                    },
                                    &quot;992&quot;: {
                                        &quot;items&quot;: 3
                                    },
                                    &quot;1200&quot;: {
                                        &quot;items&quot;: 3
                                    }
                                }
                            }">

                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1760px;">
                                <div class="owl-item active" style="width: 427px; margin-right: 13px;">
                                    <div class="icon-box mb-0 d-md-flex align-items-md-center text-center text-md-left mx-md-0 mx-auto">
                                        <span class="icon-box-icon text-dark mb-0">
                                            <img src="assets/images/icons/ScootScoot.png" alt="" >
                                        </span>
                                        <div class="icon-box-content">
                                            <h3 class="icon-box-title mb-1 font-weight-bold text-uppercase">Become a Dasher</h3>
                                            <p class="font-weight-light mb-1">As a delivery driver, you'll make reliable money—working anytime, anywhere .</p>
                                            <a href="driver.php">Register <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="flex-shrink: 0;"><path d="M12.2929 15.2929C11.9024 15.6834 11.9024 16.3166 12.2929 16.7071C12.6834 17.0976 13.3166 17.0976 13.7071 16.7071L17.7071 12.7071C18.0976 12.3166 18.0976 11.6834 17.7071 11.2929L13.7071 7.29289C13.3166 6.90237 12.6834 6.90237 12.2929 7.29289C11.9024 7.68342 11.9024 8.31658 12.2929 8.70711L14.5858 11L7 11C6.44772 11 6 11.4477 6 12C6 12.5523 6.44772 13 7 13L14.5858 13L12.2929 15.2929Z" fill="#EB1700"></path></svg></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item" style="width: 427px; margin-right: 13px;">
                                    <div class="icon-box mb-0 d-md-flex align-items-md-center text-center text-md-left mx-md-0 mx-auto">
                                        <span class="icon-box-icon text-dark mb-0">
                                            <img src="assets/images/icons/Storefront.png" alt="">
                                        </span>
                                        <div class="icon-box-content">
                                            <h3 class="icon-box-title mb-1 font-weight-bold text-uppercase">Become a Partner</h3>
                                            <p class="font-weight-light mb-1">Grow your business and reach new customers by partnering with us.</p>
                                            <a href="patner.php">Register <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="flex-shrink: 0;"><path d="M12.2929 15.2929C11.9024 15.6834 11.9024 16.3166 12.2929 16.7071C12.6834 17.0976 13.3166 17.0976 13.7071 16.7071L17.7071 12.7071C18.0976 12.3166 18.0976 11.6834 17.7071 11.2929L13.7071 7.29289C13.3166 6.90237 12.6834 6.90237 12.2929 7.29289C11.9024 7.68342 11.9024 8.31658 12.2929 8.70711L14.5858 11L7 11C6.44772 11 6 11.4477 6 12C6 12.5523 6.44772 13 7 13L14.5858 13L12.2929 15.2929Z" fill="#EB1700"></path></svg></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-item" style="width: 427px; margin-right: 13px;">
                                    <div class="icon-box mb-0 d-md-flex align-items-md-center text-center text-md-left mx-md-0 mx-auto">
                                        <span class="icon-box-icon text-dark mb-0">
                                            <img src="assets/images/icons/iphone.png" alt="">
                                        </span>
                                        <div class="icon-box-content">
                                            <h3 class="icon-box-title mb-1 font-weight-bold text-uppercase">Try the App</h3>
                                            <p class="font-weight-light mb-1"> Experience the best your neighborhood has to offer, all in one app.</p>
                                            <a href="">Download <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="flex-shrink: 0;"><path d="M12.2929 15.2929C11.9024 15.6834 11.9024 16.3166 12.2929 16.7071C12.6834 17.0976 13.3166 17.0976 13.7071 16.7071L17.7071 12.7071C18.0976 12.3166 18.0976 11.6834 17.7071 11.2929L13.7071 7.29289C13.3166 6.90237 12.6834 6.90237 12.2929 7.29289C11.9024 7.68342 11.9024 8.31658 12.2929 8.70711L14.5858 11L7 11C6.44772 11 6 11.4477 6 12C6 12.5523 6.44772 13 7 13L14.5858 13L12.2929 15.2929Z" fill="#EB1700"></path></svg></a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="icon-angle-right"></i></button></div>
                        <!-- <hr class="mt-2 mb-1"> -->
                    </div>
                </div>

            </div>


            <div class="py-4" style="background-color: #fff4f5 !important;">
                <div class="container new-arrival">
                    <div class="heading heading-center mb-3">

                        <ul class="nav nav-pills" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="new-delivery-link" data-toggle="tab" href="#new-delivery-tab" role="tab" aria-controls="new-delivery-tab" aria-selected="false"><img src="assets/images/icons/c0bb85d3a6347b2ec070a8db694588261616149578.webp" alt="" width="30" class="d-inline"> Delivery</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="new-dining-link" data-toggle="tab" href="#new-dining-tab" role="tab" aria-controls="new-dining-tab" aria-selected="true"><img src="assets/images/icons/78d25215ff4c1299578ed36eefd5f39d1616149985.webp" alt="" width="30" class="d-inline"> Dining Out</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="new-nightlife-link" data-toggle="tab" href="#new-nightlife-tab" role="tab" aria-controls="new-nightlife-tab" aria-selected="true"><img src="assets/images/icons/01040767e4943c398e38e3592bb1ba8a1616150142.webp" alt="" width="30" class="d-inline"> Nightlife</a>
                            </li>
                            <!-- <li class="nav-item">
                                <a class="nav-link" id="new-nutrition-link" data-toggle="tab" href="#new-nutrition-tab" role="tab" aria-controls="new-nutrition-tab" aria-selected="true"><img src="assets/images/icons/54cad8274d3c3ec7129e0808a13b27c31616582882.webp" alt="" width="30" class="d-inline"> Nutrition</a>
                            </li> -->
                        </ul>
                    </div>
                    <!-- End heading -->

                    <div class="tab-content">
                        <div class="tab-pane p-0 fade active show" id="new-delivery-tab" role="tabpanel" aria-labelledby="new-delivery-link">
                            <div class="products">
                                <h3>Delivery Restaurants in C Scheme</h3>
                                <p style="color: #e46d3b;font-size: 15px;font-weight: 400;margin-bottom: 10px;">Explore curated lists of top restaurants, in Jaipur, based on trends</p>
                                <hr class="mt-0">
                                <div class="row justify-content-center">
                                    <div class="col-6 col-md-4 col-lg-4 col-xl-5col">
                                        <div class="product product-7">
                                            <figure class="product-media">
                                                <span class="product-label label-sale">New</span>
                                                <a href="order.php">
                                                    <img src="assets/images/p4.jpg" alt="Product image" class="product-image">
                                                    <img src="assets/images/p4.jpg" alt="Product image" class="product-image-hover">
                                                </a>

                                                <div class="product-action">
                                                    <a href="order.php" class="btn-product"><span>Quick View</span></a>
                                                </div>



                                            </figure>

                                            <div class="product-body">
                                                <h3 class="product-title"><a href="">Title Here</a></h3>
                                                <span>Snacks</span>
                                                <div class="product-price">
                                                    <span class="new-price">54 Mins</span>
                                                    <span class="old-price float-right">Rs.80 for two</span>
                                                </div>
                                                <div class="ratings-container">
                                                    <div class="ratings">
                                                        <div class="ratings-val" style="width: 60%;"></div>
                                                        <!-- End .ratings-val -->
                                                    </div>
                                                    <!-- End .ratings -->
                                                    <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                                </div>
                                                <hr class="mt-0 mb-1">
                                                <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                            </div>

                                        </div>

                                    </div>

                                    <div class="col-6 col-md-4 col-lg-4 col-xl-5col">
                                        <div class="product product-7">
                                            <figure class="product-media">
                                                <span class="product-label label-sale">New</span>
                                                <a href="">
                                                    <img src="assets/images/p6.jpg" alt="Product image" class="product-image">
                                                    <img src="assets/images/p6.jpg" alt="Product image" class="product-image-hover">
                                                </a>

                                                <div class="product-action">
                                                    <a href="#" class="btn-product"><span>Quick View</span></a>
                                                </div>



                                            </figure>

                                            <div class="product-body">
                                                <h3 class="product-title"><a href="">Title Here</a></h3>
                                                <span>Snacks</span>
                                                <div class="product-price">
                                                    <span class="new-price">54 Mins</span>
                                                    <span class="old-price">Rs.80 for two</span>
                                                </div>
                                                <div class="ratings-container">
                                                    <div class="ratings">
                                                        <div class="ratings-val" style="width: 60%;"></div>
                                                        <!-- End .ratings-val -->
                                                    </div>
                                                    <!-- End .ratings -->
                                                    <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                                </div>
                                                <hr class="mt-0 mb-1">
                                                <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                            </div>

                                        </div>
                                    </div>

                                    <div class="col-6 col-md-4 col-lg-4 col-xl-5col">
                                        <div class="product product-7">
                                            <figure class="product-media">
                                                <span class="product-label label-sale">New</span>
                                                <a href="">
                                                    <img src="assets/images/p7.jpg" alt="Product image" class="product-image">
                                                    <img src="assets/images/p7.jpg" alt="Product image" class="product-image-hover">
                                                </a>

                                                <div class="product-action">
                                                    <a href="#" class="btn-product"><span>Quick View</span></a>
                                                </div>



                                            </figure>

                                            <div class="product-body">
                                                <h3 class="product-title"><a href="">Title Here</a></h3>
                                                <span>Snacks</span>
                                                <div class="product-price">
                                                    <span class="new-price">54 Mins</span>
                                                    <span class="old-price">Rs.80 for two</span>
                                                </div>
                                                <div class="ratings-container">
                                                    <div class="ratings">
                                                        <div class="ratings-val" style="width: 60%;"></div>
                                                        <!-- End .ratings-val -->
                                                    </div>
                                                    <!-- End .ratings -->
                                                    <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                                </div>
                                                <hr class="mt-0 mb-1">
                                                <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                            </div>

                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>

                        <div class="tab-pane p-0 fade " id="new-dining-tab" role="tabpanel" aria-labelledby="new-dining-link">
                            <h3>Collections</h3>
                            <p style="color: #e46d3b;font-size: 15px;font-weight: 400;margin-bottom: 10px;">Explore curated lists of top restaurants, cafes, pubs, and bars in Jaipur, based on trends
                            </p>
                            <a href="dineout.php" class="float-right"> <strong>See All</strong> <i class="icon-long-arrow-right"></i></a>
                            <hr class="mt-0">
                            <div class="electronic-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-sm-3 cols-lg-4 cols-xl-5 cols-xxl-6 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                                &quot;nav&quot;: false, 
                                &quot;dots&quot;: false,
                                &quot;margin&quot;: 0,
                                &quot;loop&quot;: false,
                                &quot;responsive&quot;: {
                                    &quot;0&quot;: {
                                        &quot;items&quot;:2
                                    },
                                    &quot;480&quot;: {
                                        &quot;items&quot;:2
                                    },
                                    &quot;576&quot;: {
                                        &quot;items&quot;:3
                                    },
                                    &quot;992&quot;: {
                                        &quot;items&quot;:3
                                    },
                                    &quot;1200&quot;: {
                                        &quot;items&quot;:4
                                    },
                                    &quot;1400&quot;: {
                                        &quot;items&quot;:4
                                    }
                                }
                            }">
                                <div class="owl-stage-outer">
                                    <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1371px;">
                                        <div class="owl-item active" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h2>
                                                    <div class="product-price mb-1 ">
                                                        30 Places <i class="icon-arrow-right"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item active" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/r2.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/r2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h2>
                                                    <div class="product-price mb-1 ">
                                                        30 Places <i class="icon-arrow-right"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/r3.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/r3.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h2>
                                                    <div class="product-price mb-1 ">
                                                        30 Places <i class="icon-arrow-right"></i>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h2>
                                                    <div class="product-price mb-1 ">
                                                        30 Places <i class="icon-arrow-right"></i>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/r2.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/r2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h2>
                                                    <div class="product-price mb-1 ">
                                                        30 Places <i class="icon-arrow-right"></i>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/r3.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/r3.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h2>
                                                    <div class="product-price mb-1 ">
                                                        30 Places <i class="icon-arrow-right"></i>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="icon-angle-right"></i></button></div>
                                <div class="owl-dots disabled"></div>
                            </div>

                        </div>
                        <div class="tab-pane p-0 fade " id="new-nightlife-tab" role="tabpanel" aria-labelledby="new-nightlife-link">
                            <h3>Collections</h3>
                            <p style="color: #e46d3b;font-size: 15px;font-weight: 400;margin-bottom: 10px;">Explore curated lists of top restaurants, cafes, pubs, and bars in Jaipur, based on trends
                            </p>
                            <hr class="mt-0">
                            <div class="electronic-carousel owl-carousel owl-simple carousel-equal-height row cols-2 cols-sm-3 cols-lg-4 cols-xl-5 cols-xxl-6 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                                &quot;nav&quot;: false, 
                                &quot;dots&quot;: false,
                                &quot;margin&quot;: 0,
                                &quot;loop&quot;: false,
                                &quot;responsive&quot;: {
                                    &quot;0&quot;: {
                                        &quot;items&quot;:2
                                    },
                                    &quot;480&quot;: {
                                        &quot;items&quot;:2
                                    },
                                    &quot;576&quot;: {
                                        &quot;items&quot;:3
                                    },
                                    &quot;992&quot;: {
                                        &quot;items&quot;:3
                                    },
                                    &quot;1200&quot;: {
                                        &quot;items&quot;:4
                                    },
                                    &quot;1400&quot;: {
                                        &quot;items&quot;:4
                                    }
                                }
                            }">
                                <div class="owl-stage-outer">
                                    <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1371px;">
                                        <div class="owl-item active" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/pub1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/pub1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h3 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h3>
                                                    <div class="product-price mb-1 ">
                                                        30 Places
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item active" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/pub2.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/pub2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h3 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h3>
                                                    <div class="product-price mb-1 ">
                                                        30 Places
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/pub3.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/pub3.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h3 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h3>
                                                    <div class="product-price mb-1 ">
                                                        30 Places
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/pub4.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/pub4.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h3 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h3>
                                                    <div class="product-price mb-1 ">
                                                        30 Places
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/pub1.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/pub1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h3 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h3>
                                                    <div class="product-price mb-1 ">
                                                        30 Places
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 228.5px;">
                                            <div class="product d-flex flex-column overflow-hidden">
                                                <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                                                    <a href="" class="w-100">
                                                        <img src="assets/images/pub2.jpg" alt="Product image" class="product-image" width="192" height="192">
                                                        <img src="assets/images/pub2.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                                                    </a>
                                                </figure>

                                                <div class="product-body">
                                                    <h3 class="product-title letter-spacing-normal  mb-0 text-left">
                                                        <a href="">Title Here</a>
                                                    </h3>
                                                    <div class="product-price mb-1 ">
                                                        30 Places
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="icon-angle-right"></i></button></div>
                                <div class="owl-dots disabled"></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


            <div class="py-5">
                <div class="container">
                    <div class="toolbox">
                        <div class="toolbox-left">
                            <a href="#" class="sidebar-toggler"><i class="icon-bars"></i>Filters</a>
                        </div>
                        <!-- End .toolbox-left -->

                        <div class="toolbox-center">
                            <div class="toolbox-info">
                                Showing <span>12 of 56</span> Resturansts
                            </div>
                            <!-- End .toolbox-info -->
                        </div>
                        <!-- End .toolbox-center -->

                        <div class="toolbox-right">
                            <div class="toolbox-sort">
                                <label for="sortby">Sort by:</label>
                                <div class="select-custom">
                                    <select name="sortby" id="sortby" class="form-control">
										<option value="popularity" selected="selected">Most Popular</option>
										<option value="rating">Most Rated</option>
										<option value="date">Date</option>
									</select>
                                </div>
                            </div>
                            <!-- End .toolbox-sort -->
                        </div>
                        <!-- End .toolbox-right -->
                    </div>
                    <!-- End .toolbox -->

                    <div class="products">
                        <div class="row">
                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="order.php">
                                            <img src="assets/images/p8.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p8.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="order.php" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p9.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p9.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p10.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p10.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p11.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p11.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p4.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p4.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p6.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p6.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p7.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p7.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p12.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p12.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p13.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p13.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p14.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p14.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p15.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p15.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->

                            <div class="col-6 col-md-4 col-lg-4 col-xl-3">
                                <div class="product product-7">
                                    <figure class="product-media">
                                        <span class="product-label label-sale">New</span>
                                        <a href="">
                                            <img src="assets/images/p16.jpg" alt="Product image" class="product-image">
                                            <img src="assets/images/p16.jpg" alt="Product image" class="product-image-hover">
                                        </a>

                                        <div class="product-action">
                                            <a href="#" class="btn-product"><span>Quick View</span></a>
                                        </div>



                                    </figure>

                                    <div class="product-body">
                                        <h3 class="product-title"><a href="">Title Here</a></h3>
                                        <span>Snacks</span>
                                        <div class="product-price">
                                            <span class="new-price">54 Mins</span>
                                            <span class="old-price float-right">Rs.80 for two</span>
                                        </div>
                                        <div class="ratings-container">
                                            <div class="ratings">
                                                <div class="ratings-val" style="width: 60%;"></div>
                                                <!-- End .ratings-val -->
                                            </div>
                                            <!-- End .ratings -->
                                            <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                        </div>
                                        <hr class="mt-0 mb-1">
                                        <div class="Zlfdx"><b style="color: #dc3545;">58% off on all orders</b></div>
                                    </div>

                                </div>

                                <!-- End .product -->
                            </div>
                            <!-- End .col-sm-6 col-lg-4 col-xl-3 -->
                        </div>
                        <!-- End .row -->

                        <div class="load-more-container text-center">
                            <a href="#" class="btn btn-outline-darker btn-load-more">More Products <i class="icon-refresh"></i></a>
                        </div>
                        <!-- End .load-more-container -->
                    </div>
                    <!-- End .products -->

                    <div class="sidebar-filter-overlay"></div>
                    <!-- End .sidebar-filter-overlay -->
                    <aside class="sidebar-shop sidebar-filter">
                        <div class="sidebar-filter-wrapper">
                            <div class="widget widget-clean">
                                <label><i class="icon-close"></i>Filters</label>
                                <a href="#" class="sidebar-filter-clear">Clean All</a>
                            </div>
                            <!-- End .widget -->
                            <div class="widget widget-collapsible">
                                <h3 class="widget-title">
                                    <a data-toggle="collapse" href="#widget-1" role="button" aria-expanded="true" aria-controls="widget-1">
                                        Category
                                    </a>
                                </h3>
                                <!-- End .widget-title -->

                                <div class="collapse show" id="widget-1">
                                    <div class="widget-body">
                                        <div class="filter-items filter-items-count">
                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-1">
                                                    <label class="custom-control-label" for="cat-1">Thali</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">3</span>
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-2">
                                                    <label class="custom-control-label" for="cat-2">Combo</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">0</span>
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-3">
                                                    <label class="custom-control-label" for="cat-3">Breads</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">4</span>
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-4">
                                                    <label class="custom-control-label" for="cat-4">Chainess</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">2</span>
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-5">
                                                    <label class="custom-control-label" for="cat-5">Continentals</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">2</span>
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-6">
                                                    <label class="custom-control-label" for="cat-6">Fast Food</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">1</span>
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-7">
                                                    <label class="custom-control-label" for="cat-7">Snacks</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">1</span>
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="cat-8">
                                                    <label class="custom-control-label" for="cat-8">Pizza</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                                <span class="item-count">0</span>
                                            </div>
                                            <!-- End .filter-item -->
                                        </div>
                                        <!-- End .filter-items -->
                                    </div>
                                    <!-- End .widget-body -->
                                </div>
                                <!-- End .collapse -->
                            </div>
                            <!-- End .widget -->

                            <div class="widget widget-collapsible">
                                <h3 class="widget-title">
                                    <a data-toggle="collapse" href="#widget-2" role="button" aria-expanded="true" aria-controls="widget-2">
                                        Type
                                    </a>
                                </h3>
                                <!-- End .widget-title -->

                                <div class="collapse show" id="widget-2">
                                    <div class="widget-body">
                                        <div class="filter-items">
                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="size-1">
                                                    <label class="custom-control-label" for="size-1">Veg</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="size-2">
                                                    <label class="custom-control-label" for="size-2">Non-Veg</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                        </div>
                                        <!-- End .filter-items -->
                                    </div>
                                    <!-- End .widget-body -->
                                </div>
                                <!-- End .collapse -->
                            </div>
                            <!-- End .widget -->



                            <div class="widget widget-collapsible">
                                <h3 class="widget-title">
                                    <a data-toggle="collapse" href="#widget-4" role="button" aria-expanded="true" aria-controls="widget-4">
                                        Brand
                                    </a>
                                </h3>
                                <!-- End .widget-title -->

                                <div class="collapse show" id="widget-4">
                                    <div class="widget-body">
                                        <div class="filter-items">
                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="brand-1">
                                                    <label class="custom-control-label" for="brand-1">Domino's</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="brand-2">
                                                    <label class="custom-control-label" for="brand-2">Pizza Hurt</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="brand-3">
                                                    <label class="custom-control-label" for="brand-3">Blues</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="brand-4">
                                                    <label class="custom-control-label" for="brand-4">Naturale's</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="brand-5">
                                                    <label class="custom-control-label" for="brand-5">Kanha</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="brand-6">
                                                    <label class="custom-control-label" for="brand-6">Fun Food</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                            <div class="filter-item">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" id="brand-7">
                                                    <label class="custom-control-label" for="brand-7">Bikaner Wala</label>
                                                </div>
                                                <!-- End .custom-checkbox -->
                                            </div>
                                            <!-- End .filter-item -->

                                        </div>
                                        <!-- End .filter-items -->
                                    </div>
                                    <!-- End .widget-body -->
                                </div>
                                <!-- End .collapse -->
                            </div>
                            <!-- End .widget -->


                        </div>
                        <!-- End .sidebar-filter-wrapper -->
                    </aside>
                    <!-- End .sidebar-filter -->
                </div>
                <!-- End .container -->
            </div>

            <div class="container banner-group-1">
                <div class="categories">

                    <div class="owl-carousel carousel-theme carousel-simple carousel-with-shadow row cols-2 cols-xs-3 cols-sm-4 cols-md-5 cols-lg-6 cols-xl-8 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                                        &quot;nav&quot;: false, 
                                        &quot;dots&quot;: false,
                                        &quot;margin&quot;: 10,
                                        &quot;loop&quot;: false,
                                        &quot;responsive&quot;: {
                                            &quot;0&quot;: {
                                                &quot;items&quot;:2
                                            },
                                            &quot;480&quot;: {
                                                &quot;items&quot;:2
                                            },
                                            &quot;576&quot;: {
                                                &quot;items&quot;:2
                                            },
                                            &quot;768&quot;: {
                                                &quot;items&quot;:2
                                            },
                                            &quot;992&quot;: {
                                                &quot;items&quot;:2
                                            },
                                            &quot;1200&quot;: {
                                                &quot;items&quot;:2
                                            }
                                        }
                                    }">
                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1532px;">
                                <div class="owl-item active" style="width: 181.5px; margin-right: 10px;">
                                    <div class="category position-relative">
                                        <div class="category-image">
                                            <a href="#">
                                                <img src="assets/images/s1.jpg" class="w-100" alt="" width="166" height="160">
                                            </a>
                                        </div>

                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 181.5px; margin-right: 10px;">
                                    <div class="category position-relative">
                                        <div class="category-image">
                                            <a href="#">
                                                <img src="assets/images/s2.jpg" class="w-100" alt="" width="166" height="160">
                                            </a>
                                        </div>

                                    </div>
                                </div>
                                <div class="owl-item" style="width: 181.5px; margin-right: 10px;">
                                    <div class="category position-relative">
                                        <div class="category-image">
                                            <a href="#">
                                                <img src="assets/images/s1.jpg" class="w-100" alt="" width="166" height="160">
                                            </a>
                                        </div>

                                    </div>
                                </div>
                                <div class="owl-item" style="width: 181.5px; margin-right: 10px;">
                                    <div class="category position-relative">
                                        <div class="category-image">
                                            <a href="#">
                                                <img src="assets/images/s2.jpg" class="w-100" alt="" width="166" height="160">
                                            </a>
                                        </div>

                                    </div>
                                </div>
                                <div class="owl-item" style="width: 181.5px; margin-right: 10px;">
                                    <div class="category position-relative">
                                        <div class="category-image">
                                            <a href="#">
                                                <img src="assets/images/s1.jpg" class="w-100" alt="" width="166" height="160">
                                            </a>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="icon-angle-right"></i></button></div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>

            </div>
            <div class="bg-white brand-section pt-2 pb-2">
                <div class="container">
                    <h4 class="text-center  font-weight-bold mb-4">Order By Brands</h4>
                    <div class="owl-carousel owl-simple brands-carousel row cols-2 cols-xs-3 cols-sm-4 cols-lg-5 cols-xxl-6 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                                    &quot;nav&quot;: false, 
                                    &quot;dots&quot;: false,
                                    &quot;margin&quot;:  0,
                                    &quot;loop&quot;: false,
                                    &quot;responsive&quot;: {
                                        &quot;0&quot;: {
                                            &quot;items&quot;:2
                                        },
                                        &quot;480&quot;: {
                                            &quot;items&quot;:3
                                        },
                                        &quot;576&quot;: {
                                            &quot;items&quot;:4
                                        },
                                        &quot;992&quot;: {
                                            &quot;items&quot;:5
                                        },
                                        &quot;1600&quot;: {
                                            &quot;items&quot;:6
                                        }
                                    }
                                }">

                        <div class="owl-stage-outer">
                            <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 1634px;">
                                <div class="owl-item active" style="width: 233.333px;">
                                    <a href="#" class="brand">
                                        <img src="assets/images/icons/1b.png" alt="Brand Name" width="70" height="30">

                                    </a>
                                    <div class="brand-title text-center">
                                        <span class="badge badge-warning p-2 text-white " style="position: absolute; top: -0.1px;left: -1px;font-size: 15px;"> 30%</span>
                                        <h6>Domino's pizza</h6>
                                        <span>30 mins</span>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 233.333px;">
                                    <a href="#" class="brand">
                                        <img src="assets/images/icons/2b.png" alt="Brand Name" width="85" height="30">
                                    </a>
                                    <div class="brand-title text-center">
                                        <h6>Burger Farm</h6>
                                        <span>30 mins</span>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 233.333px;">
                                    <a href="#" class="brand">
                                        <img src="assets/images/icons/3b.png" alt="Brand Name" width="85" height="30">
                                    </a>
                                    <div class="brand-title text-center">
                                        <span class="badge badge-warning p-2 text-white " style="position: absolute; top: -0.1px;left: -1px;font-size: 15px;"> 60%</span>
                                        <h6>Burger King</h6>
                                        <span>30 mins</span>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 233.333px;">
                                    <a href="#" class="brand">
                                        <img src="assets/images/icons/4b.png" alt="Brand Name" width="85" height="30">
                                    </a>
                                    <div class="brand-title text-center">
                                        <h6>KFC</h6>
                                        <span>30 mins</span>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 233.333px;">
                                    <a href="#" class="brand">
                                        <img src="assets/images/icons/5b.png" alt="Brand Name" width="85" height="30">
                                    </a>
                                    <div class="brand-title text-center">
                                        <h6>Pizza Hurt</h6>
                                        <span>30 mins</span>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 233.333px;">
                                    <a href="#" class="brand">
                                        <img src="assets/images/icons/7b.png" alt="Brand Name" width="85" height="30">
                                    </a>
                                    <div class="brand-title text-center">
                                        <h6>Subway</h6>
                                        <span>30 mins</span>
                                    </div>
                                </div>
                                <div class="owl-item active" style="width: 233.333px;">
                                    <a href="#" class="brand">
                                        <img src="assets/images/icons/8b.png" alt="Brand Name" width="85" height="30">
                                    </a>
                                    <div class="brand-title text-center">
                                        <h6>Kanha</h6>
                                        <span>30 mins</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="icon-angle-right"></i></button></div>
                        <div class="owl-dots disabled"></div>
                    </div>
                </div>
            </div>

        </main>


    </div>