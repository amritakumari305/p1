<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="offers-banners bg-dark mt-13 py-2" style="background-image: url(assets/images/header-bg.png);">
        <div class="container deal-section">
            <div class="row">
                <div class="col-md-12">
                    <div class="driver-box text-center pb-3 mt-3">
                        <h3 class="text-white">
                            Resturant Name
                        </h3>

                        <p><strong>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages </strong></p>
                        <span>Durgapura</span>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <div class="container mt-2">
        <div class="row ">
            <div class="col-lg-8">
                <div class="banner banner-big">
                    <a href="#">
                        <img src="assets/images/pizza.jpg" alt="Banner">
                    </a>
                </div><!-- End .banner -->
            </div><!-- End .col-lg-8 -->

            <div class="col-lg-4">
                <div class="row">
                    <div class="col-sm-6 col-lg-12">
                        <div class="banner">
                            <a href="#">
                                <img src="assets/images/pizza.jpg" alt="Banner">
                            </a>
                        </div><!-- End .banner -->
                    </div><!-- End .col-sm-6 col-lg-12 -->

                    <div class="col-sm-6 col-lg-12">
                        <div class="banner">
                            <a href="#">
                                <img src="assets/images/pizza.jpg" alt="Banner">
                            </a>
                        </div><!-- End .banner -->
                    </div><!-- End .col-sm-6 col-lg-12 -->
                </div><!-- End .row -->
            </div><!-- End .col-lg-4 -->
        </div>

        <div class="row mb-3">
            <div class="col-md-6">
                <h3>Reaturant Name Here</h3>
                <span>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages</span>
                <p><b>Open Now</b> - 1pm- 11pm (Today)</p>
            </div>
            <div class="col-md-3">
                <div class="ratings-container mb-0">
                    <div class="ratings">
                        <div class="ratings-vals" style="width: 60%;"></div>
                        <!-- End .ratings-val -->
                    </div>
                    <!-- End .ratings -->
                    <span class="ml-2"> <b>4.4 ( 4 Reviews )</b></span>

                </div>
                <div class="" style="border-bottom: 1px dashed #333; font-weight:400">1,985 Dining Reviews</div>
            </div>
            <div class="col-md-3">
                <div class="ratings-container mb-0">
                    <div class="ratings">
                        <div class="ratings-val" style="width: 60%;"></div>
                        <!-- End .ratings-val -->
                    </div>
                    <!-- End .ratings -->
                    <span class="ml-2"> <b>4.4 ( 4 Reviews )</b></span>

                </div>
                <div class="" style="border-bottom: 1px dashed #333; font-weight:400">1,985 Order Reviews</div>
            </div>
        </div>



        <div class="row mb-3">

            <div class="col-md-12">
                <ul class="nav nav-tabs nav-tabs-bg" id="tabs-1" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="tab-1-tab" data-toggle="tab" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="true">Overview</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tab-2-tab" data-toggle="tab" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="false">Order Online</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tab-3-tab" data-toggle="tab" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">Reviews</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tab-4-tab" data-toggle="tab" href="#tab-4" role="tab" aria-controls="tab-4" aria-selected="false">Menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tab-5-tab" data-toggle="tab" href="#tab-5" role="tab" aria-controls="tab-5" aria-selected="false">Book a Table</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="tab-6-tab" data-toggle="tab" href="#tab-6" role="tab" aria-controls="tab-6" aria-selected="false">Photos</a>
                    </li>
                </ul>
                <div class="row">
                    <div class="col-md-8">
                        <div class="tab-content tab-content-border" id="tab-content-1">
                            <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab-1-tab">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="bg-light p-4">
                                            <h4>GET 10% OFF</h4>
                                            <p>Become a Zomato Pro member and enjoy 10% Off every time at Asteria.</p>

                                        </div>

                                        <div class="about-this mt-3">
                                            <h3>About this place</h3>
                                            <ul class="pt-2">
                                                <li class=" pr-2"> Well Senitized Kitchen </li>
                                                <li class=" pr-2"> Daliy Temperature Check </li>
                                                <li class=" pr-2"> Clean Floors and sitings </li>
                                                <li class=" pr-2"> Hygenic Food</li>

                                            </ul>
                                        </div>
                                        <hr>
                                        <div class="menus">
                                            <h3>Menus</h3>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <a href="assets/images/p1.jpg"><img src="assets/images/p1.jpg" alt="">
                                                        <h6 class="mt-2">Food Menu</h6>
                                                    </a>
                                                </div>
                                                <div class="col-md-4">

                                                    <a href="assets/images/p1.jpg">
                                                        <img src="assets/images/p1.jpg" alt="">
                                                        <h6 class="mt-2">Beverages</h6>
                                                    </a>
                                                </div>
                                                <div class="col-md-4">

                                                    <a href="assets/images/p1.jpg"><img src="assets/images/p1.jpg" alt="">
                                                        <h6 class="mt-2">Bar Menu</h6>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="cuisines">
                                            <h3>Cuisines</h3>
                                            <ul class="pt-1">
                                                <li class="pr-2"> Bar Food </li>
                                                <li class="pr-2"> North Indian </li>
                                                <li class="pr-2"> Italian</li>
                                                <li class="pr-2"> Chinese</li>
                                                <li class="pr-2"> Deresset</li>
                                                <li class="pr-2"> Beverages</li>

                                            </ul>

                                            <h4 class="mt-2">Popular Dishes</h4>
                                            <p>Chocolate Dessert, Mint Ice Tea, White Wine, Farmhouse Pizza, Sangria, Cheesy Garlic Bread</p>
                                            <h4 class="mt-2">People Say This Place Is Known For</h4>
                                            <p>Live Band Performance, Nightlife, Great Environment, Fun Place, Beautiful View, Amazing View</p>
                                            <h4 class="mt-2">Average Cost</h4>
                                            <p>₹1,000 for two people (approx.) Without alcohol</p>
                                            <span>Exclusive of applicable taxes and charges, if any</span>

                                            <p>₹250 for a pint of beer (approx.)</p>

                                            <p><strong>Cash and Cards accepted</strong></p>
                                        </div>
                                        <hr>
                                        <div class="More-infos">
                                            <h3>More Info</h3>
                                            <ul>
                                                <li class="pr-2"> Home Delivery </li>
                                                <li class="pr-2"> Takeaway Available </li>
                                                <li class="pr-2"> Full Bar Available</li>
                                                <li class="pr-2"> Seating Available</li>
                                                <li class="pr-2"> Romantic Dining</li>
                                                <li class="pr-2"> Table reservation required</li>
                                                <li class="pr-2"> Indoor Seating</li>
                                                <li class="pr-2"> Rooftop</li>
                                            </ul>


                                        </div>
                                        <hr>
                                        <div class="rate-order-box">
                                            <h3>Rate your experience for</h3>
                                            <form>
                                                <input type="radio" id="dining" name="fav_language" value="dining">
                                                <label for="dining">Dining</label><br>
                                                <input type="radio" id="delivery" name="fav_language" value="delivery">
                                                <label for="delivery">Delivery</label><br>

                                            </form>
                                            <a href="login.php" style="font-size: 17px;font-weight:400">Write a Review <i class="icon-long-arrow-right"></i></a>
                                        </div>
                                        <hr>

                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab-2-tab">
                                <div class="row">
                                    <div class="">

                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab-3-tab">
                                <div class="row">
                                    <div class="co-md-12">
                                        <div class="comments">
                                            <h4>Resturant Reviews</h4>

                                            <ul class="mt-2">
                                                <li>
                                                    <div class="comment">
                                                        <figure class="comment-media">
                                                            <a href="#">
                                                                <img src="assets/images/1.jpg" alt="User name">
                                                            </a>
                                                        </figure>

                                                        <div class="comment-body">
                                                            <a href="#" class="comment-reply">Reply</a>
                                                            <div class="comment-user">
                                                                <h4><a href="#">Jimmy Pearson</a></h4>
                                                                <span class="comment-date">November 9, 2018 at 2:19 pm</span>
                                                            </div><!-- End .comment-user -->
                                                            <div class="ratings-container mb-0">
                                                                <div class="ratings">
                                                                    <div class="ratings-val" style="width: 60%;"></div>
                                                                    <!-- End .ratings-val -->
                                                                </div>
                                                                <!-- End .ratings -->
                                                                <span class="ml-2"> <b>4.4 </b></span>

                                                            </div>
                                                            <div class="comment-content">
                                                                <p>Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. </p>
                                                            </div><!-- End .comment-content -->
                                                        </div><!-- End .comment-body -->
                                                    </div><!-- End .comment -->


                                                </li>

                                                <li>
                                                    <div class="comment">
                                                        <figure class="comment-media">
                                                            <a href="#">
                                                                <img src="assets/images/1.jpg" alt="User name">
                                                            </a>
                                                        </figure>

                                                        <div class="comment-body">
                                                            <a href="#" class="comment-reply">Reply</a>
                                                            <div class="comment-user">
                                                                <h4><a href="#">Johnathan Castillo</a></h4>
                                                                <span class="comment-date">November 9, 2018 at 2:19 pm</span>
                                                            </div>
                                                            <div class="ratings-container mb-0">
                                                                <div class="ratings">
                                                                    <div class="ratings-val" style="width: 60%;"></div>

                                                                </div>

                                                                <span class="ml-2"> <b>4.4 </b></span>

                                                            </div>
                                                            <div class="comment-content">
                                                                <p>Vestibulum volutpat, lacus a ultrices sagittis, mi neque euismod dui, eu pulvinar nunc sapien ornare nisl. Phasellus pede arcu, dapibus eu, fermentum et, dapibus sed, urna.</p>
                                                            </div>
                                                            <div class="content_wrapper_text">
                                                                <button id="myShowHidebtn" class="btn btn-primary">Comment</button>
                                                                <hr>
                                                                <div class="form-group">
                                                                    <input type="text" style="display:none;" class="form-control" name="comment">
                                                                </div>
                                                            </div>
                                                            <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
                                                            <script>
                                                                $(document).ready(function() {
                                                                    $("button").click(function() {
                                                                        $("input").stop(true).toggle("slow");
                                                                        $("#myShowHidebtn").text(function(i, t) {
                                                                            return t == 'Comment' ? 'Comment' : 'Comment';
                                                                        });
                                                                    });
                                                                });
                                                            </script>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="tab-4" role="tabpanel" aria-labelledby="tab-4-tab">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h4>
                                            Resturant Menu
                                        </h4>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="assets/images/p1.jpg" download>
                                            <img src="assets/images/p1.jpg" alt="">
                                            <h6 class="mt-2">Food Menu</h6>
                                        </a>
                                    </div>
                                    <div class="col-md-4">

                                        <a href="assets/images/p1.jpg" download>
                                            <img src="assets/images/p1.jpg" alt="">
                                            <h6 class="mt-2">Beverages</h6>
                                        </a>
                                    </div>
                                    <div class="col-md-4">

                                        <a href="assets/images/p1.jpg" download>
                                            <img src="assets/images/p1.jpg" alt="">
                                            <h6 class="mt-2">Bar Menu</h6>
                                        </a>
                                    </div>


                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="retated-to-restro">
                                            <h5>RELATED TO Resturant, DURGAPURA</h5>
                                            <p>Restaurants in Jaipur, Jaipur Restaurants, Durgapura restaurants, Best Durgapura restaurants, South Jaipur restaurants, Casual Dining in Jaipur, Casual Dining near me, Casual Dining in Durgapura, Lounge in Jaipur, Lounge near me, Lounge in Durgapura, in Jaipur, near me, in Durgapura, Order food online in Durgapura, Order food online in Jaipur</p>
                                            <h5>RESTAURANTS AROUND DURGAPURA</h5>
                                            <p>Mansarovar restaurants, Tonk Road restaurants, Tonk Phatak restaurants, Malviya Nagar restaurants</p>
                                            <h5>FREQUENT SEARCHES LEADING TO THIS PAGE</h5>
                                            <p>Resturant, zomato jaipur, asteria jaipur rajasthan, asteria menu, asteria durgapura menu</p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab-5" role="tabpanel" aria-labelledby="tab-5-tab">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h4>
                                            Book Your Table In Advance
                                        </h4>
                                    </div>



                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="table-book-f">
                                            <form action="#" class="contact-form mb-3">
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <label for="cname" class="sr-only">Name</label>
                                                        <input type="text" class="form-control" id="cname" placeholder="Name *" required="">
                                                    </div><!-- End .col-sm-6 -->

                                                    <div class="col-sm-6">
                                                        <label for="cemail" class="sr-only">Email</label>
                                                        <input type="email" class="form-control" id="cemail" placeholder="Email *" required="">
                                                    </div><!-- End .col-sm-6 -->
                                                </div><!-- End .row -->

                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <label for="cphone" class="sr-only">Phone</label>
                                                        <input type="tel" class="form-control" id="cphone" placeholder="Phone">
                                                    </div><!-- End .col-sm-6 -->

                                                    <div class="col-sm-6">
                                                        <label for="csubject" class="sr-only">Table book</label>

                                                        <select name="" class="form-control" id="table">
                                                            <option value="1">1</option>
                                                            <option value="2">2</option>
                                                            <option value="3">3</option>
                                                        </select>
                                                    </div><!-- End .col-sm-6 -->
                                                </div><!-- End .row -->

                                                <label for="cmessage" class="sr-only">Message</label>
                                                <textarea class="form-control" cols="30" rows="4" id="cmessage" required="" placeholder="Message *"></textarea>

                                                <button type="submit" class="btn btn-outline-primary-2">
                                                    <span>Book</span>
                                                    <i class="icon-long-arrow-right"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="tab-6" role="tabpanel" aria-labelledby="tab-6-tab">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h4>
                                            Gallery
                                        </h4>
                                    </div>
                                    <div class="col-md-4">
                                        <a href="assets/images/p1.jpg" >
                                            <img src="assets/images/p1.jpg" alt="" style="border-radius: 10px;">
                                            <h6 class="mt-2">Food Menu</h6>
                                        </a>
                                    </div>
                                    <div class="col-md-4">

                                        <a href="assets/images/p1.jpg" >
                                            <img src="assets/images/p1.jpg" alt="" style="border-radius: 10px;">
                                            <h6 class="mt-2">Beverages</h6>
                                        </a>
                                    </div>
                                    <div class="col-md-4">

                                        <a href="assets/images/p1.jpg" >
                                            <img src="assets/images/p1.jpg" alt="" style="border-radius: 10px;">
                                            <h6 class="mt-2">Bar Menu</h6>
                                        </a>
                                    </div>


                                </div>
                                
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="restro-call-map">
                            <h4>Call</h4>
                            <p> <a href="">+91 9807895643</a>     </p>
                             <p><a href="">+91 9807895643</a>             </p>   
                             <h4>Location</h4>             
                             <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.6834031057488!2d75.75614591491475!3d26.881798067891925!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db4f798006cbb%3A0x1ba3f77f1a1f2382!2sCoral%20IT%20Solutions!5e0!3m2!1sen!2sin!4v1627555108926!5m2!1sen!2sin" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>      
                        </div>
                    </div>
                </div>
            </div>


        </div>

    </div>
</main><!-- End .main -->
</div>
<?php
include("footer.php")
?>