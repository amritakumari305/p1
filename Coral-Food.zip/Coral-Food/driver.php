<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="offers-banners bg-dark mt-13 py-4">
        <div class="container deal-section">
            <div class="row">
                <div class="col-md-6">
                    <div class="driver-box p-2 mt-7">
                        <h3 class="text-white">Become Our Delivery Patner</h3>
                        <span>Start and stop when you want</span>
                        <p><strong>Resigter Yourself with us to become Our delivery patner</strong></p>
                        <p>As a Dasher, you can be your own boss and enjoy the flexibility of choosing when, where, and how much you earn. All you need is a mode of transportation and a smartphone to start making money. It’s that simple.</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-box">
                        <div class="form-tab">
                            <div class="loging-heading ">
                                <h5 class="">Resigter For Driver</h5>
                            </div>


                            <div class="tab-pane">
                                <form action="#">
                                    <div class="form-group">
                                        <label for="singin-name-2">Full Name *</label>
                                        <input type="text" class="form-control" id="singin-name-2" name="singin-name" required>
                                    </div><!-- End .form-group -->
                                    <div class="form-group">
                                        <label for="singin-email-2">Email Address *</label>
                                        <input type="text" class="form-control" id="singin-email-2" name="singin-email" required>
                                    </div><!-- End .form-group -->

                                    <div class="form-group">
                                        <label for="singin-number-2">Number *</label>
                                        <input type="text" class="form-control" id="singin-number-2" name="singin-number" required>
                                    </div><!-- End .form-group -->

                                    <div class="form-footer">


                                        <button type="submit" class="btn btn-outline-primary-2">
                                            <span>Submit</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </button>
                                    </div>

                                </form>

                            </div><!-- .End .tab-pane -->


                        </div><!-- End .form-tab -->
                    </div><!-- End .form-box -->
                </div>
            </div>
        </div>



    </div>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12 ">
                <h3 class="text-center">Why deliver with CoralFood</h3>
            </div>
        </div>
        <div class="row justify-content-center mt-4">

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/purse.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Earn extra money</h5>

                        <p>Achieve your short-term goals or long-term dreams by driving or biking with CoralFood.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/calendar.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Choose your own hours</h5>

                        <p>Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/gps.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Freedom to dash anywhere</h5>

                        <p>Unlike full-time jobs or seasonal gigs, when and where you work is totally up to you.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/checklist.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Easy to get started</h5>

                        <p>Deliver near your home or in a city you're just visiting.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/notifications.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Receive deliveries right away</h5>

                        <p>Once approved, log on to the Dasher app to receive nearby orders immediately. </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/search.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Know how much you'll make</h5>

                        <p>Clear and concise pay model lets you know how much you will make before accepting any order.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    
</main><!-- End .main -->
</div>

<?php
include("footer.php")
?>