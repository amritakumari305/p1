<?php 
include("header.php");
include("menu.php");
?>

<main class="main">
    <div class="page-content mt-12">
            
            <div class="login-page pt-2 pb-4">
            	<div class="container">
            		<div class="form-box">
            			<div class="form-tab">
	            			<div class="loging-heading text-center">
                                <h2 class="">Login</h2>
                            </div>
							
                                
							    <div class="tab-pane">
							    	<form action="#">
							    		<div class="form-group">
							    			<label for="singin-email-2">Username or email address *</label>
							    			<input type="text" class="form-control" id="singin-email-2" name="singin-email" required>
							    		</div><!-- End .form-group -->

							    		<div class="form-group">
							    			<label for="singin-password-2">Password *</label>
							    			<input type="password" class="form-control" id="singin-password-2" name="singin-password" required>
							    		</div><!-- End .form-group -->

							    		<div class="form-footer">
                                            <div class="custom-control custom-checkbox">
												<input type="checkbox" class="custom-control-input" id="signin-remember-2">
												<label class="custom-control-label" for="signin-remember-2">Remember Me</label>
											</div>

							    			<button type="submit" class="btn btn-outline-primary-2">
			                					<span>LOG IN</span>
			            						<i class="icon-long-arrow-right"></i>
			                				</button>

			                				<div class="text-right">
                                            <a href="#" class="forgot-link">Forgot Your Password?</a>
                                            </div>

											<div>Don't Have Account?
                                            <a href="register.php" class="forgot-link text-danger"> Register</a>
                                            </div>
							    		</div>
                                        
							    	</form>
							    	<div class="form-choice">
								    	<p class="text-center">or sign in with</p>
								    	<div class="row">
								    		<div class="col-sm-6">
								    			<a href="#" class="btn btn-login btn-g">
								    				<i class="icon-google"></i>
								    				Login With Google
								    			</a>
								    		</div><!-- End .col-6 -->
								    		<div class="col-sm-6">
								    			<a href="#" class="btn btn-login btn-f">
								    				<i class="icon-facebook-f"></i>
								    				Login With Facebook
								    			</a>
								    		</div><!-- End .col-6 -->
								    	</div><!-- End .row -->
							    	</div><!-- End .form-choice -->
							    </div><!-- .End .tab-pane -->
							   
							
						</div><!-- End .form-tab -->
            		</div><!-- End .form-box -->
            	</div><!-- End .container -->
            </div>
    </div>
</main>
</div>
<?php 
include("footer.php")
?>