<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Food</title>

    <link rel="shortcut icon" href="assets/images/c2.png" type="image/png" />
    <!-- Plugins CSS File -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/plugins/owl-carousel/owl.carousel.css">

    <link rel="stylesheet" href="assets/css/plugins/magnific-popup/magnific-popup.css">
    <!-- Main CSS File -->
    <link rel="stylesheet" href="assets/css/stylef.css">
    <link rel="stylesheet" href="assets/css/demos/carousel-layout.css">
    <link rel="stylesheet" href="assets/css/demos/democ.css">
    <style>
        .header-left .select-custom select {
            line-height: 34px;
            height: 34px;
            font-weight: 400;
            width: 100%;
            border: none;
            color: #fff;
            padding: .1rem 4rem .1rem .1rem;
            border-radius: 0;
            -moz-appearance: none;
            -webkit-appearance: none;
            font-size: 1.4rem;
            letter-spacing: 0;
            background-color: transparent;
            margin: 0;
            word-wrap: normal;
        }
        
        .header-left .select-custom select option {
            font-size: 1.3rem;
            padding: .1rem .3rem;
            color: #000;
            font-weight: 400;
            flex: 0 0 200px;
            max-width: 200px;
        }
        
        .header-left .select-custom {
            flex: 0 0 220px;
            max-width: 220px;
            padding-right: 0;
            margin: 0;
            align-self: center;
        }
        
        .select-custom::after {
            right: 2rem;
            color: #fff;
            font-size: 1.2rem;
        }
    </style>
</head>