<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="cta bg-image bg-dark pt-3 pb-3 mt-13" style="background-image: url(assets/images/footer-bg-1.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center">
                        <h4 class="text-white">Which type of business do you want to sign up with today?</h4>
                    </div>
                </div>
            </div>
            <div class="row mt-5">

                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="d-features-boxs text-center">
                        <center> <img src="assets/images/driver/online-shop.png" alt="" width="70"></center>
                        <h5 class="mt-2 mb-1">Restaurant</h5>
                        <p>Pickup and delivery options</p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Register</button>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="d-features-boxs text-center">
                        <center> <img src="assets/images/driver/liquor.png" alt="" width="70"></center>
                        <h5 class="mt-2 mb-1">Liquor Store</h5>
                        <p>Available in selected states.</p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Register</button>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="d-features-boxs text-center">
                        <center> <img src="assets/images/driver/food.png" alt="" width="70"></center>
                        <h5 class="mt-2 mb-1">Convenience Store</h5>
                        <p>Groceries and household items</p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Register</button>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                    <div class="d-features-boxs text-center">
                        <center><img src="assets/images/driver/customer-service.png" alt="" width="70"></center>
                        <h5 class="mt-2 mb-1">Other</h5>
                        <p>Something else </p>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Register</button>
                    </div>
                </div>
            </div>
            <!-- The Modal -->
            <div class="modal fade" id="myModal">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">

                        <!-- Modal Header -->
                        <div class="modal-header">

                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">
                            <div class="form-box my-3">
                                <div class="loging-heading">
                                    <h4 class="">Sign up for your 30-day free trial</h4>
                                </div>
                                <form action="#">
                                    <div class="form-group">
                                        <label for="singin-email-2">Username or email address *</label>
                                        <input type="text" class="form-control" id="singin-email-2" name="singin-email" required>
                                    </div><!-- End .form-group -->
                                    <div class="form-group">
                                        <label for="singin-name-2">Full Name *</label>
                                        <input type="text" class="form-control" id="singin-name-2" name="singin-name" required>
                                    </div><!-- End .form-group -->
                                    <div class="form-group">
                                        <label for="singin-no-2">Phone No. *</label>
                                        <input type="text" class="form-control" id="singin-no-2" name="singin-no" required>
                                    </div><!-- End .form-group -->

                                    <div class="form-group">
                                        <label for="singin-password-2">Password *</label>
                                        <input type="password" class="form-control" id="singin-password-2" name="singin-password" required>
                                    </div><!-- End .form-group -->

                                    <div class="form-footer">


                                        <button type="submit" class="btn btn-outline-primary-2">
                                            <span>Sign Up</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </button>

                                        <div class="text-right">Already Register?
                                            <a href="login.php" class="forgot-link text-danger"> Login</a>
                                        </div>


                                    </div>
                                    <span display="block">By clicking Sign up, Continue with Facebook, Continue with Google or Continue with Apple, you agree to our <a href="#">Terms and Conditions</a> and <a href="#">Privacy Statement</a>.</span>
                                </form>
                                <p></p>
                                <div class="form-choice">
                                    <p class="text-center">or sign in with</p>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <a href="#" class="btn btn-login btn-g">
                                                <i class="icon-google"></i>
                                                Login With Google
                                            </a>
                                        </div><!-- End .col-6 -->
                                        <div class="col-sm-6">
                                            <a href="#" class="btn btn-login btn-f">
                                                <i class="icon-facebook-f"></i>
                                                Login With Facebook
                                            </a>
                                        </div><!-- End .col-6 -->
                                    </div><!-- End .row -->
                                </div><!-- End .form-choice -->




                            </div><!-- End .form-box -->
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12 ">
                <h3 class="text-center">Why register with CoralFood</h3>
            </div>
        </div>
        <div class="row justify-content-center mt-4">

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/operator.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Reach new customers</h5>

                        <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue.</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/financial-profit.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Increase your sales</h5>

                        <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-sm-6">
                <div class="icon-box text-center">
                    <span class="icon-box-icon">
                        <img src="assets/images/driver/phone.png" alt="">
                    </span>
                    <div class="icon-box-content">
                        <h5>Build brand awareness</h5>

                        <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue.</p>
                    </div>
                </div>
            </div>


        </div>
    </div>


    <div class="video-banner video-banner-bg bg-image text-center" style="background-image: url(assets/images/newslt.jpg)">
        <div class="container">
            <h3 class="video-banner-title h1 text-white"><span>New Video</span><strong>"We want to share our love of food from our family with the whole world"</strong></h3><!-- End .video-banner-title -->
            <a href="https://youtu.be/-HgDBmJZB5c" class="btn-video btn-iframe"><i class="icon-play"></i></a>
        </div><!-- End .container -->
    </div>

    <div class="brand-section mt-1 mb-3">
        <div class="container py-2 pt-0">
            <div class="owl-carousel owl-simple rows cols-2 cols-xs-3 cols-md-4 cols-lg-6 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                    &quot;nav&quot;: false, &quot;loop&quot;: false, &quot;dots&quot;: false, &quot;margin&quot;:0,&quot;responsive&quot;: {
                    &quot;0&quot;: {
                        &quot;items&quot;:2
                    },
                    &quot;480&quot;: {
                        &quot;items&quot;:3
                    },
                    &quot;768&quot;: {
                        &quot;items&quot;:4
                    },
                    &quot;992&quot;: {
                        &quot;items&quot;:6
                    }
                }
            }">

                <div class="owl-stage-outer">
                    <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0.4s ease 0s; width: 1400px;">
                        <div class="owl-item active" style="width: 233.333px;">
                            <a href="#" class="brand"><img src="assets/images/icons/1b.png"></a>
                        </div>
                        <div class="owl-item active" style="width: 233.333px;">
                            <a href="#" class="brand"><img src="assets/images/icons/2b.png"></a>
                        </div>
                        <div class="owl-item active" style="width: 233.333px;">
                            <a href="#" class="brand"><img src="assets/images/icons/3b.png"></a>
                        </div>
                        <div class="owl-item active" style="width: 233.333px;">
                            <a href="#" class="brand"><img src="assets/images/icons/4b.png"></a>
                        </div>
                        <div class="owl-item active" style="width: 233.333px;">
                            <a href="#" class="brand"><img src="assets/images/icons/5b.png"></a>
                        </div>
                        <div class="owl-item active" style="width: 233.333px;">
                            <a href="#" class="brand"><img src="assets/images/icons/7b.png"></a>
                        </div>
                        <div class="owl-item active" style="width: 233.333px;">
                            <a href="#" class="brand"><img src="assets/images/icons/8b.png"></a>
                        </div>
                    </div>
                </div>
                <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="icon-angle-right"></i></button></div>
                <div class="owl-dots disabled"></div>
            </div>
        </div>
    </div>
</main><!-- End .main -->
</div>
<?php
include("footer.php")
?>