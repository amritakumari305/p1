<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="offers-banners bg-dark mt-13 py-2" style="background-image: url(assets/images/header-bg.png);">
        <div class="container deal-section">
            <div class="row">
                <div class="col-md-12">
                    <div class="driver-box text-center pb-3 mt-3">
                        <h3 class="text-white">
                            Trending This Week
                        </h3>

                        <p><strong>Most popular restaurants in town this week</strong></p>
                        <span>30 Place(s)</span>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="container pt-3">
        <div class="row">
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="restroview.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h3 class="product-title"><a href="">Title Here</a></h3>



                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 60%;"></div>
                                <!-- End .ratings-val -->
                            </div>
                            <!-- End .ratings -->
                            <span class=" ml-2"> <b>4.4 ( 4 Reviews )</b></span>
                        </div>
                        <span>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages Durgapura</span>
                        <hr class="mt-0 mb-1">
                        <div class="Zlfdx"><b style="color: #dc3545;">Pro - Get 10% Off</b></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="restroview.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h3 class="product-title"><a href="">Title Here</a></h3>



                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 60%;"></div>
                                <!-- End .ratings-val -->
                            </div>
                            <!-- End .ratings -->
                            <span class=" ml-2"> <b>4.4 ( 4 Reviews )</b></span>
                        </div>
                        <span>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages Durgapura</span>
                        <hr class="mt-0 mb-1">
                        <div class="Zlfdx"><b style="color: #dc3545;">Pro - Get 10% Off</b></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="restroview.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h3 class="product-title"><a href="">Title Here</a></h3>



                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 60%;"></div>
                                <!-- End .ratings-val -->
                            </div>
                            <!-- End .ratings -->
                            <span class=" ml-2"> <b>4.4 ( 4 Reviews )</b></span>
                        </div>
                        <span>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages Durgapura</span>
                        <hr class="mt-0 mb-1">
                        <div class="Zlfdx"><b style="color: #dc3545;">Pro - Get 10% Off</b></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="restroview.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h3 class="product-title"><a href="">Title Here</a></h3>



                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 60%;"></div>
                                <!-- End .ratings-val -->
                            </div>
                            <!-- End .ratings -->
                            <span class=" ml-2"> <b>4.4 ( 4 Reviews )</b></span>
                        </div>
                        <span>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages Durgapura</span>
                        <hr class="mt-0 mb-1">
                        <div class="Zlfdx"><b style="color: #dc3545;">Pro - Get 10% Off</b></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="restroview.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h3 class="product-title"><a href="">Title Here</a></h3>



                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 60%;"></div>
                                <!-- End .ratings-val -->
                            </div>
                            <!-- End .ratings -->
                            <span class=" ml-2"> <b>4.4 ( 4 Reviews )</b></span>
                        </div>
                        <span>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages Durgapura</span>
                        <hr class="mt-0 mb-1">
                        <div class="Zlfdx"><b style="color: #dc3545;">Pro - Get 10% Off</b></div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="restroview.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h3 class="product-title"><a href="">Title Here</a></h3>



                        <div class="ratings-container">
                            <div class="ratings">
                                <div class="ratings-val" style="width: 60%;"></div>
                                <!-- End .ratings-val -->
                            </div>
                            <!-- End .ratings -->
                            <span class=" ml-2"> <b>4.4 ( 4 Reviews )</b></span>
                        </div>
                        <span>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages Durgapura</span>
                        <hr class="mt-0 mb-1">
                        <div class="Zlfdx"><b style="color: #dc3545;">Pro - Get 10% Off</b></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main><!-- End .main -->
</div>
<?php
include("footer.php")
?>
