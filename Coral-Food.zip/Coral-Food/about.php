<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="page-header text-center mt-12" style="background-image: url('assets/images/page-header-bg.jpg')">
        <div class="container">
            <h1 class="page-title">About Us</h1>
        </div>
        <!-- End .container -->
    </div>
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="#">About</a></li>
                
            </ol>
        </div>
        <!-- End .container -->
    </nav>
    <div class="page-content pb-0">
                <div class="container">
                    <div class="row">
                         
                        <div class="col-lg-6 mb-3 mb-lg-0">
                            <h4 class="">Our Vision</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Phasellus hendrerit. Pellentesque aliquet nibh nec urna. In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. </p>
                        </div>
                        
                        <div class="col-lg-6">
                            <h4 class="">Our Mission</h4>
                            <p>Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus libero, faucibus adipiscing, commodo quis, gravida id, est. Sed lectus. <br>Praesent elementum hendrerit tortor. Sed semper lorem at felis. </p>
                        </div>
                    </div>

                    <div class="mb-5"></div>
                </div>

                <div class="bg-light-2 pt-3 pb-3 mb-3">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 mb-3 mb-lg-0">
                                <h4 class="">Who We Are</h4>
                                <p class="lead text-primary mb-3">Pellentesque odio nisi, euismod pharetra a ultricies <br>in diam. Sed arcu. Cras consequat</p><!-- End .lead text-primary -->
                                <p class="mb-2">Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Suspendisse potenti. Sed egestas, ante et vulputate volutpat, uctus metus libero eu augue. </p>

                                <a href="blog.php" class="btn btn-sm btn-minwidth btn-outline-primary-2">
                                    <span>VIEW OUR NEWS</span>
                                    <i class="icon-long-arrow-right"></i>
                                </a>
                            </div>

                            <div class="col-lg-6 offset-lg-1">
                                <div class="about-images">
                                    
                                    <img src="assets/images/pub1.jpg" alt=""  width="100%">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

               

                <div class="about-testimonialspt-6 pb-2">
                    <div class="container">
                        <h4 class="text-center mb-1">What Customer Say About Us</h4>

                        <div class="owl-carousel owl-simple owl-testimonials-photo" data-toggle="owl" 
                            data-owl-options='{
                                "nav": false, 
                                "dots": true,
                                "margin": 20,
                                "loop": false,
                                "responsive": {
                                    "1200": {
                                        "nav": true
                                    }
                                }
                            }'>
                            <blockquote class="testimonial text-center">
                               
                                <p> “ Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Pellentesque aliquet nibh nec urna. <br>In nisi neque, aliquet vel, dapibus id, mattis vel, nisi. Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Nullam mollis. Ut justo. Suspendisse potenti. ”</p>
                                <span class="mt-5">
                                   
                                    <b class="pt-3">Customer</b>
                                </span>
                            </blockquote>

                            <blockquote class="testimonial text-center">
                               
                                <p>“ Impedit, ratione sequi, sunt incidunt magnam et. Delectus obcaecati optio eius error libero perferendis nesciunt atque dolores magni recusandae! Doloremque quidem error eum quis similique doloribus natus qui ut ipsum.Velit quos ipsa exercitationem, vel unde obcaecati impedit eveniet non. ”</p>

                                <cite >
                                   
                                    <b class="pt-3">Customer</b>
                                </cite>
                            </blockquote>
                        </div>
                    </div>
                </div>
            </div>

</main><!-- End .main -->
</div>
<?php
include("footer.php")
?>