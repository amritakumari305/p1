<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="page-header text-center mt-12" style="background-image: url('assets/images/page-header-bg.jpg')">
        <div class="container">
            <h1 class="page-title">My Account</h1>
        </div>
        <!-- End .container -->
    </div>
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="#">My Account</a></li>
            </ol>
        </div>
        <!-- End .container -->
    </nav>
    <div class="page-content">
        <div class="dashboard">
            <div class="container">


                <div class="row">
                    <aside class="col-md-4 col-lg-3">
                        <ul class="nav nav-dashboard flex-column mb-3" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link" id="tab-dashboard-link" data-toggle="tab" href="#tab-dashboard" role="tab" aria-controls="tab-dashboard" aria-selected="false">Dashboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-orders-link" data-toggle="tab" href="#tab-orders" role="tab" aria-controls="tab-orders" aria-selected="false">Orders</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-favourites-link" data-toggle="tab" href="#tab-favourites" role="tab" aria-controls="tab-favourites" aria-selected="false">Favourites</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="tab-address-link" data-toggle="tab" href="#tab-address" role="tab" aria-controls="tab-address" aria-selected="false">Adresses</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" id="tab-account-link" data-toggle="tab" href="#tab-account" role="tab" aria-controls="tab-account" aria-selected="true">Account Details</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Sign Out</a>
                            </li>
                        </ul>
                    </aside><!-- End .col-lg-3 -->

                    <div class="col-md-8 col-lg-9">
                        <div class="tab-content">
                            <div class="tab-pane fade" id="tab-dashboard" role="tabpanel" aria-labelledby="tab-dashboard-link">
                                <div class="row pt-2 pb-1">
                                    <div class="col-md-9">
                                        <h4>Coral Food</h4>
                                        <p><a href=""><b>+91 9532177425</b></a> <a href=""><b>+91 9532177425</b></a></p>
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" class="btn btn-outline-primary-2">
                                            <span>Edit</span>
                                            <i class="icon-long-arrow-right"></i>
                                        </button>
                                    </div>
                                </div>
                            </div><!-- .End .tab-pane -->

                            <div class="tab-pane fade" id="tab-orders" role="tabpanel" aria-labelledby="tab-orders-link">
                                <h4>Past Orders</h4>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="past-order">
                                            <div class="name-rset">

                                                <div class="_3h4gz">Thali central</div>
                                                <div class="_2haEe">Vaishali Nagar</div>
                                                <div class="_2uT6l">ORDER #110790205894 | Sat, Jul 31, 2021, 12:33 PM</div>
                                                <div class="_1ziWV">VIEW DETAILS</div>
                                                <div class="_2fkm7"><span>Delivered on Sat, Jul 31, 2021, 01:33 PM<span class="h-Ntp"><i class="icon-check"></i></span></span></div>

                                            </div>
                                            <div class="div-brd"></div>
                                            <div class="_3SKK0">
                                                <div class="nRCg_">Midi Punjabi Thali x 1</div>
                                                <div class="_2a27y"><a class="_3PUy8 f4Ovn" href="">REORDER</a><a class="_3PUy8s" href="">HELP</a></div>
                                                <div class="_23DHc">Total Paid: <span class="_3Hghg"> 110 </span></div>
                                            </div>
                                        </div>



                                        <div class="past-order">
                                            <div class="name-rset">

                                                <div class="_3h4gz">Thali central</div>
                                                <div class="_2haEe">Vaishali Nagar</div>
                                                <div class="_2uT6l">ORDER #110790205894 | Sat, Jul 31, 2021, 12:33 PM</div>
                                                <div class="_1ziWV">VIEW DETAILS</div>
                                                <div class="_2fkm7"><span>Delivered on Sat, Jul 31, 2021, 01:33 PM<span class="h-Ntp"><i class="icon-check"></i></span></span></div>

                                            </div>
                                            <div class="div-brd"></div>
                                            <div class="_3SKK0">
                                                <div class="nRCg_">Midi Punjabi Thali x 1</div>
                                                <div class="_2a27y"><a class="_3PUy8 f4Ovn" href="">REORDER</a><a class="_3PUy8s" href="">HELP</a></div>
                                                <div class="_23DHc">Total Paid: <span class="_3Hghg"> 110 </span></div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div><!-- .End .tab-pane -->

                            <div class="tab-pane fade" id="tab-favourites" role="tabpanel" aria-labelledby="tab-favourites-link">
                                <h4>Favourites</h4>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="product product-7">
                                            <figure class="product-media">
                                                <span class="product-label label-sale">New</span>
                                                <a href="order.php">
                                                    <img src="assets/images/p4.jpg" alt="Product image" class="product-image">
                                                    <img src="assets/images/p4.jpg" alt="Product image" class="product-image-hover">
                                                </a>

                                                <div class="product-action">
                                                    <a href="order.php" class="btn-product"><span>Quick View</span></a>
                                                </div>



                                            </figure>

                                            <div class="product-body">
                                                <h3 class="product-title"><a href="">Title Here</a></h3>
                                                <span>Snacks</span>
                                                <div class="product-price">
                                                    <span class="new-price">54 Mins</span>
                                                    <span class="old-price float-right">Rs.80 for two</span>
                                                </div>
                                                <div class="ratings-container">
                                                    <div class="ratings">
                                                        <div class="ratings-val" style="width: 60%;"></div>
                                                        <!-- End .ratings-val -->
                                                    </div>
                                                    <!-- End .ratings -->
                                                    <span class="ratings-text ml-2"> 4.4 ( 4 Reviews )</span>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div><!-- .End .tab-pane -->

                            <div class="tab-pane fade" id="tab-address" role="tabpanel" aria-labelledby="tab-address-link">
                                <p>The following addresses will be used on the checkout page by default.</p>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="card card-dashboard">
                                            <div class="card-body">
                                                <h3 class="card-title">
                                                    Work</h3><!-- End .card-title -->

                                                <p>User Name<br>
                                                    User Company<br>
                                                    John str<br>
                                                    JAipur, Rajasthan 10001<br>
                                                    1-234-987-6543<br>
                                                    yourmail@mail.com<br>
                                                    <a href="#">Edit <i class="icon-edit"></i></a> 
                                                </p>
                                            </div><!-- End .card-body -->
                                        </div><!-- End .card-dashboard -->
                                    </div><!-- End .col-lg-6 -->

                                    <div class="col-lg-6">
                                        <div class="card card-dashboard">
                                            <div class="card-body">
                                                <h3 class="card-title">
                                                    Home</h3><!-- End .card-title -->

                                                <p>User Name<br>
                                                    User Company<br>
                                                    John str<br>
                                                    JAipur, Rajasthan 10001<br>
                                                    1-234-987-6543<br>
                                                    yourmail@mail.com<br>
                                                    <a href="#">Edit <i class="icon-edit"></i></a>
                                                </p>
                                            </div><!-- End .card-body -->
                                        </div><!-- End .card-dashboard -->
                                    </div><!-- End .col-lg-6 -->
                                </div><!-- End .row -->
                            </div><!-- .End .tab-pane -->

                            <div class="tab-pane fade active show" id="tab-account" role="tabpanel" aria-labelledby="tab-account-link">
                            <h4>Account Details</h4>
                                <form action="#">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label>First Name *</label>
                                            <input type="text" class="form-control" required="">
                                        </div><!-- End .col-sm-6 -->

                                        <div class="col-sm-6">
                                            <label>Last Name *</label>
                                            <input type="text" class="form-control" required="">
                                        </div><!-- End .col-sm-6 -->
                                    </div><!-- End .row -->

                                    <label>Display Name *</label>
                                    <input type="text" class="form-control" required="">
                                    <small class="form-text">This will be how your name will be displayed in the account section and in reviews</small>

                                    <label>Email address *</label>
                                    <input type="email" class="form-control" required="">

                                    <label>Current password (leave blank to leave unchanged)</label>
                                    <input type="password" class="form-control">

                                    <label>New password (leave blank to leave unchanged)</label>
                                    <input type="password" class="form-control">

                                    <label>Confirm new password</label>
                                    <input type="password" class="form-control mb-2">

                                    <button type="submit" class="btn btn-outline-primary-2">
                                        <span>SAVE CHANGES</span>
                                        <i class="icon-long-arrow-right"></i>
                                    </button>
                                </form>
                            </div><!-- .End .tab-pane -->
                        </div>
                    </div><!-- End .col-lg-9 -->
                </div><!-- End .row -->
            </div><!-- End .container -->
        </div><!-- End .dashboard -->
    </div>

</main><!-- End .main -->
</div>
<?php include("footer.php") ?>