<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="page-header text-center mt-12" style="background-image: url('assets/images/page-header-bg.jpg')">
        <div class="container">
            <h1 class="page-title">Offer</h1>
        </div>
        <!-- End .container -->
    </div>
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Offer</a></li>
            </ol>
        </div>
        <!-- End .container -->
    </nav>
    <div class="page-content pb-0">
        <div class="container my-5">
            <div class="row">
                <div class="col-sm-6">
                    <div class="coupon bg-light rounded mb-3 d-flex justify-content-between">
                        
                        <div class="tengah py-3 px-3 d-flex w-100 justify-content-start">
                            <div>
                                <span class="badge badge-success" style="font-size:14px">TRYNEW</span>
                                <h3 class="lead">Get 15% discount using Citi Bank Cards </h3>
                                <p class="text-muted mb-0">Maximum discount up to ₹300 on orders above ₹129</p>
                            </div>
                        </div>
                        <div class="kanan">
                            <div class="info m-3 d-flex align-items-center">
                                <div class="w-100">
                                    <div class="block">
                                        <span class="time font-weight-light">
                                            <span>19 days</span>
                                        </span>
                                    </div>
                                    <a href="#" target="_blank" class="btn btn-sm btn-outline-danger btn-block mt-2 w-100">
                                        Copy
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="coupon bg-light rounded mb-3 d-flex justify-content-between">
                        
                        <div class="tengah  py-3 px-3 d-flex w-100 justify-content-start">
                            <div>
                                <span class="badge badge-success" style="font-size:14px">TRYNEW</span>
                                <h3 class="lead">Get 15% discount using Citi Bank Cards </h3>
                                <p class="text-muted mb-0">Maximum discount up to ₹300 on orders above ₹129</p>
                            </div>
                        </div>
                        <div class="kanan">
                            <div class="info m-3 d-flex align-items-center">
                                <div class="w-100">
                                    <div class="block">
                                        <span class="time font-weight-light">
                                            <span>19 days</span>
                                        </span>
                                    </div>
                                    <a href="#" target="_blank" class="btn btn-sm btn-outline-danger btn-block mt-2 w-100">
                                        Copy 
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="coupon bg-light rounded mb-3 d-flex justify-content-between">
                        
                        <div class="tengah py-3 px-3 d-flex w-100 justify-content-start">
                            <div>
                                <span class="badge badge-success" style="font-size:14px">TRYNEW</span>
                                <h3 class="lead">Get 15% discount using Citi Bank Cards </h3>
                                <p class="text-muted mb-0">Maximum discount up to ₹300 on orders above ₹129</p>
                            </div>
                        </div>
                        <div class="kanan">
                            <div class="info m-3 d-flex align-items-center">
                                <div class="w-100">
                                    <div class="block">
                                        <span class="time font-weight-light">
                                            <span>19 days</span>
                                        </span>
                                    </div>
                                    <a href="#" target="_blank" class="btn btn-sm btn-outline-danger btn-block mt-2 w-100">
                                        Copy
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="coupon bg-light rounded mb-3 d-flex justify-content-between">
                        
                        <div class="tengah  py-3 px-3 d-flex w-100 justify-content-start">
                            <div>
                                <span class="badge badge-success" style="font-size:14px">TRYNEW</span>
                                <h3 class="lead">Get 15% discount using Citi Bank Cards </h3>
                                <p class="text-muted mb-0">Maximum discount up to ₹300 on orders above ₹129</p>
                            </div>
                        </div>
                        <div class="kanan">
                            <div class="info m-3 d-flex align-items-center">
                                <div class="w-100">
                                    <div class="block">
                                        <span class="time font-weight-light">
                                            <span>19 days</span>
                                        </span>
                                    </div>
                                    <a href="#" target="_blank" class="btn btn-sm btn-outline-danger btn-block mt-2 w-100">
                                        Copy 
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main><!-- End .main -->
</div>
<?php include("footer.php") ?>