<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="page-header text-center mt-12" style="background-image: url('assets/images/page-header-bg.jpg')">
        <div class="container">
            <h1 class="page-title">Blog</h1>
        </div>
        <!-- End .container -->
    </div>
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Blog</a></li>
            </ol>
        </div>
        <!-- End .container -->
    </nav>
    <div class="page-content">
        <div class="container">
            <article class="entry entry-list">
                <div class="row align-items-center">
                    <div class="col-md-4">
                        <figure class="entry-media">
                            <a href="blog-s.php">
                                <img src="assets/images/r2.jpg" alt="image desc">
                            </a>
                        </figure><!-- End .entry-media -->
                    </div><!-- End .col-md-4 -->

                    <div class="col-md-8">
                        <div class="entry-body">
                            <div class="entry-meta">
                                <span class="entry-author">
                                    by <a href="#">John Doe</a>
                                </span>
                                <span class="meta-separator">|</span>
                                <a href="#">Nov 22, 2018</a>
                                <span class="meta-separator">|</span>
                                <a href="#">2 Comments</a>
                            </div><!-- End .entry-meta -->

                            <h2 class="entry-title">
                                <a href="blog-s.php">Cras ornare tristique elit.</a>
                            </h2><!-- End .entry-title -->

                            <div class="entry-cats">
                                in <a href="#">Food</a>,
                                <a href="#">Restaurant</a>
                            </div><!-- End .entry-cats -->

                            <div class="entry-content">
                                <p>Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Suspendisse potenti. Sed egestas ... </p>
                                <a href="blog-s.php" class="read-more">Continue Reading</a>
                            </div><!-- End .entry-content -->
                        </div><!-- End .entry-body -->
                    </div><!-- End .col-md-8 -->
                </div><!-- End .row -->
            </article>

            <article class="entry entry-list">
                <div class="row align-items-center">
                    <div class="col-md-4">
                        <figure class="entry-media">
                            <a href="blog-s.php">
                                <img src="assets/images/r2.jpg" alt="image desc">
                            </a>
                        </figure><!-- End .entry-media -->
                    </div><!-- End .col-md-4 -->

                    <div class="col-md-8">
                        <div class="entry-body">
                            <div class="entry-meta">
                                <span class="entry-author">
                                    by <a href="#">John Doe</a>
                                </span>
                                <span class="meta-separator">|</span>
                                <a href="#">Nov 22, 2018</a>
                                <span class="meta-separator">|</span>
                                <a href="#">2 Comments</a>
                            </div><!-- End .entry-meta -->

                            <h2 class="entry-title">
                                <a href="blog-s.php">Cras ornare tristique elit.</a>
                            </h2><!-- End .entry-title -->

                            <div class="entry-cats">
                                in <a href="#">Food</a>,
                                <a href="#">Restaurant</a>
                            </div><!-- End .entry-cats -->

                            <div class="entry-content">
                                <p>Sed pretium, ligula sollicitudin laoreet viverra, tortor libero sodales leo, eget blandit nunc tortor eu nibh. Suspendisse potenti. Sed egestas ... </p>
                                <a href="blog-s.php" class="read-more">Continue Reading</a>
                            </div><!-- End .entry-content -->
                        </div><!-- End .entry-body -->
                    </div><!-- End .col-md-8 -->
                </div><!-- End .row -->
            </article>
        </div>
    </div>

</main><!-- End .main -->
</div>
<?php include("footer.php") ?>