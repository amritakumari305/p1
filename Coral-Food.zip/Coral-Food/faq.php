<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="page-header text-center mt-12" style="background-image: url('assets/images/page-header-bg.jpg')">
        <div class="container">
            <h1 class="page-title">Faq</h1>
        </div>
        <!-- End .container -->
    </div>
    <nav aria-label="breadcrumb" class="breadcrumb-nav">
        <div class="container">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Faq</a></li>
            </ol>
        </div>
        <!-- End .container -->
    </nav>
    <div class="page-content pb-0">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h4 class="mb-3">Profile</h4>
                    <div class="accordion accordion-rounded" id="accordion-5">
                        <div class="card card-box card-sm bg-light">
                            <div class="card-header" id="heading5-1">
                                <h2 class="card-title">
                                    <a role="button" data-toggle="collapse" href="#collapse5-1" aria-expanded="true" aria-controls="collapse5-1">
                                        Cras ornare tristique elit.
                                    </a>
                                </h2>
                            </div><!-- End .card-header -->
                            <div id="collapse5-1" class="collapse show" aria-labelledby="heading5-1" data-parent="#accordion-5">
                                <div class="card-body">
                                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum.
                                </div><!-- End .card-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .card -->

                        <div class="card card-box card-sm bg-light">
                            <div class="card-header" id="heading5-2">
                                <h2 class="card-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse5-2" aria-expanded="false" aria-controls="collapse5-2">
                                        Vivamus vestibulum ntulla
                                    </a>
                                </h2>
                            </div><!-- End .card-header -->
                            <div id="collapse5-2" class="collapse" aria-labelledby="heading5-2" data-parent="#accordion-5">
                                <div class="card-body">
                                    Ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.
                                </div><!-- End .card-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .card -->

                        <div class="card card-box card-sm bg-light">
                            <div class="card-header" id="heading5-3">
                                <h2 class="card-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse5-3" aria-expanded="false" aria-controls="collapse5-3">
                                        Praesent placerat risus
                                    </a>
                                </h2>
                            </div><!-- End .card-header -->
                            <div id="collapse5-3" class="collapse" aria-labelledby="heading5-3" data-parent="#accordion-5">
                                <div class="card-body">
                                    Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.
                                </div><!-- End .card-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .card -->
                    </div><!-- End .accordion -->
                </div><!-- End .col-md-6 -->

                <div class="col-md-6">
                <h4 class="mb-3">Account</h4>
                    <div class="accordion accordion-rounded accordion-plus" id="accordion-6">
                        <div class="card card-box card-sm bg-white">
                            <div class="card-header" id="heading6-1">
                                <h2 class="card-title">
                                    <a role="button" data-toggle="collapse" href="#collapse6-1" aria-expanded="true" aria-controls="collapse6-1">
                                        Cras ornare tristique elit.
                                    </a>
                                </h2>
                            </div><!-- End .card-header -->
                            <div id="collapse6-1" class="collapse show" aria-labelledby="heading6-1" data-parent="#accordion-6">
                                <div class="card-body">
                                    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum.
                                </div><!-- End .card-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .card -->

                        <div class="card card-box card-sm bg-white">
                            <div class="card-header" id="heading6-2">
                                <h2 class="card-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse6-2" aria-expanded="false" aria-controls="collapse6-2">
                                        Vivamus vestibulum ntulla
                                    </a>
                                </h2>
                            </div><!-- End .card-header -->
                            <div id="collapse6-2" class="collapse" aria-labelledby="heading6-2" data-parent="#accordion-6">
                                <div class="card-body">
                                    Ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.
                                </div><!-- End .card-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .card -->

                        <div class="card card-box card-sm bg-white">
                            <div class="card-header" id="heading6-3">
                                <h2 class="card-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapse6-3" aria-expanded="false" aria-controls="collapse6-3">
                                        Praesent placerat risus
                                    </a>
                                </h2>
                            </div><!-- End .card-header -->
                            <div id="collapse6-3" class="collapse" aria-labelledby="heading6-3" data-parent="#accordion-6">
                                <div class="card-body">
                                    Nullam malesuada erat ut turpis. Suspendisse urna nibh, viverra non, semper suscipit, posuere a, pede. Donec nec justo eget felis facilisis fermentum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec odio. Quisque volutpat mattis eros.
                                </div><!-- End .card-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .card -->
                    </div><!-- End .accordion -->
                </div><!-- End .col-md-6 -->
            </div>
        </div>
    </div>

</main><!-- End .main -->
</div>
<?php
include("footer.php")
?>