<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="offers-banners bg-dark mt-13 pt-2" style="background-image: url(assets/images/header-bg.png);">
        <div class="container deal-section">
            <div class="row">
                <div class="col-md-3">
                    <a href="assets/images/p1.jpg"><img src="assets/images/p1.jpg" alt="">
                        <h6 class="mt-2">Food Menu</h6>
                    </a>
                </div>
                <div class="col-md-6">
                    <div class="driver-box">
                        <h3 class="text-white">
                            Resturant Name
                        </h3>

                        <p><strong>Casual Dining, Lounge - Bar Food, North Indian, Italian, Chinese, Desserts, Beverages </strong></p>
                        <div class="mt-1"><span>Durgapura</span> <mark>Closing Soon</mark></div>
                        <div class="time-min-cost">
                            <ul class="d-flex">
                                <li class="right-b">
                                    <p> <i class="icon-star"></i> 3.8 <br> <span>100+ Ratings</span></p>

                                </li>
                                <li class="right-b">
                                    <p>26 mins <br> <span>Delivery Time</span></p>

                                </li>
                                <li>
                                    <p>₹ 100 <br> <span>Cost for two</span></p>

                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="offer-side-res mt-lg-5 mb-2">
                        <h5>OFFER</h5>
                        <p>
                            30% off on orders above ₹159</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-content pt-3">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <div class="toolbox">
                        <div class="toolbox-left">
                            <div class="toolbox-info">
                                Showing <span>9 of 56</span> Products
                            </div><!-- End .toolbox-info -->
                        </div><!-- End .toolbox-left -->

                        <div class="toolbox-right">
                            <div class="toolbox-sort">
                                <label for="sortby">Sort by:</label>
                                <div class="select-custom">
                                    <select name="sortby" id="sortby" class="form-control">
                                        <option value="popularity" selected="selected">Most Popular</option>
                                        <option value="rating">Most Rated</option>
                                        <option value="date">Date</option>
                                    </select>
                                </div>
                            </div><!-- End .toolbox-sort -->

                        </div><!-- End .toolbox-right -->
                    </div><!-- End .toolbox -->

                    <div class="products mb-3">
                        <div class="product-heading" id="recom">
                            <h4 class="mb-0">Recommended</h4>
                            <span>28 Items</span>
                        </div>
                        <div class="product product-list">
                            <div class="row">


                                <div class="col-12 col-lg-12 order-lg-last">
                                    <div class="product-body">

                                        <div class="product-cat">
                                            <a href="#"><img src="assets/images/icons/vegicon.png" alt="" width="10" class="d-inline"> <span style="color:#fcb941"><i class="icon-star"></i> Bestseller</span> </a>
                                        </div><!-- End .product-cat -->
                                        <h3 class="product-title"><a href="#">Gobhi Pakoda </a> <span class="float-right text-danger"> $60.00 </span><!-- End .product-price -->
                                        </h3>

                                        <div class="product-content">
                                            <p>Penna pasta cooked alfredo style with creamy white sauce and herbs. </p>
                                        </div><!-- End .product-content -->



                                        <div class="details-filter-row details-row-size mb-0">
                                            <label for="qty">Add:</label>
                                            <div class="product-details-quantity">
                                                <input type="number" id="qty" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required="" style="display: none;">
                                                <!-- <div class="input-group  input-spinner">
                                                    <div class="input-group-prepend"><button style="min-width: 26px" class="btn btn-decrement btn-spinner" type="button"><i class="icon-minus"></i></button></div><input type="text" style="text-align: center" class="form-control " required="" placeholder="">
                                                    <div class="input-group-append"><button style="min-width: 26px" class="btn btn-increment btn-spinner" type="button"><i class="icon-plus"></i></button></div>
                                                </div> -->
                                            </div><!-- End .product-details-quantity -->
                                        </div>


                                        <!-- <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
 -->

                                    </div><!-- End .product-body -->

                                </div><!-- End .col-sm-6 col-lg-3 -->




                            </div><!-- End .row -->
                        </div><!-- End .product -->

                        <div class="product product-list">
                            <div class="row">


                                <div class="col-12 col-lg-12 order-lg-last">
                                    <div class="product-body">

                                        <div class="product-cat">
                                            <a href="#"><img src="assets/images/icons/vegicon.png" alt="" width="10" class="d-inline"> <span style="color:#fcb941"><i class="icon-star"></i> Bestseller</span> </a>
                                        </div><!-- End .product-cat -->
                                        <h3 class="product-title"><a href="#">Gobhi Pakoda </a> <span class="float-right text-danger"> $60.00 </span><!-- End .product-price -->
                                        </h3>

                                        <div class="product-content">
                                            <p>Penna pasta cooked alfredo style with creamy white sauce and herbs. </p>
                                        </div><!-- End .product-content -->



                                        <div class="details-filter-row details-row-size mb-0">
                                            <label for="qty">Add:</label>
                                            <div class="product-details-quantity">
                                                <input type="number" id="qty" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required="" style="display: none;">
                                                <!-- <div class="input-group  input-spinner">
                                                    <div class="input-group-prepend"><button style="min-width: 26px" class="btn btn-decrement btn-spinner" type="button"><i class="icon-minus"></i></button></div><input type="text" style="text-align: center" class="form-control " required="" placeholder="">
                                                    <div class="input-group-append"><button style="min-width: 26px" class="btn btn-increment btn-spinner" type="button"><i class="icon-plus"></i></button></div>
                                                </div> -->
                                            </div><!-- End .product-details-quantity -->
                                        </div>


                                        <!-- <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
 -->

                                    </div><!-- End .product-body -->

                                </div><!-- End .col-sm-6 col-lg-3 -->




                            </div><!-- End .row -->
                        </div><!-- End .product -->
                        <div class="product-heading" id="snacks">
                            <h4 class="mb-0">South Indian</h4>
                            <span>28 Items</span>
                        </div>
                        <div class="product product-list">
                            <div class="row">


                                <div class="col-12 col-lg-12 order-lg-last">
                                    <div class="product-body">

                                        <div class="product-cat">
                                            <a href="#"><img src="assets/images/icons/vegicon.png" alt="" width="10" class="d-inline"> <span style="color:#fcb941"><i class="icon-star"></i> Bestseller</span> </a>
                                        </div><!-- End .product-cat -->
                                        <h3 class="product-title"><a href="#">Gobhi Pakoda </a> <span class="float-right text-danger"> $60.00 </span><!-- End .product-price -->
                                        </h3>

                                        <div class="product-content">
                                            <p>Penna pasta cooked alfredo style with creamy white sauce and herbs. </p>
                                        </div><!-- End .product-content -->



                                        <div class="details-filter-row details-row-size mb-0">
                                            <label for="qty">Add:</label>
                                            <div class="product-details-quantity">
                                                <input type="number" id="qty" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required="" style="display: none;">
                                                <!-- <div class="input-group  input-spinner">
                                                    <div class="input-group-prepend"><button style="min-width: 26px" class="btn btn-decrement btn-spinner" type="button"><i class="icon-minus"></i></button></div><input type="text" style="text-align: center" class="form-control " required="" placeholder="">
                                                    <div class="input-group-append"><button style="min-width: 26px" class="btn btn-increment btn-spinner" type="button"><i class="icon-plus"></i></button></div>
                                                </div> -->
                                            </div><!-- End .product-details-quantity -->
                                        </div>


                                        <!-- <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
 -->

                                    </div><!-- End .product-body -->

                                </div><!-- End .col-sm-6 col-lg-3 -->




                            </div><!-- End .row -->
                        </div><!-- End .product -->
                        <div class="product product-list">
                            <div class="row">


                                <div class="col-12 col-lg-12 order-lg-last">
                                    <div class="product-body">

                                        <div class="product-cat">
                                            <a href="#"><img src="assets/images/icons/vegicon.png" alt="" width="10" class="d-inline"> <span style="color:#fcb941"><i class="icon-star"></i> Bestseller</span> </a>
                                        </div><!-- End .product-cat -->
                                        <h3 class="product-title"><a href="#">Gobhi Pakoda </a> <span class="float-right text-danger"> $60.00 </span><!-- End .product-price -->
                                        </h3>

                                        <div class="product-content">
                                            <p>Penna pasta cooked alfredo style with creamy white sauce and herbs. </p>
                                        </div><!-- End .product-content -->



                                        <div class="details-filter-row details-row-size mb-0">
                                            <label for="qty">Add:</label>
                                            <div class="product-details-quantity">
                                                <input type="number" id="qty" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required="" style="display: none;">
                                                <!-- <div class="input-group  input-spinner">
                                                    <div class="input-group-prepend"><button style="min-width: 26px" class="btn btn-decrement btn-spinner" type="button"><i class="icon-minus"></i></button></div><input type="text" style="text-align: center" class="form-control " required="" placeholder="">
                                                    <div class="input-group-append"><button style="min-width: 26px" class="btn btn-increment btn-spinner" type="button"><i class="icon-plus"></i></button></div>
                                                </div> -->
                                            </div><!-- End .product-details-quantity -->
                                        </div>


                                        <!-- <a href="#" class="btn-product btn-cart"><span>add to cart</span></a>
 -->

                                    </div><!-- End .product-body -->

                                </div><!-- End .col-sm-6 col-lg-3 -->




                            </div><!-- End .row -->
                        </div><!-- End .product -->




                    </div><!-- End .products -->


                </div><!-- End .col-lg-9 -->
                <aside class="col-lg-3 order-lg-first d-none d-sm-none d-md-none d-lg-block" style="position: sticky;">
                    <div class="sidebar sidebar-shop">
                        <div class="widget widget-clean">
                            <label>Filters:</label>
                            <a href="#" class="sidebar-filter-clear">Clean All</a>
                        </div><!-- End .widget widget-clean -->

                        <div class="widget widget-collapsible">
                            <h3 class="widget-title">
                                <a data-toggle="collapse" href="#widget-1" role="button" aria-expanded="true" aria-controls="widget-1">
                                    Category
                                </a>
                            </h3><!-- End .widget-title -->

                            <div class="collapse show" id="widget-1">
                                <div class="widget-body">
                                    <div class="filter-items filter-items-count">
                                        <div class="filter-item">
                                            <div class="">

                                                <a href="#recom"><b>Recommended</b></a>
                                            </div><!-- End .custom-checkbox -->
                                            <span class="item-count">3</span>
                                        </div><!-- End .filter-item -->

                                        <div class="filter-item">
                                            <div class="">

                                                <a href="#snacks"><b>Snacks</b></a>
                                            </div><!-- End .custom-checkbox -->
                                            <span class="item-count">3</span>
                                        </div><!-- End .filter-item -->

                                        <div class="filter-item">
                                            <div class="">

                                                <a href="#snacks"><b>South indian</b></a>
                                            </div><!-- End .custom-checkbox -->
                                            <span class="item-count">3</span>
                                        </div><!-- End .filter-item -->

                                        <div class="filter-item">
                                            <div class="">

                                                <a href="#snacks"><b>North indian</b></a>
                                            </div><!-- End .custom-checkbox -->
                                            <span class="item-count">3</span>
                                        </div><!-- End .filter-item -->

                                        <div class="filter-item">
                                            <div class="">

                                                <a href="#snacks"><b>Thalis</b></a>
                                            </div><!-- End .custom-checkbox -->
                                            <span class="item-count">3</span>
                                        </div><!-- End .filter-item -->


                                    </div><!-- End .filter-items -->
                                </div><!-- End .widget-body -->
                            </div><!-- End .collapse -->
                        </div><!-- End .widget -->


                    </div><!-- End .sidebar sidebar-shop -->
                </aside><!-- End .col-lg-3 -->
            </div><!-- End .row -->
        </div><!-- End .container -->
    </div>
    <div class="sticky-bar">
        <div class="container">
            <div class="row">
                <div class="col-6">
                    <figure class="product-media">
                        <a href="#">
                            <img src="assets/images/icons/vegicon.png" alt="" width="10">
                        </a>
                    </figure><!-- End .product-media -->
                    <h4 class="product-title"><a href="#">Gobhi Pakoda</a></h4><!-- End .product-title -->
                </div><!-- End .col-6 -->

                <div class="col-6 justify-content-end">
                    <div class="product-price">
                        $84.00
                    </div><!-- End .product-price -->
                    <div class="product-details-quantity">
                        <input type="number" id="sticky-cart-qty" class="form-control" value="1" min="1" max="10" step="1" data-decimals="0" required="" style="display: none;">
                        <!-- <div class="input-group  input-spinner">
                            <div class="input-group-prepend"><button style="min-width: 26px" class="btn btn-decrement btn-spinner" type="button"><i class="icon-minus"></i></button></div><input type="text" style="text-align: center" class="form-control " required="" placeholder="">
                            <div class="input-group-append"><button style="min-width: 26px" class="btn btn-increment btn-spinner" type="button"><i class="icon-plus"></i></button></div>
                        </div> -->
                    </div><!-- End .product-details-quantity -->

                    <div class="product-details-action">
                        <a href="cart.php" class="btn-product btn-cart"><span>Continue</span></a>
                        <a href="#" class="btn-product btn-wishlist" title="Wishlist"><span>Add to Wishlist</span></a>
                    </div><!-- End .product-details-action -->
                </div><!-- End .col-6 -->
            </div><!-- End .row -->
        </div><!-- End .container -->
    </div>

</main><!-- End .main -->
</div>
<?php
include("footer.php")
?>