<?php
include("header.php");
include("menu.php");
?>

<main class="main">

    <div class="offers-banners bg-dark mt-13 py-2" style="background-image: url(assets/images/footer-bg-1.jpg);">
        <div class="container deal-section">
            <div class="row">
                <div class="col-md-12">
                    <div class="driver-box text-center pb-3 mt-3">
                        <h3 class="text-white">Collections - Jaipur</h3>

                        <p><strong>Browse lists of the finest restaurants</strong></p>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="container pt-3">
        <div class="row">
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="dinerestro.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                            <a href="">Title Here</a>
                        </h2>
                        <div class="product-price mb-1 ">
                            30 Places <i class="icon-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="dinerestro.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                            <a href="">Title Here</a>
                        </h2>
                        <div class="product-price mb-1 ">
                            30 Places <i class="icon-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="dinerestro.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                            <a href="">Title Here</a>
                        </h2>
                        <div class="product-price mb-1 ">
                            30 Places <i class="icon-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="dinerestro.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                            <a href="">Title Here</a>
                        </h2>
                        <div class="product-price mb-1 ">
                            30 Places <i class="icon-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="dinerestro.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                            <a href="">Title Here</a>
                        </h2>
                        <div class="product-price mb-1 ">
                            30 Places <i class="icon-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="product d-flex flex-column overflow-hidden mb-3">
                    <figure class="mb-0 product-media bg-white d-flex justify-content-center align-items-center">
                        <a href="dinerestro.php" class="w-100">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image" width="192" height="192">
                            <img src="assets/images/r1.jpg" alt="Product image" class="product-image-hover" width="192" height="192">
                        </a>
                    </figure>

                    <div class="product-body">
                        <h2 class="product-title letter-spacing-normal  mb-0 text-left">
                            <a href="">Title Here</a>
                        </h2>
                        <div class="product-price mb-1 ">
                            30 Places <i class="icon-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main><!-- End .main -->
</div>
<?php
include("footer.php")
?>