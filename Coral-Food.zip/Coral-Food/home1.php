<?php include("header.php") ?>
<div class="soon">
    <div class="container">
        <div class="row">
            <div class="col-md-9 col-lg-8">
                <div class="soon-content text-center">
                    <div class="soon-content-wrapper">
                        <a href="index.php"><img src="assets/images/c2.png" alt="Logo" class="soon-logo mx-auto" width="240"></a>

                        <hr class="mt-2 mb-3 mt-md-3">
                        <h2><strong> Hungry?</strong></h2>
                        <h6> Order food from favourite restaurants near you.</h6>
                        <form action="#">
                            <div class="input-group mb-5">
                                <input type="text" id="location" class="form-control bg-transparent" placeholder="Enter your Delivery Location" required style="background-color: #c33332;">
                                <div class="input-group-append ">
                                    <button class="btn btn-outline-primary-2" type="submit" style="background-color: #c33332;">
                                        <span style="color:#fff">Select</span>
                                        <i class="icon-long-arrow-right"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                        <h3>Popular cities in India</h3>
                        <ul>
                            <li class="d-inline "><a href="jaipur">Jaipur |</a></li>
                            <li class="d-inline "><a href="bangalore">Bangalore |</a></li>
                            <li class="d-inline "><a href="chennai">Chennai |</a></li>
                            <li class="d-inline "><a href="delhi">Delhi |</a></li>
                            <li class="d-inline "><a href="gurgaon">Gurgaon |</a></li>
                            <li class="d-inline "><a href="hyderabad">Hyderabad </a></li>
                            <li class="d-inline "><a href="kolkata">Kolkata |</a></li>
                            <li class="d-inline "><a href="mumbai">Mumbai |</a></li>
                            <li class="d-inline "><a href="pune">Pune </a></li>

                        </ul>
                        <div class="social-icons social-icons-colored justify-content-center">
                            <a href="#" class="social-icon social-facebook" title="Facebook" target="_blank"><i class="icon-facebook-f"></i></a>
                            <a href="#" class="social-icon social-twitter" title="Twitter" target="_blank"><i class="icon-twitter"></i></a>
                            <a href="#" class="social-icon social-instagram" title="Instagram" target="_blank"><i class="icon-instagram"></i></a>
                            <a href="#" class="social-icon social-youtube" title="Youtube" target="_blank"><i class="icon-youtube"></i></a>
                            <a href="#" class="social-icon social-pinterest" title="Pinterest" target="_blank"><i class="icon-pinterest"></i></a>
                        </div>
                        <div class="log-sign-btn mt-4">
                            <a href="#" class="log-loc-btn">Login</a>
                            <a href="#" class="Sign-loc-btn">Sign Up</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="soon-bg bg-image " style="background-image: url(assets/images/1-compressed.jpg) "></div>
</div>
<!-- End location -->
<div style="background-image: url('assets/images/bg-6.jpg');" class="how-to-order pt-3">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="heading text-center mb-4">
                    <h1 class="title">How To Order</h1>
                    <!-- End .title -->
                    <p class="title-desc">Follow the Steps</p>
                    <!-- End .title-desc -->
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-3 col-sm-6 col-6">
                <div class="icon-box icon-box-circle text-center">
                    <center> <img src="assets/images/icons/ic1.png" alt=" "></center>
                    <span class="icon-box-icon ">
                        1
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title">Choose your location</h3>
                        <!-- End .icon-box-title -->

                    </div>
                    <!-- End .icon-box-content -->
                </div>
                <!-- End .icon-box -->
            </div>
            <!-- End .col-lg-3 col-sm-6 -->

            <div class="col-lg-3 col-sm-6 col-6">
                <div class="icon-box icon-box-circle text-center">
                    <center> <img src="assets/images/icons/ic2.png" alt=" "></center>
                    <span class="icon-box-icon ">
                        2
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title">Choose restaurant</h3>
                        <!-- End .icon-box-title -->

                    </div>
                    <!-- End .icon-box-content -->
                </div>
                <!-- End .icon-box -->
            </div>
            <!-- End .col-lg-3 col-sm-6 -->

            <div class="col-lg-3 col-sm-6 col-6">
                <div class="icon-box icon-box-circle text-center">
                    <center> <img src="assets/images/icons/ic3.png" alt=" "></center>
                    <span class="icon-box-icon ">
                        3
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title">Make your order</h3>
                        <!-- End .icon-box-title -->

                    </div>
                    <!-- End .icon-box-content -->
                </div>
                <!-- End .icon-box -->
            </div>
            <!-- End .col-lg-3 col-sm-6 -->

            <div class="col-lg-3 col-sm-6 col-6">
                <div class="icon-box icon-box-circle text-center">
                    <center> <img src="assets/images/icons/ic4.png" alt=" "></center>
                    <span class="icon-box-icon ">
                        4
                    </span>
                    <div class="icon-box-content">
                        <h3 class="icon-box-title">Food is on the way</h3>
                        <!-- End .icon-box-title -->

                    </div>
                    <!-- End .icon-box-content -->
                </div>
                <!-- End .icon-box -->
            </div>
            <!-- End .col-lg-3 col-sm-6 -->
        </div>
    </div>
</div>

<div class="cta bg-image bg-dark pt-3 pb-3" style="background-image: url(assets/images/footer-bg-1.jpg);">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-6">
                <div class="features-boxs text-center">
                    <center> <img src="assets/images/icons/f1.png" alt="" width="70"></center>
                    <h4>Free shipping </h4>
                    <p>Sign up for updates and get free shipping</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="features-boxs text-center">
                    <center> <img src="assets/images/icons/f2.png" alt="" width="70"></center>
                    <h4>Fast Delivery</h4>
                    <p>Everything you order will be quickly delivered.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="features-boxs text-center">
                    <center> <img src="assets/images/icons/f3.png" alt="" width="70"></center>
                    <h4>Hygenic Food </h4>
                    <p>We use only the best ingredients to cook food.</p>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-6">
                <div class="features-boxs text-center">
                    <center><img src="assets/images/icons/f4.png" alt="" width="70"></center>
                    <h4>Variety of dishes </h4>
                    <p>In our menu you’ll find a wide variety of dishes.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <div class="brands-text">
                <h2>Restaurants in your pocket</h2>

                <p>Order from your favorite restaurants & track on the go, with the all-new Coral Food app.</p>
                <div class="mt-4">
                    <a href="#" class="d-inline"><img src="assets/images/icons/app1.webp" alt="" width="180" class="d-inline"></a>
                    <a href="#" class="d-inline"><img src="assets/images/icons/app2.webp" alt="" width="180" class="d-inline"></a>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <div class="brands-display">
                <div class="row justify-content-center">
                    <div class="col-6">
                        <a href="#" class="brand">
                            <img src="assets/images/icons/app4.webp" alt="Brand Name">
                        </a>
                    </div>

                    <div class="col-6">
                        <a href="#" class="brand">
                            <img src="assets/images/icons/app3.webp" alt="Brand Name">
                        </a>
                    </div>

                </div>

            </div>

        </div>

    </div>
    <!-- End .row -->



</div>
<div class="cta bg-image bg-dark pt-2 pb-3 mb-5" style="background-image: url(assets/images/chef-testim.jpg);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-10 col-md-8 col-lg-6">
                <div class="cta-heading text-center">
                    <h3 class="cta-title text-white">Join Our Newsletter</h3>
                    <!-- End .cta-title -->
                    <p class="cta-desc text-light">Lorem ipsum dolor sit amet adipiscing.</p>
                    <!-- End .cta-desc -->
                </div>
                <!-- End .text-center -->

                <form action="#">
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Enter your Email Address" aria-label="Email Adress" required="">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit"><span>Subscribe</span><i class="icon-long-arrow-right"></i></button>
                        </div>
                        <!-- .End .input-group-append -->
                    </div>
                    <!-- .End .input-group -->
                </form>
            </div>
            <!-- End .col-sm-10 col-md-8 col-lg-6 -->
        </div>
        <!-- End .row -->
    </div>
    <!-- End .container -->
</div>

<div class="brand-section mt-1 mb-3">
    <div class="container py-2 pt-0">
        <div class="owl-carousel owl-simple rows cols-2 cols-xs-3 cols-md-4 cols-lg-6 owl-loaded owl-drag" data-toggle="owl" data-owl-options="{
                    &quot;nav&quot;: false, &quot;loop&quot;: false, &quot;dots&quot;: false, &quot;margin&quot;:0,&quot;responsive&quot;: {
                    &quot;0&quot;: {
                        &quot;items&quot;:2
                    },
                    &quot;480&quot;: {
                        &quot;items&quot;:3
                    },
                    &quot;768&quot;: {
                        &quot;items&quot;:4
                    },
                    &quot;992&quot;: {
                        &quot;items&quot;:6
                    }
                }
            }">

            <div class="owl-stage-outer">
                <div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: all 0.4s ease 0s; width: 1400px;">
                    <div class="owl-item active" style="width: 233.333px;">
                        <a href="#" class="brand"><img src="assets/images/icons/1b.png"></a>
                    </div>
                    <div class="owl-item active" style="width: 233.333px;">
                        <a href="#" class="brand"><img src="assets/images/icons/2b.png"></a>
                    </div>
                    <div class="owl-item active" style="width: 233.333px;">
                        <a href="#" class="brand"><img src="assets/images/icons/3b.png"></a>
                    </div>
                    <div class="owl-item active" style="width: 233.333px;">
                        <a href="#" class="brand"><img src="assets/images/icons/4b.png"></a>
                    </div>
                    <div class="owl-item active" style="width: 233.333px;">
                        <a href="#" class="brand"><img src="assets/images/icons/5b.png"></a>
                    </div>
                    <div class="owl-item active" style="width: 233.333px;">
                        <a href="#" class="brand"><img src="assets/images/icons/7b.png"></a>
                    </div>
                    <div class="owl-item active" style="width: 233.333px;">
                        <a href="#" class="brand"><img src="assets/images/icons/8b.png"></a>
                    </div>
                </div>
            </div>
            <div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="icon-angle-left"></i></button><button type="button" role="presentation" class="owl-next"><i class="icon-angle-right"></i></button></div>
            <div class="owl-dots disabled"></div>
        </div>
    </div>
</div>
<?php include("footer.php") ?>