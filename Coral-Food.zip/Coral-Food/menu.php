<div class="page-wrapper">
    <header class="header header-28 bg-transparent">

        <div class="header-top font-weight-normal text-light">
            <div class="container">
                <div class="header-left">
                    <div class="select-custom">
                        <select id="cat" name="cat">
                            <option value="">Mansarovar, Jaipur, Raj (302020)</option>
                            <option value="1">Vashali, Jaipur, Raj (302020)</option>

                        </select>
                    </div>
                    <!-- <div class="header-dropdown">
                            <a href="#">Mansarovar
                                67/55, Ward 27, Sector 6, Mansarovar, Jaipur, Rajasthan 302020, India</a>
                            <div class="header-menu">
                                <ul>
                                    <li><a href="#">Mansarovar
                                        67/55, Ward 27, Sector 6, Mansarovar, Jaipur, Rajasthan 302020, India
                                        
                                        </a></li>
                                    <li><a href="#">Usd</a></li>
                                </ul>
                            </div>
                        </div> -->

                </div>
                <div class="header-right">
                    <a href="register.php" class="d-none d-sm-block"><i class="icon-user"></i>Register</a>

                    <a href="login.php"><i class="icon-keycdn"></i>Login</a>

                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="header-middle sticky-header">
                <div class="container">
                    <div class="header-left">
                        <button class="mobile-menu-toggler" id="mobile-bar">
                            <span class="sr-only">Toggle mobile menu</span>
                            <i class="icon-bars"></i>
                        </button>
                        <a href="index.php" class="logo"><img src="assets/images/c2.png" alt="Molla Logo" width="205" height="25"></a>
                        <nav class="main-nav">
                            <ul class="menu sf-arrows">
                                <li class="megamenu-container active megamenu-list">
                                    <a href="indix.php" class="active">Home</a>

                                </li>
                                <li class="megamenu-list">
                                    <a href="#" class="">Categories</a>

                                </li>
                                <li class="megamenu-list">
                                    <a href="Offer.php" class="">Offers</a>

                                </li>
                                <li class="megamenu-list">
                                    <a href="patner.php" class="">Become Patners</a>

                                </li>

                                <!-- <li class="megamenu-list">
                                        <a href="#" class="sf-with-ul">Pages</a>
                                        <ul>
                                            <li>
                                                <a href="about.html" class="sf-with-ul">About</a>
                                                <ul>
                                                    <li><a href="about.html">About 01</a></li>
                                                    <li><a href="about-2.html">About 02</a></li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="contact.html" class="sf-with-ul">Contact</a>

                                                <ul>
                                                    <li><a href="contact.html">Contact 01</a></li>
                                                    <li><a href="contact-2.html">Contact 02</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="login.html">Login</a></li>
                                            <li><a href="faq.html">FAQs</a></li>
                                            <li><a href="404.html">Error 404</a></li>
                                            <li><a href="coming-soon.html">Coming Soon</a></li>
                                        </ul>
                                    </li> -->

                            </ul>
                        </nav>
                    </div>
                    <div class="header-right">
                        <div class="header-search">
                            <a href="#" class="search-toggle" role="button"><i class="icon-search"></i></a>
                            <form action="#" method="get">
                                <div class="header-search-wrapper">
                                    <label for="q" class="sr-only">Search</label>
                                    <input type="search" class="form-control" name="q" id="q" placeholder="Search in..." required="">
                                </div>
                                <!-- End .header-search-wrapper -->
                            </form>
                        </div>
                        <!-- End .header-search -->



                        <div class="dropdown cart-dropdown">
                            <a href="#" class="dropdown-toggle" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static">
                                <div class="icon position-relative">
                                    <i class="icon-shopping-cart"></i>
                                    <span class="cart-count bg-warning">2</span>
                                </div>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right">
                                <div class="dropdown-cart-products">
                                    <div class="product">
                                        <figure class="product-image-containers">
                                            <a href="" class="product-image">
                                                <img src="assets/images/p4.jpg" alt="product mb-0 rounded-0 w-100">
                                            </a>
                                        </figure>
                                        <div class="product-cart-details">
                                            <h4 class="product-title overflow-hidden ">
                                                <a href=""><b>Resturant Name</b></a>
                                            </h4>
                                            <p>Mansarovar</p>
                                            <a class="cart-product-info" href="">
                                                View Full Menu
                                            </a>
                                        </div>

                                    </div>

                                    <div class="product mb-0 rounded-0 w-100">
                                        <div class="product-cart-details">
                                            <h4 class="product-title overflow-hidden letter-spacing-normal">
                                                <span><img src="assets/images/icons/vegicon.png" alt="" width="10" class="d-inline"></span> <a href="">Food Name Here</a>
                                            </h4>

                                            
                                        </div>
                                        

                                        <figure class="product-image-container">
                                            <a href="" class="product-image">
                                            $84.00
                                            </a>
                                        </figure>
                                        <a href="#" class="btn-remove" title="Remove Product"><i class="icon-close"></i></a>
                                    </div>
                                    <div class="product mb-0 rounded-0 w-100">
                                        <div class="product-cart-details">
                                            <h4 class="product-title overflow-hidden letter-spacing-normal">
                                                <span><img src="assets/images/icons/vegicon.png" alt="" width="10" class="d-inline"></span> <a href="">Food Name Here</a>
                                            </h4>

                                            
                                        </div>
                                        

                                        <figure class="product-image-container">
                                            <a href="" class="product-image">
                                            $84.00
                                            </a>
                                        </figure>
                                        <a href="#" class="btn-remove" title="Remove Product"><i class="icon-close"></i></a>
                                    </div>
                                    <!-- End .product -->
                                </div>
                                <!-- End .cart-product -->

                                <div class="dropdown-cart-total">
                                    <span>Total</span>

                                    <span class="cart-total-price">$160.00</span>
                                </div>
                                <!-- End .dropdown-cart-total -->

                                <div class="dropdown-cart-action">
                                    <a href="cart.html" class="btn btn-primary">View Cart</a>
                                    <a href="checkout.html" class="btn btn-outline-primary-2"><span>Checkout</span><i class="icon-long-arrow-right"></i></a>
                                </div>
                                <!-- End .dropdown-cart-total -->
                            </div>
                            <!-- End .dropdown-menu -->
                        </div>
                        <!-- End .cart-dropdown -->

                    </div>
                </div>
            </div>
        </div>
    </header>



    