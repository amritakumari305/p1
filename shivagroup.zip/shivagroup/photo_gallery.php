<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Photo Gallery</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Photo Gallery</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<section class="section-padding gallery-wrapper">
    <div class="container">
    <div class="row">
        <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
        <div class="section-title-s2"> <span>Our Gallery</span>
            <h2>Our Portfolio</h2>
          </div>
        </div>
      </div>
     

<div class="row">
  <div class="col-sm-12">
    <ul class="grid_container gutter_medium grid_col3">
      <!-- START PORTFOLIO ITEM -->
      <li class="grid_item events">
        <div class="gallery_item"> <a href="#" class="image_link"> <img src="assets/img/gallery/product-jpeg-500x500.jpg" alt> </a>
          <div class="gallery_content">
            <div class="link_container"> <a href="assets/img/gallery/product-jpeg-500x500.jpg" class="image_popup"><span class="ripple"><i class="fa fa-search"></i></span></a> </div>
            <div class="text_holder">
              <h3>Handicraft</h3>
            </div>
          </div>
        </div>
      </li>
      <!-- END PORTFOLIO ITEM --> 
      <!-- START PORTFOLIO ITEM -->
      <li class="grid_item events">
        <div class="gallery_item"> <a href="#" class="image_link"> <img src="assets/img/gallery/nano-white-marble-slabs-1567409156-5062739.jpeg" alt="image"> </a>
          <div class="gallery_content">
            <div class="link_container"> <a href="assets/img/gallery/nano-white-marble-slabs-1567409156-5062739.jpeg" class="image_popup"><span class="ripple"><i class="fa fa-search"></i></span></a> </div>
            <div class="text_holder">
              <h3>White Marble</h3>
            </div>
          </div>
        </div>
      </li>
      <!-- END PORTFOLIO ITEM --> 
      <!-- START PORTFOLIO ITEM -->
      <li class="grid_item events">
        <div class="gallery_item"> <a href="#" class="image_link"> <img src="assets/img/gallery/pink-marble-1537437566-4321400.jpeg" alt="image"> </a>
          <div class="gallery_content">
            <div class="link_container"> <a href="assets/img/gallery/pink-marble-1537437566-4321400.jpeg" class="image_popup"><span class="ripple"><i class="fa fa-search"></i></span></a> </div>
            <div class="text_holder">
              <h3>Pink Marble</h3>
            </div>
          </div>
        </div>
      </li>
      <!-- END PORTFOLIO ITEM --> 
      <!-- START PORTFOLIO ITEM -->
      <li class="grid_item events">
        <div class="gallery_item"> <a href="#" class="image_link"> <img src="assets/img/gallery/Indian-Green-Marble.jpg" alt="image"> </a>
          <div class="gallery_content">
            <div class="link_container"> <a href="assets/img/gallery/Indian-Green-Marble.jpg" class="image_popup"><span class="ripple"><i class="fa fa-search"></i></span></a> </div>
            <div class="text_holder">
              <h3>Green Marble</h3>
            </div>
          </div>
        </div>
      </li>
      <!-- END PORTFOLIO ITEM --> 
      <!-- START PORTFOLIO ITEM -->
      <li class="grid_item events">
        <div class="gallery_item"> <a href="#" class="image_link"> <img src="assets/img/gallery/red.jpg" alt="image"> </a>
          <div class="gallery_content">
            <div class="link_container"> <a href="assets/img/gallery/red.jpg" class="image_popup"><span class="ripple"><i class="fa fa-search"></i></span></a> </div>
            <div class="text_holder">
              <h3>Red Grenite</h3>
            </div>
          </div>
        </div>
      </li>
      <!-- END PORTFOLIO ITEM --> 
      <!-- START PORTFOLIO ITEM -->
      <li class="grid_item events">
        <div class="gallery_item"> <a href="#" class="image_link"> <img src="assets/img/gallery/rajasthan-black-granite-block-slab-500x500.jpg" alt="image"> </a>
          <div class="gallery_content">
            <div class="link_container"> <a href="assets/img/gallery/rajasthan-black-granite-block-slab-500x500.jpg" class="image_popup"><span class="ripple"><i class="fa fa-search"></i></span></a> </div>
            <div class="text_holder">
              <h3>Black Grenite</h3>
            </div>
          </div>
        </div>
      </li>
      <!-- END PORTFOLIO ITEM -->             
         	  
    </ul>
  </div>
</div>	  
    </div>
    <!-- end container --> 
  </section>



<?php
	include('footer.php');
?>