<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Video Gallery</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Video Gallery</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<section class="about-us-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="theme-sidebar  float-left  theme-col">
                    <div class="sidebar-list">
                        <div class="section-title">
                            <h2>Categories</h2>
                        </div>
                        <ul>
                           
                            <li><a href="video_gallery.php" class="tran3s">Granite</a></li>
                            <li><a href="video_gallery.php" class="tran3s">Marble</a></li>
                            <li><a href="video_gallery.php" class="tran3s">Imported Marble</a></li>
                            <li><a href="video_gallery.php" class="tran3s">Imported Granite</a></li>
                            <li><a href="video_gallery.php" class="tran3s">Sand Stone</a></li>
                            <li><a href="video_gallery.php" class="tran3s">Handicraft</a></li>
                           
                        </ul>
                    </div>
<!--                     
                    <div class="sidebar-list downloaditem">
                        <ul>
                            <li><a href="" class="tran3s">Download Brochures <i class="fa fa-file-pdf-o" aria-hidden="true"></i></a></li>
                            <li><a href="" class="tran3s">Download History <i class="fa fa-file-pdf-o" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                    <div class="sep30"></div> -->
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
                    <div class="section-title"> <span>Video Gallery </span>
                    <h2>We Build for Your Comfort</h2>
                </div>
                <div class="row">
                     <div class="col-md-6">
                         <div class="video-glry my-2">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/XTMCSS80y68" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                         </div>
                     </div>
                     <div class="col-md-6">
                        <div class="video-glry my-2">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/XTMCSS80y68" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                         </div>
                     </div>
                     <div class="col-md-6">
                        <div class="video-glry my-2">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/XTMCSS80y68" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                         </div>
                     </div>
                     <div class="col-md-6">
                        <div class="video-glry my-2">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/XTMCSS80y68" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                         </div>
                     </div>
                </div>
            </div>
        </div>
    </div>
</section>





<?php
	include('footer.php');
?>