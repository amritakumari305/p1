<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Get Quote</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Get Quote</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<section>
  <div class="container contacts-sec">
    <div class="row">
      <div class="col-md-3">
        <div class="contacts-sec-info">
          <img src="https://image.ibb.co/kUASdV/contact-image.png" alt="image"/>
          <h2>Enquiry Now</h2>
          <h4>We would love to hear from you !</h4>
        </div>
      </div>
      <div class="col-md-9">
        <div class="contacts-sec-form">
          <div class="form-group">
            <label class="control-label col-sm-2" for="fname">First Name:</label>
            <div class="col-sm-10">          
            <input type="text" class="form-control" id="fname" placeholder="Enter First Name" name="fname">
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-sm-2" for="phone">Phone:</label>
            <div class="col-sm-10">          
            <input type="text" class="form-control" id="phone" placeholder="Enter Phone No." name="lname">
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-sm-2" for="email">Email:</label>
            <div class="col-sm-10">
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-sm-2" for="subj">Subject:</label>
            <div class="col-sm-10">
                <select name="subj" id="subj" class="form-control">
                      <option value="1">Marble</option>
                      <option value="2">Granite</option>
                      <option value="3">Sand Stone</option>
                      <option value="4">Imported Marble</option>
                      <option value="5">Imported Granite</option>
                      <option value="6">Handicraft</option>

                </select>
            </div>
          </div>
          <div class="form-group">
            <label class="control-label col-sm-2" for="comment">Comment:</label>
            <div class="col-sm-10">
            <textarea class="form-control" rows="5" id="comment"></textarea>
            </div>
          </div>
          <div class="form-group">        
            <div class="col-sm-offset-2 col-sm-10">
            <button type="submit" class="btn btn-default">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php
	include('footer.php');
?>