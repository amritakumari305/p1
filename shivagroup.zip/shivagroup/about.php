<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>About Us</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">About Us</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>





  <!-- start about-section -->
  <section class="about-section section-padding">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 col-md-5">
          <div class="section-title"> <span>About us</span>
            <h2>We Build for Your Comfort</h2>
          </div>
          <div class="about-text">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
           </div>
        </div>
        <div class="col-lg-6 col-lg-offset-1 col-md-7">
          <div class="about-pic-area">
            
             
              <img src="assets/img/welcome-to-stone.png" width="100%">
          </div>
        </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end about-section --> 

  <!-- start fun-fact-section -->
  <section class="fun-fact-section">
    <div class="container">
      <div class="row">
        <div class="col col-xs-12">
          <div class="fun-fact-grids clearfix">
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="500">50</span>+</h3>
                <p>Finished Projects</p>
              </div>
            </div>
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="250">20</span>+</h3>
                <p>Years of Experience</p>
              </div>
            </div>
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="15">00</span>+</h3>
                <p>Awards winning</p>
              </div>
            </div>
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="100">00</span>%</h3>
                <p>Happy Clients</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end fun-fact-section --> 
<section class="about-us-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="theme-sidebar  float-left  theme-col">
                    <div class="sidebar-list">
                        <ul>
                           
                            <li><a href="features.php" class="tran3s">Who we are</a></li>
                            <li><a href="features.php" class="tran3s">What We do</a></li>
                            <li><a href="features.php" class="tran3s">Why Choose Us?</a></li>
                           
                        </ul>
                    </div>
                    <div class="sep30"></div>
                    <div>
                        <div class="sidebar-short-banner">
                            <div class="opacity opacityOne">
                                <h4>Weekly free 50% off Handicraft</h4>
                                <p>For over 20 years, we’ve crafted quality flooring for the American home. We build innovative design into all of our products to make </p>
                               
                            </div> 
                        </div>
                    </div>
                    <!-- <div class="sep30"></div>
                    <div class="sidebar-list downloaditem">
                        <ul>
                            <li><a href="" class="tran3s">Download Brochures <i class="fa fa-file-pdf-o" aria-hidden="true"></i></a></li>
                            <li><a href="" class="tran3s">Download History <i class="fa fa-file-pdf-o" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                    <div class="sep30"></div> -->
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
                <div class="theme-large-content theme-col  float-right ">
                    <div id="block-world-content">
                        <article role="article">
                           
                            <div>
                                <h4>Our Vission & Mission</h4>
                                <p class="text1">Renowned for its high-quality hardwood flooring and environmentally sound manufacturing practices, Mullican Flooring provides customers with endless possibilities for beautifully designed spaces. Mullican’s distinctive collections are available in elegant, smooth finishes, as well as rustic, hand-sculpted or wire-brushed surface treatments. Unique features also include random 6- and 7-foot planks and exceptionally wider widths</p>
                                <img src="assets/img/DSC_0349.jpg" alt="alt" width="100%">
                                <p class="text1">Wasting no time, the duo established Business with the aim of providing business support services to the Merseyside SME market 17 years on, the bcore network now spans across over 50 offices in the UK and offices in New york,</p>
                                
                                <div class="theme-company-overview">
                                    <h4>Company overview</h4>
                                    <div class="clearfix">
                                        <div class="row">
                                            <div class="col-lg-4">
                                                <div class="wrapper">
                                                    <span>2000</span>
                                                    <div>
                                                        <h6><span class="p-color">Business</span> Established</h6>
                                                        <p>21 december 2015</p>
                                                    </div>
                                                </div> 
                                            </div> 
                                            <div class="col-lg-4">
                                                <div class="wrapper">
                                                    <span>2010</span>
                                                    <div>
                                                        <h6>NY Office Success</h6>
                                                        <p>21 december 2015</p>
                                                    </div>
                                                </div> 
                                            </div> 
                                            <div class="col-lg-4">
                                                <div class="wrapper">
                                                    <span>2015</span>
                                                    <div>
                                                        <h6><span class="p-color">NEW</span> launch in Dhaka</h6>
                                                        <p>21 december 2015</p>
                                                    </div>
                                                </div> 
                                            </div> 
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
	include('footer.php');
?>