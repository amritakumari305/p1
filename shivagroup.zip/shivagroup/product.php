<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Products</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Products</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- start portfolio-section -->
<section class="portfolio-section section-padding pro-duct">
    <div class="container">
      <div class="row">
        <div class="col col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
          <div class="section-title-s2"> <span>All Categories</span>
            <h2>Our Products</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
          </div>
        </div>
      </div>
      <div class="row">
          <div class="col-lg-8 col-md-8 col-sm-7">
                <div class="grid mb-5">
                    <div class="img-holder"> <img src="assets/img/tipos_de_marmol-848x450.jpg" alt>
                        <div class="service-image-overlay"></div>
                    </div>
                    <div class="details">
                            <h3><a href="marble.php">Marble</a></h3>
                            <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                        <div class="list-pro">
                            <ul>
                                <li><a href="#">White Marble</a></li>
                                <li><a href="#">Pink Marble</a></li>
                                <li><a href="#">Black Marble</a></li>
                                <li><a href="#">Green Marble</a></li>
                                <li><a href="#">Gold Marble</a></li>
                                <li><a href="#">Brown Marble</a></li>
                                <li><a href="#">Makrana Marble</a></li>

                            </ul>
                        </div>

                        <a href="marble.php" class="theme-btn one">See More</a>


                    </div>
                   
                </div>
                <div class="grid mb-5">
                    <div class="img-holder"> <img src="assets/img/dhan-laxmi-granite-bangalore-06mpl6fp17.jpg" alt>
                        <div class="service-image-overlay"></div>
                    </div>
                    <div class="details">
                    <h3><a href="granite.php">Granite</a></h3>
                            <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                        <div class="list-pro">
                            <ul>
                                <li><a href="#">Red Granites</a></li>
                                <li><a href="#">Black Granites</a></li>
                                <li><a href="#">Green Granites</a></li>
                                <li><a href="#">White Granites</a></li>
                                <li><a href="#">Gold Granites</a></li>
                                <li><a href="#">Brown Granites</a></li>
                                <li><a href="#">Grey Granite</a></li>
                                <li><a href="#">Vanity Granite Range</a></li>

                            </ul>
                        </div>

                        <a href="granite.php" class="theme-btn one">See More</a>


                    </div>
                   
                </div>
                <div class="grid mb-5">
                    <div class="img-holder"> <img src="assets/img/A-wall-of-sandstone.jpg" alt>
                        <div class="service-image-overlay"></div>
                    </div>
                    <div class="details">
                    <h3><a href="sand_stone.php">Sand Stone</a></h3>
                            <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                        <div class="list-pro">
                            <ul>
                                <li><a href="#">Gold Sandstones</a></li>
                                <li><a href="#">Teakwood Sandstones</a></li>
                                <li><a href="#">Red Sandstone</a></li>
                                
                            </ul>
                        </div>

                        <a href="sand_stone.php" class="theme-btn one">See More</a>


                    </div>
                   
                </div>
                <div class="grid mb-5">
                    <div class="img-holder"> <img src="assets/img/unnamed.jpg" alt>
                        <div class="service-image-overlay"></div>
                    </div>
                    <div class="details">
                    <h3><a href="imported_marble.php">Imported Marble </a></h3>
                            <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                        <div class="list-pro">
                            <ul>
                                <li><a href="#">Milky Range</a></li>
                                <li><a href="#">Creamy Range</a></li>
                                <li><a href="#">Darkling Range</a></li>
                                <li><a href="#">Italian Marbles</a></li>
                                
                            </ul>
                        </div>

                        <a href="imported_marble.php" class="theme-btn one">See More</a>


                    </div>
                   
                </div>
                <div class="grid mb-5">
                    <div class="img-holder"> <img src="assets/img/17249Granites.jpg" alt>
                        <div class="service-image-overlay"></div>
                    </div>
                    <div class="details">
                    <h3><a href="imported_granite.php">Imported Granite </a></h3>
                            <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                        <div class="list-pro">
                            <!-- <ul>
                                <li><a href="#">White Marble</a></li>
                                <li><a href="#">Pink Marble</a></li>
                                <li><a href="#">Black Marble</a></li>
                                <li><a href="#">Green Marble</a></li>
                                <li><a href="#">Gold Marble</a></li>
                                <li><a href="#">Brown Marble</a></li>
                                <li><a href="#">Makrana Marble</a></li>

                            </ul> -->
                        </div>

                        <a href="imported_granite.php" class="theme-btn one">See More</a>


                    </div>
                   
                </div>
                <div class="grid mb-5">
                    <div class="img-holder"> <img src="assets/img/marble-candlestick-holder-051116-1147-01b-e1478372142582-800x405.jpg" alt>
                        <div class="service-image-overlay"></div>
                    </div>
                    <div class="details">
                           <h3><a href="handicraft.php">Handicraft </a></h3>
                            <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                        <div class="list-pro">
                            <!-- <ul>
                                <li><a href="#">White Marble</a></li>
                                <li><a href="#">Pink Marble</a></li>
                                <li><a href="#">Black Marble</a></li>
                                <li><a href="#">Green Marble</a></li>
                                <li><a href="#">Gold Marble</a></li>
                                <li><a href="#">Brown Marble</a></li>
                                <li><a href="#">Makrana Marble</a></li>

                            </ul> -->
                        </div>

                        <a href="handicraft.php" class="theme-btn one">See More</a>


                    </div>
                   
                </div>
          </div>
          <div class="col-lg-4 col-md-4 col-sm-5">
                <div class="theme-sidebar  float-left  theme-col">
                    <div class="sidebar-list">
                        <ul>
                           
                            <li><a href="marble.php" class="tran3s">White Marble</a></li>
                            <li><a href="marble.php" class="tran3s">Pink Marble</a></li>
                            <li><a href="marble.php" class="tran3s">Black Marble</a></li>
                            <li><a href="marble.php" class="tran3s">Green Marble</a></li>
                            <li><a href="marble.php" class="tran3s">Gold Marble</a></li>
                            <li><a href="marble.php" class="tran3s">Brown Marble</a></li>
                            <li><a href="marble.php" class="tran3s">Makrana Marble </a></li>
                            <li><a href="granite.php" class="tran3s">Red Granites</a></li>
                            <li><a href="granite.php" class="tran3s">Black Granites</a></li>
                            <li><a href="granite.php" class="tran3s">Green Granites</a></li>
                            <li><a href="granite.php" class="tran3s">White Granites</a></li>
                            <li><a href="granite.php" class="tran3s">Gold Granites</a></li>
                            <li><a href="granite.php" class="tran3s">Brown Granites</a></li>
                            <li><a href="granite.php" class="tran3s">Grey Granite</a></li>
                            <li><a href="granite.php" class="tran3s">Vanity Granite Range</a></li>
                           
                        </ul>
                    </div>
                    
                    <div class="sidebar-list downloaditem">
                        <ul>
                            <li><a href="sand_stone.php" class="tran3s">Gold Sandstones</a></li>
                            <li><a href="sand_stone.php" class="tran3s">Teakwood Sandstones</a></li>
                            <li><a href="sand_stone.php" class="tran3s">Red Sandstone</a></li>
                            <li><a href="imported_marble.php" class="tran3s">Milky Range</a></li>
                            <li><a href="imported_marble.php" class="tran3s">Creamy Range</a></li>
                            <li><a href="imported_marble.php" class="tran3s">Darkling Range</a></li>
                            <li><a href="imported_marble.php" class="tran3s">Italian Marbles</a></li>
                            <li><a href="imported_granite.php" class="tran3s">Imported Granite</a></li>
                            <li><a href="handicraft.php" class="tran3s">Handicraft</a></li>
                           
                        </ul>
                    </div>
                    <div class="sep30"></div>
                </div>
          </div>
      </div>
    </div>
    <!-- end container --> 
</section>
  <!-- end portfolio-section --> 

<?php
	include('footer.php');
?>