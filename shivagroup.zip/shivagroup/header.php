<!DOCTYPE html>
<html>
  <head>
  <title>Shiva Group</title>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta http-equiv="X-UA-Compatible" content="IE=10">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="assets/img/icons/favicon.png" type="image/x-icon" />
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css"/>
  <!--===============================================================================================-->
  <script src="https://kit.fontawesome.com/75405d81d0.js" crossorigin="anonymous"></script>
  <!-- other css -->
<link href="assets/css/themify-icons.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/owl.carousel.css" rel="stylesheet">
<link href="assets/css/owl.theme.css" rel="stylesheet">
<link href="assets/css/slick.css" rel="stylesheet">
<link href="assets/css/slick-theme.css" rel="stylesheet">
<link href="assets/css/swiper.min.css" rel="stylesheet">
<link href="assets/css/owl.transitions.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.css" rel="stylesheet">
<link href="assets/css/default.css" rel="stylesheet">
<link href="assets/css/magnific-popup.css" rel="stylesheet">
  </head>
<body>
<!-- +++++++++++++++++++++++++++++++++++++top header start++++++++++++++++++++++++++++++++  -->
<div class="icon-bar">
  <a href="#" class="facebook"><i class="fab fa-whatsapp"></i></a> 
 
</div>
<div class="header-top">
  <div class="container header_sec">
    <div class="row">
      <div class="col-lg-8  text-lg-left text-center top_head">
        <div class="contact-info">
            <ul class="list-inline mb-0 pt-2 pb-2">
              <li class="d-inline"><a href="mailto:shivainfra2017@gmail.com" class="active"><i class="fas fa-envelope"></i>&nbsp; shivainfra2017@gmail.com </a></li>
              <li class="d-inline"><a href="tel:9651100008" class="actives"><i class="fas fa-phone"></i>&nbsp; Call Us:- +91-9651100008 </a></li>
              <li class="d-inline"><a href="#" class="actives"><i class="fas fa-map-marker-alt"></i>&nbsp; Shiva Marbles, Ajmer Raj </a></li>
            </ul>
          </div>
       
      </div>
      <div class="col-lg-4  text-lg-right text-center top_head">
        <div class="social-links">  
          <ul class="list-inline mb-0 pt-2 pb-2">
            <li class="d-inline pr-2"><a href="#" class="social-m"><i class="fab fa-twitter"></i></a></li>
            <li class="d-inline pr-2"><a href="#" class="social-m"><i class="fab fa-facebook-f"></i></a></li>
            <li class="d-inline pr-2"><a href="#" class="social-m"><i class="fab fa-linkedin-in"></i></a></li>
            <li class="d-inline pr-2"><a href="#" class="social-m"><i class="fab fa-whatsapp"></i></a></li>
            <li class="d-inline pr-2"><a href="#" class="social-m"><i class="fab fa-instagram"></i></a></li>
            </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!--+++++++++++++++++++++++++++++++++++++top header end++++++++++++++++++++++++++++++++ -->
<div class="container-fluid hrader-navbar">
  <div class="container">
	  <nav class="navbar navbar-expand-lg navbar-light navbar-fixed">
      <a class="navbar-brand" href="index.php"> <img src="assets/img/icons/logo.png" alt="Logo" width="100" height="100"> </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto topnav">
          <li class="nav-item active"><a class="nav-link" href="index.php">Home </a></li>         
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> About Us</a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="about.php">About Company</a>
                <!-- <a class="dropdown-item" href="team.php">Team</a> -->
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="features.php">Features</a>
              </div>
          </li>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Products</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="marble.php"> Marble</a>
                  <a class="dropdown-item" href="granite.php"> Granite</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="sand_stone.php"> Sand Stone</a>
                  <a class="dropdown-item" href="imported_marble.php"> Imported Marble</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="imported_granite.php">Imported Granite</a>
                  <a class="dropdown-item" href="handicraft.php">Handicraft</a>
                </div>
          </li>
          <li class="nav-item"><a class="nav-link" href="services.php">Services</a></li>
          <li class="nav-item"><a class="nav-link" href="industries.php">Industeries</a></li>
          <li class="nav-item"><a class="nav-link" href="blog.php">Blog</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
        </ul>
      </div>

      <div class="cart-contact">
          <div class="contact-btn hidden-xs"> <a href="quote.php" class="theme-btn">Request Quote</a> </div>
      </div>
    </nav>
  </div>
</div>

