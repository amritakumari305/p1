<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Services</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Services</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<!-- start service-section-s2 -->
<section class="service-section-s2 section-padding pt0">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
                <div class="section-title-s2"> <span>What we do</span>
                    <h2>See Our Best Services</h2>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
                </div>
            </div>
        </div>
        <div class="row">
	        <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/living-room-pendant-light.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Interior Design</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
			</div>
			<div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/Roof-extension.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Renovation</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
			</div>
			<div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/developer-services.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Builder Services</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
            </div>
            <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/download.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Carpenter</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
            </div>
            <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/081219110833.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Construction</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
            </div>
           <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/hire-a-painter-3-paintzen.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Painter</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
            </div>
            <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/plumbing-0.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Plumber</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
            </div>
            <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/Software+App+for+Electricians.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Electrician</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					
				</div>
			</div>

    
	    </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end service-section-s2 --> 




<?php
	include('footer.php');
?>