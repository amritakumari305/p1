<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Imported Granite</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Imported Granite</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

 <!-- start portfolio-section -->
 <section class="portfolio-section section-padding">
    <div class="container">
    <div class="row">
        <div class="col col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
          <div class="section-title-s2"> <span>Our Product</span>
            <h2>Imported Granite</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
          </div>
        </div>
    </div>
      <div class="row">
        <div class="col col-12">
          <div class="portfolio-grids portfolio-slider">
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/polished-square-white-marble-115.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">Red Granites</a></h3>
               
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/NOBLE-PinkMarble..jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">Black Granites</a></h3>
              
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/U50-Ash-Black-Marble-Second.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">Green Granites</a></h3>
               
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/green-marble-500x500.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">White Granites </a></h3>
               
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/Gold-Marble-Slab-Gold-Marble-Yellow-Marble.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">Gold Granites</a></h3>
               
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/359f68e17e8fedc01ee06ba60e55d074.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">Brown Granites </a></h3>
               
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/maxresdefault.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">Grey Granite</a></h3>
               
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/gallery/maxresdefault.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="#">Vanity Granite Range</a></h3>
               
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end portfolio-section --> 
  
<section class="marble-cat-sec">
  <div class="container">
    
    <div class="row">

      <div class="col-md-12 ">
                  <nav>
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                      <a class="nav-item nav-link active" id="nav-white-tab" data-toggle="tab" href="#nav-white" role="tab" aria-controls="nav-white" aria-selected="true">White Granites</a>
                      <a class="nav-item nav-link" id="nav-pink-tab" data-toggle="tab" href="#nav-pink" role="tab" aria-controls="nav-pink" aria-selected="false">Red Granites</a>
                      <a class="nav-item nav-link" id="nav-black-tab" data-toggle="tab" href="#nav-black" role="tab" aria-controls="nav-black" aria-selected="false">Black Granites</a>
                      <a class="nav-item nav-link" id="nav-green-tab" data-toggle="tab" href="#nav-green" role="tab" aria-controls="nav-green" aria-selected="false">Green Granites</a>
                      <a class="nav-item nav-link" id="nav-gold-tab" data-toggle="tab" href="#nav-gold" role="tab" aria-controls="nav-gold" aria-selected="true">Gold Granites</a>
                      <a class="nav-item nav-link" id="nav-brown-tab" data-toggle="tab" href="#nav-brown" role="tab" aria-controls="nav-brown" aria-selected="true">Brown Granites</a>
                      <a class="nav-item nav-link" id="nav-makrana-tab" data-toggle="tab" href="#nav-makrana" role="tab" aria-controls="nav-makrana" aria-selected="true">Grey Marble</a>
                      <a class="nav-item nav-link" id="nav-vanity-tab" data-toggle="tab" href="#nav-vanity" role="tab" aria-controls="nav-vanity" aria-selected="true">Vanity Range</a>
                    </div>
                  </nav>
                  <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-white" role="tabpanel" aria-labelledby="nav-white-tab">
                      <div class="product-inr-marble">
          
                        <h4>White Granites</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>

                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="nav-pink" role="tabpanel" aria-labelledby="nav-pink-tab">
                      <div class="product-inr-marble">
          
                        <h4>Red Marble</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                        
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>

                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="nav-black" role="tabpanel" aria-labelledby="nav-black-tab">
                      <div class="product-inr-marble">
          
                        <h4>Black Granites</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                        
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>

                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="nav-green" role="tabpanel" aria-labelledby="nav-green-tab">
                      <div class="product-inr-marble">
          
                        <h4>Green Granites</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                        <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/im/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          
                         

                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="nav-gold" role="tabpanel" aria-labelledby="nav-gold-tab">
                      <div class="product-inr-marble">
          
                        <h4>Gold Granites</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                        <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          
                        

                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="nav-brown" role="tabpanel" aria-labelledby="nav-brown-tab">
                       <div class="product-inr-marble">
          
                        <h4>Brown Granites</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="tab-pane fade" id="nav-makrana" role="tabpanel" aria-labelledby="nav-makrana-tab">
                      <div class="product-inr-marble">
                        <h4>Grey Granites</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="tab-pane fade" id="nav-vanity" role="tabpanel" aria-labelledby="nav-vanity-tab">
                       <div class="product-inr-marble">
          
                        <h4>Vanity Granite Range</h4> 
                        <div class="row">
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                        <div class="col-md-4 col-sm-6 col-12">
                            <figure class="snip1091 red">
                              <img src="assets/img/gallery/50e6a49bbb9b584da4a44bdd3a3571fe.jpg" alt="sq-sample6"/>
                              <figcaption>
                                <h5>Makrana   <span>White</span> Marble</h5>
                              </figcaption><a href="#"></a>
                            </figure>
                          </div>
                          
                        

                        </div>
                      </div>
                    </div>


                  </div>
                
      </div>
      
      
    </div>
  </div>
</section>


<?php
	include('footer.php');
?>