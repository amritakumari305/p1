<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Blog</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Blog</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



  <!-- start blog-section -->
  <section class="blog-section section-padding">
    <div class="container">
      
      <div class="row">
         <div class="col-lg-4">
            <div class="blog-inner">
              <div class="img-cat">
                <div class="img-holder"> <img src="assets/img/image.jpg" alt> </div>
              </div>
              <div class="details">
                <h3><a href="#">Lorem ipsum dolor site nec amet consec adipiscing elite.</a></h3>
                <div class="meta">
                  <div class="author"> <a href="#">By : Mich Jhon </a> </div>
                 
               	</div>
				        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
              <a href="blog_single.php" class="theme-btn one">Read More</a>
              </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="blog-inner">
              <div class="img-cat">
                <div class="img-holder"> <img src="assets/img/1a309508fee8e15e55d0381fd1f7600b.jpg" alt> </div>
              </div>
              <div class="details">
                <h3><a href="#">Lorem ipsum dolor site nec amet consec adipiscing elite.</a></h3>
                <div class="meta">
                  <div class="author"> <a href="#">By : Mich Jhon </a> </div>
                 
               	</div>
				        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
              <a href="blog_single.php" class="theme-btn one">Read More</a>
              </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="blog-inner">
              <div class="img-cat">
                <div class="img-holder"> <img src="assets/img/natural-stones11.jpg" alt> </div>
              </div>
              <div class="details">
                <h3><a href="#">Lorem ipsum dolor site nec amet consec adipiscing elite.</a></h3>
                <div class="meta">
                  <div class="author"> <a href="#">By : Mich Jhon </a> </div>
                 
               	</div>
				        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
              <a href="blog_single.php" class="theme-btn one">Read More</a>
              </div>
            </div>
         </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end blog-section --> 

<?php
	include('footer.php');
?>