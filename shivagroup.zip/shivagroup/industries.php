<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Industries</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Industries</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>







<!-- start blog-section -->
<section class="industries-section section-padding">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
          <div class="section-title-s2"> <span>Industries View</span>
            <h2>Photo & Video Gallery</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
          </div>
        </div>
      </div>
      <div class="row">
         <div class="col-md-6">
           <div class="background-img">
                <div class="box">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <div class="content">
                    <h2>Photo Gallery </h2>
                    <p><a href="photo_gallery.php" style="color:#00ffe9;" target="_blank">All our modules are designed to play nicely with responsive of course. </a></p>
                    <a href="photo_gallery.php" class="theme-btn one" style="background-color: #98184b;">See Photo Gallery</a>    
                </div>
                    
                </div>
            </div>
            <!-- <div class="gallery-btn text-center">
                <a href="photo_gallery.php" class="theme-btn one">See Photo Gallery</a>
            </div> -->
         </div>
         <div class="col-md-6">
           <div class="background-img">
                <div class="box">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <div class="content">
                    <h2>Video Gallery </h2>
                    <p><a href="video_gallery.php" style="color:#00ffe9;" target="_blank">All our modules are designed to play nicely with responsive of course.</a></p>
                    <a href="video_gallery.php" class="theme-btn one" style="background-color: #98184b;">See Photo Gallery</a>   
                </div>
                    
                </div>
            </div>
            <!-- <div class="gallery-btn text-center">
                <a href="video_gallery.php" class="theme-btn one">See Photo Gallery</a>
            </div> -->
         </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end blog-section --> 





<?php
	include('footer.php');
?>