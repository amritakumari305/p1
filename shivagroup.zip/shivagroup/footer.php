
 <!-- start site-footer -->
 <footer class="site-footer">
    <div class="upper-footer">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-3 col-md-3 col-sm-6">
            <div class="widget about-widget">
              <div class="logo widget-title">
                <h3>About Us</h3>
              </div>
              <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
              
            </div>
          </div>
          <div class="col-6 col-lg-3 col-md-3 col-sm-6">
            <div class="widget link-widget">
              <div class="widget-title">
                <h3>Quick Links</h3>
              </div>
              <ul>
                <li><a href="about.php">About Us</a></li>
                <li><a href="services.php">Our Services</a></li>
                <li><a href="product.php">Our Products</a></li>
                <li><a href="blog.php">Blog</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="industries.php">Industries</a></li>
               
              </ul>
            </div>
          </div>
          <div class="col-6 col-lg-3 col-md-3 col-sm-6">
            <div class="widget link-widget">
              <div class="widget-title">
                <h3>Our Products</h3>
              </div>
              <ul>
                <li><a href="marble.php">Marble</a></li>
                <li><a href="granite.php">Granite</a></li>
                <li><a href="sand_stone.php">Sand Stone</a></li>
                <li><a href="imported_marble.php">Imported Marble</a></li>
                <li><a href="imported_granite.php">Imported Granite</a></li>
                <li><a href="handicraft.php">Handicraft</a></li>
               
              </ul>
            </div>
          </div>
          <div class="col-12 col-lg-3 col-md-3 col-sm-6">
            <div class="widget contact-widget service-link-widget">
              <div class="widget-title">
                <h3>Head office</h3>
              </div>
              <p>Shiva Marbles
              Makarana Road, Madanganj-Kishangarh, Ajmer Raj. 305801</p>
              <ul>
                <li>Phone: +91-9651100008, <br>+91-9799333468 </li>
                <li>Email: <a href="mailto:prakashksgg@gmail.com">prakashksgg@gmail.com</a> <a href="mailto:shivainfra2017@gmail.com">shivainfra2017@gmail.com</a></li>
                <li>Office Time: 9 a.m.- 6 p.m.</li>
              </ul>
            </div>
          </div>
          
        </div>
      </div>
      <!-- end container --> 
    </div>
    <div class="sec-footer">
      <div class="container">
        <div class="row">
         
            <div class="col-lg-6 col-12">
              <div class="skt-columns-2 mt-2">
           
                <ul class="footer-social-menu list-inline">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
                    <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-6 col-12">
                <div class="widget newsletter-widget">
                
                    <form>
                        <div class="input-1">
                        <input type="email" class="form-control" placeholder="Email Address *" required>
                        </div>
                        <div class="submit clearfix">
                        <button type="submit">Submit</button>
                        </div>
                    </form>
                </div>
          </div>
        </div>
      </div>
    </div>
    <div class="lower-footer">
      <div class="container">
        <div class="row">
          <div class="separator"></div>
          <div class="col col-12">
            <p class="copyright">Copyright &copy; 2020 <span>Shiva Group</span>. All rights reserved.</p>
            <div class="social-icons">
            <p class="text-white">Designed and Developed by : <img src="assets/img/coral-logo.png" width="130"></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- end site-footer --> 
  
</div>
<!-- end of page-wrapper --> 

<script id="bs-live-reload" data-sseport="4859" data-lastchange="1530918619334" src="/js/livereload.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.min.js"></script>

<script src="assets/js/bootstrap.min.js"></script>
<!-- Plugins for this template --> 
<script src="assets/js/jquery-plugin-collection.js"></script> 

<!-- Custom script for this template --> 
<script src="assets/js/custom.js"></script>
</body>
</html>