<section class="hero-style-slider">
    <div class="carousel slide carousel-fade" data-ride="carousel" data-interval="3000" id="carousel-1">
    <div class="carousel-inner" role="listbox">
        <div class="carousel-item active">
            <img class="img-fluid w-100 " src="assets/img/slider1.jpg" alt="Slide Image">
            <div class="carousel-caption hidden-xs">
            <h4>Constructo Builders</h4>
                <h3 class="animated slideInDown"> Build Your Construction</h3>
                <p class="animated slideInLeft"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                <button class="btn  btn-lg animated slideInUp " type="button">Explore More</button>
            </div>
        </div>
        <div class="carousel-item">
            <img class="img-fluid w-100 " src="assets/img/slider2.jpg" alt="Slide Image">
            <div class="carousel-caption hidden-xs">
            <h4>Constructo Builders</h4>
                <h3 class="animated fadeInDown">Build Your Construction </h3>
                <p class="animated slideInUp">Lorem Ipsum is simply dummy text of the printing and typesetting industry..</p>
                <button class="btn  btn-lg animated slideInLeft" type="button">Explore More</button>
            </div>
        </div>
        <div class="carousel-item">
            <img class="img-fluid w-100" src="assets/img/slider3.jpg" alt="Slide Image">
            <div class="carousel-caption hidden-xs">
            <h4>Constructo Builders</h4>
                <h3 class="animated slideInDown">Build Your Construction</h3>
                <p class="animated slideInLeft">Lorem Ipsum is simply dummy text of the printing and typesetting industry..</p>
                <button class="btn  btn-lg animated slideInUp" type="button">Explore More</button>
            </div>
        </div>
        
      <!-- <div class="carousel-item">
            <img class="img-fluid w-100 " src="images/banner3.jpg" alt="Slide Image">
            <div class="carousel-caption hidden-xs">
                <h3 class="animated slideInDown">Perfect And Responsive</h3>
                <p class="animated slideInLeft">incididunt ut labore et dolore magna aliqua.</p>
                <button class="btn btn-outline-light btn-lg animated slideInUp" type="button">Read More</button>
            </div>
        </div> -->
    </div>
    <div>
        <a class="carousel-control-prev" href="#carousel-1" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel-1" role="button" data-slide="next">
            <span class="carousel-control-next-icon"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
            
    </div>
</section>




 <!-- start of Features Wrapper -->
 <section class="features-wrapper">
    <div class="container">
      <div class="row box-shadow2 bg-white featured-box">
        <div class="col-md-4 col-sm-6 col-12 ">
          <div class="featured-icon-box text-center">
            <div class="featured-icon"> <i class="fas fa-cog"></i> </div>
            <div class="featured-content">
              <div class="featured-title">
                <h5>Who we are</h5>
              </div>
              <div class="featured-desc">
                <p>Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                <a class="btn" href="features.php">More Services<i class="fas fa-angle-double-right"></i></a> </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6  col-12 box-shadow2">
          <div class="featured-icon-box text-center">
            <div class="featured-icon"> <i class="fas fa-user "></i> </div>
            <div class="featured-content">
              <div class="featured-title">
                <h5>What we do</h5>
              </div>
              <div class="featured-desc">
                <p>Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                <a class="btn" href="features.php">More Services<i class="fas fa-angle-double-right"></i></a> </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 col-12 ">
          <div class="featured-icon-box text-center">
            <div class="featured-icon"> <i class="far fa-thumbs-up"></i> </div>
            <div class="featured-content">
              <div class="featured-title">
                <h5>Why Choose Us?</h5>
              </div>
              <div class="featured-desc">
                <p>Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
                <a class="btn" href="features.php">More Services<i class="fas fa-angle-double-right"></i></a> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- End of Features Wrapper --> 



  <!-- start about-section -->
  <section class="about-section section-padding">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 col-md-5">
          <div class="section-title"> <span>About us</span>
            <h2>We Build for Your Comfort</h2>
          </div>
          <div class="about-text">
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
            <a href="about.php" class="theme-btn">More About us</a> </div>
        </div>
        <div class="col-lg-6 col-lg-offset-1 col-md-7">
          <div class="about-pic-area">
            
             
              <img src="assets/img/welcome-to-stone.png" width="100%">
          </div>
        </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end about-section --> 




  <!-- start service-section-s2 -->
  <section class="service-section-s2 section-padding pt0">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
                <div class="section-title-s2"> <span>What we do</span>
                    <h2>See Our Best Services</h2>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
                </div>
            </div>
        </div>
        <div class="row">
	        <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
          <div class="what_we_do_figure">
                    <img src="assets/img/living-room-pendant-light.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Interior Design</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					<a class="what_we_do_icon" href="services.php">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</a>
				</div>
			</div>
			<div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/Roof-extension.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Renovation</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					<a class="what_we_do_icon" href="services.php">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</a>
				</div>
			</div>
			<div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
					<div class="top_line"></div>
					<div class="what_we_do_figure">
                    <img src="assets/img/developer-services.jpg" alt="" width="100%">
					</div>
					<h4 class="what_we_do_title">Builder Services</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					<a class="what_we_do_icon" href="services.php">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</a>
				</div>
            </div>
            <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
          <div class="top_line"></div>
          <div class="what_we_do_figure">
                    <img src="assets/img/download.jpg" alt="" width="100%">
					</div>
					<!-- <div class="what_we_do_figure">
                    <div class="icon"> <i class="fas fa-tools"></i> </div>
					</div> -->
					<h4 class="what_we_do_title">Carpenter</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					<a class="what_we_do_icon" href="services.php">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</a>
				</div>
            </div>
            <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
          <div class="top_line"></div>
          <div class="what_we_do_figure">
                    <img src="assets/img/081219110833.jpg" alt="" width="100%">
					</div>
					<!-- <div class="what_we_do_figure">
                    <div class="icon"> <i class="fas fa-toolbox"></i> </div>
					</div> -->
					<h4 class="what_we_do_title">Construction</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					<a class="what_we_do_icon" href="services.php">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</a>
				</div>
            </div>
        <div class="col-sm-6 col-md-4">
				<div class="single_what_we_do">
          <div class="top_line"></div>
          <div class="what_we_do_figure">
                    <img src="assets/img/hire-a-painter-3-paintzen.jpg" alt="" width="100%">
					</div>
					<!-- <div class="what_we_do_figure">
                    <div class="icon"> <i class="fas fa-paint-roller"></i> </div>
					</div> -->
					<h4 class="what_we_do_title">Painter</h4>
					<div class="what_we_do_content">Lorem ipsum dolor amet, consectetur adipiscing elit eiusmod.</div>
					<a class="what_we_do_icon" href="services.php">
						<i class="fa fa-angle-right" aria-hidden="true"></i>
					</a>
				</div>
			</div>

      <div class="col-lg-12 cart-contact pt-5">
         <center> <a href="services.php" class="theme-btn text-center">See More</a></center>
      </div>
	    </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end service-section-s2 --> 

  
  <!-- start fun-fact-section -->
  <section class="fun-fact-section">
    <div class="container">
      <div class="row">
        <div class="col col-xs-12">
          <div class="fun-fact-grids clearfix">
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="500">50</span>+</h3>
                <p>Finished Projects</p>
              </div>
            </div>
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="250">20</span>+</h3>
                <p>Years of Experience</p>
              </div>
            </div>
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="15">00</span>+</h3>
                <p>Awards winning</p>
              </div>
            </div>
            <div class="grid">
              <div class="info">
                <h3><span class="counter" data-count="100">00</span>%</h3>
                <p>Happy Clients</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end fun-fact-section --> 



  <!-- start portfolio-section -->
  <section class="portfolio-section section-padding">
    <div class="container">
      <div class="row">
        <div class="col col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
          <div class="section-title-s2"> <span>All Categories</span>
            <h2>Our Products</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col col-12">
          <div class="portfolio-grids portfolio-slider">
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/indian_marbles.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="marble.php">Marble</a></h3>
                <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/granite.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="granite.php">Granite</a></h3>
                <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/sandstone.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="sand_stone.php">Sand Stone</a></h3>
                <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/imported_marbles.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="imported_marble.php">Imported Marble </a></h3>
                <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/imported-granite.jpeg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="imported_granite.php">Imported Granite </a></h3>
                <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
              </div>
            </div>
            <div class="grid">
              <div class="img-holder"> <img src="assets/img/designer-marble-temple-250x250.jpg" alt>
                <div class="service-image-overlay"></div>
              </div>
              <div class="details">
                <h3><a href="handicraft.php">Handicraft </a></h3>
                <p class="cat">Lorem ipsum dolor sit amet consect adipisi elit sed do eiusm tempor</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end portfolio-section --> 


  
  <!-- start cta-section -->
  <section class="cta-section section-padding">
    <div class="container">
      <div class="row">
        <div class="col col-12">
          <div class="cta-content">
            <h2>We have 20 years experience in Constrution</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
            <div class="phone-btn"><a href="#" class="theme-btn">Contact us</a> </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end cta-section --> 


   <!-- start team-section -->
   <section class="team-section">
    <div class="container">
      <div class="row">
        <div class="col col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
          <div class="section-title-s2"> <span>Products View</span>
            <h2>Our Gallery</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
          </div>
        </div>
      </div>
    </div>
    <div class="content-area">
      <div class="team-grids team-slider">
        <div class="grid">
          <div class="inner">
            <div class="img-holder"> <img src="assets/img/gallery/product-jpeg-500x500.jpg" alt> </div>
            <div class="details">
              <h4>Handicraft</h4>
              <div class="social">
               
                <a href="photo_gallery.php">See More<i class="fas fa-angle-double-right"></i></a>
                  
               
              </div>
              
            </div>
          </div>
        </div>
        <div class="grid">
          <div class="inner">
            <div class="img-holder"> <img src="assets/img/gallery/nano-white-marble-slabs-1567409156-5062739.jpeg" alt> </div>
            <div class="details">
              <h4>White Marble</h4>
              <div class="social">
               
                <a href="photo_gallery.php">See More<i class="fas fa-angle-double-right"></i></a>
                  
               
              </div>
            </div>
          </div>
        </div>
        <div class="grid">
          <div class="inner">
            <div class="img-holder"> <img src="assets/img/gallery/pink-marble-1537437566-4321400.jpeg" alt> </div>
            <div class="details">
              <h4>Pink Marble</h4>
             
              <div class="social">
               
                <a href="photo_gallery.php">See More<i class="fas fa-angle-double-right"></i></a>
                  
               
              </div>
            </div>
          </div>
        </div>
        <div class="grid">
          <div class="inner">
            <div class="img-holder"> <img src="assets/img/gallery/Indian-Green-Marble.jpg" alt> </div>
            <div class="details">
              <h4>Green Marble</h4>
              <div class="social">
               
               <a href="photo_gallery.php">See More<i class="fas fa-angle-double-right"></i></a>
                 
              
             </div>
            </div>
          </div>
        </div>
        <div class="grid">
          <div class="inner">
            <div class="img-holder"> <img src="assets/img/gallery/red.jpg" alt> </div>
            <div class="details">
              <h4>Red Grenite</h4>
              <div class="social">
               
                <a href="photo_gallery.php">See More<i class="fas fa-angle-double-right"></i></a>
                  
               
              </div>
            </div>
          </div>
        </div>
        <div class="grid">
          <div class="inner">
            <div class="img-holder"> <img src="assets/img/gallery/rajasthan-black-granite-block-slab-500x500.jpg" alt> </div>
            <div class="details">
              <h4>Black Grenite</h4>
              <div class="social">
               
                <a href="photo_gallery.php">See More<i class="fas fa-angle-double-right"></i></a>
                  
               
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end team-section --> 



    <!-- start testimonial-section -->
    <section class="testimonial-section">
    <div class="container"> 
      <!-- Sec Title -->
      <div class="section-title-s2"> <span>Client Testimonials</span>
        <h2>Service Recipient Says</h2>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
      </div>
      <div class="testimonials-carousel owl-carousel owl-theme"> 
        <!-- Testimonial Block -->
        <div class="testimonials-item">
          <h2>Awesome Service</h2>
         
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy texty</p>
          <picture><img alt="" src="assets/img/testimonials2.png"></picture>
          <h3>Nancy<br>
            <span>Corporator</span> </h3>
        </div>
        
        <!-- Testimonial Block -->
        <div class="testimonials-item">
          <h2>Awesome Service</h2>
        
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy texty</p>
          <img alt="" src="assets/img/happy-clients-02.jpg">
          <h3>Nancy Muller<br>
            <span>Corporator</span> </h3>
        </div>
        
        <!-- Testimonial Block -->
        <div class="testimonials-item">
          <h2>Awesome Service</h2>
        
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy texty</p>
          <img alt="" src="assets/img/happy-clients-02.jpg">
          <h3>Nancy<br>
            <span>Corporator</span> </h3>
        </div>
		        <!-- Testimonial Block -->
        <div class="testimonials-item">
          <h2>Awesome Service</h2>
         
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy texty</p>
          <img alt="" src="assets/img/happy-clients-02.jpg">
          <h3>Nancy<br>
            <span>Corporator</span> </h3>
        </div>
      </div>
    </div>
  </section>
  <!-- end testimonial-section --> 


  <!-- start blog-section -->
  <section class="blog-section section-padding">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
          <div class="section-title-s2"> <span>Recent inside</span>
            <h2>Blog & Articles</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry lorem Ipsum has been the industry's standard dummy text</p>
          </div>
        </div>
      </div>
      <div class="row">
         <div class="col-lg-4">
            <div class="blog-inner">
              <div class="img-cat">
                <div class="img-holder"> <img src="assets/img/image.jpg" alt> </div>
              </div>
              <div class="details">
                <h3><a href="#">Lorem ipsum dolor site nec amet consec adipiscing elite.</a></h3>
                <div class="meta">
                  <div class="author"> <a href="#">By : Mich Jhon </a> </div>
                 
               	</div>
				        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
              <a href="blog.php" class="theme-btn one">Read More</a>
              </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="blog-inner">
              <div class="img-cat">
                <div class="img-holder"> <img src="assets/img/1a309508fee8e15e55d0381fd1f7600b.jpg" alt> </div>
              </div>
              <div class="details">
                <h3><a href="#">Lorem ipsum dolor site nec amet consec adipiscing elite.</a></h3>
                <div class="meta">
                  <div class="author"> <a href="#">By : Mich Jhon </a> </div>
                 
               	</div>
				        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
              <a href="blog.php" class="theme-btn one">Read More</a>
              </div>
            </div>
         </div>
         <div class="col-lg-4">
            <div class="blog-inner">
              <div class="img-cat">
                <div class="img-holder"> <img src="assets/img/natural-stones11.jpg" alt> </div>
              </div>
              <div class="details">
                <h3><a href="#">Lorem ipsum dolor site nec amet consec adipiscing elite.</a></h3>
                <div class="meta">
                  <div class="author"> <a href="#">By : Mich Jhon </a> </div>
                 
               	</div>
				        <p>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
              <a href="blog.php" class="theme-btn one">Read More</a>
              </div>
            </div>
         </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end blog-section --> 
   <!-- start partners-section -->
   <section class="partners-section">
     
    <div class="container">

    <div class="row">
        <div class="col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-sm-10 offset-sm-1">
          <div class="section-title-s2">
            <h2>Our Patners</h2>
            
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col col-xs-12">
          <div class="partner-grids partners-slider">
            <div class="grid"> <img src="assets/img/mysql.jpg" alt> </div>
            <div class="grid"> <img src="assets/img/mysql.jpg" alt> </div>
            <div class="grid"> <img src="assets/img/mysql.jpg" alt> </div>
            <div class="grid"> <img src="assets/img/mysql.jpg" alt> </div>
            <div class="grid"> <img src="assets/img/mysql.jpg" alt> </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end container --> 
  </section>
  <!-- end partners-section --> 