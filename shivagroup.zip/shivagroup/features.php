<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Our Features</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Our Features</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>




<section class="about-us-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="theme-sidebar  float-left  theme-col">
                    <div class="sidebar-list">
                        <ul>
                           
                            <li><a href="features.php" class="tran3s">Who we are</a></li>
                            <li><a href="features.php" class="tran3s">What We do</a></li>
                            <li><a href="features.php" class="tran3s">Why Choose Us?</a></li>
                            <li><a href="about.php" class="tran3s">About Us</a></li>
                           
                        </ul>
                    </div>
                    
                    <div class="sidebar-list downloaditem">
                        <ul>
                            <li><a href="product.php" class="tran3s">Products</a></li>
                            <li><a href="contact.php" class="tran3s">Contact Us</a></li>
                            <li><a href="services.php" class="tran3s">Services </a></li>
                        </ul>
                    </div>
                    <div class="sep30"></div>
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12">
                <div class="theme-large-content theme-col  float-right ">
                    <div id="block-world-content">
                        <article role="article">
                           
                            <div>
                                <h4>Who we are</h4>
                                <p class="text1">Renowned for its high-quality hardwood flooring and environmentally sound manufacturing practices, Mullican Flooring provides customers with endless possibilities for beautifully designed spaces. Mullican’s distinctive collections are available in elegant, smooth finishes, as well as rustic, hand-sculpted or wire-brushed surface treatments. Unique features also include random 6- and 7-foot planks and exceptionally wider widths</p>
                                
                                <p class="text1">Wasting no time, the duo established Business with the aim of providing business support services to the Merseyside SME market 17 years on, the bcore network now spans across over 50 offices in the UK and offices in New york,</p>
                                <hr>
                                <div class="theme-company-overview">
                                <h4>What we do</h4>
                                <p class="text1">Renowned for its high-quality hardwood flooring and environmentally sound manufacturing practices, Mullican Flooring provides customers with endless possibilities for beautifully designed spaces. Mullican’s distinctive collections are available in elegant, smooth finishes, as well as rustic, hand-sculpted or wire-brushed surface treatments. Unique features also include random 6- and 7-foot planks and exceptionally wider widths</p>
                               
                                <hr>
                                <h4>Why you choose us?</h4>
                                <p class="text1">Renowned for its high-quality hardwood flooring and environmentally sound manufacturing practices, Mullican Flooring provides customers with endless possibilities for beautifully designed spaces. Mullican’s distinctive collections are available in elegant, smooth finishes, as well as rustic, hand-sculpted or wire-brushed surface treatments. Unique features also include random 6- and 7-foot planks and exceptionally wider widths</p>
                               
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
	include('footer.php');
?>