<?php
	include('header.php');
?>

<div class="pagehding-sec">
  <div class="images-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="page-heading">
          <h1>Blog Single</h1>
        </div>
        <div class="page-breadcrumb-inner">
          <div class="page-breadcrumb">
            <div class="breadcrumb-list">
              <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="#">Blog Single</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<section class="section-padding blog-single-section">
    <div class="container">
<div class="row">
  <div class="col col-md-8">
    <div class="blog-content">
      <div class="post format-standard-image">
        <div class="entry-media"> <img src="assets/img/1a309508fee8e15e55d0381fd1f7600b.jpg" alt="" width="100%"> </div>
        <ul class="entry-meta">
          <li><a href="#"><i class="far fa-clock"></i>Feb 20, 2019</a></li>
          <li><a href="#"><i class="fas fa-user"></i>Admin</a></li>
         
        </ul>
        <h2>Comprehensive learning platform for serious consultants and skilled professionals who want to grow</h2>
        <p>Travelling salesman  and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame. It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the whole of her lower </p>
        <p>His many legs, pitifully thin compared with the size of the rest of him, waved about helplessly as he looked. "What's happened to me?" he thought. It wasn't a dream. His room, a proper human room although a little too small, lay peacefully between its four familiar walls. A collection of textile samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame. It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the whole of her lower arm towards the viewer. Gregor then turned to look out the window at the dull weather. Drops</p>
        <blockquote> Samples lay spread out on the table - Samsa was a travelling salesman - and above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame. It showed a lady fitted out with a fur hat and fur boa who sat upright <span class="quoter">- Mic dow</span> </blockquote>
        <h3>Recently cut out of an illustrated magazine and housed in a nice, gilded frame. It showed a lady fitted out with a fur hat and fur boa </h3>
        <p>And above it there hung a picture that he had recently cut out of an illustrated magazine and housed in a nice, gilded frame. It showed a lady fitted out with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the whole of her lower arm towards the viewer. Gregor then turned to look out the window at the dull weather. Drops with a fur hat and fur boa who sat upright, raising a heavy fur muff that covered the </p>
      </div>
      <div class="tag-share">
        <div class="tag"> Tags: &nbsp;
          <ul>
            <li><a href="#">Business ,</a></li>
            <li><a href="#">Agency ,</a></li>
            <li><a href="#">Finance</a></li>
            <li><a href="#">Consutling ,</a></li>
          </ul>
        </div>
        <div class="share"> Share: &nbsp;
          <ul>
            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
          </ul>
        </div>
      </div>
      <!-- end tag-share -->
      
      <!-- end author-box -->
      
      <div class="more-posts">
        <div class="previous-post"> <a href="#"> <span class="post-control-link"><i class="fas fa-angle-double-left"></i>Previous post</span> </a> </div>
        <div class="next-post"> <a href="0.html"> <span class="post-control-link">Next post <i class="fas fa-angle-double-right"></i></span> </a> </div>
      </div>
      <!-- end more-posts -->
     
      <!-- end comments-area --> 
    </div>
  </div>
  <div class="col col-md-4">
    <div class="blog-sidebar">
      <div class="widget search-widget">
        <h3>Search</h3>
        <form>
          <div>
            <input type="text" class="form-control" placeholder="Search Post..">
            <button type="submit"><i class="ti-search"></i></button>
          </div>
        </form>
      </div>
      <div class="widget category-widget">
        <h3>Categories</h3>
        <ul>
          <li><a href="#">Building Staff <span>(2)</span></a></li>
          <li><a href="#">Renovation <span>(5)</span></a></li>
          <li><a href="#">Roof Repairing <span>(3)</span></a></li>
          <li><a href="#">Architectural <span>(7)</span></a></li>
          <li><a href="#">Interior <span>(10)</span></a></li>
        </ul>
      </div>
      <div class="widget recent-post-widget">
        <h3>Recent post</h3>
        <div class="posts">
          <div class="post">
            <div class="img-holder"> <img src="assets/img/download (1).jpg" alt=""> </div>
            <div class="details">
              <h4><a href="#">Slightly domed and divided by arches</a></h4>
              <span class="date">Mar 19 2019</span> </div>
          </div>
          <div class="post">
            <div class="img-holder"> <img src="assets/img/download (1).jpg" alt=""> </div>
            <div class="details">
              <h4><a href="#">Collection of textile samples lay spread</a></h4>
              <span class="date">Mar 19 2019</span> </div>
          </div>
          <div class="post">
            <div class="img-holder"> <img src="assets/img/download (1).jpg" alt=""> </div>
            <div class="details">
              <h4><a href="#">Recently cut out of an illustrated magazine </a></h4>
              <span class="date">Mar 19 2019</span> </div>
          </div>
        </div>
      </div>
      <div class="widget tag-widget">
        <h3>Tags</h3>
        <ul>
          <li><a href="#">Smart Houses</a></li>
          <li><a href="#">Interior</a></li>
          <li><a href="#">Architectural</a></li>
          <li><a href="#">Renovation</a></li>
          <li><a href="#">Building Staff</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

    </div>
    <!-- end container --> 
  </section>

<?php
	include('footer.php');
?>