<?php 
session_start();
if(!isset($_SESSION['login'])){
	header('location:login.php');
}
include('../config.php');
?>
<?php include("header.php"); ?>
<?php include("menu.php"); ?>
<?php include("home.php"); ?>
<?php include("footer.php"); ?>