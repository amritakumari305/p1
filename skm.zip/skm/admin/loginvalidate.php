<?php 
// Inialize session
session_start();  
include('../config.php'); 
  
   
if(isset($_POST['submit'])) { 
      
    $username = $_POST["username"]; 
    $password = $_POST["password"]; 
    $sql = " select * from  login where username='$username' and password='$password' ";
    $result = mysqli_query($conn,$sql);
      
    $row = mysqli_num_rows($result);
    
		if($row > 0){
			$_SESSION['login'] = $username;
			header('location:index.php');
		}else{
			header('location:login.php');
		}
} 
  
?> 