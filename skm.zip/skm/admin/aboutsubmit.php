<?php
include("../config.php");
$title = $_POST['title'];
$para = $_POST['para'];
$file_name = $_FILES['image']['name'];
$status = $_POST['status'];

$temp_path=$_FILES['image']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);
// display the results
$sql = "INSERT INTO about (title, image, para, status) VALUES ('$title', '$destination', '$para', '$status')";
mysqli_query($conn, $sql);   
?>