<aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav" class="p-t-30">

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="index.php" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard</span></a></li>
                        
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="fas fa-truck"></i><span class="hide-menu">Slider  </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="slideradd.php" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Add</span></a></li>
                                <li class="sidebar-item"><a href="slidershow.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Show </span></a></li>
                                <li class="sidebar-item"><a href="slideredit.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Edit </span></a></li>
                                <li class="sidebar-item"><a href="sliderupdate.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Update </span></a></li>
                                <li class="sidebar-item"><a href="sliderdelete.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Delete </span></a></li>
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="fas fa-truck"></i><span class="hide-menu">Services  </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="servicesadd.php" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Add</span></a></li>
                                <li class="sidebar-item"><a href="servicesshow.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Show </span></a></li>
                                <li class="sidebar-item"><a href="servicesedit.php" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Edit</span></a></li>
                                <li class="sidebar-item"><a href="servicesupdate.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Update </span></a></li>
                                <li class="sidebar-item"><a href="servicesdelete.php" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Delete</span></a></li>
                                
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="fas fa-truck"></i><span class="hide-menu">About  </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="aboutadd.php" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Add </span></a></li>
                                <li class="sidebar-item"><a href="aboutshow.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> show </span></a></li>
                                <li class="sidebar-item"><a href="aboutedit.php" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Edit </span></a></li>
                                <li class="sidebar-item"><a href="aboutupdate.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Update </span></a></li>
                                <li class="sidebar-item"><a href="aboutdelete.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Delete </span></a></li>
                               
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="contact.php" aria-expanded="false"><i class="fas fa-minus-square"></i><span class="hide-menu">Contact</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="fas fa-truck"></i><span class="hide-menu">Media  </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="media.php" class="sidebar-link"><i class="mdi mdi-note-outline"></i><span class="hide-menu"> Add </span></a></li>
                                <li class="sidebar-item"><a href="mediashow.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> show </span></a></li>
                                <li class="sidebar-item"><a href="mediaedit.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Edit </span></a></li>
                                <li class="sidebar-item"><a href="mediaupdate.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Update </span></a></li>
                                <li class="sidebar-item"><a href="mediadelete.php" class="sidebar-link"><i class="mdi mdi-note-plus"></i><span class="hide-menu"> Delete </span></a></li>
                               
                            </ul>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link has-arrow waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-account-key"></i><span class="hide-menu">Authentication </span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
                                <li class="sidebar-item"><a href="authentication-login.php" class="sidebar-link"><i class="mdi mdi-all-inclusive"></i><span class="hide-menu"> Login </span></a></li>
                                <li class="sidebar-item"><a href="authentication-register.php" class="sidebar-link"><i class="mdi mdi-all-inclusive"></i><span class="hide-menu"> Register </span></a></li>
                            </ul>
                        </li>

                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <div class="page-wrapper">