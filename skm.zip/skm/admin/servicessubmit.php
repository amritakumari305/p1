<?php
include("../config.php");
$title = $_POST['title'];
$para = $_POST['para'];
$file_name = $_FILES['image']['name'];

$temp_path=$_FILES['image']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);
// display the results
$sql = "INSERT INTO services (title, image, para) VALUES ('$title', '$destination', '$para')";
mysqli_query($conn, $sql);   
?>