<?php 
include("../config.php");
$id= $_POST['id'];
$title = $_POST['title'];
$para = $_POST['para'];
$file_name = $_FILES['image']['name'];
$aql ="UPDATE about set id='" . $_POST['id'] . "', title='" . $_POST['title'] . "', para='" . $_POST['para'] . "', image='" . $_POST['image'] . "' WHERE id='" . $_POST['id'] . "'";
$message = "Record Modified Successfully";

$result = mysqli_query($conn,"SELECT * FROM about WHERE id='" . $_GET['id'] . "'");
$row= mysqli_fetch_array($result);
?>
