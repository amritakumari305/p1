<?php
include("../config.php");
$result = mysqli_query($conn,"SELECT * FROM contact");
?>
<?php include("header.php"); ?>
<?php include("menu.php");?>

<div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Add Slider</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="inr-form" style="border: 1px solid rgb(194, 190, 190);padding: 10px;">
                    <div class="row">
                        <div class="col-lg-12">


                            <div class="card">
                                <article class="card-group-item">

                                    <div class="filter-content">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                   
                                                <?php
                                                if (mysqli_num_rows($result) > 0) {
                                                ?>
                                                            <table class="table table-striped table-bordered table-hover">
                                                                <colgroup>
                                                                    <col class="con0">
                                                                    <col class="con1">
                                                                    <col class="con0">
                                                                    <col class="con1">
                                                                    <col class="con0">
                                                                </colgroup>
                                                                <thead>
                                                                    <tr>
                                                                        <th class="head1">Sr.No.</th>
                                                                        <th class="head1">Fname</th>
                                                                        <th class="head1">email</th>
                                                                        <th class="head1">subject</th>
                                                                        <th class="head1">Phone</th>
                                                                        <th class="head1">massages</th>
                                                                        <th class="head1">Date</th>
                                                                       

                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                <?php
                                                                $i=1;
                                                                while($row = mysqli_fetch_array($result)) {
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo $i; ?></td>
                                                                    
                                                                    <th class="head1"><?php echo $row["fname"]; ?></th>
                                                                    <td><?php echo $row["email"]; ?></td>
                                                                    <td><?php echo $row["subject"]; ?></td>
                                                                    <td><?php echo $row["phone"]; ?></td>
                                                                    <td><?php echo $row["massages"]; ?></td>
                                                                    <td><?php echo $row["created"]; ?></td>
                                                                </tr>
                                                                <?php
                                                                $i++;
                                                                }
                                                                ?>
                                                                </tbody>
                                                            </table>
                                                            <?php
                                                            }
                                                            else{
                                                                echo "No result found";
                                                            }
                                                            ?>
                                                </div>
                                                <!-- /.row (nested) -->
                                            </div>
                                        </div>
                                        <!-- card-body.// -->
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>

                </div>


                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>

        
        
<?php include("footer.php"); ?>