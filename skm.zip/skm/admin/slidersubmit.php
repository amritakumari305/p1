<?php
include("../config.php");
$title = $_POST['title'];
$file_name = $_FILES['images_sld']['name'];

$temp_path=$_FILES['images_sld']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);
// display the results
$sql = "INSERT INTO slider (title, images_sld) VALUES ('$title', '$destination')";
mysqli_query($conn, $sql);   
?>