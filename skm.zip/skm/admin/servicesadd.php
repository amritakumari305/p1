<?php include("header.php"); ?>
<?php include("menu.php");?>

<div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Add Services</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="inr-form" style="border: 1px solid rgb(194, 190, 190);padding: 10px;">
                    <div class="row">
                        <div class="col-lg-12">


                            <div class="card">
                                <article class="card-group-item">

                                    <div class="filter-content">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <form role="form" id="add_media" method="post" action="servicessubmit.php" name="add_media" enctype="multipart/form-data">
                                                       
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <label>Title </label>
                                                                    <input type="text" name="title" value="" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <label>Description </label>
                                                                    <input type="text" name="para" value="" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <label>Images </label>
                                                                    <input type="file" name="image" value="" class="form-control">
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="col-lg-12">
                                                                <div class="form-group">
                                                                    <button type="submit" onclick="document.getElementById('').submit();" class="btn btn-default" name="view" value="submit">Add Services</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                    
                                                </div>
                                                <!-- /.row (nested) -->
                                            </div>
                                        </div>
                                        <!-- card-body.// -->
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>

                </div>


                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>

        
        
<?php include("footer.php"); ?>