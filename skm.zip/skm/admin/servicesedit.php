<?php
include ('../config.php');
if(count($_POST)>0) {

    if($_FILES['image']['name']!='')
    {
        $file_name = $_FILES['image']['name'];
    
        $temp_path=$_FILES['image']['tmp_name'];
        $destination="images/".$file_name;
        if(move_uploaded_file($temp_path, $destination)){
            unlink($_POST['old_img']); // for delete file from server
        }
    
        mysqli_query($conn,"UPDATE services set  title='" . $_POST['title'] . "', para='" . $_POST['para'] . "', image='" . $destination. "' WHERE id='" . $_POST['id'] . "'");
    }else{
    
    
        mysqli_query($conn,"UPDATE services set  title='" . $_POST['title'] . "', para='" . $_POST['para'] . "', image='" . $_POST['old_img'] . "' WHERE id='" . $_POST['id'] . "'");
    }
    
    
    
    $message = "Record Modified Successfully";
    }
    
    
    $result = mysqli_query($conn,"SELECT * FROM services WHERE id='" . $_GET['id'] . "'");
    $row= mysqli_fetch_array($result);
?>
<?php include("header.php"); ?>
<?php include("menu.php");?>

<div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Add Services</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Library</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <div class="inr-form" style="border: 1px solid rgb(194, 190, 190);padding: 10px;">
                    <div class="row">
                        <div class="col-lg-12">


                            <div class="card">
                                <article class="card-group-item">

                                    <div class="filter-content">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <form role="form" id="add_media" method="post" action="" name="add_media" enctype="multipart/form-data">
                                                    <div><?php if(isset($message)) { echo $message; } ?>
</div>
                                                        <div class="row">
                                                        <input type="hidden" name="id" class="txtField" value="<?php echo $row['id']; ?>">
                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <label>Title </label>
                                                                    <input type="text" name="title" value="<?php echo $row['title']; ?>" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <label>Description </label>
                                                                    <input type="text" name="para" value="<?php echo $row['para']; ?>" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="form-group">
                                                                    <label>Images </label>
                                                                    <input type="file" name="image" value="" class="form-control">
                                                                    <img src="<?php echo $row['image']; ?>" />
                                                                    <input type="hidden" name="old_img" value="<?php echo $row['image']; ?>">
                                                                </div>
                                                            </div>
                                                            
                                                            <div class="col-lg-12">
                                                                <div class="form-group">
                                                                    <button type="submit" class="btn btn-default" name="submit" value="submit">Edit Services</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                    
                                                </div>
                                                <!-- /.row (nested) -->
                                            </div>
                                        </div>
                                        <!-- card-body.// -->
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>

                </div>


                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Right sidebar -->
                <!-- ============================================================== -->
                <!-- .right-sidebar -->
                <!-- ============================================================== -->
                <!-- End Right sidebar -->
                <!-- ============================================================== -->
            </div>

        
        
<?php include("footer.php"); ?>