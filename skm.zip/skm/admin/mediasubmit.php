<?php
include("../config.php");
$file_name = $_FILES['media_img']['name'];

$temp_path=$_FILES['media_img']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);
// display the results
$sql = "INSERT INTO media (media_img) VALUES ('$destination')";
 mysqli_query($conn, $sql);   
?>