<?php 
include('config.php');
$result = mysqli_query($conn,"SELECT * FROM slider");
?>
<section id="carsolues">

  <div class="swiper-container slideshow">

    <div class="swiper-wrapper">
    <?php
while($row = mysqli_fetch_array($result)) { ?>
      <div class="swiper-slide slide">
        <div class="slide-image" style="background-image: url(images/<?php echo $row["images_sld"]; ?>)"></div>
        <span class="slide-title"><?php echo $row["title"]; ?></span>
      </div>

      <div class="swiper-slide slide">
        <div class="slide-image" style="background-image: url(images/skm2.jpg)"></div>
        <span class="slide-title">Miles of Tiles.</span>
      </div>

      <div class="swiper-slide slide">
        <div class="slide-image" style="background-image: url(images/skm4.jpg)"></div>
        <span class="slide-title">Custom Grenite.</span>
      </div>

      <div class="swiper-slide slide">
        <div class="slide-image" style="background-image: url(images/skm5.jpg)"></div>
        <span class="slide-title">Choose the best.</span>
      </div>
      
      <?php } ?>
    </div>

    <div class="slideshow-pagination"></div>

    <div class="slideshow-navigation">
      <div class="slideshow-navigation-button prev"><span class="fas fa-chevron-left"></span></div>
      <div class="slideshow-navigation-button next"><span class="fas fa-chevron-right"></span></div>
    </div>

  </div>

</section>


<!-- about section start -->
<section id="about" class="section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center">About Us</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="py-3"> 
          <p class="text-center">We provide a professional renovation and installation services with a real focus on customer satisfaction.<br>
          Our installations are carried out by fully trained staff to the highest professional standards.</p>
        </div>
      </div>
    </div>



    <div class="row text-center pt-4">
      <div class="col-md-3"></div>

      <div class="col-md-2 col-sm-4 col-6">
        <div class="about-inner-box">
          <div class="about-box-ixon"><i class="far fa-check-square"></i></div>
          <a href="#" class="sl-small-bubble-check" role="presentation">We Offer</a>
        </div>
      </div>
      <div class="col-md-2 col-sm-4 col-6">
        <div class="about-inner-box">
          <div class="about-box-ixon"><i class="fas fa-shield-alt"></i></div>
          <a href="#" class="sl-small-shield" role="presentation">We Guarantee</a>
        </div>
      </div>
      <div class="col-md-2 col-sm-4 col-6">
        <div class="about-inner-box">
          <div class="about-box-ixon"><i class="fas fa-truck-moving"></i></div>
          <a href="#" class="sl-small-truck" role="presentation">We Provide</a>
        </div>
      </div>

      <div class="col-md-3 "></div>
    </div>
  </div>
</section>


<!-- why section start -->
<section id="why" class="section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center">Why Choose SKM</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="pt-3"> 
          <p class="text-center">With our efforts and dedication, we have reached where we are today. Having been in the granite industry for 25 years now, <br>we have secured a global foothold for ourselves. So what makes our company unique and different?</p>

        </div>
      </div>
    </div>



    <div class="row text-center pt-5">
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big">
          <i class="fas fa-home"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">OVER 24 YEARS EXPERIENCE</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big">
          <i class="far fa-thumbs-up"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">BEST MATERIALS</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big">
          <i class="fas fa-warehouse"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">PROFESSIONAL STANDARDS</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
    </div>
  </div>
</section>


<!-- products section start -->
<section id="products" class="section-padding">
  <div class="container py-3">
    <div class="row">
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center">Our Products</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="pt-3"> 
          <p class="text-center">We provide a professional renovation and installation services with a real focus on customer satisfaction.<br>
          Our installations are carried out by fully trained staff to the highest professional standards.</p>
        </div>
      </div>
    </div>



    <div class="row pt-5">
      
      <div class="col-md-6">
        <figure class="snip1104 blue">
          <img src="images/tile-and-stone-industry-software-micronet.jpg" alt="sample33" />
          <figcaption>
            <h2>Mar  <span> ble</span></h2>
          </figcaption>
          <a href="marble.php"></a>
        </figure>
      </div>
      <div class="col-md-6">
        <div class="stone-content-box"  style="text-align: left;">
           <h2> Marbal</h2>
           <!-- <h4 class="vc_custom_heading dt-sc-skin-highlight txt dt-sc-dark-bg vc_custom_1506595309211"><a href="">EXEMPLARY WORKMANSHIP</a></h4> -->
           <p>Marble is often regarded as the 'queen of stones' which has massive demand. We provide a professional renovation and installation services with a real focus on customer satisfaction.
                  Our installations are carried out by fully trained staff to the highest professional standards.</p>
           <a href="marble.php" class="btn">VIEW ALL</a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="stone-content-box"  style="text-align: right;">
           <h2>Grenite</h2>
           <!-- <h4 class="vc_custom_heading dt-sc-skin-highlight txt dt-sc-dark-bg vc_custom_1506595309211"><a href="">EXEMPLARY WORKMANSHIP</a></h4> -->
           <p>Granite is a natural stone that is famous for its beauty and strength. We provide a professional renovation and installation services with a real focus on customer satisfaction.
                   Our installations are carried out by fully trained staff to the highest professional standards.</p>
           <a href="grenite.php"  class="btn">VIEW ALL</a>
        </div>
      </div>

      <div class="col-md-6">
        <figure class="snip1104 yellow">
          <img src="images/grenite.jpg" alt="sample33">
          <figcaption>
            <h2>Gre  <span> nite</span></h2>
          </figcaption>
          <a href="grenite.php"></a>
        </figure>
      </div>
    </div>
  </div>
</section>


<!-- counter section start -->
<section id="counter" class="section-padding">
<div class="upb_bg_overlay" style="background-color:rgba(0,0,0,0.8);"></div>
  <div class="container">
    <div class="row"></div>
    <div class="row text-center">
      <div class="col">
        <div class="counter">
          <div class="counter-img"><img src="images/team.png" alt=""></div>
          <h2 class="timer count-title count-number mt-3" data-to="1700" data-speed="1500">+</h2>
          <p class="count-text mt-4">Our Customer</p>
        </div>
      </div>
      <div class="col">
        <div class="counter">
          <div class="counter-img"><img src="images/hayypcilent.png" alt=""></div>
          <h2 class="timer count-title count-number mt-3" data-to="100" data-speed="1500">+</h2>
          <p class="count-text mt-4">Happy Clients</p>
        </div>
      </div>
      <div class="col">
        <div class="counter">
          <div class="counter-img"><img src="images/brickwall.png" alt=""></div>
          <h2 class="timer count-title count-number mt-3" data-to="1000" data-speed="1500">+</h2>
          <p class="count-text mt-4">Products</p>
        </div>
      </div>
      <div class="col">
        <div class="counter">
          <div class="counter-img"><img src="images/calendar.png" alt=""></div>
          <h2 class="timer count-title count-number mt-3" data-to="25" data-speed="1500">+</h2>
          <p class="count-text mt-4">Year Of Experince</p>
        </div>
      </div>
    </div>
  </div>
</section>





<section id="get_quote" class="section-padding">
  <div class="container py-4">
    <div class="row">
      <div class="col-md-9">
        <div class="vertical-align">
          <div class="wallet_get float-left"><i class="fas fa-wallet"></i></div>
          <div class="vertical-align-cell sl-small-wallet">
            <h3>COST OF GRENITE</h3>
            <p class="description">Use our form to estimate the initial cost of renovation or installation</p>
          </div>
        </div>
      </div>
      <div class="col-md-3"><div class="get-quote-button mt-4 text-center"> <a href="#"  class="btn">Get Quote</a></div></div>
    </div>
  </div>
</section>




<!-- applications section start -->
<section id="applications" class="section-padding">
  <div class="container-fluid py-3">
    <div class="row">
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center text-white">Applications</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="pt-3"> 
          <p class="text-center text-white">We provide a professional renovation and installation services with a real focus on customer satisfaction.<br>
          Our installations are carried out by fully trained staff to the highest professional standards.</p>
        </div>
      </div>
    </div>



    <div class="row pt-4 px-2">
      <div class="col-md-3">
          <div class="application-section">
            <img src="images/basketweave2.jpg" alt="Notebook" style="width:100%;">
            <div class="content">
              <h3>Flooring</h3>
            </div>
          </div>
      </div>
      <div class="col-md-3">
        <div class="application-section">
            <img src="images/countertop.jpg" alt="Notebook" style="width:100%;">
            <div class="content">
              <h3>Countertop</h3>
            </div>
          </div>
      </div>
      <div class="col-md-3">
         <div class="application-section">
            <img src="images/ed257716185a497a4ae7cad76822019b.jpg" alt="Notebook" style="width:100%;">
            <div class="content">
              <h3>Table Top</h3>
            </div>
          </div>  
      </div>
      <div class="col-md-3">
        <div class="application-section">
            <img src="images/wallcladding.jpg" alt="Notebook" style="width:100%;">
            <div class="content">
              <h3>Wall Cladding</h3>
            </div>
          </div>
      </div>
    </div>
  </div>
</section>




<!-- media section start -->
<section id="media" class="section-padding">
  <div class="container-fluid py-3">
    <div class="row">
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center">Media</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="pt-3"> 
          <p class="text-center">We provide a professional renovation and installation services with a real focus on customer satisfaction.<br>
          Our installations are carried out by fully trained staff to the highest professional standards.</p>
        </div>
      </div>
    </div>
  </div>
</section>
<section id="media_slider" class="customer-logos slider pb-5">
          <div class="slide"><img src="images/slide1.jpg"></div>
          <div class="slide"><img src="images/slide2.jpg"></div>
          <div class="slide"><img src="images/unnamed.jpg"></div>
          <div class="slide"><img src="images/slide3.jpg"></div>
          <div class="slide"><img src="images/slide1.jpg"></div>
          <div class="slide"><img src="images/slide1.jpg"></div>
          <div class="slide"><img src="images/slide1.jpg"></div>
          <div class="slide"><img src="images/slide1.jpg"></div>
          <div class="slide"><img src="images/slide1.jpg"></div>
</section>



<!-- adrs start -->
<section id="adrs_ph" class="py-4">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="left-icon-adrs float-left"><i class="fas fa-phone fa-rotate-90"></i></div>
        <div class="contact-details-box sl-small-phone"><p>Phone:<br>
          +149 75 23 222 35</p>
        </div>
      </div>
      <div class="col-md-4">
      <div class="left-icon-adrs float-left"><i class="fas fa-map-marked-alt"></i></div>
        <div class="contact-details-box sl-small-location"><p>28A, Santosh Nagra<br>
              Jaipur, FL 32789</p></div>
        </div>
      <div class="col-md-4">
        <div class="left-icon-adrs float-left"><i class="fas fa-envelope-open-text"></i></div>
          <div class="contact-details-box sl-small-mail"><p>E-mail:<br>
           <a href="mailto:skm@mail.com">skm@mail.com</a></p>
          </div>
      </div>
    </div>
  </div>
</section>








