<?php
	include('header.php'); 
?>
<?php
	include('menu.php'); 
?>

<!-- breadcrumb -->
<section id="breadcrumb_reg" class="register_breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="header-page">
                    <h1>Media Gallery</h1>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="media_page">

    <!-- Page Content -->
    <div class="container page-top">



<div class="row">


    <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a href="images/images.jpg" class="fancybox" rel="ligthbox">
            <img  src="images/images.jpg" class="zoom img-fluid "  alt="">
           
        </a>
    </div>
    <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a href="images/slide2.jpg"  class="fancybox" rel="ligthbox">
            <img  src="images/slide2.jpg" class="zoom img-fluid"  alt="">
        </a>
    </div>
    
    <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a href="images/images.jpg" class="fancybox" rel="ligthbox">
            <img  src="images/images.jpg" class="zoom img-fluid "  alt="">
        </a>
    </div>
    
    <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a href="images/images.jpg" class="fancybox" rel="ligthbox">
            <img  src="images/images.jpg" class="zoom img-fluid "  alt="">
        </a>
    </div>
    
     <div class="col-lg-3 col-md-4 col-xs-6 thumb">
        <a href="images/images.jpg" class="fancybox" rel="ligthbox">
            <img  src="images/images.jpg" class="zoom img-fluid "  alt="">
        </a>
    </div>
    
        
</div>




</div>



</section>


<?php
	include('footer.php'); 
?>