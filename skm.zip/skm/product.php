<?php
	include('header.php'); 
?>
<?php
	include('menu.php'); 
?>

<!-- breadcrumb -->
<section id="breadcrumb_reg" class="register_breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="header-page">
                    <h1>Product</h1>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- products section start -->
<section id="products" class="section-padding">
  <div class="container py-3">
    <div class="row">
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center">Our Products</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="pt-3"> 
          <p class="text-center">We provide a professional renovation and installation services with a real focus on customer satisfaction.<br>
          Our installations are carried out by fully trained staff to the highest professional standards.</p>
        </div>
      </div>
    </div>



    <div class="row pt-5">
      
      <div class="col-md-6">
        <figure class="snip1104 blue">
          <img src="images/tile-and-stone-industry-software-micronet.jpg" alt="sample33" />
          <figcaption>
            <h2>Mar  <span> bal</span></h2>
          </figcaption>
          <a href="marble.php"></a>
        </figure>
      </div>
      <div class="col-md-6">
        <div class="stone-content-box"  style="text-align: left;">
           <h2> Marble</h2>
           <!-- <h4 class="vc_custom_heading dt-sc-skin-highlight txt dt-sc-dark-bg vc_custom_1506595309211"><a href="">EXEMPLARY WORKMANSHIP</a></h4> -->
           <p>Marble is often regarded as the 'queen of stones' which has massive demand. We provide a professional renovation and installation services with a real focus on customer satisfaction.
                  Our installations are carried out by fully trained staff to the highest professional standards.</p>
           <a href="marble.php" class="btn">VIEW ALL</a>
        </div>
      </div>
      <div class="col-md-6">
        <div class="stone-content-box"  style="text-align: right;">
           <h2>Grenite</h2>
           <!-- <h4 class="vc_custom_heading dt-sc-skin-highlight txt dt-sc-dark-bg vc_custom_1506595309211"><a href="">EXEMPLARY WORKMANSHIP</a></h4> -->
           <p>Granite is a natural stone that is famous for its beauty and strength. We provide a professional renovation and installation services with a real focus on customer satisfaction.
                   Our installations are carried out by fully trained staff to the highest professional standards.</p>
           <a href="grenite.php"  class="btn">VIEW ALL</a>
        </div>
      </div>

      <div class="col-md-6">
        <figure class="snip1104 yellow">
          <img src="images/grenite.jpg" alt="sample33">
          <figcaption>
            <h2>Gre  <span> nite</span></h2>
          </figcaption>
          <a href="grenite.php"></a>
        </figure>
      </div>
    </div>
  </div>
</section>


<?php
	include('footer.php'); 
?>