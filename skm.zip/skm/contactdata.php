<?php
include("config.php");
$fname = $_POST['fname'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$phone = $_POST['phone'];
$massages = $_POST['massages'];

// display the results
$sql = "INSERT INTO contact (fname, email, subject, phone, massages) VALUES ('$fname', '$email', '$subject', '$phone', '$massages')";
 mysqli_query($conn, $sql);   
?>