<?php
  include('config.php');
  include('header.php'); 
  include('menu.php'); 
?>


<!-- breadcrumb -->
<section id="breadcrumb_reg" class="register_breadcrumb">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="header-page">
                    <h1>About Us</h1>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- about section start -->
<section id="about" class="section-padding">
  <div class="container">
    <div class="row">
    
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center">About US</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="py-3"> 
          <p class="text-center">We provide a professional renovation and installation services with a real focus on customer satisfaction.<br>
          Our installations are carried out by fully trained staff to the highest professional standards.</p>
        </div>
      </div>
    </div>



    <div class="row text-center pt-4">
      <div class="col-md-3"></div>

      <div class="col-md-2 col-sm-4 col-6">
        <div class="about-inner-box">
          <div class="about-box-ixon"><i class="far fa-check-square"></i></div>
          <a href="#" class="sl-small-bubble-check" role="presentation">We Offer</a>
        </div>
      </div>
      <div class="col-md-2 col-sm-4 col-6">
        <div class="about-inner-box">
          <div class="about-box-ixon"><i class="fas fa-shield-alt"></i></div>
          <a href="#" class="sl-small-shield" role="presentation">We Guarantee</a>
        </div>
      </div>
      <div class="col-md-2 col-sm-4 col-6">
        <div class="about-inner-box">
          <div class="about-box-ixon"><i class="fas fa-truck-moving"></i></div>
          <a href="#" class="sl-small-truck" role="presentation">We Provide</a>
        </div>
      </div>

      <div class="col-md-3 "></div>
    </div>
  </div>
</section>


<section id="we_offer" class="section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="about-inner">
                    
                    <p class="float-left" style="color:#e8dfc5;font-size:16px;letter-spacing:0.6px">We provide a professional renovation and installation services with a real focus on customer satisfaction.
                    Our installations are carried out by fully trained staff to the highest professional standards.We provide a professional renovation and installation services with a real focus on customer satisfaction.
                    Our installations are carried out by fully trained staff to the highest professional standards.</p>
                </div>
            </div>
            <div class="col-md-5">
                <div class="about-imgaes">
                <img src="images/images.jpg" alt="" width="100%">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- <section id="team" class="section-padding">
    <div class="container">
        <div class="row">
        <div class="col-md-12">
            <div class="about-inner text-center">
            <h2 class="text-center">About US</h2>
            <img src="images/header-boredr.png" alt="" width="230" class="py-3"> 
            <p class="text-center">We provide a professional renovation and installation services with a real focus on customer satisfaction.<br>
            Our installations are carried out by fully trained staff to the highest professional standards.</p>
            </div>
        </div>
        </div>
       
        <div class="row text-center pt-4">
    			
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                           
                               <img class="img-rounded" alt="team-photo" src="https://images.pexels.com/photos/295821/pexels-photo-295821.jpeg?h=350&auto=compress&cs=tinysrgb" width="100%"> 
                               
                               <div class="team-member">
                            
                               <h4>John Doe</h4>
                               
                               <p>Web developer</p>
                            
                               </div>
                               
                                                                            
                 </div>
                        
                 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                           
                               <img class="img-rounded" alt="team-photo" src="https://images.pexels.com/photos/428333/pexels-photo-428333.jpeg?h=350&auto=compress&cs=tinysrgb" width="100%">
                               
                               <div class="team-member">
                            
                               <h4>Jack Doe</h4>
                               
                               <p>Web designer</p>
                            
                               </div>
                               
                               
                                                                            
                 </div>
                        
                 <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                           
                               <img class="img-rounded" alt="team-photo" src="https://images.pexels.com/photos/295821/pexels-photo-295821.jpeg?h=350&auto=compress&cs=tinysrgb" width="100%"> 
                               
                               <div class="team-member">
                            
                               <h4>James</h4>
                               
                               <p>CEO</p>
                            
                               </div>
                               
                               
                                                                            
                    </div>
                       
            </div> 
    </div>
</section> -->


<!-- why section start -->
<section id="why" class="section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="about-inner text-center">
          <h2 class="text-center">Why Choose SKM</h2>
          <img src="images/header-boredr.png" alt="" width="230" class="pt-3"> 
          <p class="text-center">With our efforts and dedication, we have reached where we are today. Having been in the granite industry for 25 years now, <br>we have secured a global foothold for ourselves. So what makes our company unique and different?</p>
        </div>
      </div>
    </div>



    <div class="row text-center pt-5">
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big mt-3">
          <i class="fas fa-home"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">OVER 24 YEARS EXPERIENCE</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big mt-3">
          <i class="far fa-thumbs-up"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">BEST MATERIALS</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big mt-3">
          <i class="fas fa-warehouse"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">PROFESSIONAL STANDARDS</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
      
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big mt-3">
        <i class="fas fa-snowflake"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">EXTENSIVE RANGE </h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big mt-3">
        <i class="fas fa-user-secret"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">EXPERIENCED WORKFORCE</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>
      <div class="col-md-4">
        <div class="feature-item sl-large-house-1 feature-item-big mt-3">
        <i class="fab fa-stack-exchange"></i>
          <div class="ornament"></div>
          <h4 class="box-header page-margin-top">100% QUALITY ASSURED</h4>
          <p>Morbi nulla tortor, dignissim est node cursus euismod est arcu. Nomad at vehicula novum justo magna.</p>
        </div>
      </div>


    </div>
  </div>
</section>



<?php
	include('footer.php'); 
?>