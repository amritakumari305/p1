<?php
include('header.php');

?>
<?php
include('menu.php');

?>
<?php
include('home.php');

?>
<?php
include('footer.php');

?>