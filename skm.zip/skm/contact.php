<?php
	include('header.php'); 
?>
<?php
	include('menu.php'); 
?>

<!-- breadcrumb -->
<section id="map">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.118714424329!2d77.23883161494862!3d28.656163889761952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfce26ec085ef%3A0x441e32f4fa5002fb!2sRed%20Fort!5e0!3m2!1sen!2sin!4v1577345169717!5m2!1sen!2sin" width="100%" height="350" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
</section>


<section id="contact" class="section-padding">
  <div class="container">
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-11">
        <div class="about-inner">
          <h2>Conatct Us</h2>
          <img src="images/header-boredr.png" alt="" width="230"> 
          <p style="color:#777;font-weight:500">We provide a professional renovation and installation services with a real focus on customer satisfaction.</p>
        </div>
      </div>
    </div>
    <div class="row text-center">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="contact-form-box">
                <form action="contactdata.php" class="contact-form" method="POST">
                        <div class="row">
                           <div class="col-xl-6">
                              <input type="text" name="fname" id="fname" placeholder="name" value="">
                              <input type="email" name="email" id="email" placeholder="email" value="">
                              <input type="text" name="subject" id="subject" placeholder="subject" value="">
                              <input type="tel" name="phone" id="phone" placeholder="telephone" value="" maxlength="10">
                           </div>
                           
                           <div class="col-xl-6">
                              <textarea name="massages" id="massages" placeholder="message" cols="30" rows="9" value=""></textarea>
                              
                           </div>
                           <div class="col-xl-7">
                             
                           </div>
                           <div class="col-xl-5">
                             
                              <input type="submit"name="submit" value="submit">
                           </div>
                           
                        </div>
                </form>
            </div>         
        </div>
        <div class="col-md-1"></div>
    </div>
  </div>
</section>

<!-- adrs start -->
<section id="adrs_ph" class="py-4">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="left-icon-adrs float-left"><i class="fas fa-phone fa-rotate-90"></i></div>
        <div class="contact-details-box sl-small-phone"><p>Phone:<br>
          +149 75 23 222 35</p>
        </div>
      </div>
      <div class="col-md-4">
      <div class="left-icon-adrs float-left"><i class="fas fa-map-marked-alt"></i></div>
        <div class="contact-details-box sl-small-location"><p>28A, Santosh Nagra<br>
              Jaipur, FL 32789</p></div>
        </div>
      <div class="col-md-4">
        <div class="left-icon-adrs float-left"><i class="fas fa-envelope-open-text"></i></div>
          <div class="contact-details-box sl-small-mail"><p>E-mail:<br>
           <a href="mailto:skm@mail.com">skm@mail.com</a></p>
          </div>
      </div>
    </div>
  </div>
</section>

<?php
	include('footer.php'); 
?>