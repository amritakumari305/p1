<section id="header">
        <div class="container-fluid bg-white" style="border-bottom:2px solid #a0dbe5">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-3">
                        <div class="skm-logo text-lg-center text-center">
                            <a href="index.php" title="skm">
                                <img src="images/Skmg-logo.jpg" alt="" width="240" class="image">
                            </a>
                        </div>
                   
                    </div>
                    <div class="col-md-7 col-sm-5  d-none  d-lg-block">
                        <h1 class="ml14">
                            <span class="text-wrapper">
                                <span class="letters">Shri Keshariya Ji Marble & Grenite</span>
                                <span class="line">"Nature's Creation SKM Perfection"</span>
                            </span>
                        </h1>
                    </div>
                    
                    <div class="col-md-2 col-sm-4 d-none  d-lg-block">
                         <div class="skm-call-direction">
                            <div class="skm-call"><a href=""><i class="fas fa-phone fa-rotate-90"></i> Call Now</a></div>
                            <div class="skm-direction"><a href=""><i class="fas fa-directions"></i> Get Direction</a></div>
                         </div>
                    </div>
                </div>
            </div>
        </div>




        <div class="container-fluid navsec-dark">
            <div class="container limoking-header-container p-0">
                <div class="row px-2">
                        <!-- Brand -->
                    <div class="col-md-10 col-sm-6 col-6">
                        <nav class="navbar navbar-expand-lg navbar-dark p-0" id="banner">
                            <!-- Toggler/collapsibe Button -->
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                                <span class="navbar-toggler-icon"></span>
                            </button>
                        
                                <!-- Navbar links -->
                                <div class="collapse navbar-collapse" id="collapsibleNavbar">
                                    <ul class="navbar-nav">
                                        <li class="current nav-item">
                                            <a class="nav-link" href="index.php">
                                                <i class="fa fa-home" aria-hidden="true"></i>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about.php">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="infra.php">Infrastructure</a>
                                        </li> 
                                        <li class="nav-item">
                                        <a class="nav-link" href="product.php">Product</a>
                                        </li> 
                                    <!-- Dropdown -->
                                        <!-- <li class="nav-item">
                                        <a class="nav-link" href="menu.php">Menu</a>
                                        </li> 
                                        <li class="nav-item">
                                        <a class="nav-link" href="reservation.php">Reservation</a>
                                        </li>  -->
                                        <!-- <li class="nav-item">
                                        <a class="nav-link" href="blog.php">Blog</a>
                                        </li>  -->

                                        <li class="nav-item">
                                        <a class="nav-link" href="media.php">Media</a>
                                        </li>
                                        <li class="nav-item">
                                        <a class="nav-link" href="contact.php">Contact Us</a>
                                        </li>
                                        
                                    </ul>
                                </div>
                                
                        </nav>
                    </div>
                    <div class="col-md-2 col-sm-6 col-6">
                        <div class="button">
                            <a href="#" class="btn btn-default"><i class="fas fa-mobile"></i> GET QUOTE</a>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
    </header>
</section>