<div class="page-title-area bg-1">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="page-title-content">
                            <h2><?php echo $_GET["page_name"];?></h2>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li class="active"><?php echo $_GET["page_name"];?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>