
<!DOCTYPE html>
<html lang="zxx">

<head>
    <link rel="icon" type="image/png" href="img/.png" />
    <meta charSet="utf-8" />
    <title>DK Garg</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/fancybox.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>