<?php
include('header.php');
include('menu.php');
include('banner.php');
?>
 <div class="blog-details-area ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-12">
                        <div class="blog-left-sidebar">
                            <div class="widget-area left-sidebar" id="secondary">
                                <!-- <div class="widget widget_search">
                                    <h3 class="widget-title">Search Now</h3>
                                    <div class="post-wrap">
                                        <form class="search-form"><label><span class="screen-reader-text">Search for:</span><input type="search" class="search-field" placeholder="Search..."/></label><button type="submit"><i class="bx bx-search"></i></button></form>
                                    </div>
                                </div> -->
                                <div class="widget widget-peru-posts-thumb">
                                    <h3 class="widget-title">Popular Posts</h3>
                                    <div class="post-wrap">
                                        <div class="item"><a class="thumb" href="blog-details.html"><span class="fullimage cover bg1" role="img"></span></a>
                                            <div class="info"><span class="time">Nov 20, 2020</span>
                                                <h4 class="title usmall"><a href="blog-details.html">250+ Medical Tips We just had to share</a></h4>
                                            </div>
                                            <div class="clear"></div>
                                        </div>
                                        <div class="item"><a class="thumb" href="blog-details.html"><span class="fullimage cover bg2" role="img"></span></a>
                                            <div class="info"><span class="time">Nov 21, 2020</span>
                                                <h4 class="title usmall"><a href="blog-details.html">What Can I Do To Prevent Myself &amp; prevent Disease</a></h4>
                                            </div>
                                            <div class="clear"></div>
                                        </div>
                                        
                                    </div>
                                </div>
                                
                                <div class="widget widget_categories">
                                    <h3 class="widget-title">Categories</h3>
                                    <div class="post-wrap">
                                        <ul>
                                            <li><a href="#">Antibiotic <span>(10)</span></a></li>
                                            <li><a href="#">Diseases <span>(20)</span></a></li>
                                            <li><a href="#">Health Care <span>(10)</span></a></li>
                                            <li><a href="#">Heart Rate <span>(12)</span></a></li>
                                            <li><a href="#">Hospital <span>(16)</span></a></li>
                                            <li><a href="#">Infectious <span>(17)</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                
                                <div class="widget widget_tag_cloud">
                                    <h3 class="widget-title">Tags</h3>
                                    <div class="post-wrap">
                                        <div class="tagcloud"><a href="#">Antibiotic (3)</a><a href="#">Diseases (3)</a><a href="#">Heart (2)</a><a href="#">Health (2)</a><a href="#">Hospital (1)</a><a href="#">Infectious </a></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12">
                        <div class="blog-details-desc">
                            <div class="row">
                            <?php
                        $result1 = mysqli_query($conn,"SELECT * FROM blog");
                        while($rows = mysqli_fetch_array($result1)) {
                        
                    ?>
                                <div class="col-lg-6 col-md-6">
                                    <div class="single-blog">
                                    <a href="<?php echo $rows["bloglink"]; ?>"><img src="admin/<?php echo $rows["blogimg"]; ?>" alt="Image" width="100%"></a><span><?php echo $rows["blogdate"]; ?></span>
                           
                                        <div class="blog-content">
                                            <ul>
                                                <li><a href="#">Treatment</a></li>
                                            </ul>
                                            <a href="<?php echo $rows["bloglink"]; ?>">
                                    <h3><?php echo $rows["blogtitile"]; ?></h3>
                                </a><a class="read-more" href="<?php echo $rows["bloglink"]; ?>">Read More <i class="bx bx-plus"></i></a></div>
                                    </div>
                                </div>
                    <?php
                    }
                    ?>
                                <!-- <div class="col-lg-6 col-md-6">
                                    <div class="single-blog">
                                        <a href="blog-details.php"><img src="img/blog/blog3.jpg" alt="Image" /></a><span>13 May 2020</span>
                                        <div class="blog-content">
                                            <ul>
                                                <li><a href="#">COVID-19</a></li>
                                            </ul>
                                            <a href="blog-details.php">
                                                <h3>CCU For Emergency Services &amp; Medical support</h3>
                                            </a><a class="read-more" href="blog-details.php">Read More <i class="bx bx-plus"></i></a></div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="single-blog">
                                        <a href="blog-details.php"><img src="img/blog/blog3.jpg" alt="Image" /></a><span>13 May 2020</span>
                                        <div class="blog-content">
                                            <ul>
                                                <li><a href="#">COVID-19</a></li>
                                            </ul>
                                            <a href="blog-details.php">
                                                <h3>CCU For Emergency Services &amp; Medical support</h3>
                                            </a><a class="read-more" href="blog-details.php">Read More <i class="bx bx-plus"></i></a></div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="single-blog">
                                        <a href="blog-details.php"><img src="img/blog/blog3.jpg" alt="Image" /></a><span>13 May 2020</span>
                                        <div class="blog-content">
                                            <ul>
                                                <li><a href="#">COVID-19</a></li>
                                            </ul>
                                            <a href="blog-details.php">
                                                <h3>CCU For Emergency Services &amp; Medical support</h3>
                                            </a><a class="read-more" href="blog-details.php">Read More <i class="bx bx-plus"></i></a></div>
                                    </div>
                                </div> -->
                                
                                <div class="col-lg-12">
                                    <div class="page-navigation-area">
                                        <nav aria-label="Page navigation example text-center">
                                            <ul class="pagination">
                                                <li class="page-item"><a class="page-link page-links" href="#"><i class="bx bx-chevrons-left"></i></a></li>
                                                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                                <li class="page-item"><a class="page-link" href="#">2</a></li>
                                                <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                <li class="page-item"><a class="page-link" href="#"><i class="bx bx-chevrons-right"></i></a></li>
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include('footer.php');?>