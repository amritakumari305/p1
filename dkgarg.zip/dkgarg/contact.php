<?php
include("common/config.php");
include('header.php');
include('menu.php');
include('banner.php');
?>

<div class="contact-info-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 p-0">
                        <div class="single-contact-info"><i class="bx bx-location-plus"></i>
                            <h3>Jaipur</h3>
                            <p>B-20,10-B -scheme, Gopalpura bypass near Manglam electronic market,Jaipur</p><span>Email: contact@deventa.com</span><span>Tel: +91-772-700-9167</span></div>
                    </div>
                    <div class="col-lg-3 p-0">
                        <div class="single-contact-map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d227748.38256739752!2d75.6504717531237!3d26.88544791551138!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c4adf4c57e281%3A0xce1c63a0cf22e09!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1606384103627!5m2!1sen!2sin"></iframe></div>
                    </div>
                    <div class="col-lg-3 p-0">
                        <div class="single-contact-info"><i class="bx bx-location-plus"></i>
                            <h3>Agra</h3>
                            <p>C/O Pushpanjali & Research Centre Pvt Ltd, Delhi Gate, Civil Line, Agra, Uttar Pradesh - 282002</p><span>Email: contact@deventa.com</span><span>Tel: +01414156653</span></div>
                    </div>
                    <div class="col-lg-3 p-0">
                        <div class="single-contact-map"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3548.707999967487!2d77.99492861492068!3d27.196912854344863!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3974774018e3e6f1%3A0xd4d6e1b23ab856bb!2sPushpanjali%20Hospital%20%26%20Research%20Centre!5e0!3m2!1sen!2sin!4v1606816283215!5m2!1sen!2sin" ></iframe></div>
                    </div>
                </div>
            </div>
        </div>
<?php
$message = "";
if(isset($_POST['submit'])){
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// display the results
$sql = "INSERT INTO contact (name, email, phone, subject, message) VALUES ('$name', '$email', '$phone', '$subject', '$message')";
mysqli_query($conn, $sql); 
$message = "Successfully submitted! ";
}  
?>
        <div class="main-contact-area contact py-5">
            <div class="container">
                <div class="section-title"><span class="top-title">Contact Us</span>
                    <h2>Drop us a message for any query</h2>
                    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque quibusdam deleniti porro praesentium. Aliquam minus quisquam velit in at nam.</p>
                </div>
                <div class="contact-wrap contact-pages mb-0">
                    <div class="contact-form">
                        <form id="contactForm" action="" method="POST">
                        <?php echo $message; ?>
                            <div class="row">
                                <div class="col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <label>Name</label>
                                        <input type="text" name="name" class="form-control" placeholder="Your Name" value="" />
                                        <div class="invalid-feedback" style="display:block"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="text" name="email" class="form-control" placeholder="Your Email" value="" />
                                        <div class="invalid-feedback" style="display:block"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="tel" name="phone" class="form-control" placeholder="Your Phone" value="" />
                                        <div class="invalid-feedback" style="display:block"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <div class="form-group">
                                        <label>Subject</label>
                                        <input type="text" name="subject" class="form-control" placeholder="Your Subject" value="" />
                                        <div class="invalid-feedback" style="display:block"></div>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-md-12">
                                    <div class="form-group">
                                        <label>Message</label>
                                        <textarea name="message" class="form-control" cols="30" rows="5" placeholder="Your Message" value=""></textarea>
                                        <div class="invalid-feedback" style="display:block"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6">
                                    <div class="contact-num">
                                        <h3>For Emergency</h3><span><a href="tel:+91-772-700-9167">+91-772-700-9167</a></span></div>
                                </div>
                                <div class="col-lg-6 col-sm-6"><button type="submit"  name="submit" value="submit" class="default-btn btn-two">Send Message</button></div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php include('footer.php');?>