<?php include("common/config.php");?>
<div class="main-banner-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="banner-text"><span class="fadeInUp">Smarter Service Care</span>
                                    <h1 class="fadeInUp">We are Committed to Your Best Health</h1>
                                    <p class="fadeInUp">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua gravida. Risus commodo.</p>
                                    <div class="banner-btn fadeInUp">
                                        <a class="default-btn" href="#appointment">Book An Appointment</a>
                                        <a class="default-btn active" href="#">Get Direction</a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 pr-0">
                                <div class="banner-img-wrap">
                                    <div class="banner-img fadeInUp"><img src="img/dk.png" alt="Image" /></div>
                                    <div class="banner-shape"><img src="img/home-one/home-one-shape.png" alt="Image" /></div>
                                </div>
                            </div>
                        </div>
                        <div class="first-facility-area">
                            <div class="row">
                                <div class="col-lg-4 col-sm-6">
                                    <div class="first-facility-item"><i class="flaticon-care"></i>
                                        <h3>Special Service</h3>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do</p>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="first-facility-item"><i class="flaticon-support"></i>
                                        <h3>24/7 Advanced Care</h3>
                                        <p>Smarter care services offers round the clock 24/7-One of only heart emergency.</p>
                                    </div>
                                </div>
                                <div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0">
                                    <div class="first-facility-item"><i class="flaticon-online-learning"></i>
                                        <h3>Get Booking Online</h3>
                                        <p>Our Superspecialists will Advice you to get Right Diagnosis & Treatment Plan</p>
                                    </div>
                                </div>
                            </div>
                            <div class="shape"><img src="img/shape/shape1.png" alt="Image" /></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="second-facility-area pt-5 pb-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-sm-6">
                        <div class="second-facility-item"><img src="img/facility-img/facility-icon1.png" alt="Image" />
                            <h3>Qualified Doctor</h3>
                            <p>The purpose of a doctor or any human in general should not be to simply delay the death of a patient, but to increase the person's quality of life</p><a class="read-more" href="services-details.html">Read More <i class="bx bx-plus"></i></a></div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="second-facility-item"><img src="img/facility-img/technical-support.png" alt="Image" />
                            <h3>Emergency Service</h3>
                            <p>Doctor 24×7 acts as a platform, through mobile App & Website, for facilitating ... emergency, visit your Doctor/Hospital or call emergency services immediately.</p><a class="read-more" href="services-details.html">Read More <i class="bx bx-plus"></i></a></div>
                    </div>
                    <div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0">
                        <div class="second-facility-item"><img src="img/facility-img/facility-icon3.png" alt="Image" />
                            <h3>Leading Technology</h3>
                            <p>In healthcare, technology is increasingly playing a role in almost all processes, from patient registration to data monitoring, from lab tests to self-care tools.</p><a class="read-more" href="services-details.html">Read More <i class="bx bx-plus"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="about-area pb-130">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img"><img src="img/about/dkgarg.jpg" alt="Image" />
                            <div class="shape-1"><img src="img/about/about-shape-1.png" alt="Image" /></div>
                            <div class="shape-2"><img src="img/about/about-shape-2.png" alt="Image" /></div>
                            <div class="shape-3"><img src="img/about/about-shape-3.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-content"><span class="top-title">About Us</span>
                            <h2>We are trusted The Best Certificate Healthcare</h2>
                            <p>Dr.Devendra Garg is best Cardiologist/Heart Specialist working at Metro Hospital, Jaipur, Rajasthan. Dr. Garg is the cardiologist with vast experience and training in Angioplasty and other cardiac procedures. Dr. Garg’s Dynamic personality, believe in quality of work, hard working. Dr. Garg has worked in field of medicine & cardiology for more 15 years. Dr. Devendra Garg has worked as a ex assocate professor of medicine JTS DC formerly director & Head of cardiology Pushpanjali Hospital & Research Center Agra, & Unit Head cardiology Paras hospital gurgoen.</p>
                            <ul>
                                <li><i class="flaticon-tick"></i>Scientific skills for getting a better result</li>

                                <li><i class="flaticon-tick"></i>Professional doctor</li>
                                <li><i class="flaticon-tick"></i>Digital laboratory</li>
                                <li><i class="flaticon-tick"></i>Emergency services</li>
                            </ul><a class="default-btn" href="about.php">About Us</a></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="services-area bg py-5">
            <div class="container">
                <div class="section-title"><span class="top-title">Treatments </span>
                    <h2>Our Healthcare Treatments </h2>
                    <p> Healthcare has come to mean every aspect,service& device for taking care of your health.</p>
                </div>

                <div class="row">
                    <?php
                        $result = mysqli_query($conn,"SELECT * FROM services limit 0,6");
                                    
                        while($row = mysqli_fetch_array($result)) {
                        
                                                    
                    ?>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3><?php echo $row["srv_titile"]; ?></h3>
                            <p><?php echo mb_substr($row["srv_desc"], 0,100) ?>..</p>
                            <a class="read-more" href="<?php echo $row["srv_link"]; ?>">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Heart Failure Treatment</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Angiography Treatment</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Heart Valve Replacement</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Pacemaker</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div> -->
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
       

        <div class="our-work-area pt-5 pb-3">
            <div class="container">
                <div class="section-title"><span class="top-title">Our Works</span>
                    <h2>Our Intensive Care Unit</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facilis vel consequatur tempora atque blanditiis exercitationem incidunt, alias corporis quam assumenda dicta, temporibus.</p>
                </div>
                <div class="row">
                    <div class="col-sm-12">
                        <div class="owl-slider">
                            <div id="carousel" class="owl-carousel">
                                <div class="item">
                                    <img class="owl-lazy" data-src="img/blog/blog4.jpg" alt="">
                                    <div class="single-work">
                                        <a href="photogallery.php"><h3 class="work-title"><i class="flaticon-cardiology"></i>Cardiologist</h3></a>

                                    </div>
                                </div>
                                <div class="item">
                                    <img class="owl-lazy" data-src="img/blog/blog4.jpg" alt="">
                                    <div class="single-work">
                                        <a href="photogallery.php"><h3 class="work-title"><i class="flaticon-cardiology"></i>Cardiologist</h3></a>

                                    </div>
                                </div>
                                <div class="item">
                                    <img class="owl-lazy" data-src="img/blog/blog4.jpg" alt="">
                                    <div class="single-work">
                                        <a href="photogallery.php"><h3 class="work-title"><i class="flaticon-cardiology"></i>Cardiologist</h3></a>

                                    </div>
                                </div>
                                <div class="item">
                                    <img class="owl-lazy" data-src="img/blog/blog4.jpg" alt="">
                                    <div class="single-work">
                                        <a href="photogallery.php"><h3 class="work-title"><i class="flaticon-cardiology"></i>Cardiologist</h3></a>

                                    </div>
                                </div>
                                <div class="item">
                                    <img class="owl-lazy" data-src="img/blog/blog4.jpg" alt="">
                                    <div class="single-work">
                                        <a href="photogallery.php"><h3 class="work-title"><i class="flaticon-cardiology"></i>Cardiologist</h3></a>

                                    </div>
                                </div>
                                <div class="item">
                                    <img class="owl-lazy" data-src="img/blog/blog4.jpg" alt="">
                                    <div class="single-work">
                                        <a href="photogallery.php"><h3 class="work-title"><i class="flaticon-cardiology"></i>Cardiologist</h3></a>

                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape"><img src="img/shape/work-shape.png" alt="Image"></div>
        </div>

        <div class="counter-area py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="single-counter"><i class="flaticon-man"></i>
                            <h2>25,000 <span class="target">+</span></h2>
                            <p>Total Client</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="single-counter"><i class="flaticon-tick"></i>
                            <h2>20,000 <span class="target">+</span></h2>
                            <p>Setisfied Client</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="single-counter"><i class="flaticon-trophy"></i>
                            <h2>10 <span class="traget">+</span></h2>
                            <p>Awards</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="single-counter"><i class="flaticon-experience"></i>
                            <h2>15 <span class="traget">+</span></h2>
                            <p>Experiences</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape-wrap">
                <div class="shape-1"><img src="img/shape/counter-shape.png" alt="Image" /></div>
                <div class="shape-2"><img src="img/shape/counter-shape.png" alt="Image" /></div>
            </div>
        </div>
<?php
$message = "";
if(isset($_POST['submit'])){
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$services = $_POST['services'];
$date = $_POST['date'];
$time = $_POST['time'];
$message = $_POST['message'];

// display the results
$sql = "INSERT INTO appointment (name, email, phone, services, date, time, message) VALUES ('$name', '$email', '$phone', '$services', '$date', '$time','$message')";
mysqli_query($conn, $sql); 
$message = "Successfully submitted! ";
}  
?>

        <div class="appointment-area jarallax" id="appointment">
            <div class="container">
                <div class="appointment-here-form"><span class="top-title">Make An Appointment</span>
                    <h2>We Are Here For You</h2>
                    <form action="" method="POST" class="formappointment">
                    <?php echo $message; ?>
                        <div class="row">
                            <div class="col-lg-6 col-sm-6"><label>Your Name</label>
                                <div class="form-group">
                                    <input type="text" class="form-control"  name="name" id="Name" placeholder="Enter Your Name" /><i class="flaticon-account"></i>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6"><label>Your Email</label>
                                <div class="form-group">
                                    <input type="text" class="form-control"  name="email" id="Email" placeholder="Enter Your Email" /><i class="flaticon-email"></i>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6"><label>Your Phone</label>
                                <div class="form-group">
                                    <input type="text" class="form-control"  name="phone" id="Phone" placeholder="Enter Your Phone" /><i class="flaticon-smartphone"></i>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6"><label>Select Service</label>
                                <div class="form-group">
                                    <select class="form-control" name="services" id="services">
                                        <option value="0">Select Service</option>
                                        <option value="1">Non - Invasive  &amp;  Cardiology</option>
                                        <option value="2">Invasive &amp; Cardiology</option>
                                        <option value="3">Interventional &amp; Cardiology</option>
                                        <option value="4">Cardio Vascular &amp; Surgery</option>
                                        <option value="5">Electrophysiology</option>
                                        <option value="6">Cardiac &amp; Rehabilitation</option>
                                    </select>
                                    <i class="flaticon-heart"></i>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6"><label>Appointment Date</label>
                                <div class="form-group">
                                    <div class="input-group date">
                                        <div>
                                            <div><input type="date" name="date" id="date" value="" class="form-control"></div>
                                        </div>
                                    </div><i class="flaticon-appointment"></i></div>
                            </div>
                            <div class="col-lg-6 col-sm-6"><label>Time</label>
                                <div class="form-group">
                                    <input type="time" name="time" id="time" value="" class="form-control">
                                    <i class="flaticon-clock"></i>
                                </div>
                            </div>
                            <div class="col-lg-12"><label>Message</label>
                                <div class="form-group"><textarea name="message" class="form-control" id="message" cols="30" rows="5" placeholder="Your Message"></textarea><i class="flaticon-edit"></i></div>
                            </div>
                            <div class="col-12"><button type="submit"  name="submit" value="submit" class="default-btn">Send Request</button></div>
                        </div>
                    </form>
                    <div class="shape"><img src="img/shape/appointment-shape.png" alt="Image" /></div>
                </div>
            </div>
        </div>

        <div class="emergency-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="emergency-content py-4">
                            <h2>Emergency? For any Help Contact Us Now</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#x27;s standard dummy text ever since the 1500s.</p>
                            <ul>
                                <li class="active"><i class="bx bx-phone-call"></i><span>Call Now</span>
                                    <h3><a href="tel:7727009167">+91 772-700-9167</a></h3>
                                </li>
                                <li><i class="bx bx-envelope"></i><span>Mail Us</span>
                                    <h3><a href="mailto:info@deventa.com">info@deventa.com</a></h3>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="emergency-img">
                            <iframe width="100%" height="400" src="https://www.youtube.com/embed/Ozsbpa56btA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape"><img src="img/shape/emergency-shape.png" alt="Image" /></div>
        </div>




        <div class="client-area c-bg py-5">
            <div class="container">
                <div class="section-title"><span class="top-title">Testimonials</span>
                    <h2>What Our Client’s Say</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facilis vel consequatur tempora atque blanditiis exercitationem incidunt, alias corporis quam assumenda dicta, temporibus.</p>
                </div>

                <div class="row">
               
                    <div class="col-md-12">
                        <div class="slideshow-container">
                        <?php
                        $result = mysqli_query($conn,"SELECT * FROM testimonial ");
                                    
                        while($row = mysqli_fetch_array($result)) {
                        
                                                    
                    ?>
                            <div class="mySlides">
                                <q>"<?php echo $row["testquote"]; ?>"</q>
                                <h3><?php echo $row["testname"]; ?></h3>
                                <p class="author"><?php echo $row["testpost"]; ?></p>
                            </div>

                            <!-- <div class="mySlides">
                                <q>Lorem ipsum dolor sit amet, Lorem Ipsum is simply dummy text of the printing and Quis suspendisse typesetting ipsum dolor sit amet, consectetur</q>
                                <h3>Steven Jony</h3>
                                <p class="author"> Company Founder</p>
                            </div>

                            <div class="mySlides">
                                <q>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem Ipsum is simply dummy text of the printing and Quis suspendisse typesetting ipsum dolor sit amet, consectetur</q>
                                <h3> Omit Jacson</h3>
                                <p class="author"> Company Founder</p>
                            </div> -->
                        <?php 
                           }
                        ?>
                            <a class="prev" onclick="plusSlides(-1)">❮</a>
                            <a class="next" onclick="plusSlides(1)">❯</a>

                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div class="blog-area py-5">
            <div class="container">
                <div class="section-title"><span class="top-title">Blog</span>
                    <h2>Our Latest Blog</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus</p>
                </div>
                <div class="row">
                    <?php
                        $result1 = mysqli_query($conn,"SELECT * FROM blog limit 0,3");
                        while($rows = mysqli_fetch_array($result1)) {
                        
                    ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="single-blog">
                            <a href="<?php echo $rows["bloglink"]; ?>"><img src="admin/<?php echo $rows["blogimg"]; ?>" alt="Image" width="100%"></a><span><?php echo $rows["blogdate"]; ?></span>
                            <div class="blog-content">
                                <ul>
                                    <li><a href="#">Medical</a></li>
                                </ul>
                                <a href="<?php echo $rows["bloglink"]; ?>">
                                    <h3><?php echo $rows["blogtitile"]; ?></h3>
                                </a><a class="read-more" href="<?php echo $rows["bloglink"]; ?>">Read More <i class="bx bx-plus"></i></a></div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-4 col-md-6">
                        <div class="single-blog">
                            <a href="blog-details.php"><img src="img/blog/blog2.jpg" alt="Image" /></a><span>11 Nov 2020</span>
                            <div class="blog-content">
                                <ul>
                                    <li><a href="#">Treatment</a></li>
                                </ul>
                                <a href="blog-details.php">
                                    <h3>What Can I Do To Prevent Myself &amp; prevent Disease</h3>
                                </a><a class="read-more" href="blog-details.php">Read More <i class="bx bx-plus"></i></a></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 offset-md-3 offset-lg-0">
                        <div class="single-blog d-none d-sm-block">
                            <a href="blog-details.php"><img src="img/blog/blog3.jpg" alt="Image" /></a><span>13 Nov 2020</span>
                            <div class="blog-content">
                                <ul>
                                    <li><a href="#">COVID-19</a></li>
                                </ul>
                                <a href="blog-details.php">
                                    <h3>CCU For Emergency Services &amp; Medical support</h3>
                                </a><a class="read-more" href="blog-details.php">Read More <i class="bx bx-plus"></i></a></div>
                        </div>
                    </div> -->
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="subscribe-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <h2>Subscribe Now</h2>
                        <p>Get our latest news &amp; update regularly</p>
                    </div>
                    <div class="col-lg-6">
                        <form class="newsletter-form"><input type="email" class="form-control" placeholder="Enter Your Email" name="EMAIL" required="" /><button class="default-btn" type="submit">Subscribe</button></form>
                    </div>
                </div>
            </div>
        </div>
