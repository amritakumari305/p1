<?php
include('header.php');
include('menu.php');
include('banner.php');
?>

<div class="about-area pt-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img"><img src="img/about/dkgarg.jpg" alt="Image" />
                            <div class="shape-1"><img src="img/about/about-shape-1.png" alt="Image" /></div>
                            <div class="shape-2"><img src="img/about/about-shape-2.png" alt="Image" /></div>
                            <div class="shape-3"><img src="img/about/about-shape-3.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-content"><span class="top-title">About Us</span>
                            <h2>We are trusted The Best Certificate Healthcare</h2>
                            <p>Dr.Devendra Garg is best Cardiologist/Heart Specialist working at Metro Hospital, Jaipur, Rajasthan. Dr. Garg is the cardiologist with vast experience and training in Angioplasty and other cardiac procedures. Dr. Garg’s Dynamic personality, believe in quality of work, hard working. Dr. Garg has worked in field of medicine & cardiology for more 15 years. Dr. Devendra Garg has worked as a ex assocate professor of medicine JTS DC formerly director & Head of cardiology Pushpanjali Hospital & Research Center Agra, & Unit Head cardiology Paras hospital gurgoen. He has worked as a Consultant cardiology in Fortis & escort Hospital new delhi. Dr. Garg has performed more than 20,000 Procedures Coronary Angiographies, Peripheral Angiographies, Coronary Angioplasty, Pacemakers & alcohol Septal Ablations. Dr Garg's success rate in interventional procedures is comparable to some of the best in Jaipur and Rajasthan. Dr Garg gets his patients at Metro Hospital, Jaipur from as far as Agra, Delhi, Bharatpur & Faridabad and other parts of Rajasthan. Dr Devendra Garg as a cardiologist is very popular amongst his patient because of the time that he gives to each and every patient during the consultation and counselling</p>
                            <ul>
                                <li><i class="flaticon-tick"></i>Scientific skills for getting a better result</li>

                                <li><i class="flaticon-tick"></i>Professional doctor</li>
                                <li><i class="flaticon-tick"></i>Digital laboratory</li>
                                <li><i class="flaticon-tick"></i>Emergency services</li>
                            </ul></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="second-facility-area six pt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-sm-6">
                        <div class="second-facility-item">
                            <img src="img/home-six/home-six-service-icon1.png" alt="Image">
                            <h3>Our Vision</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                           
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6">
                        <div class="second-facility-item">
                            <img src="img/home-six/home-six-service-icon2.png" alt="Image">
                            <h3>Our Mission</h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p>
                        
                    </div>
                </div>
                
            </div>
        </div>
    </div>
        <div class="about-area two ptb-100 ">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about-img"><img src="img/about/about-two1.png" alt="Image" />
                            <div class="shape-1"><img src="img/about-two/about--shape2.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about-content"><span class="top-title">About Heart Disease</span>
                            <h2>Why Heart Disease Occur</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p><strong>The best way to prevent illness is to avoid being exposed to this virus.</strong>
                            <ul>
                                <li><i class="flaticon-tick"></i>Clean and disinfect frequently touched surfaces</li>
                                <li><i class="flaticon-tick"></i>Avoid touching your eyes, nose, and mouth</li>
                                <li><i class="flaticon-tick"></i>Clean your hands with a hand sanitizer</li>
                                <li><i class="flaticon-tick"></i>Cover coughs and sneezes</li>
                                <li><i class="flaticon-tick"></i>Stay home if you’re sick</li>
                               
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include('footer.php');?>