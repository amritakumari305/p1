<?php
include('header.php');
include('menu.php');
include('banner.php');
?>

<div class="doctors-details-area ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="doctors-sidebar">
                            <div class="doctors-img"><img src="img/dkgarg.jpg" alt="Image" />
                                <ul>
                                    <li><a href="#" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-twitter"></i></a></li>
                                   
                                    <li><a href="#" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-youtube"></i></a></li>
                                </ul>
                            </div>
                            <div class="availability">
                                <h3><i class="bx bx-time"></i>Availability Jaipur Clinic</h3>
                                <ul>
                                    <li>Monday - Wed<span>7.00AM - 9.00AM</span></li>
                                    <li>Monday - Wed<span>6.00PM - 9.00PM</span></li>
                                    <li>Saturday-Sun<span>7.00AM - 9.00AM</span></li>
                                    <li>Saturday-Sun<span>6.00PM - 9.00PM</span></li>
                                    <li>Thursday-Friday<span>Closed</span></li>
                                </ul>
                                <h3><i class="bx bx-time"></i>Availability Agra Clinic</h3>
                                <ul>
                                    
                                    <li>Friday<span>8.00AM - 5.00PM</span></li>
                                </ul>
                                <a class="default-btn mt-4" href="#">Request An Appointment</a></div>
                            
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="doctors-detailss">
                            <div class="doctors-history">
                                <h2>Dr.D.K Garg</h2><span>MBBS, MD (Medicine), DNB (Cardiology)</span>
                                <p>Dr.Devendra Garg is best Cardiologist/Heart Specialist working at Metro Hospital, Jaipur, Rajasthan. Dr. Garg is the cardiologist with vast experience and training in Angioplasty and other cardiac procedures.</p>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Specialty</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>Electrophysiology</li>
                                                <li><i class="bx bxs-hand-right"></i> Medicine</li>
                                                <li><i class="bx bxs-hand-right"></i>Cardiology  </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Education</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>MD postgraduate degree in Medicine</li>
                                                <li><i class="bx bxs-hand-right"></i>Diplomate of the National Board (DNB) in Cardiology</li>
                                               
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Experience</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>15 years of Experience in Medicine</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Address</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>B-20,10-B -scheme, Gopalpura bypass near Manglam electronic market,Jaipur</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Phone</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>+91-772-700-9167</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Email</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>contact@drdkgarg.com</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                           
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="doctors-sidebar">
                            <div class="doctors-img"><img src="img/womwnicon.png" alt="Image" />
                                <ul>
                                    <li><a href="#" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-twitter"></i></a></li>
                                   
                                    <li><a href="#" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-youtube"></i></a></li>
                                </ul>
                            </div>
                            <div class="availability">
                                <h3><i class="bx bx-time"></i>Availability</h3>
                                <ul>
                                    <li>Monday - Friday<span>9.00 - 20.00</span></li>
                                    <li>Saturday<span>10.00 - 16.00</span></li>
                                    <li>Sunday<span>9.30 - 18.00</span></li>
                                    <li>Friday<span>Closed</span></li>
                                </ul><a class="default-btn mt-4" href="#">Request An Appointment</a></div>
                            
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="doctors-detailss">
                            <div class="doctors-history">
                                <h2>Dr.Sonia Garg</h2><span>MBBS, MD (Pathology)</span>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat, totam! Dicta rerum deserunt itaque. Incidunt in quo architecto eveniet rem facere, necessitatibus, dolorem voluptas deleniti iure fuga magni velit molestiae
                                    ipsum dolor sit amet consectetur adipisicing elit. Repellat, totam adipisicing.</p>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Specialty</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>Pathology</li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Education</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>MBBS (Pathology)</li>
                                                <li><i class="bx bxs-hand-right"></i>MD (Pathology)</li>
                                               
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Experience</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>15 years of Experience in Medicine</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Address</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>B-20,10-B -scheme, Gopalpura bypass near Manglam electronic market,Jaipur</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Phone</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>+91-772-700-9167</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="row borders">
                                    <div class="col-lg-3 pl-0">
                                        <div class="left-title">
                                            <h3>Email</h3>
                                        </div>
                                    </div>
                                    <div class="col-lg-9">
                                        <div class="right-title">
                                            <ul>
                                                <li><i class="bx bxs-hand-right"></i>contact@soniagarg.com</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                           
                        </div>
                    </div>
                </div> 

            </div>
</div>
<?php include('footer.php');?>