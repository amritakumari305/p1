-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2021 at 09:27 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drdkgarg`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` int(12) NOT NULL,
  `services` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `name`, `email`, `phone`, `services`, `date`, `time`, `message`) VALUES
(2, 'wwww', 'a@gmail.com', 2147483647, '2', '2020-12-24', '03:43:00', 'fffffffffffffff');

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `bnr_id` int(11) NOT NULL,
  `menu_type` varchar(255) NOT NULL,
  `submenu_type` varchar(255) NOT NULL,
  `banner_title` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`bnr_id`, `menu_type`, `submenu_type`, `banner_title`, `status`) VALUES
(3, '22', '<br />\r\n<b>Notice</b>:  Undefined index: id in <b>D:xampphtdocsdkgargadminanneraddedit.php</b> on line <b>124</b><br />\r\n', 'Chest Pain', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blg_id` int(11) NOT NULL,
  `blogimg` varchar(255) NOT NULL,
  `blogdate` date NOT NULL,
  `blogpostby` varchar(255) NOT NULL,
  `blogtitile` varchar(255) NOT NULL,
  `bloglink` text NOT NULL,
  `blogdesc` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blg_id`, `blogimg`, `blogdate`, `blogpostby`, `blogtitile`, `bloglink`, `blogdesc`, `status`) VALUES
(4, 'images/blog1.jpg', '2020-12-10', 'John Anderson', '250+ Medical Tips We just had to share', 'blog.php', 'Quuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quia non numquam eius modi tempora incidunt ut labore et dolore magnam dolor sit, consectetur qui ratione voluptatem sequi nesciunt.\r\n\r\nLorem ipsum dolor sit amet, consectetur ad', 1),
(5, 'images/blog1.jpg', '2020-12-12', 'John Anderson', '250+ Medical Tips We just had to share', 'blog.php', 'Quuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quia non numquam eius modi tempora incidunt ut labore et dolore magnam dolor sit, consectetur qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur ad', 1),
(6, 'images/blog1.jpg', '2020-12-13', 'John Anderson', '250+ Medical Tips We just had to share', 'blog.php', 'Quuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quia non numquam eius modi tempora incidunt ut labore et dolore magnam dolor sit, consectetur qui ratione voluptatem sequi nesciunt. Lorem ipsum dolor sit amet, consectetur ad', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(2) NOT NULL,
  `phone` int(12) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `subject`, `message`, `status`) VALUES
(4, 'wwww kumari', 'a@', 2147483647, 'classes kjnhbv kjhbgvc', 'vvvvvvvvvvvvvvvv', 1),
(5, 'vvvvvvvvv', 'vv', 0, 'vvvvvvv', 'vvvvvvvvvvvvvv', 1);

-- --------------------------------------------------------

--
-- Table structure for table `navmenutype`
--

CREATE TABLE `navmenutype` (
  `id` int(11) NOT NULL,
  `menuname` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `menulink` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `navmenutype`
--

INSERT INTO `navmenutype` (`id`, `menuname`, `status`, `menulink`) VALUES
(20, 'Home', 1, 'index.php'),
(21, 'About Us', 1, 'about.php'),
(22, 'Treatments', 1, ''),
(23, 'Gallery ', 1, ''),
(24, 'Doctors', 1, 'doctor.php'),
(25, 'Blog', 1, 'blog.php'),
(26, 'Contact', 1, 'contact.php');

-- --------------------------------------------------------

--
-- Table structure for table `navsubmenu`
--

CREATE TABLE `navsubmenu` (
  `sub_id` int(11) NOT NULL,
  `menutype` varchar(255) NOT NULL,
  `submenuname` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `submenulink` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `navsubmenu`
--

INSERT INTO `navsubmenu` (`sub_id`, `menutype`, `submenuname`, `status`, `submenulink`) VALUES
(18, '22', 'Chest Pain', 1, 'chestpain.php'),
(19, '22', 'Angina Treatment', 1, 'chestpain.php'),
(20, '22', 'Heart Attack Treatment', 1, 'chestpain.php'),
(21, '22', 'Heart Failure Treatment', 1, 'chestpain.php'),
(22, '22', 'Angiography Treatment', 1, 'chestpain.php'),
(23, '22', 'Angioplasty Treatment', 1, 'chestpain.php'),
(24, '22', 'Pacemaker', 1, 'chestpain.php'),
(25, '22', 'Heart Valve Replacement', 1, 'chestpain.php'),
(26, '23', 'Photo Gallery', 1, 'photogallery.php'),
(27, '23', 'Video Gallery', 1, 'videogallery.php');

-- --------------------------------------------------------

--
-- Table structure for table `photogallery`
--

CREATE TABLE `photogallery` (
  `ph_id` int(11) NOT NULL,
  `glry_title` varchar(255) NOT NULL,
  `glry_img` varchar(255) NOT NULL,
  `glry_link` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `photogallery`
--

INSERT INTO `photogallery` (`ph_id`, `glry_title`, `glry_img`, `glry_link`, `status`) VALUES
(2, 'f', 'images/banner-2.jpg', 'f', 1);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `ser_id` int(11) NOT NULL,
  `srv_titile` varchar(255) NOT NULL,
  `srv_desc` varchar(255) NOT NULL,
  `srv_link` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`ser_id`, `srv_titile`, `srv_desc`, `srv_link`, `status`) VALUES
(6, 'Chest Pain	', 'Having a pain in your chest can be scary. It does not always mean that you are having a heart attack.', 'chestpain.php?page_name=Chest Pain', 1),
(17, 'Angina Treatment', 'To diagnose angina, doctor will start by doing a physical exam and asking about your symptoms. You will also be asked about any risk factors, including whether you have a family history of heart disease.', 'angina.php', 1),
(18, 'Heart Attack Treatment', 'Ideally, doctor should screen you during regular physical exams for risk factors that can lead to a heart attack. ECG is the first test done to diagnose a heart attack records electrical signals.', 'heartattack.php', 1),
(19, 'Heart Failure Treatment', 'Heart failure caused by damage to the heart that has developed over time canâ€™t be cured. But it can be treated, quite often with strategies to improve symptoms.', 'heartfail.php', 1),
(20, 'Angiography Treatment', 'Coronary angiography is a procedure that uses a special dye (contrast material) and x-rays to see how blood flows through the arteries in your heart. This is a procedure which measures pressures in the heart chambers.', 'angiography.php', 1),
(21, 'Pacemaker', 'A small battery-operated device that helps the heart beat in a regular rhythm. There are two parts: a generator and wires (leads).Abnormal heart rhythms are controlled using a device placed in the chest or abdomen, called the Pacemaker', 'pacemaker.php', 1),
(22, 'Angioplasty Treatment', 'Angioplasty is the process in which a narrowing of a blood vessel is corrected. Any accessible blood vessel in the body can be treated using angioplasty, but we will follow a patient through a heart angioplasty, as it involves a little bit more care durin', 'angioplasty.php', 1),
(23, 'Heart Valve Replacement', 'If your heart valve can not be repaired and a catheter-based procedure is not feasible, the valve might need to be replaced. To replace a heart valve, your doctor removes the heart valve and replaces it with a mechanical valve', 'heartavalvereplc.php', 1);

-- --------------------------------------------------------

--
-- Table structure for table `testimonial`
--

CREATE TABLE `testimonial` (
  `test_id` int(11) NOT NULL,
  `testname` varchar(255) NOT NULL,
  `testpost` varchar(255) NOT NULL,
  `testquote` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testimonial`
--

INSERT INTO `testimonial` (`test_id`, `testname`, `testpost`, `testquote`, `status`) VALUES
(4, 'Steven Jony', 'Company Founder', 'Lorem ipsum dolor sit amet, Lorem Ipsum is simply dummy text of the printing and Quis suspendisse typesetting ipsum dolor sit amet, consectetur', 1),
(5, 'Omit Jacson', 'Admin', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem Ipsum is simply dummy text of the printing and Quis suspendisse typesetting ipsum dolor sit amet, consectetur', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`bnr_id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blg_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navmenutype`
--
ALTER TABLE `navmenutype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `navsubmenu`
--
ALTER TABLE `navsubmenu`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `photogallery`
--
ALTER TABLE `photogallery`
  ADD PRIMARY KEY (`ph_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`ser_id`);

--
-- Indexes for table `testimonial`
--
ALTER TABLE `testimonial`
  ADD PRIMARY KEY (`test_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `bnr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `navmenutype`
--
ALTER TABLE `navmenutype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `navsubmenu`
--
ALTER TABLE `navsubmenu`
  MODIFY `sub_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `photogallery`
--
ALTER TABLE `photogallery`
  MODIFY `ph_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `ser_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `testimonial`
--
ALTER TABLE `testimonial`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
