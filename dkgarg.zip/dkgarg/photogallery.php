<?php
include('header.php');
include('menu.php');
include('banner.php');
?>
<section class="services-area bg py-5">
    <div class="container page-top">
                <div class="section-title"><span class="top-title">Gallery </span>
                    <h2>Our Photo Gallery </h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facilis vel consequatur tempora atque blanditiis exercitationem incidunt, alias corporis quam assumenda dicta, temporibus.</p>
                </div>
        <div class="row">


            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/coming-soon.jpg" class="fancybox" rel="ligthbox">
                    <img  src="img/coming-soon.jpg" class="zoom img-fluid "  alt="">
                
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/Heart-Beats.jpg"  class="fancybox" rel="ligthbox">
                    <img  src="img/Heart-Beats.jpg" class="zoom img-fluid"  alt="">
                </a>
            </div>
            
            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/CIS women heart disease.jpeg" class="fancybox" rel="ligthbox">
                    <img  src="img/CIS women heart disease.jpeg" class="zoom img-fluid "  alt="">
                </a>
            </div>
            
            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/R-1.jpg" class="fancybox" rel="ligthbox">
                    <img  src="img/R-1.jpg" class="zoom img-fluid "  alt="">
                </a>
            </div>
            
            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/coming-soon.jpg" class="fancybox" rel="ligthbox">
                    <img  src="img/coming-soon.jpg" class="zoom img-fluid "  alt="">
                
                </a>
            </div>
            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/Heart-Beats.jpg"  class="fancybox" rel="ligthbox">
                    <img  src="img/Heart-Beats.jpg" class="zoom img-fluid"  alt="">
                </a>
            </div>
            
            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/CIS women heart disease.jpeg" class="fancybox" rel="ligthbox">
                    <img  src="img/CIS women heart disease.jpeg" class="zoom img-fluid "  alt="">
                </a>
            </div>
            
            <div class="col-lg-3 col-md-4 col-6 thumb">
                <a href="img/R-1.jpg" class="fancybox" rel="ligthbox">
                    <img  src="img/R-1.jpg" class="zoom img-fluid "  alt="">
                </a>
            </div>
            
        
        
        </div>
    </div>
</section>
<?php include('footer.php');?>