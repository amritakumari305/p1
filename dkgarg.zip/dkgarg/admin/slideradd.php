<?php
include("../config.php");
$message = "";
if(isset($_POST['submit'])){
$sld_title = $_POST['sld_title'];
$sld_url = $_POST['sld_url'];
$sld_des = $_POST['sld_des'];
$status = $_POST['status'];
$file_name = $_FILES['sld_img']['name'];

$temp_path=$_FILES['sld_img']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);

// display the results
$sql = "INSERT INTO slider (sld_title, sld_img, sld_url, sld_des, status) VALUES ('$sld_title', '$destination', '$sld_url', '$sld_des', '$status')";
mysqli_query($conn, $sql);  
$message = "Successfull! ";
}  
?>
<?php
include("header.php"); 
include("sidemenu.php");
include("menu.php");
?>

<!-- Mobile Menu end -->
 <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add Slider</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php echo $message; ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <input name="sld_title" type="text" class="form-control" placeholder="Slider Title">
                                                                </div>
                                                                <div class="form-group">
                                                                    <input name="sld_img" type="file" class="form-control" placeholder="images">
                                                                </div>
                                                                <div class="form-group">
                                                                    <input id="sld_url" name="sld_url" type="url" class="form-control" placeholder="URL">
                                                                </div>
                                                               
                                                               
                                                                <div class="form-group">
                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                        <option value="1">Active</option>
                                                                        <option value="0">Inactive</option>
                                                                    </select>
                                                                </div>
                                                            
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                    <textarea name="sld_des" placeholder="Description"></textarea>
                                                                </div>
                                                                
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                    <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light">Add</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        
<?php include("footer.php"); ?>