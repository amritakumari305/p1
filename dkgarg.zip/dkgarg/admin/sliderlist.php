<?php
include("../config.php");
$result = mysqli_query($conn,"SELECT * FROM slider");
?>
<?php
include("header.php"); 
include("sidemenu.php");
include("menu.php");
?>
  <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">All Slider</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Static Table Start -->
        <div class="product-status mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap drp-lst">
                            <h4>Slider List</h4>
                            <div class="add-product">
                                <a href="slideradd.php">Add Slider</a>
                            </div>
                            <div class="asset-inner">
                            <?php
                                                if (mysqli_num_rows($result) > 0) {
                                                ?>
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th width="1%">No</th>
                                        <th width="20%">Title</th>
                                       
                                        <th width="25%">Description </th>
                                        <th width="19%">Images</th>
                                        <th width="15%">URL</th>
                                        <th width="10%">Status</th>
                                        <th width="15%">Setting</th>
                                    </tr>
                                    </thead>
                                   <tbody>
                                   <?php
                                                                $i=1;
                                                                while($row = mysqli_fetch_array($result)) {
                                                                ?>
                                   <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $row["sld_title"]; ?></td>
                                        
                                        
                                        <td><?php echo $row["sld_des"]; ?></td>
                                        <td><img src="<?php echo $row["sld_img"]; ?>" class="img-circle img-thumbnail img-responsive messange_img"></td>
                                        <td><?php echo $row["sld_url"]; ?></td>
                                        <td>
                                            
                                            <button class="pd-setting"><?php  if($row["status"]==1) echo "active"; else echo "Inactive"; ?></button>
                                        </td>
                                        <td>
                                            <a  href="slideredit.php?id=<?php echo $row["id"]; ?>" data-toggle="tooltip" title="Edit" class="pd-setting-ed"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            <a  href="delete.php?id=<?php echo $row["id"]; ?>" data-toggle="tooltip" title="Trash" class="pd-setting-ed"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                                                $i++;
                                                                }
                                                                ?>
                                   </tbody>
                                    
                                </table>
                                <?php
                                                            }
                                                            else{
                                                                echo "No result found";
                                                            }
                                                            ?>
                            </div>
                            <div class="custom-pagination">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        
<?php include("footer.php"); ?>