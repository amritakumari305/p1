<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="index.html"><img class="main-logo" src="img/imgpsh_fullsize_anim.png" width="120" alt="" /></a>
                <strong><a href="index.html"><img src="img/imgpsh_fullsize_anim.png" width="120" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a href="index.php"><span class="educate-icon educate-home icon-wrap"></span><span class="mini-click-non">Dashboard</span></a>
                        </li>
                        
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Nav Menu</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="navmenulist.php"><span class="mini-sub-pro">All Menu</span></a></li>
                                <li><a title="Add Professor" href="navmenuadd.php"><span class="mini-sub-pro">Add Menu</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Nav SubMenu</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="navsubmenulist.php"><span class="mini-sub-pro">All Menu</span></a></li>
                                <li><a title="Add Professor" href="navsubmenuadd.php"><span class="mini-sub-pro">Add Menu</span></a></li>
                               
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-apps icon-wrap"></span> <span class="mini-click-non">Banner</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Professors" href="bannerlist.php"><span class="mini-sub-pro">All Banner</span></a></li>
                                <li><a title="Add Professor" href="banneraddedit.php"><span class="mini-sub-pro">Add Banner</span></a></li>
                               
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Services</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Students" href="serviceslist.php"><span class="mini-sub-pro">All Services</span></a></li>
                                <li><a title="Add Students" href="servicesadd.php"><span class="mini-sub-pro">Add Services</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Photo Gallery</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Students" href="serviceslist.php"><span class="mini-sub-pro">All Services</span></a></li>
                                <li><a title="Add Students" href="photogallery.php"><span class="mini-sub-pro">Add photo Gallery</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Video Gallery</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Students" href="serviceslist.php"><span class="mini-sub-pro">All Services</span></a></li>
                                <li><a title="Add Students" href="videogallery.php"><span class="mini-sub-pro">Add Video Gallery</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-library icon-wrap"></span> <span class="mini-click-non">Testimonial</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="All Library" href="testimonaillist.php"><span class="mini-sub-pro">All Testimonial</span></a></li>
                                <li><a title="Add Library" href="testimonailadd.php"><span class="mini-sub-pro">Add Testimonial</span></a></li>
                               
                            </ul>
                        </li>
                       
                        <li>
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-department icon-wrap"></span> <span class="mini-click-non">Blog</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Departments List" href="bloglist.php"><span class="mini-sub-pro">Blog List</span></a></li>
                                <li><a title="Add Departments" href="blogadd.php"><span class="mini-sub-pro">Add Blog</span></a></li>
                               
                            </ul>
                        </li>

                        <li>
                            <a class="has-arrow" href="mailbox.html" aria-expanded="false"><span class="educate-icon educate-interface icon-wrap"></span> <span class="mini-click-non">Social Media</span></a>
                            <ul class="submenu-angle interface-mini-nb-dp" aria-expanded="false">
                                <li><a title="Google Map" href="google-map.html"><span class="mini-sub-pro">Google Map</span></a></li>
                                <li><a title="Data Maps" href="data-maps.html"><span class="mini-sub-pro">Data Maps</span></a></li>
                                <li><a title="Pdf Viewer" href="pdf-viewer.html"><span class="mini-sub-pro">Pdf Viewer</span></a></li>
                                <li><a title="X-Editable" href="x-editable.html"><span class="mini-sub-pro">X-Editable</span></a></li>
                                <li><a title="Code Editor" href="code-editor.html"><span class="mini-sub-pro">Code Editor</span></a></li>
                                <li><a title="Tree View" href="tree-view.html"><span class="mini-sub-pro">Tree View</span></a></li>
                                <li><a title="Preloader" href="preloader.html"><span class="mini-sub-pro">Preloader</span></a></li>
                                <li><a title="Images Cropper" href="images-cropper.html"><span class="mini-sub-pro">Images Cropper</span></a></li>
                            </ul>
                        </li>

                        <li>
                            <a title="Landing Page" href="contact.php" aria-expanded="false"><span class="educate-icon educate-message  icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Enquiry List</span></a>
                        </li>
                        <li>
                            <a title="Landing Page" href="appointment.php" aria-expanded="false"><span class="educate-icon educate-message  icon-wrap sub-icon-mg" aria-hidden="true"></span> <span class="mini-click-non">Appointment List</span></a>
                        </li>
                        <li id="removable">
                            <a class="has-arrow" href="#" aria-expanded="false"><span class="educate-icon educate-pages icon-wrap"></span> <span class="mini-click-non">Pages</span></a>
                            <ul class="submenu-angle page-mini-nb-dp" aria-expanded="false">
                               
                                <li><a title="Password Recovery" href="password-recovery.php"><span class="mini-sub-pro">Password Recovery</span></a></li>

                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>