<?php
include("../common/config.php");
include("header.php"); 
include("sidemenu.php");
include("menu.php");
$btnname= "Add";


if(isset($_GET['action']) && $_GET['action']=="delete")
{
   // echo "<meta http-equiv='refresh' content='0'>";
    $sql1 = "DELETE FROM blog WHERE blg_id='" . $_GET["id"] . "'";
        if (mysqli_query($conn, $sql1)) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . mysqli_error($conn);
        }
            unset($_GET);
            
}

if(isset($_GET['action']) && $_GET['action']=="edit")
{
    $btnname="update";
    $result = mysqli_query($conn,"SELECT * FROM blog WHERE blg_id='" . $_GET['id'] . "'");
    $row= mysqli_fetch_array($result);
}
?>

<!-- Mobile Menu end -->
 <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list single-page-breadcome">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                            <form role="search" class="sr-input-func">
                                                <input type="text" placeholder="Search..." class="search-int form-control">
                                                <a href="#"><i class="fa fa-search"></i></a>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Add Services</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
$message = "";
if(isset($_POST['submit'])){
$blogtitile = $_POST['blogtitile'];
$blogdate = $_POST['blogdate'];
$blogpostby = $_POST['blogpostby'];
$bloglink = $_POST['bloglink'];
$blogdesc=$_POST['blogdesc'];
$status = $_POST['status'];

$file_name = $_FILES['blogimg']['name'];

$temp_path=$_FILES['blogimg']['tmp_name'];
$destination="images/".$file_name;
move_uploaded_file($temp_path, $destination);
// display the results
if($_POST['id5']=="")
{
  $sql = "INSERT INTO blog (blogimg, blogtitile, blogdate, blogpostby, bloglink, blogdesc, status) VALUES ('$destination', '$blogtitile', '$blogdate','$blogpostby', '$bloglink', '$blogdesc', '$status')";
  
}

else
{
    if($_FILES['blogimg']['name']!='')
    {
        $file_name = $_FILES['blogimg']['name'];
    
        $temp_path=$_FILES['blogimg']['tmp_name'];
        $destination="images/".$file_name;
        if(move_uploaded_file($temp_path, $destination)){
            unlink($_POST['old_img']); // for delete file from server
        }
    
        $sql ="UPDATE blog set blogtitile='" . $_POST['blogtitile'] . "', blogdate='" . $_POST['blogdate'] . "', blogpostby='" . $_POST['blogpostby'] . "',  bloglink='" . $_POST['bloglink'] . "', blogdesc='" . $_POST['blogdesc'] . "', blogimg='" . $destination. "', status='" . $_POST['status']. "' WHERE blg_id='" . $_POST['id5'] . "'";
    }else{
    
    
        $sql = "UPDATE blog set blogtitile='" . $_POST['blogtitile'] . "',blogdate='" . $_POST['blogdate'] . "', blogpostby='" . $_POST['blogpostby'] . "',  bloglink='" . $_POST['bloglink'] . "', blogdesc='" . $_POST['blogdesc'] . "', blogimg='" . $_POST['old_img'] . "', status='" . $_POST['status']. "' WHERE blg_id='" . $_POST['id5'] . "'";
    }
    

}

   mysqli_query($conn, $sql);  
    $message = "Successfull! ";
}  
?>
        <!-- Single pro tab review Start-->
        <div class="single-pro-review-area mt-t-30 mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-payment-inner-st">
                        <form action="" method="POST" class="dropzone dropzone-custom needsclick addcourse" id="demo1-upload" enctype="multipart/form-data">
                        <?php echo $message; ?>
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <input type="hidden" name="id5" class="txtField" value="<?php echo @$row['blg_id']; ?>">
                                                                <div class="form-group">
                                                                    <input name="blogimg" type="file" class="form-control" placeholder="Images">
                                                                    <img src="<?php echo $row['blogimg']; ?>" />
                                                                    <input type="hidden" name="old_img" value="<?php echo $row['blogimg']; ?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <input name="blogdate" type="date" class="form-control" placeholder=" date" value="<?php echo @$row['blogdate'];?>">
                                                                </div>
                                                                
                                                               
                                                                <div class="form-group">
                                                                    <input name="blogpostby" type="text" class="form-control" placeholder="Posted By" value="<?php echo @$row['blogpostby'];?>">
                                                                </div>
                                                               
                                                                
                                                                
                                                                
                                                               
                                                               
                                                                <div class="form-group">
                                                                    <label>Status </label>
                                                                    <select name="status" id="status" class="form-control">
                                                                    <option value="1" <?php if(@$row['status']==1); echo"selected"?>>Active</option>
                                                                        <option value="0" <?php if(@$row['status']==0); echo"selected"?>>Inactive</option>
                                                                    </select>
                                                                </div>
                                                            
                                                            </div>
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <div class="form-group">
                                                                        <input name="blogtitile" type="text" class="form-control" placeholder="Blog Title" value="<?php echo @$row['blogtitile'];?>">
                                                                </div>
                                                                <div class="form-group">
                                                                    <input name="bloglink" type="text" class="form-control" placeholder="Blog Link" value="<?php echo @$row['bloglink'];?>"> 
                                                                </div>
                                                                <div class="form-group">
                                                                    <textarea name="blogdesc" placeholder="Description"><?php echo @$row['blogdesc'];?></textarea>
                                                                </div>
                                                                
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-12">
                                                                <div class="payment-adress">
                                                                <button type="submit" name="submit" value="submit" class="btn btn-primary waves-effect waves-light"><?php echo $btnname; ?></button>
                                                                 
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php
    $result = mysqli_query($conn,"SELECT * FROM blog");
?>
        <div class="product-status mg-b-15">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="product-status-wrap drp-lst">
                            <h4>Submenu List</h4>
                           
                            <div class="asset-inner">
                            <?php
                                                if (mysqli_num_rows($result) > 0) {
                                                ?>
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th width="1%">No</th>
                                        <th width="20%">Images</th>
                                        <th width="5%">Title</th>
                                        <th width="5%">Date</th>
                                       
                                        <th width="5%">Post</th>
                                        <th width="5%">Link</th>
                                        <th width="10%">Description</th>
                                        <th width="19%">Status</th>
                                        <th width="30%">Setting</th>
                                    </tr>
                                    </thead>
                                   <tbody>
                                    <?php
                                        $i=1;
                                        while($row = mysqli_fetch_array($result)) {
                                    ?>
                                   <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><img src="<?php echo $row["blogimg"]; ?>" class="img-circle img-thumbnail img-responsive messange_img"></td>
                                        <td><?php echo $row["blogtitile"]; ?></td>
                                        <td><?php echo $row["blogdate"]; ?></td>
                                        <td><?php echo $row["blogpostby"]; ?></td>
                                        <td><?php echo $row["bloglink"]; ?></td>
                                        <td><?php echo $row["blogdesc"]; ?></td>
                                        <td>
                                            
                                            <button class="pd-setting"><?php  if($row["status"]==1) echo "active"; else echo "Inactive"; ?></button>
                                        </td>
                                        <td>
                                            <a  href="blogadd.php?action=edit&id=<?php echo $row["blg_id"]; ?>" data-toggle="tooltip" title="Edit" class="pd-setting-ed"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            <a  href="blogadd.php?action=delete&id=<?php echo $row["blg_id"]; ?>" data-toggle="tooltip" title="Trash" class="pd-setting-ed"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                
                                        </td>
                                    </tr>
                                    <?php
                                                                $i++;
                                                                }
                                                                ?>
                                   </tbody>
                                    
                                </table>
                                <?php
                                    }
                                     else{
                                     echo "No result found";
                                    }
                                ?>
                            </div>
                            <div class="custom-pagination">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">
                                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
                
        
<?php include("footer.php"); ?>