<?php 
include("common/config.php");
?>
<body>
    
    <div id="__next">
        <header class="header-area fixed-top">
            <div class="top-header-area">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-8 col-md-9 col-sm-6" class="">
                            <ul class="header-content-left d-none d-sm-block">
                                <li><i class="bx bx-time"></i>Mon-Wed 7am-9am</li>
                                <li><a href="tel:+7727009167"><i class="bx bx-phone-call"></i>Call Us: +772-700-9167</a></li>
                                <li><a href="mailto:hello@info.com" ><i class="bx bxs-paper-plane"></i>Email: hello@info.com</a></li>
                            </ul>
                        </div>
                        <div class="col-lg-4 col-md-3 col-sm-6">
                            <ul class="header-content-right">
                                <li><a href="contact.php" target="_blank"><i class="bx bx-map"></i></a></li>
                                <li><a href="#" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                                <li><a href="#" target="_blank"><i class="bx bxl-twitter"></i></a></li>
                                <li><a href="#" target="_blank"><i class="bx bxl-youtube"></i></a></li>
                                <li><a href="#" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="nav-area">
                <div id="navbar" class="navbar-area">
                    <div class="main-nav">
                        <nav class="navbar navbar-expand-lg navbar-light ">
                            <div class="container">
                                <a class="navbar-brand" href="index.php"><img src="img/logojpg.png" alt="logo" width="90"></a>
                                <button class="navbar-toggler navbar-toggler-right collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="icon-bar top-bar"></span><span class="icon-bar middle-bar"></span><span class="icon-bar bottom-bar"></span></button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav m-auto">
                                    <?php
                                       $xyz=0;
                                        $result = mysqli_query($conn,"SELECT * FROM navmenutype");
                                   
                                        while($row = mysqli_fetch_array($result)) {
                                            if($row["menulink"]!='')
                                            {
                                                
                                    ?>
                                                <li class="nav-item"><a class="nav-link <?php if($xyz==0){echo "active"; $xyz++; }?> " href="<?php echo $row["menulink"]; ?>?page_name=<?php echo $row["menuname"]; ?>"><?php echo $row["menuname"]; ?></a></li>

                                    <?php
                                            }   
                                        else
                                        {
                                    ?>
                                            <li class="nav-item"><a class="nav-link <?php if($xyz==0){echo "active"; $xyz++; }?>" href="#"><?php echo $row["menuname"]; ?>  <i class="bx bx-plus"></i></a>
                                            <ul class="dropdown-menu">
                                        <?php
                                            $result1 = mysqli_query($conn,"SELECT * FROM navsubmenu where menutype=".$row["id"]);
                                                                            
                                            while($row1 = mysqli_fetch_array($result1)) {
                                                
                                        ?>
                                                    <li class="nav-item"><a class="nav-link" href="<?php echo $row1["submenulink"]; ?>?page_name=<?php echo $row1["submenuname"]; ?>"><?php echo $row1["submenuname"]; ?></a></li>
                                                    
                                            <?php
                                                }
                                                echo " </ul>  </li>";

                                            }


                                        }
                                    ?>
                                       
                                        
                                        <!-- <li class="nav-item"><a class="nav-link" href="#">Treatments  <i class="bx bx-plus"></i></a>
                                            <ul class="dropdown-menu">
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Chest Pain</a></li>
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Angina Treatment</a></li>
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Heart Attack Treatment</a></li>
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Heart Failure Treatment</a></li>
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Angiography Treatment</a></li>
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Angioplasty Treatment</a></li>
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Pacemaker</a></li>
                                                <li class="nav-item"><a class="nav-link" href="chestpain.php">Heart Valve Replacement</a></li>
                                            </ul>
                                        </li>
                                        <li class="nav-item"><a class="nav-link" href="#">Gallery <i class="bx bx-plus"></i></a>
                                            <ul class="dropdown-menu">
                                                <li class="nav-item"><a class="nav-link" href="photogallery.php">Photo Gallery</a></li>
                                                <li class="nav-item"><a class="nav-link" href="videogallery.php">Video Gallery</a></li>
                                                
                                            </ul>
                                        </li>
                                        <li class="nav-item"><a class="nav-link" href="doctor.php">Doctors </a></li>
                                        <li class="nav-item"><a class="nav-link" href="blog.php">Blog </a></li>
                                        <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li> -->
                                    </ul>
                                    <div class="others-option">
                                        <div class="subscribe"><a class="default-btn" href="#appointment">Book An Appointment</a></div>
                                    </div>
                                </div>
                            </div>
                        </nav>




                       
                    </div>
                </div>
            </div>
        </header>