<?php
include('header.php');
include('menu.php');
include('banner.php');
?>
<div class="blog-details-area ptb-100">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-12">
                        <div class="blog-details-desc">
                            <div class="article-image"><img src="img/blog/blog11.jpg" alt="image" width="100%"></div>
                            <div class="article-content">
                                <div class="entry-meta">
                                    <ul>
                                        <li><span>Posted On:</span> <a href="#">Nov 19, 2020</a></li>
                                        <li><span>Posted By:</span> <a href="#">John Anderson</a></li>
                                    </ul>
                                </div>
                                <h3>What Can I Do To Prevent Myself &amp; prevent Disease</h3>
                                <p>Quuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quia non numquam eius modi tempora incidunt ut labore et dolore magnam dolor sit, consectetur qui ratione voluptatem sequi nesciunt.</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                    consequat. Duis aute irure dolor in reprehenderit in sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat labore et dolore magna aliqua consectetur adipisicing elit.</p>
                               
                                     <div
                                        class="row mb-3">
                                        <div class="col-lg-4 mt-4">
                                            <div class="b-d-s-img"><img src="img/blog/blog4.jpg" alt="Image" /></div>
                                        </div>
                                        <div class="col-lg-4 mt-4">
                                            <div class="b-d-s-img"><img src="img/blog/blog5.jpg" alt="Image" /></div>
                                        </div>
                                        <div class="col-lg-4 mt-4">
                                            <div class="b-d-s-img"><img src="img/blog/blog6.jpg" alt="Image" /></div>
                                        </div>
                            </div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                Duis aute irure dolor in reprehenderit in sed quia non numquam. consectetur adipisicing elit, sed</p>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                                Duis aute irure dolor in reprehenderit in sed quia non numquam. consectetur adipisicing elit, sed</p>
                        </div>
                        <div class="article-footer">
                            <div class="article-tags"><span><i class="bx bx-share-alt"></i></span><a href="#">Share</a></div>
                            <div class="article-share">
                                <ul class="social">
                                    <li><a href="#" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-twitter"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-youtube"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="post-navigation">
                            <div class="navigation-links">
                                <div class="nav-previous"><a href="#"><i class="bx bx-left-arrow-alt"></i> Prev Post</a></div>
                                <div class="nav-next"><a href="#">Next Post <i class="bx bx-right-arrow-alt"></i></a></div>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-4 col-md-12">
                    <div class="blog-right-sidebar">
                        <div class="widget-area left-sidebar" id="secondary">
                            <div class="widget widget_search">
                                <h3 class="widget-title">Search Now</h3>
                                <div class="post-wrap">
                                    <form class="search-form"><label><span class="screen-reader-text">Search for:</span><input type="search" class="search-field" placeholder="Search..."/></label><button type="submit"><i class="bx bx-search"></i></button></form>
                                </div>
                            </div>
                            <div class="widget widget-peru-posts-thumb">
                                <h3 class="widget-title">Popular Posts</h3>
                                <div class="post-wrap">
                                    <div class="item"><a class="thumb" href="blog-details.html"><span class="fullimage cover bg1" role="img"></span></a>
                                        <div class="info"><span class="time">Nov 20, 2020</span>
                                            <h4 class="title usmall"><a href="blog-details.html">250+ Medical Tips We just had to share</a></h4>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                    <div class="item"><a class="thumb" href="blog-details.html"><span class="fullimage cover bg2" role="img"></span></a>
                                        <div class="info"><span class="time">Nov 21, 2020</span>
                                            <h4 class="title usmall"><a href="blog-details.html">What Can I Do To Prevent Myself &amp; prevent Disease</a></h4>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                    
                                </div>
                            </div>
                           
                            <div class="widget widget_categories">
                                <h3 class="widget-title">Categories</h3>
                                <div class="post-wrap">
                                    <ul>
                                        <li><a href="#">Antibiotic <span>(10)</span></a></li>
                                        <li><a href="#">Diseases <span>(20)</span></a></li>
                                        <li><a href="#">Health Care <span>(10)</span></a></li>
                                        <li><a href="#">Heart Rate <span>(12)</span></a></li>
                                        <li><a href="#">Hospital <span>(16)</span></a></li>
                                        <li><a href="#">Infectious <span>(17)</span></a></li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="widget widget_tag_cloud">
                                <h3 class="widget-title">Tags</h3>
                                <div class="post-wrap">
                                    <div class="tagcloud"><a href="#">Antibiotic (3)</a><a href="#">Diseases (3)</a><a href="#">Heart (2)</a><a href="#">Health (2)</a><a href="#">Hospital (1)</a><a href="#">Infectious </a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include('footer.php');?>