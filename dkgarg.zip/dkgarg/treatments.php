<?php
include('header.php');
include('menu.php');
include('banner.php');
?>
<div class="services-area bg py-5">
            <div class="container">
                <div class="section-title"><span class="top-title">Treatments </span>
                    <h2>Our Healthcare Treatments </h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facilis vel consequatur tempora atque blanditiis exercitationem incidunt, alias corporis quam assumenda dicta, temporibus.</p>
                </div>
                <div class="row">
                    <?php
                        $result = mysqli_query($conn,"SELECT * FROM services");
                                    
                        while($row = mysqli_fetch_array($result)) {
                        
                                                    
                    ?>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3><?php echo $row["srv_titile"]; ?></h3>
                            <p><?php echo $row["srv_desc"]; ?></p>
                            <a class="read-more" href="<?php echo $row["srv_link"]; ?>">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3></h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Heart Failure Treatment</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Angiography Treatment</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Heart Valve Replacement</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="single-services"><span class="flaticon-heart"></span>
                            <h3>Pacemaker</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore dolore</p>
                            <a class="read-more" href="treatments.php">Read More <i class="bx bx-plus"></i></a>
                            <div class="services-shape"><img src="img/services-card-shape.png" alt="Image" /></div>
                        </div>
                    </div> -->
                    <?php
                    }
                    ?>
                </div>
            </div>
        </div>
<?php include('footer.php');?>