<?php
include('header.php');
include('menu.php');
include('banner.php');
?>
  <div class="services-area bg py-5">
            <div class="container">
                <div class="section-title"><span class="top-title">Gallery </span>
                    <h2>Our Video Gallery </h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facilis vel consequatur tempora atque blanditiis exercitationem incidunt, alias corporis quam assumenda dicta, temporibus.</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-sm-6">
                        <div class="videos mb-4">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/Ozsbpa56btA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="videos mb-4">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/Ozsbpa56btA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="videos mb-4">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/Ozsbpa56btA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="videos mb-4">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/Ozsbpa56btA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
       
<?php include('footer.php');?>