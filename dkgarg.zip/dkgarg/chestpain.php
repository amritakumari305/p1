<?php
include('header.php');
include('menu.php');
include('banner.php');
?>
<div class="second-facility-area pt-5 pb-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-sm-6">
                        <div class="second-facility-item"><img src="img/facility-img/facility-icon1.png" alt="Image" />
                            <h3>Qualified Doctors</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p><a class="read-more" href="services-details.html">Read More <i class="bx bx-plus"></i></a></div>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <div class="second-facility-item"><img src="img/facility-img/technical-support.png" alt="Image" />
                            <h3>Emergency Service</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p><a class="read-more" href="services-details.html">Read More <i class="bx bx-plus"></i></a></div>
                    </div>
                    <div class="col-lg-4 col-sm-6 offset-sm-3 offset-lg-0">
                        <div class="second-facility-item"><img src="img/facility-img/facility-icon3.png" alt="Image" />
                            <h3>Leading Technology</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore.</p><a class="read-more" href="services-details.html">Read More <i class="bx bx-plus"></i></a></div>
                    </div>
                </div>
            </div>
        </div>
<div class="ours-doctors-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="doctors-content ptb-100"><span class="top-title">Chest Pain</span>
                            <h2>We are Offering Reliable Consulting Services</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.</p>
                            <ul>
                                <li><i class="flaticon-tick"></i>Provide free and high-quality medical services for poor population</li>
                                <li><i class="flaticon-tick"></i>Raise health awareness among the community and teach them to deal with communicable and noncommunicable.</li>
                                <li><i class="flaticon-tick"></i>Refer medical cases towards surgeries if required</li>
                            </ul></div>
                    </div>
                    <div class="col-lg-6 pr-0">
                        <div class="doctors-img about"></div>
                    </div>
                </div>
            </div>
            <div class="shape"><img src="img/home-six/home-six-about-shape.png" alt="Image" /></div>
        </div>

        <div class="how-its-work pt-5">
            <div class="container">
                <div class="section-title"><span class="top-title">Woks</span>
                    <h2>How We Works</h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facilis vel consequatur tempora atque blanditiis exercitationem incidunt, alias corporis quam assumenda dicta, temporibus.</p>
                </div>
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="how-its-work-content">
                            <div class="content-wrap">
                                <h3>Make An Appoinment</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum</p>
                            </div>
                            <div class="content-wrap">
                                <h3>Get Ready To Meet Doctor</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum</p>
                            </div>
                            <div class="content-wrap">
                                <h3>Admidmission to the Hospital</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="how-work-img"><img src="img/appointment.jpg" alt="Image" /></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="operate-area ptb-100"><div class="container"><div class="row align-items-center"><div class="col-lg-4"><div class="operate-img"><img src="img/home-three/operate-img.png" alt="Image"></div></div><div class="col-lg-4"><div class="operate-text"><h2>We operate 24 a day!</h2><p>Call us if you have any urgent help!</p></div></div><div class="col-lg-4"><div class="operate-btn"><a href="tel:7727009167" class="default-btn"><i class="bx bx-phone-call"></i>+91 772-700-9167</a></div></div></div></div></div>
<?php include('footer.php');?>