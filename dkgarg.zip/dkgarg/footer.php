
        <footer class="footer-top-area f-bg pt-5 pb-3">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget">
                        <h3>Company</h3>
                            <!-- <a href="index.html"><img src="img/logojpg.png" alt="Image" width="120"></a> -->
                            <p>Lorem ipsum dolor, sit amet earum consectetur adipisicing elit. Cupiditate rerum quidem fugiat sapiente! Iusto quae perspiciatis.</p>
                            <div class="social-area">
                                <ul>
                                    <li><a href="#" target="_blank"><i class="bx bxl-facebook"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-twitter"></i></a></li>
                                    <!-- <li><a href="#" target="_blank"><i class="bx bxl-linkedin"></i></a></li> -->
                                    <li><a href="#" target="_blank"><i class="bx bxl-youtube"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="bx bxl-instagram"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget">
                            <h3>Quick Links</h3>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="about.php">About</a></li>
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="treatments.php">Treatments </a></li>
                                <li><a href="photogallery.php">Photo Gallery</a></li>
                                <li><a href="videogallery.php">Video Gallery</a></li>
                                <li><a href="blog.php">Blog</a></li>
                                <li><a href="achievement.php">Achievement</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget open-time">
                            <h3>Opening Hours</h3>
                            <ul>
                               
                                <li><span>Mon-Wed:</span><span class="right">7:00AM-9:00AM</span></li>
                                <li><span>Mon-Wed:</span><span class="right">6:00PM-9:00PM</span></li>
                                <li><span>Thus-Fri:</span><span class="right">Closed</span></li>
                                <li><span>Sat-Sun:</span><span class="right">7:00AM-9:00AM</span></li>
                                <li><span>Sat-Sun:</span><span class="right">6:00PM-9:00PM</span></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="single-widget contact">
                            <h3>Get In Touch</h3>
                            <ul>
                                <li class="pl-0"><a href="tel:+7727009167"><i class="bx bx-phone-call"></i><span>Call On:</span>Phone: +91 772-700-9167</a></li>
                                <li class="pl-0"><a href="mailto:hello@deventa.com"><i class="bx bx-envelope"></i><span>Email:</span>hello@deventa.com</a></li>
                                <li><i class="bx bx-location-plus"></i><span>Address:</span>B-20, Scheme No.10-B Gopalpura Bypass, Jaipur</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <div class="footer-bottom-area">
            <div class="container">
                <div class="copy-right">
                    <p>&copy; 2020 Dr.DK Garg. Designed and Developed by: 
                        <a href="https://coralitsolution.com/" target="blank"><img src="img/coral-logo.png" alt="" width="110"></a>
                    </p>
                </div>
            </div>
        </div>

        <div class="go-top "><i class="bx bx-chevrons-up"></i><i class="bx bx-chevrons-up"></i></div>
    </div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script>
        jQuery("#carousel").owlCarousel({
            autoplay: true,
            lazyLoad: true,
            rewind: true,
            margin: 20,
            /*
  animateOut: 'fadeOut',
  animateIn: 'fadeIn',
  */
            responsiveClass: true,
            autoHeight: true,
            autoplayTimeout: 7000,
            smartSpeed: 800,
            nav: true,
            responsive: {
                0: {
                    items: 1
                },

                600: {
                    items: 3
                },

                1024: {
                    items: 3
                },

                1366: {
                    items: 3
                }
            }
        });
</script>
<script>
        var slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        function currentSlide(n) {
            showSlides(slideIndex = n);
        }

        function showSlides(n) {
            var i;
            var slides = document.getElementsByClassName("mySlides");
            var dots = document.getElementsByClassName("dot");
            if (n > slides.length) {
                slideIndex = 1
            }
            if (n < 1) {
                slideIndex = slides.length
            }
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }
            for (i = 0; i < dots.length; i++) {
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
        }
</script>
<!-- images gallery-->
<script src="assets/js/jquery.fancybox.min.js"></script>
<script>
$(document).ready(function(){
  $(".fancybox").fancybox({
        openEffect: "none",
        closeEffect: "none"
    });
    
    $(".zoom").hover(function(){
		
		$(this).addClass('transition');
	}, function(){
        
		$(this).removeClass('transition');
	});
});
</script>
</body>

</html>