<?php
include('header.php');
include('menu.php');
include('banner.php');
?>
<section class="services-area bg py-5">
    <div class="container page-top">
                <div class="section-title"><span class="top-title">Gallery </span>
                    <h2>Our Achievement </h2>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facilis vel consequatur tempora atque blanditiis exercitationem incidunt, alias corporis quam assumenda dicta, temporibus.</p>
                </div>
        <div class="row">


            <div class="col-lg-4 col-md-4 col-6 ">
                
                    <img  src="img/achievements.jpg" class="img-fluid "  alt="">
                    <p class="pt-4">Best Doctor Award. Fortis Hospital, New Delhi.</p>
                
            </div>
            <div class="col-lg-4 col-md-4 col-6 ">
               
            <img  src="img/achievements.jpg" class="img-fluid "  alt="">
                    <p class="pt-4">Best Doctor and Great Human Award. Agrawal Sewa Samiti, Agra. 

2013</p>
            </div>
            
            <div class="col-lg-4 col-md-4 col-6 ">
               
            <img  src="img/achievements.jpg" class="img-fluid "  alt="">
               <p class="pt-4">Best Doctor Award. Fortis Hospital, New Delhi.</p>
            </div>
            
            
        
        
        </div>
    </div>
</section>
<?php include('footer.php');?>