<footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="footer-left">
                        <div class="footer-logo">
                            <a href="#"><img src="img/coralgifting.png" alt=""></a>
                        </div>

                        <ul>
                            <li>Address: 28A, Brijlalpura Near Ganga Jamuna Petrol Pump, Gopalpura Bypass, Jaipur, Rajasthan, India</li>
                            <li>Phone: +91-952-113-2592</li>
                            <li>Email: <a href="mailto:hr@coralitsolution.com" >hr@coralitsolution.com</a></li>
                        </ul>
                       
                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1 col-6">
                    <div class="footer-widget">
                        <h5>Information</h5>
                        <ul>
                            <li><a href="about.php">About Us</a></li>
                            <li><a href="contact.php">Contact Us</a></li>
                            <li><a href="newitem.php">New Item</a></li>
                            <li><a href="olditem.php">Old Used Item</a></li>
                           
                            <li><a href="pp.php">Privacy Policy</a></li>
                            <li><a href="tc.php">Terms and Condition</a></li>
                            <li><a href="faq.php">FAQ</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="footer-widget">
                        <h5>My Account</h5>
                        <ul>
                             <li><a href="register.php">Register</a></li>
                            <li><a href="login.php">Login</a></li>
                            <li><a href="myprofile.php">My Account</a></li>
                            <li><a href="#"></a></li>
                            <li><a href="cart.php">Shopping Cart</a></li>
                            <li><a href="shop.php">Shop</a></li>
                            <li><a href="blog.php">Blog</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="newslatter-item">
                        <h5>Join Our Newsletter Now</h5>
                        <p>Get E-mail updates about our latest shop and special offers.</p>
                        <form action="#" class="subscribe-form">
                            <input type="text" placeholder="Enter Your Mail">
                            <button type="button">Subscribe</button>
                        </form>
                    </div>
                    <div class="footer-social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-pinterest"></i></a>
                        </div>
                </div>
            </div>
        </div>
        <div class="copyright-reserved">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright-text">

                            &copy;
                           
                            <script>
                                document.write(new Date().getFullYear());
                            </script> All rights reserved | Designed and Developed by <a href="https://coralitsolution.com/" target="_blank">
                            <img src="img/coral-logo.png" alt="" width="120"></a>

                        </div>
                        <div class="payment-pic">
                            <img src="img/payment-method.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.zoom.min.js"></script>
    <script src="js/jquery.dd.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="js/slick.js"></script>
  <script type="text/javascript">
    $(document).on('ready', function() {
        $(".center").slick({
        dots: true,
        infinite: true,
        centerMode: true,
        slidesToShow: 9,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 2
            }
        }, {
            breakpoint: 520,
            settings: {
                slidesToShow: 2
            }
        }]
      });
    });
</script>
</body>


</html>