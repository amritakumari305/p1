
    <section class="hero-section">
        <div class="hero-items owl-carousel">
            <div class="single-hero-items set-bg" data-setbg="">
                <img src="img/Personalised-21-sept-2020.webp" alt="">
                <!-- <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <span>Bag,kids</span>
                            <h1>Black friday</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>
                            <a href="#" class="primary-btn">Shop Now</a>
                        </div>
                    </div>
                    <div class="off-card">
                        <h2>Sale <span>50%</span></h2>
                    </div>
                </div> -->
            </div>
            <div class="single-hero-items set-bg" data-setbg="">
            <img src="img/BirthdayCakes-1-dec-2020.webp" alt="">
                <!-- <div class="container">
                    <div class="row">
                        <div class="col-lg-5">
                            <span>Bag,kids</span>
                            <h1>Black friday</h1>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore</p>
                            <a href="#" class="primary-btn">Shop Now</a>
                        </div>
                    </div>
                    <div class="off-card">
                        <h2>Sale <span>50%</span></h2>
                    </div>
                </div> -->
            </div>
        </div>
    </section>
    
    <div class="container-fluid">
        <section class="center slider">
            <div>
                <img src="img/flowericon.jpg" alt="">
                <center><a href="">Flowers</a></center>
            </div>
            <div>
                <img src="img/plantsicon.jpg" alt="">
                <center><a href="">Plants</a></center>
            </div>
            <div>
                <img src="img/cakeslider.jpg" alt="">
                <center><a href="">Cakes</a></center>
            </div>
            <div>
                <img src="img/chocolates.jpg" alt="">
                <center><a href="">Chocolates</a></center>
            </div>
            <div>
                <img src="img/Personalised.jpg" alt="" >
                <center><a href="">Personalised</a></center>
            </div>
            <div>
                <img src="img/combo.jpg" alt="">
                <center><a href="">Combos</a></center>
            </div>
            <div>
                <img src="img/birthdaycake.jpg" alt="">
                <center><a href="">Birthday</a></center>
            </div>
            <div>
                <img src="img/anniversery.jpg" alt="">
                <center><a href="">Anniversary</a></center>
            </div>
            <div>
                <img src="img/newARRIVAL.jpg" alt="">
                <center><a href="">New Arrivals</a></center>
            </div>
            <div>
                <img src="img/USEDGIFT.jpg" alt="">
                <center><a href="">Used Items</a></center>
            </div>
            
        </section>
    </div>
  

    <!-- <section class="banner-section spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-2 col-6">
                    <div class="single-banner text-center">
                        <img src="img/flowericon.jpg" alt="">
                        
                        <p>Flower</p>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="single-banner text-center">
                        <img src="img/plantsicon.jpg" alt="">
                        
                        <p>Plant</p>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="single-banner text-center">
                        <img src="img/cakeicon.jpg" alt="">
                        
                        <p>Cake</p>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="single-banner text-center">
                        <img src="img/flowers-online-106.jpg" alt="" >
                        
                        <p>Flower</p>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="single-banner text-center">
                        <img src="img/flowers-online-106.jpg" alt="">
                        
                        <p>Flower</p>
                    </div>
                </div>
                <div class="col-lg-2 col-6">
                    <div class="single-banner text-center">
                        <img src="img/flowers-online-106.jpg" alt="">
                        
                        <p>Flower</p>
                    </div>
                </div>
               
            </div>
        </div>
    </section> -->

<section  class="spad pb-5">
    <div class="container-fluid p-0">
        <div class="row no-gutters">
            <div class="col-md-6">
                <div class="text-home4 fresh-sec text-center">
                    <div class="wpb_wrapper">
                        <div class="wpb_text_column wpb_content_element ">
                            <div class="wpb_wrapper">
                                <h3>New Collections</h3>
                                <p>Show your style naturaly</p>
                            </div>
                        </div>
                        <div class="ftc-button-wrapper">
                            <a href="shop.php" target="_self" class="ftc-button ftc-button-2 large ">Shop Now</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-md-4">
                <div class="text-home5 deal-sec">
                    <div class="wpb_wrapper">
                        <div class="wpb_text_column wpb_content_element ">
                            <div class="wpb_wrapper">
                                <h3>New Year</h3>
                                <p>sale up to 70% off</p>
                            </div>
                        </div>
                        <div class="ftc-button-wrapper">
                            <a href="shop.php" target="_self" class="ftc-button ftc-button-3 large ">Shop now</a>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="col-md-6">
                <div class="text-home4 used-sec text-center">
                    <div class="wpb_wrapper">
                        <div class="wpb_text_column wpb_content_element ">
                            <div class="wpb_wrapper">
                                <h3>Used Item</h3>
                                <p>All you need for this season</p>
                            </div>
                        </div>
                        <div class="ftc-button-wrapper">
                            <a href="shop.php" target="_self" class="ftc-button ftc-button-4 large ">Shop Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="women-banner ">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 d-none d-sm-none d-md-block">
                <div class="product-large set-bg" data-setbg="img/background1.jpg">
                        
                    <h2>Bestseller </h2>
                    <a href="#">Discover More</a>
                </div>
                
            </div>
            <div class="col-lg-8 offset-lg-1">
                <!-- <div class="filter-control">
                        <ul>
                            <li class="active">Clothings</li>
                            <li>HandBag</li>
                            <li>Shoes</li>
                            <li>Accessories</li>
                        </ul>
                    <img width="36" height="50" src="img/before.png"  alt="" class="mb-2" >
                    <h3>Shop By Bestseller Categories</h3>
                    
                </div> -->
                <div class="section-title">
                        <!-- <img width="36" height="50" src="img/before.png"  alt="" class="mb-2">
                             -->
                            
                        <h2>Shop By Bestseller </h2>
                        <!-- <p>Check out our most recent items</p> -->
                       
                    </div>
                <div class="product-slider owl-carousel">
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/combogift.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                    <h5>Combo Pack</h5>
                                </a>
                                
                            </div>
                    </div>
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/aniversry.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                <h5>Anniversary</h5>
                                </a>
                                
                            </div>
                    </div>
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/wallets.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                <h5>Branded</h5>
                                </a>
                                
                            </div>
                    </div>
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/cakes.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                <h5>Birhtday</h5>
                                </a>
                                
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="deal-of-week set-bg" data-setbg="img/time-bg-Recovered.jpg">
        <div class="container">
            <div class="col-lg-8 text-center">
                <div class="section-title">
                    <h2>Deal Of The Week</h2>
                    <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed </p> -->
                </div>
                <div class="countdown-timer" id="countdown">
                    <div class="cd-item">
                        <span>56</span>
                        <p>Days</p>
                    </div>
                    <div class="cd-item">
                        <span>12</span>
                        <p>Hrs</p>
                    </div>
                    <div class="cd-item">
                        <span>40</span>
                        <p>Mins</p>
                    </div>
                    <div class="cd-item">
                        <span>52</span>
                        <p>Secs</p>
                    </div>
                </div>
                <a href="shop.php" class="primary-btn">Shop Now</a>
            </div>
        </div>
</section>

<section class="man-banner spad">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <!-- <div class="filter-control">
                            
                        <img width="36" height="50" src="img/before.png"  alt="" class="mb-2" >
                        <h3>Shop Gifts By Choice</h3>
                        <p>Check out our most recent items</p>
                    </div> -->
                    <div class="section-title">
                        <!-- <img width="36" height="50" src="img/before.png"  alt="" class="mb-2">
                             -->
                            
                        <h2>Shop Gifts By Choice </h2>
                        <!-- <p>Check out our most recent items</p> -->
                       
                    </div>
                    <div class="product-slider owl-carousel">
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/combogift.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                    <h5>Combo Pack</h5>
                                </a>
                                
                            </div>
                    </div>
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/aniversry.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                <h5>Anniversary</h5>
                                </a>
                                
                            </div>
                    </div>
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/wallets.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                <h5>Branded</h5>
                                </a>
                                
                            </div>
                    </div>
                    <div class="product-item">
                            <div class="pi-pic">
                                <img src="img/products/cakes.jpg" alt="">
                                <div class="sale">Bestseller</div>
                                <div class="icon">
                                    <i class="icon_heart_alt"></i>
                                </div>
                                <!-- <ul>
                                    <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li>
                                    <li class="quick-view"><a href="#">+ Quick View</a></li>
                                    <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li>
                                </ul> -->
                            </div>
                            <div class="pi-text">
                                <!-- <div class="catagory-name">Gift</div> -->
                                <a href="bycategories.php">
                                <h5>Birhtday</h5>
                                </a>
                                
                            </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 offset-lg-1 d-none d-sm-none d-md-block">
                    <div class="product-large set-bg m-large" data-setbg="img/background1.jpg">
                        <h2>By Choice</h2>
                        <a href="shop.php">Discover More</a>
                    </div>
            </div>
        </div>
    </div>
</section>
<section class="filter-controls_head">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="filter-controls pb-3">
                    <h3>Premium Gifts</h3>
                </div>
            </div>
            
        </div>
        <div class="row">
           <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                <div class="category" data-id="EXP14586">
                    <a href="shop.php"target="_blank">
                        <figure>
                            <div class="thum">
                                <img src="img/products/Corporate-Gifts.jpg" alt="corporate gift">
                            </div>
                            <figcaption>
                                <span class="p-name">Corporate Gifts</span>
                                
                            </figcaption>
                        </figure>
                    </a>
                </div>
           </div>
           <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                <div class="category" data-id="EXP14586">
                <a href="shop.php"target="_blank">
                        <figure>
                            <div class="thum">
                                <img src="img/products/wallet.jpg" alt="Wallets Pack">
                            </div>
                            <figcaption>
                                <span class="p-name">Combo</span>
                               
                            </figcaption>
                        </figure>
                    </a>
                </div>
           </div>
           <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                <div class="category" data-id="EXP14586">
                <a href="shop.php"target="_blank">
                        <figure>
                            <div class="thum">
                                <img src="img/products/oFFice Gift.jpg" alt="Hamper of chocolates and teddy bear choclates gifts">
                            </div>
                            <figcaption>
                                <span class="p-name">Pen Stand</span>
                                
                            </figcaption>
                        </figure>
                    </a>
                </div>
           </div>
           <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                <div class="category" data-id="EXP14586">
                <a href="shop.php"target="_blank">
                        <figure>
                            <div class="thum">
                                <img src="img/products/coffeelover.jpg" alt="Hamper of chocolates and teddy bear choclates gifts">
                            </div>
                            <figcaption>
                                <span class="p-name">Coffee Set</span>
                               
                            </figcaption>
                        </figure>
                    </a>
                </div>
           </div>
           <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                <div class="category" data-id="EXP14586">
                <a href="shop.php"target="_blank">
                        <figure>
                            <div class="thum">
                                <img src="img/products/bagpacks.jpg" alt="Hamper of chocolates and teddy bear choclates gifts">
                            </div>
                            <figcaption>
                                <span class="p-name">Bag</span>
                                
                            </figcaption>
                        </figure>
                    </a>
                </div>
           </div>
           <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                <div class="category" data-id="EXP14586">
                <a href="shop.php"target="_blank">
                        <figure>
                            <div class="thum">
                                <img src="img/products/bottelset.jpg" alt="Hamper of chocolates and teddy bear choclates gifts">
                            </div>
                            <figcaption>
                                <span class="p-name">Bottel Set</span>
                                
                            </figcaption>
                        </figure>
                    </a>
                </div>
           </div>
        </div>
    </div>

</section>  
    <!-- <div class="instagram-photo">
        <div class="insta-item set-bg" data-setbg="img/cate1.webp">
            <div class="inside-text">
                <i class="ti-eye"></i>
                <h5><a href="shop.php">Chocolate</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" data-setbg="img/cate2.webp">
            <div class="inside-text">
            <i class="ti-eye"></i>
                <h5><a href="shop.php">Gift</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" data-setbg="img/cate3.webp">
            <div class="inside-text">
            <i class="ti-eye"></i>
                <h5><a href="shop.php">Plant</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" data-setbg="img/cate4.webp">
            <div class="inside-text">
            <i class="ti-eye"></i>
                <h5><a href="shop.php">Cake</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" data-setbg="img/cate5.webp">
            <div class="inside-text">
            <i class="ti-eye"></i>
                <h5><a href="shop.php">Gift</a></h5>
            </div>
        </div>
        <div class="insta-item set-bg" data-setbg="img/cate6.webp">
            <div class="inside-text">
            <i class="ti-eye"></i>
                <h5><a href="shop.php">Gift</a></h5>
            </div>
        </div>
    </div> -->

<section class="py-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-12 col-sm-12 col-12">
                <div id="demo" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="carousel-caption">
                                <img src="img/test1.jpg">
                                <p>If Shai Reznik's TDD videos don't convince you to add automated testing your code, I don't know what will.This was the very best explanation of frameworks for brginners that I've ever seen. </p> 
                                
                                <div id="image-caption">Nick Doe</div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="carousel-caption">
                                <img src="img/test1.jpg" class="img-fluid">
                                <p>If Shai Reznik's TDD videos don't convince you to add automated testing your code, I don't know what will.This was the very best explanation of frameworks for brginners that I've ever seen.</p> 
                               
                                <div id="image-caption">Cromption Greves</div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="carousel-caption">
                                <img src="img/test1.jpg" class="img-fluid">
                                <p>If Shai Reznik's TDD videos don't convince you to add automated testing your code, I don't know what will.This was the very best explanation of frameworks for brginners that I've ever seen.</p> 
                               
                                <div id="image-caption">Harry Mon</div>
                            </div>
                        </div>
                    </div> 
                    <a class="carousel-control-prev" href="#demo" data-slide="prev"><i class='fa fa-arrow-left'></i> </a> 
                    <a class="carousel-control-next" href="#demo" data-slide="next"> <i class='fa fa-arrow-right'></i> </a>
                </div>
            </div>
            <div class="col-lg-7 col-md-12 col-sm-12 col-12">
                <div class="row">
                
                    <div class="col-md-6 col-sm-6">
                        <div class="bottom-banner-img1"> 
                            <a href="shop.php"> 
                                <img src="img/forher.jpg" alt="bottom banner" width="100%"> 
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6">
                        <div class="bottom-banner-img1"> 
                            <a href="shop.php"> 
                                <img src="img/forhim.jpg" alt="bottom banner"  width="100%">
                            
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-md-12 col-sm-12">
                        <div class="bottom-banner-img2 last "> 
                            <a href="#" class="">
                                <img src="img/aboutbanner.jpg" alt="bottom banner"  width="100%"> 
                                <!-- <div class="bottom-img-info last">
                                    <h3>up to <span>25%</span> off</h3>
                                    <h6>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</h6>
                                </div> -->
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- <section class="filter-controls_head">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="filter-controls pl-3">
                    <h3>Top Products</h3>
                </div>
            </div>
            <div class="col-md-6">
                <div class="filter-controls float-right">
                    <a href="#" class="primary-btn">See More</a>
                </div>
            </div>
        </div>
    </div>
</section> -->
<section class="product-shop">
        <div class="container">
            <div class="row">
                
                <div class="col-lg-12 order-1 order-lg-2">
                        <!-- <div class="filter-control">
                            
                            <img width="36" height="50" src="img/before.png"  alt="" class="mb-2">
                            <h3>Shop Gifts Popular</h3>
                            <p>Check out our most recent items</p>
                        </div> -->
                        <div class="section-title">
                        <!-- <img width="36" height="50" src="img/before.png"  alt="" class="mb-2">
                             -->
                            
                        <h2>Shop Popular Gifts  </h2>
                        <!-- <p>Check out our most recent items</p> -->
                       
                    </div>
                    <div class="product-list">
                        <div class="row">
                            <div class="col-lg-3 col-sm-6 col-6">
                                <div class="product-item">
                                    <div class="pi-pic">
                                        <img src="img/products/f1.jpg" alt="">
                                        <div class="sale pp-sale">Sale</div>
                                        <div class="icon">
                                            <i class="icon_heart_alt"></i>
                                        </div>
                                        <ul>
                                            <!-- <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li> -->
                                            <li class="quick-view"><a href="shop.php">+ Quick View</a></li>
                                            <!-- <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li> -->
                                        </ul>
                                    </div>
                                    <div class="pi-text">
                                        <!-- <div class="catagory-name">Gift</div> -->
                                        <a href="shop.php">
                                            <h5>Flower</h5>
                                        </a>
                                        <div class="product-price">
                                            $14.00
                                            <span>$35.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-6">
                                <div class="product-item">
                                    <div class="pi-pic">
                                        <img src="img/products/f2.jpg" alt="">
                                        <div class="icon">
                                            <i class="icon_heart_alt"></i>
                                        </div>
                                        <ul>
                                            <!-- <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li> -->
                                            <li class="quick-view"><a href="shop.php">+ Quick View</a></li>
                                            <!-- <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li> -->
                                        </ul>
                                    </div>
                                    <div class="pi-text">
                                        <!-- <div class="catagory-name">Gift</div> -->
                                        <a href="shop.php">
                                            <h5>Flower</h5>
                                        </a>
                                        <div class="product-price">
                                            $13.00
                                            <span>$35.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-6">
                                <div class="product-item">
                                    <div class="pi-pic">
                                        <img src="img/products/f3.jpg" alt="">
                                        <div class="icon">
                                            <i class="icon_heart_alt"></i>
                                        </div>
                                        <ul>
                                            <!-- <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li> -->
                                            <li class="quick-view"><a href="shop.php">+ Quick View</a></li>
                                            <!-- <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li> -->
                                        </ul>
                                    </div>
                                    <div class="pi-text">
                                        <!-- <div class="catagory-name">Gift</div> -->
                                        <a href="shop.php">
                                            <h5>Flower</h5>
                                        </a>
                                        <div class="product-price">
                                            $34.00
                                            <span>$35.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-sm-6 col-6">
                                <div class="product-item">
                                    <div class="pi-pic">
                                        <img src="img/products/f4.jpg" alt="">
                                        <div class="icon">
                                            <i class="icon_heart_alt"></i>
                                        </div>
                                        <ul>
                                            <!-- <li class="w-icon active"><a href="#"><i class="icon_bag_alt"></i></a></li> -->
                                            <li class="quick-view"><a href="shop.php">+ Quick View</a></li>
                                            <!-- <li class="w-icon"><a href="#"><i class="fa fa-random"></i></a></li> -->
                                        </ul>
                                    </div>
                                    <div class="pi-text">
                                        <!-- <div class="catagory-name">Gift</div> -->
                                        <a href="shop.php">
                                            <h5>Flower</h5>
                                        </a>
                                        <div class="product-price">
                                            $64.00
                                            <span>$35.00</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                    <div class="loading-more">
                    <span class="spinner-border spinner-border-sm"></span> <a href="shop.php"> Loading More </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

<!-- <section class="latest-blog">
        <div class="container">
           
            <div class="benefit-items">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="single-benefit">
                            <div class="sb-icon">
                                <img src="img/icon-1.png" alt="">
                            </div>
                            <div class="sb-text">
                                <h6>Free Shipping</h6>
                                <p>For all order over 99$</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-benefit">
                            <div class="sb-icon">
                                <img src="img/icon-2.png" alt="">
                            </div>
                            <div class="sb-text">
                                <h6>Delivery On Time</h6>
                                <p>If good have prolems</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-benefit">
                            <div class="sb-icon">
                                <img src="img/icon-1.png" alt="">
                            </div>
                            <div class="sb-text">
                                <h6>Secure Payment</h6>
                                <p>100% secure payment</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section> -->
    <section class="latest-blog pt-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <!-- <img width="36" height="50" src="img/before.png"  alt="" class="mb-2">
                            
                             -->
                        <h2>From The Blog</h2>
                       
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="single-latest-blog">
                        <img src="img/blog1.jpg" alt="">
                        <div class="latest-text">
                            <div class="tag-list">
                                <div class="tag-item">
                                    <i class="fa fa-calendar-o"></i> Fab 17,2021
                                </div>
                                
                            </div>
                            <a href="blog.php">
                                <h5>The Best Street Style From London Fashion Week</h5>
                            </a>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-latest-blog">
                        <img src="img/blog2.jpg" alt="">
                        <div class="latest-text">
                            <div class="tag-list">
                                <div class="tag-item">
                                    <i class="fa fa-calendar-o"></i> Fab 17,2021
                                </div>
                               
                            </div>
                            <a href="blog.php">
                                <h5>Vogue's Ultimate Guide To Autumn / Winter 2019 Shoes</h5>
                            </a>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="single-latest-blog">
                        <img src="img/blog3.jpg" alt="">
                        <div class="latest-text">
                            <div class="tag-list">
                                <div class="tag-item">
                                    <i class="fa fa-calendar-o"></i> Fab 17,2021
                                </div>
                                
                            </div>
                            <a href="blog.php">
                                <h5>How To Brighten Your Wardrobe With A Dash .</h5>
                            </a>
                            <p>Sed quia non numquam modi tempora indunt ut labore et dolore magnam aliquam quaerat </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="benefit-items">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="single-benefit">
                            <div class="sb-icon">
                                <img src="img/icon-1.png" alt="">
                            </div>
                            <div class="sb-text">
                                <h6>Free Shipping</h6>
                                <p>For all order over 99$</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-benefit">
                            <div class="sb-icon">
                                <img src="img/icon-2.png" alt="">
                            </div>
                            <div class="sb-text">
                                <h6>Delivery On Time</h6>
                                <p>If good have prolems</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="single-benefit">
                            <div class="sb-icon">
                                <img src="img/icon-1.png" alt="">
                            </div>
                            <div class="sb-text">
                                <h6>Secure Payment</h6>
                                <p>100% secure payment</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<div class="partner-logo">
        <div class="container">
            <div class="logo-carousel owl-carousel">
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-1.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-2.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-3.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-4.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-5.png" alt="">
                    </div>
                </div>
                <div class="logo-item">
                    <div class="tablecell-inner">
                        <img src="img/logo-carousel/logo-5.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    