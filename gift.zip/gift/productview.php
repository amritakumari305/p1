<?php 
include("header.php");
include("menu.php");
?>
 <div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <a href="shop.php"> Shop</a>
                        <span>Bottel</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

<div class="container py-3">
    <div class="row">
        <div class="col-md-6">
            <div class="product-view">
                <img src="img/products/pro1.jpg" alt="">
            </div>
        </div>
        <div class="col-md-6">
            <div class="product-view-detail">
                <div class="product-content">
                    <h1 class="item-heading product-name"title="Gift Bottel">Gift Bottel</h1>
                </div>
                <div class="product-price"> 
                    <span style="text-align: left;box-sizing: border-box;font-size: 30px;color: #e53333;font-weight: 300;"> $13.00 </span> 
                    <del><span style="display: inline-block;vertical-align: top;font-size: 14px;margin: 10px 0 0 10px;text-align: left;color: #666;font-weight: 400;"> $35.00 </span></del>
                </div>
                <div class="tax-msg">Inclusive of all taxes</div>
                <div class="enterPincodeMsg"><i class="material-icons"></i> ! Enter correct Pincode for hassle free timely delivery.</div>
                <div class="pin-input mt-3">
                    <input class="border-warning py-2 px-4" type="text" id="destlookup" name="destlookup" placeholder="Enter Pincode" autofocus="autofocus" autocomplete="off">
                </div>
                <div class="btn-submit mt-3">
                    
                    <button type="submit" id="addToCart" class="btn btn-success mr-3 " title="ADD TO CART"><i class="material-icons"></i>ADD TO CART</button>
                    <button type="submit" id="buynow" class="btn btn-warning ml-3" title="BUY NOW"><i class="material-icons"></i>BUY NOW</button>
                </div>
                <button type="submit" class="btn btn-info mt-3">Continue Shopping</button>
            </div>
        </div>
    </div>
</div>

<?php
include("footer.php");
?>