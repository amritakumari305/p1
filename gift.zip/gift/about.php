<?php 
include("header.php");
include("menu.php");
?>
<div class="breacrumb-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <a href="index.php"><i class="fa fa-home"></i> Home</a>
                        <span>About Us</span>
                    </div>
                </div>
            </div>
        </div>
</div>

<section id="about">
    <div class="container pb-3">
        <div class="row">
            <div class="col-md-6">
                <div class="filters-control">
                    <h3>Shop Gifts By Choice</h3>
                    <p>Check out our most recent items</p>

                </div>
                <p>Here’s another outstanding florist website that will inspire fellow florists all over the world. The Bouqs is a great florist website with clutter-free, minimalist and elegant design. With this website, it’s a lot easier to shop flowers online and deliver them fresh and lovely. Basically, visitors can easily signup, login, or login via Facebook.</p>
            </div>
            <div class="col-md-6">
                <div class="about-text">
                    <p> Since it is important that contents should look comprehensive, this website ensures that all the sections of the website are clear enough to comprehend its messages. Since promos are one of the most enticing strategies that work best for both old and new customers, the website welcomes visitors with an engaging, limited promo. In displaying different categories, flower thumbnails even look more interesting with the cool hover effect. It also comes with testimonials, blog, sticky menu and more!</p>
                </div>
            </div>
            <div class="col-md-12">
                <div class="bnner-about">
                    <img src="img/aboutbanner.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid" style="background-color: #fbdcd8;text-align:center;padding-top:10px; ">
        <div class="row">
            <div class="col-md-12">
                <a class="ribbon-content-block__content">
                    <p><span style="color: #000000;">Save money on your honey! Flirty flowers, all under $50.&nbsp;&nbsp;<u><b>Shop Now</b></u></span><br></p>
                </a>
            </div>
        </div>
    </div>
    <div class="container-fluid about-why">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="catalog-pods-content-block__item">
                        <div class="pod-image-container">
                            <div class="pod-image">
                                <center><img alt=""  src="img/NextDay.svg"></center>
                            </div>
                        </div>
                        <div class="pod-middle-separator" style="border-color: #0a7256"></div>
                        <div class="pod-copy">
                            <h5 class="wysiwyg-font-size-large">Need it ASAP</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="catalog-pods-content-block__item">
                        <div class="pod-image-container">
                            <div class="pod-image">
                                <center><img alt=""  src="img/Bloom.svg"></center>
                            </div>
                        </div>
                        <div class="pod-middle-separator" style="border-color: #0a7256"></div>
                        <div class="pod-copy">
                            <h5 class="wysiwyg-font-size-large">Best Sellers</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="catalog-pods-content-block__item">
                        <div class="pod-image-container">
                            <div class="pod-image">
                                <center><img alt=""  src="img/Birthday.svg"></center>
                            </div>
                        </div>
                        <div class="pod-middle-separator" style="border-color: #0a7256"></div>
                        <div class="pod-copy">
                            <h5 class="wysiwyg-font-size-large">Birthday</h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="catalog-pods-content-block__item">
                        <div class="pod-image-container">
                            <div class="pod-image">
                                <center><img alt=""  src="img/Save.svg"></center>
                            </div>
                        </div>
                        <div class="pod-middle-separator" style="border-color: #0a7256"></div>
                        <div class="pod-copy">
                            <h5 class="wysiwyg-font-size-large">Under $50</h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container pt-5">
        <div class="row">
            <div class="col-md-6">
                <div class="mission-about">
                    <h3 class="pb-3">Our Mission</h3>    <hr/>  
                    <p>We strive to become a Rs 500-Crore business by 2020 and staying ahead of the competition exponentially by offering customers a wow experience through continuous innovation of premium products and services by using world class technology and processes.</p>                  
                </div>
            </div>
            <div class="col-md-6">
                <div class="mission-about">
                    <h3 class="pb-3">Our Vision</h3>      <hr/>  
                    <p>We are passionately strives to be the largest premium gifting leader with flowers, gifts, cakes and weddings being the core verticals driven by people first approach and innovation in all spheres of business</p>                  
                </div>
            </div>
        </div>
    </div>
</section>

<?php
include("footer.php");
?>